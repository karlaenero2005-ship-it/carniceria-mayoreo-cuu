const { app, BrowserWindow, ipcMain, Menu, dialog, shell } = require("electron");
const path = require("path");
const fs = require("fs");
// La copia para la otra PC trae la carpeta datos-nube. Ahí vive su base,
// separada de la caja. En esta computadora de venta ese archivo no existe.
const marcaPortatil = path.join(path.dirname(process.execPath), "datos-nube", "activa.txt");
const esCopiaEnVivo = fs.existsSync(marcaPortatil);
if (esCopiaEnVivo) app.setPath("userData", path.join(path.dirname(process.execPath), "datos-nube"));
const https = require("https");
const net = require("net");
const os = require("os");
const dbLocal = require("./db");
const printer = require("./printer");
const backup = require("./backup");
const supabaseSync = require("./supabase");
const eleventa = require("./eleventa");
const bascula = require("./bascula");
const basculaDirecta = require("./bascula_directa");
const facturador = require("./facturador");
const actualizador = require("./actualizador");
// nodemailer es opcional: si no está instalado, el envío por correo avisa.
let nodemailer = null;
try { nodemailer = require("nodemailer"); } catch (_) { nodemailer = null; }

// Selecciona el puente de la báscula según la configuración: TCP directo
// (recomendado, sin Scale Link) o lectura de la base Access de Scale Link.
function puenteBascula(cfg) {
  return (cfg && cfg.modoDirecto) ? basculaDirecta : bascula;
}

// Lista de básculas en modo directo (soporta varias IP). Devuelve una config
// por báscula, lista para pasarse a basculaDirecta.leerVentas/probar.
function basculasDirectas(cfg) {
  cfg = cfg || {};
  const ips = [];
  const push = (v) => { const s = String(v == null ? "" : v).trim(); if (s && !ips.includes(s)) ips.push(s); };
  if (Array.isArray(cfg.ips)) cfg.ips.forEach(push);
  else if (typeof cfg.ips === "string") cfg.ips.split(/[,;\n]/).forEach(push);
  push(cfg.ip);
  push(cfg.ip2);
  return ips.map((ip, i) => ({
    modoDirecto: true,
    ip,
    puertoDirecto: cfg.puertoDirecto || 50036,
    timeoutMs: cfg.timeoutMs,
    idBascula: i + 1
  }));
}

// Prefijos /24 de las redes IPv4 de esta PC (p. ej. "192.168.100.").
function prefijosLocales() {
  const pref = new Set();
  const ifs = os.networkInterfaces();
  for (const k in ifs) {
    for (const a of (ifs[k] || [])) {
      if (a.family === "IPv4" && !a.internal) {
        const p = String(a.address).split(".");
        if (p.length === 4) pref.add(p[0] + "." + p[1] + "." + p[2] + ".");
      }
    }
  }
  return [...pref];
}
// Escanea un prefijo /24 buscando hosts con `port` abierto (timeout corto).
function escanearPuerto(prefijo, port, timeoutMs) {
  return new Promise((resolve) => {
    let pend = 254; const found = [];
    for (let i = 1; i <= 254; i++) {
      const ip = prefijo + i;
      const s = new net.Socket(); let done = false;
      const fin = (ok) => { if (done) return; done = true; if (ok) found.push(ip); try { s.destroy(); } catch (e) {} if (--pend === 0) resolve(found); };
      s.setTimeout(timeoutMs);
      s.on("connect", () => fin(true));
      s.on("timeout", () => fin(false));
      s.on("error", () => fin(false));
      s.connect(port, ip);
    }
    setTimeout(() => resolve(found), timeoutMs + 3000);
  });
}
// Descubre básculas TORREY en la red buscando el puerto 50036 abierto.
async function descubrirBasculas() {
  const port = 50036;
  const all = [];
  for (const p of prefijosLocales()) {
    const f = await escanearPuerto(p, port, 500);
    for (const ip of f) if (!all.includes(ip)) all.push(ip);
  }
  return all;
}
ipcMain.handle("bascula:descubrir", async () => {
  try { const ips = await descubrirBasculas(); return { ok: true, ips }; }
  catch (e) { return { error: e.message }; }
});

// Motor de aplicación de escritorio. Funciona 100% offline (sin internet).
// Toda la marca visible corresponde a "Mayoreo de Carnes de Res".

const isDev = process.argv.includes("--dev");

let mainWindow = null;
let actualizacionTimer = null;

// Carpetas de trabajo del actualizador (dentro de userData, siempre escribible).
function dirsActualizacion() {
  const base = path.join(app.getPath("userData"), "actualizaciones");
  return { stagingDir: path.join(base, "staging"), backupsDir: path.join(base, "respaldos") };
}

// Revisa (barato) si el canal de ESTA PC tiene una versión más nueva.
async function revisarActualizacion() {
  try {
    const cfg = (dbLocal.getConfig().actualizaciones) || {};
    return await actualizador.revisar(cfg, app.getVersion());
  } catch (e) {
    return { ok: false, error: e.message, versionActual: app.getVersion() };
  }
}

// Revisa y, si la ventana existe, empuja el resultado al renderer para que
// habilite el botón "Actualizar sistema" y avise.
async function chequeoActualizacion() {
  const info = await revisarActualizacion();
  try {
    if (info && mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send("actualizacion:estado", info);
    }
  } catch (_) {}
  return info;
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1366,
    height: 850,
    minWidth: 1024,
    minHeight: 700,
    backgroundColor: "#eef1f6",
    show: false,
    autoHideMenuBar: true,
    title: esCopiaEnVivo ? "Mayoreo — otra PC en vivo" : "Mayoreo de Carnes de Res — Punto de Venta",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  Menu.setApplicationMenu(null);
  mainWindow.loadFile(path.join(__dirname, "src", "index.html"));

  // Siempre abre MAXIMIZADO (pantalla grande), sin tamaños intermedios.
  mainWindow.once("ready-to-show", () => {
    mainWindow.maximize();
    mainWindow.show();
    if (isDev) mainWindow.webContents.openDevTools({ mode: "detach" });
  });

  // Al recuperar el foco de la ventana (volver de otra app, restaurar, mostrar),
  // devuelve SIEMPRE el foco de teclado al contenido web. Evita el error de que
  // "se bloquea el teclado" al salir y volver a entrar a la ventana del sistema.
  const reenfocarWeb = () => {
    try {
      if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.focus();
    } catch (e) {}
  };
  mainWindow.on("focus", reenfocarWeb);
  mainWindow.on("restore", reenfocarWeb);
  mainWindow.on("show", reenfocarWeb);

  // Confirmación al cerrar la ventana (evita cierres accidentales).
  let cierreConfirmado = false;
  mainWindow.on("close", (e) => {
    if (cierreConfirmado) return;
    e.preventDefault();
    const resp = dialog.showMessageBoxSync(mainWindow, {
      type: "question",
      buttons: ["Cancelar", "Cerrar"],
      defaultId: 0,
      cancelId: 0,
      noLink: true,
      title: "Cerrar el punto de venta",
      message: "¿Seguro que quieres cerrar el punto de venta?",
      detail: "Se cerrará la aplicación. Asegúrate de haber terminado la venta en curso."
    });
    if (resp === 1) { cierreConfirmado = true; mainWindow.close(); }
  });

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

// Información del sistema disponible para la interfaz (sin depender de internet).
ipcMain.handle("app:info", () => ({
  version: app.getVersion(),
  name: "Mayoreo de Carnes de Res",
  platform: process.platform,
  userDataPath: app.getPath("userData"),
  copiaEnVivo: esCopiaEnVivo
}));

// ---- Puente a la base de datos local ----
ipcMain.handle("db:bootstrap", () => dbLocal.bootstrap());
ipcMain.handle("db:registrarVenta", async (_e, venta) => {
  await reservar("ventas", "folio", "folioVenta", dbLocal.folioVentaActual(), {
    fecha: new Date().toISOString(), total_cents: 0, subtotal_cents: 0, descuento_cents: 0,
    pago: "reserva", cancelada: true, cancelada_motivo: "reserva", origen_eleventa: false
  });
  return dbLocal.registrarVenta(venta);
});
ipcMain.handle("db:registrarMovimiento", (_e, mov) => dbLocal.registrarMovimiento(mov));
ipcMain.handle("db:registrarDevolucion", async (_e, dev) => {
  await reservar("devoluciones", "folio", "folioDevolucion", dbLocal.folioDevolucionActual(), {
    fecha: new Date().toISOString(), total_cents: 0, motivo: "reserva"
  });
  return dbLocal.registrarDevolucion(dev);
});
ipcMain.handle("db:detalleDia", (_e, fecha) => dbLocal.detalleDia(fecha));
ipcMain.handle("db:resumenIngresosMeses", () => dbLocal.resumenIngresosMeses());
ipcMain.handle("db:reimpresionDia", (_e, fecha) => dbLocal.reimpresionDia(fecha));
ipcMain.handle("db:movimientosEfectivoDia", (_e, fecha) => dbLocal.movimientosEfectivoDia(fecha));
ipcMain.handle("db:renombrarUsuario", (_e, id, nombre, pinActual) => dbLocal.renombrarUsuario(id, nombre, pinActual));
ipcMain.handle("db:crearUsuario", (_e, nombre, pin, rol) => dbLocal.crearUsuario(nombre, pin, rol));
ipcMain.handle("db:eliminarUsuario", (_e, id) => dbLocal.eliminarUsuario(id));
ipcMain.handle("db:cambiarPin", (_e, id, pin, pinActual) => dbLocal.cambiarPin(id, pin, pinActual));
ipcMain.handle("db:guardarProducto", async (_e, prod) => {
  if (!prod || prod.id == null) {
    const lista = (dbLocal.getSnapshot().db.productos) || [];
    await reservar("productos", "id", "producto", dbLocal.maxIdLista(lista) + 1, {
      nombre: "reserva", precio_cents: 0, activo: false
    });
  }
  return dbLocal.guardarProducto(prod);
});
ipcMain.handle("db:eliminarProducto", (_e, id) => dbLocal.eliminarProducto(id));
ipcMain.handle("db:guardarCategoria", (_e, cat) => dbLocal.guardarCategoria(cat));
ipcMain.handle("db:eliminarCategoria", (_e, id) => dbLocal.eliminarCategoria(id));
ipcMain.handle("db:getClientes", () => dbLocal.getClientes());
ipcMain.handle("db:guardarCliente", async (_e, cli) => {
  if (!cli || cli.id == null) {
    const lista = (dbLocal.getSnapshot().db.clientes) || [];
    await reservar("clientes", "id", "cliente", dbLocal.maxIdLista(lista) + 1, {
      nombre: "reserva", saldo_cents: 0, credito_activo: false, limite_cents: 0
    });
  }
  return dbLocal.guardarCliente(cli);
});
ipcMain.handle("db:eliminarCliente", (_e, id) => dbLocal.eliminarCliente(id));
ipcMain.handle("db:limpiarHistorialPantallaCliente", (_e, id) => dbLocal.limpiarHistorialPantallaCliente(id));
ipcMain.handle("db:getHistorialPantallaDesde", (_e, id) => dbLocal.getHistorialPantallaDesde(id));
ipcMain.handle("db:getOcultarPagadasCliente", (_e, id) => dbLocal.getOcultarPagadasCliente(id));
ipcMain.handle("db:setOcultarPagadasCliente", (_e, id, v) => dbLocal.setOcultarPagadasCliente(id, v));
ipcMain.handle("db:getOcultarPagadasProveedor", (_e, n) => dbLocal.getOcultarPagadasProveedor(n));
ipcMain.handle("db:setOcultarPagadasProveedor", (_e, n, v) => dbLocal.setOcultarPagadasProveedor(n, v));
ipcMain.handle("db:movimientoCredito", async (_e, id, tipo, monto, nota, usuario, formaPago) => {
  // Un abono entra a caja: reserva su id de caja en la nube para no chocar con la otra PC.
  if (tipo === "abono") {
    const fp = String(formaPago || "efectivo").toLowerCase();
    if (["efectivo", "tarjeta", "transferencia"].includes(fp)) await reservarMovimiento(fp);
  }
  return dbLocal.movimientoCredito(id, tipo, monto, nota, usuario, formaPago);
});
ipcMain.handle("db:estadoCuentaCliente", (_e, id) => dbLocal.estadoCuentaCliente(id));
ipcMain.handle("db:abonarCredito", async (_e, id, monto, opciones) => {
  // Reserva el id de caja en la nube (salvo efectivo casa / ajuste, que no entran a caja).
  const fp = String((opciones && opciones.formaPago) || "efectivo").toLowerCase();
  if (["efectivo", "tarjeta", "transferencia"].includes(fp)) await reservarMovimiento(fp);
  return dbLocal.abonarCredito(id, monto, opciones);
});
ipcMain.handle("db:cancelarMovimientoCredito", (_e, clienteId, movId) => dbLocal.cancelarMovimientoCredito(clienteId, movId));
ipcMain.handle("db:resumenCreditos", () => dbLocal.resumenCreditos());
ipcMain.handle("db:resumenAuditoria", (_e, periodo, ancla) => dbLocal.resumenAuditoria(periodo, ancla));
ipcMain.handle("db:corteDia", (_e, fecha) => dbLocal.corteDia(fecha));
// Caja / corte
ipcMain.handle("db:estadoCaja", () => dbLocal.estadoCaja());
ipcMain.handle("db:abrirCaja", async (_e, fondoCents, usuario, tipoCambio) => {
  const lista = (dbLocal.getSnapshot().db.cajas) || [];
  await reservar("cajas", "id", "caja", dbLocal.maxIdLista(lista) + 1, {
    usuario: "reserva", abierta: false, fondo_cents: 0, apertura_fecha: new Date().toISOString()
  });
  return dbLocal.abrirCaja(fondoCents, usuario, tipoCambio);
});
ipcMain.handle("db:setFondoInicialCaja", (_e, fondoCents, tipoCambio, usuario) => dbLocal.setFondoInicialCaja(fondoCents, tipoCambio, usuario));
ipcMain.handle("db:setTipoCambioCaja", (_e, tipoCambio) => dbLocal.setTipoCambioCaja(tipoCambio));
ipcMain.handle("db:movimientoEfectivo", async (_e, tipo, montoCents, motivo, usuario, proveedor, categoria, formaPago, cantidad) => {
  await reservarMovimiento(formaPago);
  return dbLocal.movimientoEfectivo(tipo, montoCents, motivo, usuario, proveedor, categoria, formaPago, cantidad);
});
ipcMain.handle("db:getMovimientosPendientes", () => dbLocal.getMovimientosPendientes());
ipcMain.handle("db:liberarMovimientoPendiente", async (_e, id, formaPago, usuario) => {
  // Pago de compra: reserva su id de caja en la nube (efectivo casa no entra a caja).
  const fp = String(formaPago || "").toLowerCase();
  if (["efectivo", "tarjeta", "transferencia"].includes(fp)) await reservarMovimiento(fp);
  return dbLocal.liberarMovimientoPendiente(id, formaPago, usuario);
});
  ipcMain.handle("db:abonarCreditoProveedor", async (_e, proveedor, montoCents, formaPago, usuario, opts) => {
    await reservarMovimiento(formaPago);
    return dbLocal.abonarCreditoProveedor(proveedor, montoCents, formaPago, usuario, opts);
  });
ipcMain.handle("db:estadoCuentaProveedor", (_e, nombre) => dbLocal.estadoCuentaProveedor(nombre));
  ipcMain.handle("db:cancelarMovimientoPendiente", (_e, id, usuario) => dbLocal.cancelarMovimientoPendiente(id, usuario));
  ipcMain.handle("db:cancelarCuentaProveedor", (_e, nombre, usuario, motivo) => dbLocal.cancelarCuentaProveedor(nombre, usuario, motivo));
  ipcMain.handle("db:getProveedores", () => dbLocal.getProveedores());
  ipcMain.handle("db:guardarProveedor", (_e, nombre) => dbLocal.guardarProveedor(nombre));
  ipcMain.handle("db:eliminarProveedor", (_e, nombre, usuario) => dbLocal.eliminarProveedor(nombre, usuario));
ipcMain.handle("db:cancelarMovimientoEfectivo", (_e, movId, usuario) => dbLocal.cancelarMovimientoEfectivo(movId, usuario));
ipcMain.handle("db:cerrarCaja", (_e, conteoCents, usuario, extras) => dbLocal.cerrarCaja(conteoCents, usuario, extras));
// Inventario
ipcMain.handle("db:getInventario", () => dbLocal.getInventario());
ipcMain.handle("db:getVentaPorFolio", (_e, folio) => dbLocal.getVentaPorFolio(folio));
ipcMain.handle("db:cancelarVenta", (_e, folio, usuario, motivo) => dbLocal.cancelarVenta(folio, usuario, motivo));
ipcMain.handle("db:ventasDelDia", (_e, fecha) => dbLocal.ventasDelDia(fecha));
ipcMain.handle("db:resumenBasculaCorte", () => dbLocal.resumenBasculaCorte());
ipcMain.handle("db:detalleCorteBasculaDia", (_e, fecha) => dbLocal.detalleCorteBasculaDia(fecha));
ipcMain.handle("db:getImagenesProducto", () => dbLocal.getImagenesProducto());
ipcMain.handle("db:setImagenProducto", (_e, id, dataURL) => dbLocal.setImagenProducto(id, dataURL));
ipcMain.handle("db:getMovimientos", (_e, filtro) => dbLocal.getMovimientos(filtro));
ipcMain.handle("db:getMovimientosInv", (_e, filtro) => dbLocal.getMovimientosInv(filtro));

ipcMain.handle("db:exportar", async () => {
  try {
    const snap = dbLocal.getSnapshot();
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
    const res = await dialog.showSaveDialog(mainWindow, {
      title: "Guardar respaldo",
      defaultPath: `respaldo-mayoreo-${stamp}.json`,
      filters: [{ name: "Respaldo JSON", extensions: ["json"] }]
    });
    if (res.canceled || !res.filePath) return { cancelado: true };
    fs.writeFileSync(res.filePath, JSON.stringify(snap, null, 2), "utf8");
    return { ok: true, ruta: res.filePath };
  } catch (e) { return { error: e.message }; }
});

ipcMain.handle("db:importar", async () => {
  try {
    const res = await dialog.showOpenDialog(mainWindow, {
      title: "Seleccionar respaldo a importar",
      properties: ["openFile"],
      filters: [{ name: "Respaldo JSON", extensions: ["json"] }]
    });
    if (res.canceled || !res.filePaths || !res.filePaths[0]) return { cancelado: true };
    const txt = fs.readFileSync(res.filePaths[0], "utf8");
    const obj = JSON.parse(txt);
    return dbLocal.reemplazarDatos(obj);
  } catch (e) { return { error: "No se pudo leer el archivo: " + e.message }; }
});
// ---- Configuración inicial e importación desde ELEVENTA ----
ipcMain.handle("db:marcarConfigurado", () => dbLocal.marcarConfigurado());
ipcMain.handle("eleventa:elegirArchivo", async () => {
  try {
    const res = await dialog.showOpenDialog(mainWindow, {
      title: "Seleccionar base de datos de ELEVENTA (PDVDATA.FDB)",
      properties: ["openFile"],
      filters: [{ name: "Base de datos Firebird", extensions: ["fdb", "FDB"] }, { name: "Todos", extensions: ["*"] }]
    });
    if (res.canceled || !res.filePaths || !res.filePaths[0]) return { cancelado: true };
    return { ok: true, archivo: res.filePaths[0] };
  } catch (e) { return { error: e.message }; }
});
ipcMain.handle("eleventa:probar", (_e, cfg) => eleventa.probar(cfg));
ipcMain.handle("eleventa:analizar", (_e, cfg) => eleventa.analizar(cfg));
ipcMain.handle("eleventa:importar", async (_e, cfg) => {
  const r = await eleventa.importar(cfg);
  if (r && r.error) return r;
  const g = dbLocal.importarCatalogoEleventa(r.datos);
  if (g && g.error) return g;
  return { ok: true, resumen: g.resumen };
});
// Importación OPERATIVA (clientes, ventas recientes, devoluciones, cortes) SIN inventario.
ipcMain.handle("eleventa:importarOperativo", async (_e, cfg, opciones) => {
  // Respaldo del db.json actual antes de reemplazar datos.
  try {
    const dataDir = path.join(app.getPath("userData"), "data");
    const dbFile = path.join(dataDir, "db.json");
    if (fs.existsSync(dbFile)) {
      const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
      fs.copyFileSync(dbFile, path.join(dataDir, "db.antes-eleventa-" + stamp + ".json"));
    }
  } catch (e) {}
  const r = await eleventa.importarOperativo(cfg, opciones);
  if (r && r.error) return r;
  const g = dbLocal.importarOperativoEleventa(r.datos);
  if (g && g.error) return g;
  return { ok: true, resumen: g.resumen };
});
ipcMain.handle("db:cortesEleventa", () => dbLocal.getCortesEleventa());

ipcMain.handle("db:getEsperas", () => dbLocal.getEsperas());
ipcMain.handle("db:guardarEspera", (_e, orden) => dbLocal.guardarEspera(orden));
ipcMain.handle("db:eliminarEspera", (_e, id) => dbLocal.eliminarEspera(id));
ipcMain.handle("db:getApartados", () => dbLocal.getApartados());
ipcMain.handle("db:crearApartado", (_e, data) => dbLocal.crearApartado(data));
ipcMain.handle("db:abonarApartado", (_e, id, montoCents, metodo, usuario) => dbLocal.abonarApartado(id, montoCents, metodo, usuario));
ipcMain.handle("db:liquidarApartado", (_e, id, metodo, usuario) => dbLocal.liquidarApartado(id, metodo, usuario));
ipcMain.handle("db:entregarApartado", (_e, id, entregado) => dbLocal.entregarApartado(id, entregado));
ipcMain.handle("db:eliminarApartado", (_e, id) => dbLocal.eliminarApartado(id));
ipcMain.handle("db:marcarEntregado", (_e, folio, entregado) => dbLocal.marcarEntregado(folio, entregado));
ipcMain.handle("db:actualizarNotaApartado", (_e, folio, nota) => dbLocal.actualizarNotaApartado(folio, nota));
ipcMain.handle("db:guardarPaquete", (_e, pq) => dbLocal.guardarPaquete(pq));
ipcMain.handle("db:eliminarPaquete", (_e, id) => dbLocal.eliminarPaquete(id));
ipcMain.handle("db:movimientoInventario", (_e, productoId, tipo, cant, nota, usuario) => dbLocal.movimientoInventario(productoId, tipo, cant, nota, usuario));
// Configuración (negocio / impresora)
ipcMain.handle("db:getConfig", () => dbLocal.getConfig());
ipcMain.handle("db:setConfig", (_e, parcial) => {
  const r = dbLocal.setConfig(parcial);
  if (parcial && parcial.respaldo) backup.reconfigurar();
  if (parcial && parcial.supabase) reprogramarSupabase();
  if (parcial && parcial.bascula) reprogramarBascula();
  return r;
});

// ---- Integración báscula (Scale Link) ----
ipcMain.handle("bascula:probar", async (_e) => {
  const c = dbLocal.getConfig().bascula;
  if (!c || !c.modoDirecto) return bascula.probar(c);
  // Modo directo: prueba cada báscula configurada y reporta una por una.
  const escalas = basculasDirectas(c);
  if (!escalas.length) return { error: "No hay ninguna IP de báscula configurada." };
  const detalle = [];
  for (const esc of escalas) {
    const r = await basculaDirecta.probar(esc);
    detalle.push({ id: esc.idBascula, ip: esc.ip, puerto: esc.puertoDirecto, ok: !!(r && r.ok), error: r && r.error });
  }
  const ok = detalle.some((d) => d.ok);
  return { ok, directo: true, basculasProbar: detalle };
});
// Lectura manual (para diagnóstico): devuelve las ventas recientes SIN marcarlas.
ipcMain.handle("bascula:leerAhora", (_e) => { const c = dbLocal.getConfig().bascula; return puenteBascula(c).leerVentas(c); });
// Enviar precios modificados a una báscula concreta (modo directo).
// payload: { ip?, items:[{id, precio}] }. Si no se indica ip, usa la primera.
ipcMain.handle("bascula:enviarPrecios", (_e, payload) => {
  const c = dbLocal.getConfig().bascula;
  if (!c || !c.modoDirecto) {
    return { error: "El envío de precios requiere el modo directo (TCP) de la báscula." };
  }
  payload = payload || {};
  const items = Array.isArray(payload) ? payload : (payload.items || []);
  const ip = Array.isArray(payload) ? null : payload.ip;
  const escalas = basculasDirectas(c);
  if (!escalas.length) return { error: "No hay ninguna IP de báscula configurada." };
  const esc = ip ? escalas.find((e) => e.ip === ip) : escalas[0];
  if (!esc) return { error: `No se encontró la báscula ${ip}.` };
  return basculaDirecta.programarPrecios(esc, items);
});
// Leer el catálogo completo (productos y precios) de TODAS las básculas directas.
// Devuelve { ok, basculas:[{ id, ip, nombre, ok, error, productos }] }.
ipcMain.handle("bascula:leerProductos", async (_e) => {
  const c = dbLocal.getConfig().bascula;
  if (!c || !c.modoDirecto) {
    return { error: "La lectura de productos requiere el modo directo (TCP) de la báscula." };
  }
  const escalas = basculasDirectas(c);
  if (!escalas.length) return { error: "No hay ninguna IP de báscula configurada." };
  const basculas = [];
  for (const esc of escalas) {
    let r; try { r = await basculaDirecta.leerProductos(esc); } catch (e) { r = { error: e.message }; }
    basculas.push({
      id: esc.idBascula,
      ip: esc.ip,
      nombre: `Báscula ${esc.idBascula}`,
      ok: !!(r && r.ok),
      error: r && r.error,
      productos: (r && r.productos) || []
    });
  }
  return { ok: basculas.some((b) => b.ok), basculas };
});
// Lee las ventas acumuladas en TODAS las básculas (para el corte comparativo).
// Devuelve { ok, ventas:[...], basculas:[{ip, ok, error, num}] }.
ipcMain.handle("bascula:leerVentasTodas", async (_e) => {
  const c = dbLocal.getConfig().bascula;
  if (!c || !c.modoDirecto) {
    return { error: "El corte de báscula requiere el modo directo (TCP)." };
  }
  const escalas = basculasDirectas(c);
  if (!escalas.length) return { error: "No hay ninguna IP de báscula configurada." };
  // Lectura en paralelo de todas las básculas (más rápido con varias).
  const res = await Promise.all(escalas.map(async (esc) => {
    let r; try { r = await basculaDirecta.leerVentas(esc); } catch (e) { r = { error: e.message }; }
    return { esc, r };
  }));
  const ventas = [];
  const basculas = [];
  for (const { esc, r } of res) {
    const vs = (r && r.ventas) || [];
    for (const v of vs) { v.ip = esc.ip; v.idBascula = esc.idBascula; }
    ventas.push(...vs);
    basculas.push({ ip: esc.ip, idBascula: esc.idBascula, ok: !!(r && r.ok), error: r && r.error, num: vs.length });
  }
  return { ok: basculas.some((b) => b.ok), ventas, basculas };
});
ipcMain.handle("bascula:reiniciarVistas", (_e) => dbLocal.reiniciarBasculaVistas());
// Marca una venta como "vista/procesada" (la llama el POS cuando ya creó su ticket).
ipcMain.handle("bascula:marcarVistas", (_e, keys) => dbLocal.marcarBasculaVistas(keys || []));

// ---- Impresión de tickets / cajón ----
function cfgImpresora() {
  const c = dbLocal.getConfig();
  return Object.assign({}, c.impresora, { negocio: c.negocio, ticket: c.ticket });
}
ipcMain.handle("printer:imprimir", (_e, ticket) => printer.imprimirTicket(ticket, cfgImpresora()));
ipcMain.handle("printer:abrirCajon", () => printer.abrirCajon(cfgImpresora()));
ipcMain.handle("printer:probar", () => printer.probar(cfgImpresora()));
ipcMain.handle("printer:vistaPrevia", (_e, ticket) => printer.vistaPrevia(ticket, cfgImpresora()));
ipcMain.handle("printer:imprimirCorte", (_e, corte) => printer.imprimirCorte(corte, cfgImpresora()));
ipcMain.handle("printer:vistaPreviaCorte", (_e, corte) => printer.vistaPreviaCorte(corte, cfgImpresora()));
ipcMain.handle("printer:imprimirTexto", (_e, titulo, lineas) => printer.imprimirTexto(titulo, lineas, cfgImpresora()));
ipcMain.handle("printer:vistaPreviaTexto", (_e, titulo, lineas) => printer.vistaPreviaTexto(titulo, lineas, cfgImpresora()));
ipcMain.handle("printer:imprimirHtml", (_e, html) => printer.imprimirHtmlDocumento(html, cfgImpresora()));
ipcMain.handle("printer:esDocumentoHoja", () => printer.debeUsarTextoWindows(cfgImpresora()));
ipcMain.handle("printer:listarImpresoras", () => printer.listarImpresorasWindows());

// ---- Tipo de cambio del dólar (USD -> MXN, automático de internet) ----
let fxCache = null; // { rate, dia, fuente }
function fxHoy() {
  const d = new Date();
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
}
function httpGetJson(url, timeoutMs = 8000) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { timeout: timeoutMs }, (res) => {
      let data = "";
      res.on("data", (c) => { data += c; });
      res.on("end", () => { try { resolve(JSON.parse(data)); } catch (e) { reject(new Error("Respuesta inválida")); } });
    });
    req.on("error", reject);
    req.on("timeout", () => req.destroy(new Error("Tiempo de espera agotado")));
  });
}
// Obtiene el tipo de cambio del día (cacheado). force=true ignora el cache del día.
async function obtenerTipoCambioUSD(force) {
  const dia = fxHoy();
  if (!force && fxCache && fxCache.dia === dia) return { ok: true, rate: fxCache.rate, dia, fuente: fxCache.fuente, cache: true };
  const fuentes = [
    { url: "https://open.er-api.com/v6/latest/USD", pick: (j) => j && j.rates && j.rates.MXN, nombre: "open.er-api.com" },
    { url: "https://api.frankfurter.app/latest?from=USD&to=MXN", pick: (j) => j && j.rates && j.rates.MXN, nombre: "frankfurter.app" }
  ];
  for (const f of fuentes) {
    try {
      const j = await httpGetJson(f.url);
      const r = f.pick(j);
      if (r && isFinite(r)) {
        fxCache = { rate: Math.round(Number(r) * 100) / 100, dia, fuente: f.nombre };
        try { dbLocal.setFxCache(fxCache); } catch (e) {}
        return { ok: true, rate: fxCache.rate, dia, fuente: f.nombre };
      }
    } catch (e) { /* intenta la siguiente fuente */ }
  }
  // Sin internet: usa el último conocido (memoria o disco).
  const cache = fxCache || (dbLocal.getFxCache && dbLocal.getFxCache());
  if (cache && cache.rate) return { ok: true, rate: cache.rate, dia: cache.dia || "", fuente: "cache", offline: true };
  return { error: "No se pudo obtener el tipo de cambio (sin internet)." };
}
ipcMain.handle("fx:usdMxn", (_e, force) => obtenerTipoCambioUSD(force));

// ---- Respaldo en la nube (Cloudflare) ----
ipcMain.handle("backup:estado", () => backup.estadoActual());
ipcMain.handle("backup:probar", () => backup.probar());
ipcMain.handle("backup:sincronizar", () => backup.sincronizarAhora());

ipcMain.handle("supabase:estado", () => supabaseSync.estadoActual());
ipcMain.handle("supabase:probar", () => supabaseSync.probar());
ipcMain.handle("supabase:sincronizar", (_e, full) => supabaseSync.sincronizarTodo({ full: !!full }));
ipcMain.handle("supabase:listarTicketsCorte", (_e, filtro) => supabaseSync.listarTicketsCorte(filtro || {}));
ipcMain.handle("supabase:bajarAhora", async () => {
  try { const r = await supabaseSync.descargarYMezclar(); return r || { ok: false }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle("supabase:abrirSchema", async () => {
  const schema = path.join(__dirname, "supabase", "schema.sql");
  const dest = path.join(app.getPath("desktop"), "Mayoreo-Supabase-schema.sql");
  try {
    fs.copyFileSync(schema, dest);
    shell.showItemInFolder(dest);
    return { ok: true, ruta: dest };
  } catch (e) {
    try { shell.openPath(schema); return { ok: true, ruta: schema }; }
    catch (e2) { return { error: e.message }; }
  }
});

// ---- Actualizaciones del sistema (canal GitHub, sin Supabase) ----
ipcMain.handle("actualizador:estado", () => revisarActualizacion());
ipcMain.handle("actualizador:revisar", () => revisarActualizacion());
ipcMain.handle("actualizador:instalar", async () => {
  const cfg = (dbLocal.getConfig().actualizaciones) || {};
  let info;
  try { info = await actualizador.revisar(cfg, app.getVersion()); }
  catch (e) { return { ok: false, error: e.message }; }
  if (!info || !info.ok) return { ok: false, error: "No se pudo contactar el canal de actualizaciones." };
  if (!info.hay) return { ok: false, error: "Ya tienes la versión más reciente." };
  const { stagingDir } = dirsActualizacion();
  let r;
  try { r = await actualizador.descargarYPreparar({ cfg, info, stagingDir }); }
  catch (e) { return { ok: false, error: e.message }; }
  if (!r || !r.ok) return r || { ok: false, error: "No se pudo preparar la actualización." };
  // Deja que el renderer reciba la respuesta y reinicia para aplicar al arrancar.
  setTimeout(() => { try { app.relaunch(); app.exit(0); } catch (_) {} }, 500);
  return { ok: true, version: r.version, reiniciando: true };
});

// ---- Facturación electrónica (CFDI 4.0) ----
function rutaFacturas() {
  const dir = path.join(app.getPath("userData"), "facturas");
  try { fs.mkdirSync(dir, { recursive: true }); } catch (e) {}
  return dir;
}
function nombreArchivoFactura(f) {
  const base = `${f.serie}${f.folioFactura}-${f.uuid || "sin-uuid"}`;
  return base.replace(/[^A-Za-z0-9_\-]/g, "_");
}
const fmtDinero = (cents) => "$" + (Math.round(cents || 0) / 100).toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// Timbra una factura ya creada (o reintenta). Guarda XML/PDF y actualiza estado.
async function timbrarFactura(id) {
  const f = dbLocal.getFacturaPorId(id);
  if (!f) return { error: "Factura no encontrada." };
  if (f.estado === "timbrado") return { ok: true, factura: f, yaTimbrada: true };
  const cfg = (dbLocal.getConfig().factura) || {};
  let r;
  try { r = await facturador.timbrar(f, cfg); }
  catch (e) { r = { error: e.message }; }
  if (!r || r.error) {
    dbLocal.actualizarFactura(id, { estado: "error", ultimoError: (r && r.error) || "Error desconocido", intentos: (f.intentos || 0) + 1 });
    return { error: (r && r.error) || "No se pudo timbrar." };
  }
  // Guardar XML y PDF en la carpeta de datos.
  const dir = rutaFacturas();
  const fConUuid = Object.assign({}, f, { uuid: r.uuid });
  const nombre = nombreArchivoFactura(fConUuid);
  const xmlPath = path.join(dir, nombre + ".xml");
  const pdfPath = path.join(dir, nombre + ".pdf");
  try { fs.writeFileSync(xmlPath, r.xml || "", "utf8"); } catch (e) {}
  try { if (r.pdfBuffer) fs.writeFileSync(pdfPath, r.pdfBuffer); } catch (e) {}
  let liga = r.ligaPublica || "";
  if (!liga && cfg.ligaBase) liga = String(cfg.ligaBase).replace(/\/+$/, "") + "/" + encodeURIComponent(nombre + ".pdf");
  const patch = {
    estado: "timbrado", uuid: r.uuid, fechaTimbrado: r.fechaTimbrado || new Date().toISOString(),
    xmlPath, pdfPath, ligaPublica: liga, ultimoError: "", simulado: !!r.simulado
  };
  dbLocal.actualizarFactura(id, patch);
  const actual = dbLocal.getFacturaPorId(id);
  // Auto-envío por correo si está configurado y el receptor tiene correo.
  if (cfg.correo && cfg.correo.activo && actual.receptor.email) {
    try { await enviarCorreoFactura(id); } catch (e) {}
  }
  return { ok: true, factura: dbLocal.getFacturaPorId(id) };
}

async function enviarCorreoFactura(id) {
  const f = dbLocal.getFacturaPorId(id);
  if (!f) return { error: "Factura no encontrada." };
  if (f.estado !== "timbrado") return { error: "Timbra la factura antes de enviarla." };
  if (!f.receptor.email) return { error: "El receptor no tiene correo capturado." };
  const c = (dbLocal.getConfig().factura || {}).correo || {};
  if (!c.host || !c.usuario) return { error: "Configura el correo (SMTP) en Configuración → Facturación." };
  if (!nodemailer) return { error: "Falta la dependencia 'nodemailer'. Reinstala dependencias (npm install)." };
  const transporter = nodemailer.createTransport({
    host: c.host, port: Number(c.puerto) || 587, secure: !!c.seguro,
    auth: { user: c.usuario, pass: c.password || "" }
  });
  const attachments = [];
  try { if (f.xmlPath && fs.existsSync(f.xmlPath)) attachments.push({ filename: nombreArchivoFactura(f) + ".xml", path: f.xmlPath }); } catch (e) {}
  try { if (f.pdfPath && fs.existsSync(f.pdfPath)) attachments.push({ filename: nombreArchivoFactura(f) + ".pdf", path: f.pdfPath }); } catch (e) {}
  try {
    await transporter.sendMail({
      from: c.remitente || c.usuario,
      to: f.receptor.email,
      subject: `Factura ${f.serie}${f.folioFactura} — ${f.emisor.razonSocial}`,
      text: `Estimado cliente,\n\nAdjuntamos su factura ${f.serie}${f.folioFactura} por ${fmtDinero(f.totalCents)}.\nUUID: ${f.uuid}\n\n${f.emisor.razonSocial}`,
      attachments
    });
  } catch (e) {
    return { error: "No se pudo enviar el correo: " + e.message };
  }
  dbLocal.actualizarFactura(id, { enviadoCorreo: true });
  return { ok: true };
}

async function enviarWhatsAppFactura(id) {
  const f = dbLocal.getFacturaPorId(id);
  if (!f) return { error: "Factura no encontrada." };
  if (f.estado !== "timbrado") return { error: "Timbra la factura antes de enviarla." };
  let tel = String(f.receptor.telefono || "").replace(/\D/g, "");
  if (!tel) return { error: "El receptor no tiene teléfono capturado." };
  if (tel.length === 10) tel = "52" + tel;               // México sin lada país
  const cfg = (dbLocal.getConfig().factura || {}).whatsapp || {};
  const liga = f.ligaPublica || "(la factura se envió a tu correo)";
  const plantilla = cfg.plantilla || "Hola {cliente}, aquí está tu factura {folio} por {total}. Descárgala aquí: {liga}";
  const msg = plantilla
    .replace(/\{cliente\}/g, f.receptor.nombre || "cliente")
    .replace(/\{folio\}/g, `${f.serie}${f.folioFactura}`)
    .replace(/\{total\}/g, fmtDinero(f.totalCents))
    .replace(/\{liga\}/g, liga);
  const url = `https://wa.me/${tel}?text=${encodeURIComponent(msg)}`;
  try { await shell.openExternal(url); } catch (e) { return { error: "No se pudo abrir WhatsApp: " + e.message }; }
  dbLocal.actualizarFactura(id, { enviadoWhats: true });
  return { ok: true, url };
}

// Vista previa de los conceptos que se facturarían de una venta.
ipcMain.handle("factura:previewVenta", (_e, folio) => dbLocal.construirConceptosVenta(folio));
// Crea la factura y trata de timbrarla de inmediato.
ipcMain.handle("factura:crear", async (_e, data) => {
  const r = dbLocal.crearFactura(data || {});
  if (r.error) return r;
  const t = await timbrarFactura(r.factura.id);
  // Aunque el timbrado falle (p. ej. sin internet), la factura queda encolada.
  return { ok: true, factura: dbLocal.getFacturaPorId(r.factura.id), timbrado: t };
});
ipcMain.handle("factura:listar", () => dbLocal.getFacturas());
ipcMain.handle("factura:timbrar", (_e, id) => timbrarFactura(id));
ipcMain.handle("factura:enviarCorreo", (_e, id) => enviarCorreoFactura(id));
ipcMain.handle("factura:enviarWhatsApp", (_e, id) => enviarWhatsAppFactura(id));
ipcMain.handle("factura:verPdf", async (_e, id) => {
  const f = dbLocal.getFacturaPorId(id);
  if (!f || !f.pdfPath) return { error: "La factura no tiene PDF." };
  const err = await shell.openPath(f.pdfPath);
  return err ? { error: err } : { ok: true };
});

// Procesador: reintenta timbrar las facturas pendientes cuando hay internet.
let facturaTimer = null;
let facturaOcupado = false;
async function procesarFacturasPendientes() {
  if (facturaOcupado) return;
  const pend = dbLocal.facturasPendientes();
  if (!pend.length) return;
  facturaOcupado = true;
  try {
    for (const f of pend) {
      const r = await timbrarFactura(f.id);
      if (r && r.error) break; // si una falla (sin red), no insistir con las demás ahora
    }
  } catch (e) { /* silencioso, reintenta al próximo ciclo */ }
  finally { facturaOcupado = false; }
}

// ---- Poller de la báscula: lee cada báscula y empuja las ventas nuevas ----
// Diseño clave: en modo directo CADA báscula se sondea de forma INDEPENDIENTE
// y sin esperar a la otra. Así, aunque una tenga mala señal WiFi (lenta o
// intermitente), NO frena a la que sí responde: cada una entrega sus ventas en
// tiempo real apenas contesta.
let basculaTimer = null;
const basculaEnVuelo = new Set();       // idBascula que se está leyendo ahora (no re-encolar)
const basculaFallosId = {};             // idBascula -> fallos de conexión consecutivos
const basculaPrimerHecho = new Set();   // idBascula que ya hizo su marcado inicial
let basculaArranqueFresco = false;      // true si al iniciar la app no había ventas vistas
let basculaPausado = false;             // tras N fallos de TODAS: espera "Reintentar"
let basculaBanner = false;              // si el letrero de desconexión está en pantalla
let basculaOcupadoSL = false;           // candado del modo Scale Link (lectura única)
let basculaScanEnCurso = false;         // evita escaneos de red simultáneos
let basculaCaidaDesde = null;           // instante en que empezó la caída CONTINUA (null si conectada)
const BASCULA_MAX_FALLOS = 10;          // fallos antes de mostrar el letrero + botón
// ANTI-PARPADEO: el letrero de "desconectada" solo aparece si la báscula lleva
// caída de forma CONTINUA al menos este tiempo. Un corte corto de WiFi se
// reintenta en silencio y se recupera solo, SIN letrero (negocio en vivo).
const BASCULA_GRACIA_MS = 30000;        // 30 s de caída continua antes de avisar

function enviarConexion(estado, datos) {
  if (mainWindow) mainWindow.webContents.send("bascula:conexion", Object.assign({ estado }, datos || {}));
}

// Una báscula respondió: limpia su contador, corta la racha de caída y quita el
// letrero si estaba puesto. La recuperación es INMEDIATA (a la primera respuesta).
function basculaScaleOk(id) {
  basculaFallosId[id] = 0;
  basculaCaidaDesde = null;
  if (basculaBanner) { basculaBanner = false; basculaPausado = false; enviarConexion("reconectada"); }
}

// Una báscula falló. El letrero (y la pausa) SOLO aparecen cuando TODAS las
// básculas configuradas están fallando; si al menos una responde, se sigue
// trabajando en tiempo real con esa.
async function basculaScaleFallo(id, escalas, primerError) {
  basculaFallosId[id] = (basculaFallosId[id] || 0) + 1;
  const todasFallan = escalas.length > 0 && escalas.every((e) => (basculaFallosId[e.idBascula] || 0) >= 1);
  if (!todasFallan) return;   // otra báscula sigue viva: nada de letrero ni pausa
  if (basculaCaidaDesde == null) basculaCaidaDesde = Date.now();   // arranca la racha de caída
  const maxFallos = Math.max(0, ...escalas.map((e) => basculaFallosId[e.idBascula] || 0));
  // Intento PROFUNDO: escanea la red por si cambiaron de IP (DHCP/WiFi). Solo
  // re-mapea si encuentra AL MENOS tantas básculas como las configuradas, para
  // NUNCA borrar una báscula que solo está intermitente por mala señal.
  if ((maxFallos === 1 || maxFallos % 3 === 0) && !basculaScanEnCurso) {
    basculaScanEnCurso = true;
    try {
      const ips = await descubrirBasculas();
      const actual = dbLocal.getConfig().bascula || {};
      const confNum = [actual.ip, actual.ip2].filter((x) => String(x || "").trim()).length || 1;
      if (ips.length >= confNum) {
        const nuevoIp = ips[0];
        const nuevoIp2 = confNum >= 2 ? (ips[1] || actual.ip2 || "") : (actual.ip2 || "");
        if (nuevoIp && (nuevoIp !== actual.ip || nuevoIp2 !== (actual.ip2 || ""))) {
          dbLocal.setConfig({ bascula: Object.assign({}, actual, { ip: nuevoIp, ip2: nuevoIp2 }) });
          enviarConexion("reintentando", { intentos: maxFallos, max: BASCULA_MAX_FALLOS, hallazgo: ips.join(", ") });
          return; // el próximo ciclo probará con las IP encontradas
        }
      }
    } catch (e) { /* sigue reintentando */ }
    finally { basculaScanEnCurso = false; }
  }
  // El letrero SOLO aparece tras una caída CONTINUA de al menos BASCULA_GRACIA_MS.
  // Antes de eso se reintenta en silencio (sin parpadeo). Se sigue poléando siempre;
  // en cuanto la báscula responda, basculaScaleOk quita el letrero al instante.
  if (Date.now() - basculaCaidaDesde >= BASCULA_GRACIA_MS) {
    if (!basculaBanner) {
      basculaBanner = true;
      enviarConexion("desconectada", { intentos: maxFallos, error: primerError || "" });
    }
  }
}

// Botón "Reintentar" del letrero: arranca otra ronda de intentos de inmediato.
ipcMain.handle("bascula:reintentar", async () => {
  basculaPausado = false;
  basculaBanner = false;
  basculaCaidaDesde = null;
  for (const k in basculaFallosId) delete basculaFallosId[k];
  enviarConexion("reintentando", { intentos: 0, max: BASCULA_MAX_FALLOS });
  setTimeout(pollBascula, 100);
  return { ok: true };
});

// Lee UNA báscula (modo directo). Corre por su cuenta: si esta báscula está
// lenta o caída, NO retrasa a la otra. Si sigue ocupada del tick anterior
// (respuesta lenta), se salta su turno para no encolar lecturas.
async function pollScaleDirecta(esc, escalas) {
  const id = esc.idBascula;
  if (basculaEnVuelo.has(id)) return;
  basculaEnVuelo.add(id);
  try {
    // 1) Lectura LIGERA de encabezados (rápida) para detectar ventas nuevas.
    let r;
    try { r = await basculaDirecta.leerEncabezados(esc); }
    catch (e) { r = { error: e.message }; }
    if (!r || r.error) { await basculaScaleFallo(id, escalas, (r && r.error) || "sin respuesta"); return; }
    basculaScaleOk(id);
    const enc = r.ventas || [];
    // Primera lectura de esta báscula en la sesión: si la app arrancó sin
    // ventas vistas, tomamos lo ya acumulado como "visto" (no reimportar viejo).
    if (!basculaPrimerHecho.has(id)) {
      basculaPrimerHecho.add(id);
      if (basculaArranqueFresco) { if (enc.length) dbLocal.marcarBasculaVistas(enc.map((v) => v.key)); return; }
    }
    const vistas = dbLocal.getBasculaVistas();
    const nuevasKeys = new Set(enc.filter((v) => !vistas[v.key]).map((v) => v.key));
    if (!nuevasKeys.size) return;
    // 2) Solo cuando hay algo nuevo bajamos el detalle completo (Ld) de esta báscula.
    let full;
    try { full = await basculaDirecta.leerVentas(esc); }
    catch (e) { full = { error: e.message }; }
    if (!full || full.error) return;
    const nuevas = [];
    for (const v of (full.ventas || [])) {
      if (nuevasKeys.has(v.key)) { v.idBascula = id; v.ip = esc.ip; nuevas.push(v); }
    }
    if (nuevas.length) {
      dbLocal.marcarBasculaVistas(nuevas.map((v) => v.key));
      if (mainWindow) mainWindow.webContents.send("bascula:lote", nuevas);
    }
  } finally {
    basculaEnVuelo.delete(id);
  }
}

async function pollBascula() {
  if (basculaPausado) return;   // tras N fallos de TODAS: espera "Reintentar"
  const cfg = dbLocal.getConfig().bascula || {};
  if (!cfg.activa) return;
  if (cfg.modoDirecto) {
    // Lanza cada báscula por separado y SIN await entre ellas: la lenta no
    // frena a la rápida. Cada lectura maneja sus propios errores.
    const escalas = basculasDirectas(cfg);
    for (const esc of escalas) { pollScaleDirecta(esc, escalas).catch(() => {}); }
    return;
  }
  // Modo Scale Link (no directo): una sola lectura secuencial.
  if (basculaOcupadoSL) return;
  basculaOcupadoSL = true;
  try {
    const r = await bascula.leerVentas(cfg);
    if (r.error) {
      basculaFallosId.SL = (basculaFallosId.SL || 0) + 1;
      if (basculaFallosId.SL >= BASCULA_MAX_FALLOS) { basculaPausado = true; basculaBanner = true; enviarConexion("desconectada", { intentos: basculaFallosId.SL, error: r.error }); }
      else enviarConexion("reintentando", { intentos: basculaFallosId.SL, max: BASCULA_MAX_FALLOS });
      return;
    }
    basculaFallosId.SL = 0;
    if (basculaBanner) { basculaBanner = false; basculaPausado = false; enviarConexion("reconectada"); }
    const ventas = r.ventas || [];
    const vistas = dbLocal.getBasculaVistas();
    if (!basculaPrimerHecho.has("SL")) {
      basculaPrimerHecho.add("SL");
      if (basculaArranqueFresco && ventas.length) { dbLocal.marcarBasculaVistas(ventas.map((v) => v.key)); return; }
    }
    const nuevas = ventas.filter((v) => !vistas[v.key]);
    if (nuevas.length) {
      dbLocal.marcarBasculaVistas(nuevas.map((v) => v.key));
      if (mainWindow) mainWindow.webContents.send("bascula:lote", nuevas);
    }
  } catch (e) {
    // Silencioso: se reintenta en el siguiente ciclo.
  } finally {
    basculaOcupadoSL = false;
  }
}

function reprogramarBascula() {
  if (basculaTimer) { clearInterval(basculaTimer); basculaTimer = null; }
  const cfg = dbLocal.getConfig().bascula || {};
  if (!cfg.activa) return;
  const seg = Math.max(1, Math.min(60, parseInt(cfg.intervaloSeg, 10) || 3));
  // Reinicia el estado del sondeo.
  basculaEnVuelo.clear();
  basculaPrimerHecho.clear();
  for (const k in basculaFallosId) delete basculaFallosId[k];
  basculaPausado = false;
  basculaOcupadoSL = false;
  basculaScanEnCurso = false;
  basculaCaidaDesde = null;
  basculaArranqueFresco = Object.keys(dbLocal.getBasculaVistas() || {}).length === 0;
  if (basculaBanner) { basculaBanner = false; enviarConexion("reconectada"); }
  basculaTimer = setInterval(pollBascula, seg * 1000);
  setTimeout(pollBascula, 400); // primer sondeo casi inmediato
}

let supabaseKeepAliveTimer = null;
let supabaseBajarTimer = null;
let supabaseDebounce = null;      // anti-rebote de la sync en tiempo real
let supabasePendiente = false;    // llegaron cambios mientras sincronizaba

// Dispara una sincronización EN TIEMPO REAL tras cada cambio local. No usa
// intervalos: agrupa la ráfaga de una venta (varios guardados) con un pequeño
// retardo y sube en cuanto termina. Si ya hay una sync en curso, reintenta al
// terminar sin perder el último cambio.
function dispararSupabaseTiempoReal() {
  const s = (dbLocal.getConfig().supabase) || {};
  if (!s.activo || !s.url || !s.key) return;
  supabasePendiente = true;
  if (supabaseDebounce) clearTimeout(supabaseDebounce);
  supabaseDebounce = setTimeout(function run() {
    const est = supabaseSync.estadoActual ? supabaseSync.estadoActual() : {};
    if (est && est.enviando) { supabaseDebounce = setTimeout(run, 2500); return; }
    supabasePendiente = false;
    supabaseSync.sincronizarTodo()
      .then((r) => { if (r && r.ocupado) { supabasePendiente = true; dispararSupabaseTiempoReal(); } })
      .catch(() => {})
      .finally(() => { if (supabasePendiente) dispararSupabaseTiempoReal(); });
  }, 1200);
}

async function reservar(tabla, columna, campo, minimo, extra, opts) {
  try {
    const n = await supabaseSync.reclamarNumero(tabla, columna, minimo, extra, opts);
    dbLocal.apartar(campo, n);
  } catch (_) {}
}

async function reservarMovimiento(formaPago) {
  const base = dbLocal.getSnapshot().db;
  if (String(formaPago || "").toLowerCase() === "credito") {
    await reservar("movimientos_pendientes", "id", "pendiente", dbLocal.maxIdLista(base.movimientosPendientes) + 1, {
      fecha: new Date().toISOString(), monto_cents: 0, motivo: "reserva", estado: "pendiente"
    });
    return;
  }
  const cajaId = base.config && base.config.cajaActualId;
  if (!cajaId) return;
  const caja = (base.cajas || []).find((c) => c.id === cajaId);
  const max = dbLocal.maxIdLista(caja && caja.movimientos);
  await reservar("caja_movimientos", "id", "movCaja", max + 1, {
    caja_id: cajaId, fecha: new Date().toISOString(), monto_cents: 0, motivo: "reserva", tipo: "ajuste"
  }, { filtro: "caja_id=eq." + cajaId, conflicto: "terminal,caja_id,id" });
}

// Sondeo de bajada en segundo plano. Usa descargarSiHayNovedad: una consulta
// diminuta a sync_log y SOLO baja la base completa si la otra PC subió algo.
// Así el sync sigue siendo en vivo pero sin agotar la cuota de egress.
async function bajarNube(forzar) {
  if (supabasePendiente) return;
  try {
    const r = forzar
      ? await supabaseSync.descargarYMezclar()
      : await supabaseSync.descargarSiHayNovedad();
    if (r && r.cambio && mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send("supabase:enVivo", { cuando: new Date().toISOString() });
    }
  } catch (_) {}
}

function reprogramarSupabase() {
  if (supabaseKeepAliveTimer) { clearInterval(supabaseKeepAliveTimer); supabaseKeepAliveTimer = null; }
  if (supabaseBajarTimer) { clearInterval(supabaseBajarTimer); supabaseBajarTimer = null; }
  const cfg = (dbLocal.getConfig().supabase) || {};
  if (!cfg.url || !cfg.key) return;

  // Keep-alive cada 12 h: evita que Supabase Free pause el proyecto por inactividad.
  supabaseKeepAliveTimer = setInterval(() => {
    supabaseSync.keepAlive().catch(() => {});
  }, 12 * 60 * 60 * 1000);
  if (supabaseKeepAliveTimer.unref) supabaseKeepAliveTimer.unref();
  // Primer ping a los ~2 min de arrancar (no bloquea el cobro).
  setTimeout(() => { supabaseSync.keepAlive().catch(() => {}); }, 120000);

  if (!cfg.activo) return;
  // Al arrancar sube lo pendiente y, enseguida, baja TODO una vez (forzado).
  setTimeout(() => {
    supabaseSync.sincronizarTodo()
      .catch(() => {})
      .finally(() => { bajarNube(true); });
  }, 4000);
  // Baja los cambios de la OTRA PC cada N minutos (configurable). Cada ciclo
  // primero sondea sync_log (unos bytes) y SOLO descarga si hubo algo nuevo.
  // Subir es barato (casi no gasta cuota); DESCARGAR es lo que consume egress,
  // por eso se espacia: así juntas muchos cambios en una sola bajada y no se
  // agota la cuota gratis de Supabase aunque haya muchísimos movimientos.
  const minBajar = Math.max(1, parseInt(cfg.bajarCadaMin, 10) || 120);
  supabaseBajarTimer = setInterval(() => { bajarNube(); }, minBajar * 60 * 1000);
}

app.whenReady().then(() => {
  // Si quedó una actualización preparada en la sesión anterior, se aplica ANTES
  // de cargar nada: respalda el código actual, copia el nuevo y reinicia.
  try {
    const { stagingDir, backupsDir } = dirsActualizacion();
    if (fs.existsSync(path.join(stagingDir, "pendiente.json"))) {
      const r = actualizador.aplicarPendiente({ appDir: __dirname, stagingDir, backupsDir });
      if (r && r.aplicado) { app.relaunch(); app.exit(0); return; }
    }
  } catch (_) {}

  dbLocal.init(app.getPath("userData"));
  // Respaldo Cloudflare (snapshot): se dispara tras cada escritura durable.
  backup.init({
    getRespaldo: () => dbLocal.getRespaldoConfig(),
    getSnapshot: () => dbLocal.getSnapshot()
  });
  // Supabase: sync desglosado (tablas). Solo se dispara a mano o por intervalo.
  supabaseSync.init({
    getConfig: () => dbLocal.getConfig(),
    getDb: () => dbLocal.getSnapshot().db,
    getTicketCaja: (cj) => dbLocal.armarTicketImpresionCaja(cj),
    guardarSilencioso: (fn) => dbLocal.guardarSilencioso(fn),
    mezclarRemoto: (parte, opts) => dbLocal.mezclarRemoto(parte, opts),
    cacheFile: path.join(app.getPath("userData"), "data", "supabase-sync-cache.json")
  });
  dbLocal.setOnPersist(() => { backup.marcarCambio(); dispararSupabaseTiempoReal(); });
  createWindow();
  reprogramarBascula();
  reprogramarSupabase();

  // Actualizaciones: revisa a los ~15 s de abrir y luego cada intervalo.
  setTimeout(() => { chequeoActualizacion().catch(() => {}); }, 15000);
  try {
    const cfgAc = (dbLocal.getConfig().actualizaciones) || {};
    const minAc = Math.max(5, parseInt(cfgAc.intervaloMin, 10) || 30);
    actualizacionTimer = setInterval(() => { chequeoActualizacion().catch(() => {}); }, minAc * 60 * 1000);
    if (actualizacionTimer.unref) actualizacionTimer.unref();
  } catch (_) {}
  // Reintenta timbrar facturas pendientes cada 45s (cuando hay internet).
  facturaTimer = setInterval(procesarFacturasPendientes, 45000);
  setTimeout(procesarFacturasPendientes, 5000);
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

// Al cerrar: solo un ping rápido (keep-alive). La sync completa va en segundo plano
// por intervalo; no bloqueamos el cierre con 30k+ ventas.
let supabaseSaliendo = false;
app.on("before-quit", (e) => {
  if (supabaseSaliendo) return;
  try {
    const cfg = (dbLocal.getConfig().supabase) || {};
    if (!cfg.url || !cfg.key) return;
    supabaseSaliendo = true;
    e.preventDefault();
    const t = setTimeout(() => { app.exit(0); }, 20000);
    supabaseSync.sincronizarTodo()
      .catch(() => {})
      .finally(() => { clearTimeout(t); app.exit(0); });
  } catch (_) {
    supabaseSaliendo = true;
  }
});
