"use strict";

/* ============================================================
   Base de datos local (persistente en disco, sin internet).
   Se guarda como JSON dentro de la carpeta de datos del usuario.
   Los precios se almacenan en CENTAVOS (enteros) para cálculos exactos.
   ============================================================ */

const fs = require("fs");
const path = require("path");
const mezclaNube = require("./mezcla-nube");

let DATA_DIR = null;
let DB_FILE = null;
let db = null;

const toCents = (pesos) => (pesos == null ? null : Math.round(Number(pesos) * 100));
const r3 = (n) => +Number(n || 0).toFixed(3); // redondeo a 3 decimales (kg)
function nombreClienteVenta(v) {
  const c = v && v.cliente;
  let n = (c && typeof c === "object") ? (c.nombre || "") : (c || "");
  n = String(n || "").trim();
  if (!n && v && v.creditoClienteId != null) {
    const cli = (db.clientes || []).find((x) => String(x.id) === String(v.creditoClienteId));
    if (cli && cli.nombre) n = String(cli.nombre).trim();
  }
  return n || "Sin nombre";
}
function listaCreditos(ventas) {
  const lista = [];
  let total = 0;
  for (const v of ventas || []) {
    if (!ventaCuentaEnCorte(v)) continue;
    const monto = montoMetodo(v, "credito");
    if (!monto) continue;
    total += monto;
    lista.push({ folio: v.folio, cliente: nombreClienteVenta(v), montoCents: monto, hora: v.fecha || "" });
  }
  return { lista, total };
}

function esVentaACredito(v) {
  return !!(v && (
    String(v.pago || "").toLowerCase() === "credito" ||
    v.creditoClienteId != null ||
    montoMetodo(v, "credito") > 0
  ));
}

function tieneCargoCreditoVigente(folio) {
  const f = Number(folio);
  if (!f) return false;
  for (const c of db.clientes || []) {
    for (const m of (c.movimientos || [])) {
      if (m && m.tipo === "cargo" && Number(m.ventaFolio) === f) return true;
    }
  }
  return false;
}

// Si se canceló el cargo en Créditos, la venta ya no cuenta (ni en corte ni en historial).
function ventaCuentaEnCorte(v) {
  if (!v || v.cancelada) return false;
  if (esVentaACredito(v) && !tieneCargoCreditoVigente(v.folio)) return false;
  return true;
}

function quitarCargoCreditoDeVenta(v) {
  if (!v) return;
  const folio = Number(v.folio);
  if (!folio) return;
  for (const c of db.clientes || []) {
    const movs = c.movimientos || [];
    const n = movs.length;
    c.movimientos = movs.filter((m) => !(m && m.tipo === "cargo" && Number(m.ventaFolio) === folio));
    if (c.movimientos.length !== n) recomputarCredito(c);
  }
}

// Día local (YYYY-MM-DD) a partir de un ISO, según la zona horaria de la PC.
const localDay = (iso) => {
  const d = new Date(iso);
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
};

// Definición oficial de los paquetes de carne asada (según lonas del negocio).
function definicionPaquetes() {
  const salsa = { nombre: "Salsa casera", cant: 1, unidad: "pza" };
  const carbon = { nombre: "Carbón", cant: 1, unidad: "bolsa" };
  const tortillas = { nombre: "Tortillas", cant: 1, unidad: "kg" };
  const salchichas = { nombre: "Salchichas para asar", cant: 1, unidad: "paq" };
  const ceb = (n) => ({ nombre: "Cebollitas de rabo", cant: n, unidad: "manojo" });
  return {
    "pq-1": { nombre: "Paquete #1", precio: 612, comp: [
      { nombre: "Chuleta marinada", cant: 2, unidad: "kg" },
      { nombre: "Costilla marinada", cant: 1, unidad: "kg" },
      salchichas, tortillas, ceb(3), salsa, carbon ] },
    "pq-2": { nombre: "Paquete #2", precio: 657, comp: [
      { nombre: "Chuleta marinada", cant: 3, unidad: "kg" },
      salchichas, tortillas, ceb(3), salsa, carbon ] },
    "pq-3": { nombre: "Paquete #3", precio: 443, comp: [
      { nombre: "Chuleta marinada", cant: 1, unidad: "kg" },
      { nombre: "Costilla marinada", cant: 1, unidad: "kg" },
      salchichas, tortillas, ceb(2), salsa, carbon ] },
    "pq-4": { nombre: "Paquete #4", precio: 661, comp: [
      { nombre: "Chuleta para asar a elegir (del 0, 7, chuck o aguja)", cant: 2, unidad: "kg" },
      { nombre: "Costilla trasera", cant: 1, unidad: "kg" },
      salchichas, tortillas, ceb(3), salsa, carbon ] },
    "pq-5": { nombre: "Paquete #5", precio: 763, comp: [
      { nombre: "Chuleta para asar a elegir (Rib steak o chuleta de lomo)", cant: 2, unidad: "kg" },
      { nombre: "Costilla cargada", cant: 1, unidad: "kg" },
      salchichas, tortillas, ceb(3), salsa, carbon ] },
    "pq-6": { nombre: "Paquete #6", precio: 791, comp: [
      { nombre: "Chuleta para asar a elegir (T-bone o sirloin sin hueso)", cant: 2, unidad: "kg" },
      { nombre: "Costilla cargada", cant: 1, unidad: "kg" },
      salchichas, tortillas, ceb(3), salsa, carbon ] },
    "pq-arrachera": { nombre: "Paquete Arrachera", precio: 796, comp: [
      { nombre: "Arrachera marinada", cant: 3, unidad: "kg" },
      salchichas, tortillas, ceb(3), salsa, carbon ] }
  };
}
const clonComp = (comp) => comp.map((x) => ({ nombre: x.nombre, cant: x.cant, unidad: x.unidad }));

/* ---------- Datos ficticios (demo) ----------
   Precios y unidades tentativos para los productos que no tenían precio
   determinado, y existencias ficticias para poder operar de momento.
   Cuando se importe la información real (respaldo o ELEVENTA) estos datos
   se reemplazan por completo. */
function preciosFicticios() {
  return {
    "Barbacoa Frita": { precio: 320, unidad: "kg" },
    "Barbacoa Dominical": { precio: 340, unidad: "kg" },
    "Salchicha para Asar": { precio: 90, unidad: "paq" },
    "Carbón": { precio: 120, unidad: "bolsa" },
    "Tortillas": { precio: 35, unidad: "kg" },
    "Cebollitas de Cambray": { precio: 20, unidad: "manojo" },
    "Tocino": { precio: 160, unidad: "kg" }
  };
}
function stockFicticio(unidad) {
  const m = { kg: 80, pza: 40, paq: 30, bolsa: 25, manojo: 30, litro: 20 };
  return m[unidad] != null ? m[unidad] : 25;
}
function stockMinFicticio(unidad) { return unidad === "kg" ? 10 : 5; }

// El negocio NO controla inventario de carnes (siempre disponibles). Solo se
// lleva inventario de productos de reventa: quesos, salsas y abarrotes
// (tortillas, salchichas, carbón, chicharrones, etc.).
const CATS_INVENTARIO = ["quesos", "salsas", "abarrotes"];
function controlaInvCat(cat) { return CATS_INVENTARIO.includes(cat); }

/* ---------- Claves SAT (CFDI 4.0) ----------
   Valores por defecto para facturar. La carne de res sin procesar es tasa 0%;
   los abarrotes que no son alimento (carbón, etc.) llevan 16%. Cada producto
   puede ajustar su ClaveProdServ, ClaveUnidad e IVA en su edición. */
function clavesSatCat(cat) {
  const carne = { claveProdServ: "50111500", ivaTasa: 0 };   // Carne de res
  const map = {
    carnes: carne, asar: carne, finos: carne, menudo: carne,
    barbacoa: carne, visceras: carne, especialidades: carne,
    quesos: { claveProdServ: "50131600", ivaTasa: 0 },
    salsas: { claveProdServ: "50171550", ivaTasa: 0 },
    abarrotes: { claveProdServ: "50190000", ivaTasa: 0.16 }
  };
  return map[cat] || carne;
}
function claveUnidadSat(unidad) {
  if (unidad === "kg") return "KGM";
  if (unidad === "litro") return "LTR";
  return "H87"; // pieza
}
// Completa (sin sobreescribir) las claves SAT de un producto.
function defaultsSatProducto(p) {
  const base = clavesSatCat(p.cat);
  return {
    claveProdServ: p.claveProdServ || base.claveProdServ,
    claveUnidad: p.claveUnidad || claveUnidadSat(p.unidad),
    ivaTasa: (p.ivaTasa != null ? p.ivaTasa : base.ivaTasa)
  };
}

// Estructura configurable del ticket impreso (qué campos y textos aparecen).
function defaultTicket() {
  return {
    mostrarLogo: true,
    mostrarNombre: true,
    mostrarSucursal: true,
    mostrarDireccion: true,
    mostrarTelefono: true,
    mostrarRFC: false,
    lineasEncabezado: [],          // líneas de texto extra bajo el nombre
    mostrarFolio: true,
    mostrarFecha: true,
    mostrarCajero: true,
    mostrarCliente: true,
    etiquetaCajero: "Atiende",
    etiquetaCliente: "Cliente",
    mostrarPrecioUnitario: true,
    mostrarFormaPago: true,
    lineasPie: []                  // líneas de texto extra al final (además de pie/pie2)
  };
}

// Respaldo en la nube (Cloudflare Worker + D1). Best-effort, no bloquea la venta.
function defaultRespaldo() {
  return {
    activo: false,
    endpoint: "",                  // https://tu-worker.tu-cuenta.workers.dev
    token: "",                     // token secreto (Authorization: Bearer)
    intervaloSeg: 60,              // respaldo periódico además del respaldo por cambios
    comprimir: true                // gzip del snapshot antes de enviar
  };
}

// Supabase: sincronización DESGLOSADA (ventas, clientes, créditos, cajas…).
// Usa la URL del proyecto + service_role key (Settings → API).
function defaultSupabase() {
  return {
    activo: false,
    url: "",                       // https://xxxx.supabase.co
    key: "",                       // service_role (secreta; no la anon key)
    intervaloMin: 360,             // sync periódica (6 h). Keep-alive adicional cada 12 h.
    bajarCadaMin: 120,             // cada cuánto BAJAR cambios de la otra PC (controla el egress)
    retenerAnos: 2                 // en la nube: ventana móvil de los últimos N años
  };
}

// Actualizaciones del sistema vía canal de GitHub (público). Sin Supabase.
// Cada PC tiene un "canal" (oficina / carniceria) y solo descarga lo de su canal.
function defaultActualizaciones() {
  return {
    activo: true,
    owner: "karlaenero2005-ship-it",   // usuario de GitHub dueño del repositorio
    repo: "carniceria-mayoreo-cuu",    // repositorio público de actualizaciones
    rama: "main",                       // rama donde viven los canales
    canal: "",                          // "oficina" | "carniceria"  (propio de ESTA PC)
    intervaloMin: 30                    // cada cuánto revisa si hay novedad
  };
}

// Fusiona lo guardado con los valores por defecto, tratando "" como "usar el
// predeterminado" para owner/repo/rama (así todas las PCs traen el repo ya
// configurado y solo falta elegir el canal de cada una).
function mezclarActualizaciones(guardado) {
  const d = defaultActualizaciones();
  const g = guardado || {};
  const txt = (v, def) => (v && String(v).trim()) ? String(v).trim() : def;
  return {
    activo: g.activo !== undefined ? !!g.activo : d.activo,
    owner: txt(g.owner, d.owner),
    repo: txt(g.repo, d.repo),
    rama: txt(g.rama, d.rama),
    canal: txt(g.canal, d.canal),
    intervaloMin: parseInt(g.intervaloMin, 10) || d.intervaloMin
  };
}

// Facturación electrónica (CFDI 4.0) vía web service del PAC (Copynorte).
// El timbrado requiere internet; las facturas se encolan y se timbran en cuanto
// hay conexión. En modo "simulacion" se generan UUID/XML/PDF de prueba sin PAC.
function defaultFactura() {
  return {
    activa: true,
    serie: "A",
    folio: 1,
    modo: "simulacion",             // "simulacion" | "produccion"
    ws: {
      tipo: "rest",                 // "rest" | "soap"
      url: "",                      // endpoint del web service de Copynorte
      usuario: "",
      password: ""
    },
    correo: {
      activo: false,
      host: "", puerto: 587, seguro: false,
      usuario: "", password: "", remitente: ""
    },
    whatsapp: {
      activo: true,
      // {cliente} {folio} {total} {liga} se reemplazan al enviar.
      plantilla: "Hola {cliente}, aquí está tu factura {folio} por {total}. Descárgala aquí: {liga}"
    },
    // Base pública para la liga de descarga (si Copynorte no entrega una propia).
    ligaBase: ""
  };
}

/* ---------- Semilla de datos inicial ---------- */
function construirSemilla() {
  const categorias = [
    { id: "carnes", nombre: "Carnes", emoji: "🥩", orden: 1 },
    { id: "asar", nombre: "Para Asar", emoji: "🔥", orden: 2 },
    { id: "finos", nombre: "Cortes Finos", emoji: "⭐", orden: 3 },
    { id: "menudo", nombre: "Para Menudo", emoji: "🍲", orden: 4 },
    { id: "barbacoa", nombre: "Para Barbacoa", emoji: "🌮", orden: 5 },
    { id: "visceras", nombre: "Vísceras", emoji: "🫀", orden: 6 },
    { id: "especialidades", nombre: "Especialidades", emoji: "🍔", orden: 7 },
    { id: "quesos", nombre: "Quesos", emoji: "🧀", orden: 8 },
    { id: "salsas", nombre: "Salsas", emoji: "🌶️", orden: 9 },
    { id: "abarrotes", nombre: "Abarrotes", emoji: "🛒", orden: 10 }
  ];

  const prods = [
    ["carnes", "Molida Especial", 120, "kg"],
    ["carnes", "Pulpa Molida", 210, "kg"],
    ["carnes", "Pulpa Picada", 210, "kg"],
    ["carnes", "Pulpa p/Milanesa", 230, "kg"],
    ["carnes", "Chamberete", 150, "kg"],
    ["carnes", "Chamberete s/hueso", 210, "kg"],
    ["carnes", "Cocido Surtido", 130, "kg"],
    ["carnes", "Suadero", 170, "kg"],
    ["carnes", "Carne p/Deshebrar", 210, "kg"],
    ["carnes", "Brisket", 210, "kg"],
    ["carnes", "Filete de Res", 350, "kg"],

    ["asar", "Chuleta del 7", 180, "kg"],
    ["asar", "Chuleta del 0", 180, "kg"],
    ["asar", "Chuleta Chuck", 180, "kg"],
    ["asar", "Chuleta Aguja", 180, "kg"],
    ["asar", "Chuleta de Lomo", 196, "kg"],
    ["asar", "Costilla Cargada", 200, "kg"],
    ["asar", "Costilla Trasera", 130, "kg"],
    ["asar", "Costilla Flecha", 130, "kg"],
    ["asar", "Costilla Backrib", 120, "kg"],
    ["asar", "Tuétano", 90, "kg"],
    ["asar", "Short Rib", 230, "kg"],

    ["finos", "Rib Eye", 310, "kg"],
    ["finos", "Tomahawk", 230, "kg"],
    ["finos", "Picaña", 210, "kg"],
    ["finos", "T-bone", 210, "kg"],
    ["finos", "Ribsteack", 196, "kg"],
    ["finos", "Sirloin sin Hueso", 210, "kg"],
    ["finos", "Arrachera", 230, "kg"],
    ["finos", "Aguja Norteña", 260, "kg"],
    ["finos", "Prime Rib", 240, "kg"],
    ["finos", "Costilla Norteña", 230, "kg"],

    ["menudo", "Menudo Entero", 127, "kg"],
    ["menudo", "Menudo Picado", 137, "kg"],
    ["menudo", "Pata de Res", 100, "kg"],
    ["menudo", "Zancarrón", 45, "kg"],
    ["menudo", "Maíz p/Menudo", 25, "pza"],

    ["barbacoa", "Cabeza Entera", 65, "kg"],
    ["barbacoa", "Cachete", 150, "kg"],
    ["barbacoa", "Lengua", 350, "kg"],
    ["barbacoa", "Trozo p/Barbacoa", 130, "kg"],
    ["barbacoa", "Pecho p/Barbacoa", 130, "kg"],
    ["barbacoa", "Diezmillo p/Barbacoa", 175, "kg"],

    ["visceras", "Hígado Rebanado", 95, "kg"],
    ["visceras", "Riñón Rebanado", 50, "kg"],
    ["visceras", "Corazón Rebanado", 50, "kg"],
    ["visceras", "Rueda de Tripas", 100, "pza"],
    ["visceras", "Tripa Cruda", 95, "kg"],

    ["especialidades", "Carne para Hamburguesa", 15, "pza"],
    ["especialidades", "Albóndigas (plato 9 pzas)", 15, "pza"],
    ["especialidades", "Diezmillo sin Hueso", 250, "kg"],
    ["especialidades", "Molleja de Res", 220, "kg"],
    ["especialidades", "Bisteck Taquero", 160, "kg"],
    ["especialidades", "Discada Preparada", 118, "kg"],
    ["especialidades", "Tripa Cocida", 100, "pza"],
    ["especialidades", "Barbacoa Frita", null, "s/pedido"],
    ["especialidades", "Barbacoa Dominical", null, "s/pedido"],

    ["quesos", "Requesón", 30, "pza"],
    ["quesos", "Queso Laurel", 160, "pza"],
    ["quesos", "Queso Artesanal", 165, "pza"],
    ["quesos", "Queso Asadero", 170, "pza"],

    ["salsas", "Salsa Verde", 25, "pza"],
    ["salsas", "Salsa Roja", 25, "pza"],
    ["salsas", "Salsa Villa Ahumada", 25, "pza"],

    ["abarrotes", "Salchicha para Asar", null, "s/pedido"],
    ["abarrotes", "Carbón", null, "s/pedido"],
    ["abarrotes", "Tortillas", null, "s/pedido"],
    ["abarrotes", "Cebollitas de Cambray", null, "s/pedido"],
    ["abarrotes", "Tocino", null, "s/pedido"]
  ];

  const fict = preciosFicticios();
  const productos = prods.map((p, i) => {
    let precio = p[2];
    let unidad = p[3];
    // Precio/unidad ficticios para los que no tenían precio determinado.
    if (precio == null && fict[p[1]]) { precio = fict[p[1]].precio; unidad = fict[p[1]].unidad; }
    else if (precio == null) { precio = 100; if (unidad === "s/pedido") unidad = "pza"; }
    if (unidad === "s/pedido") unidad = "pza";
    const controla = controlaInvCat(p[0]);
    const base = {
      id: i + 1,
      cat: p[0],
      nombre: p[1],
      precioCents: toCents(precio),
      unidad,
      controlaInventario: controla,
      existencia: controla ? stockFicticio(unidad) : 0,
      stockMin: controla ? stockMinFicticio(unidad) : 0,
      activo: true,
      manual: false
    };
    return Object.assign(base, defaultsSatProducto(base));
  });

  const c = (n) => toCents(n);
  const def = definicionPaquetes();
  const pqDef = (id) => ({
    id, nombre: def[id].nombre, emoji: "🎁", precioCents: c(def[id].precio),
    porConfirmar: false, componentes: clonComp(def[id].comp)
  });
  const paquetes = [
    pqDef("pq-arrachera"),
    {
      id: "pq-discada1", nombre: "Paquete P/Discada #1", emoji: "🎁", precioCents: c(475),
      porConfirmar: true,
      componentes: [
        { nombre: "Discada preparada", cant: 3, unidad: "kg" },
        { nombre: "Salsa casera", cant: 1, unidad: "pza" },
        { nombre: "Tortillas", cant: 1, unidad: "kg" }
      ]
    },
    {
      id: "pq-discada2", nombre: "Paquete P/Discada #2", emoji: "🎁", precioCents: c(440),
      porConfirmar: true,
      componentes: [
        { nombre: "Discada preparada", cant: 1, unidad: "kg" },
        { nombre: "Salsa casera", cant: 1, unidad: "pza" },
        { nombre: "Tortillas", cant: 1, unidad: "kg" }
      ]
    },
    {
      id: "pq-barbacoa", nombre: "Paquete P/Barbacoa", emoji: "🎁", precioCents: c(506),
      porConfirmar: true,
      componentes: [
        { nombre: "Barbacoa", cant: 1, unidad: "kg" },
        { nombre: "Tortillas", cant: 1, unidad: "kg" },
        { nombre: "Salsa casera", cant: 1, unidad: "pza" },
        { nombre: "Consomé", cant: 1, unidad: "pza" }
      ]
    },
    pqDef("pq-1"), pqDef("pq-2"), pqDef("pq-3"),
    pqDef("pq-4"), pqDef("pq-5"), pqDef("pq-6")
  ];

  const usuarios = [
    { id: 1, nombre: "Administrador", rol: "Administrador", pin: "1234" }
  ];

  return {
    meta: { version: 4, creada: new Date().toISOString() },
    config: {
      terminal: "Caja Principal",
      folioVenta: 1,
      folioDevolucion: 1,
      folioApartado: 1,
      cajaActualId: null,
      configurado: true,
      demoRellenado: true,
      negocio: {
        nombre: "Mayoreo de Carnes de Res",
        sucursal: "",
        direccion: "",
        telefono: "",
        rfc: "",
        razonSocial: "",
        regimenFiscal: "",
        codigoPostal: "",
        pie: "¡Gracias por su compra!",
        pie2: ""
      },
      impresora: {
        modo: "off",            // "red" | "windows" | "off"
        ip: "192.168.1.100",
        puerto: 9100,
        rutaWindows: "",
        envioWindows: "auto",   // auto | texto (DeskJet) | raw (térmica ESC/POS)
        anchoCols: 48,
        autoImprimir: true,
        abrirCajonEfectivo: true,
        imprimirLogo: true,
        pulsoCajon: 0           // 0 => pin estándar; permite ajustar el pulso del cajón
      },
      ticket: defaultTicket(),
      respaldo: defaultRespaldo(),
      bascula: defaultBascula(),
      factura: defaultFactura()
    },
    categorias,
    productos,
    paquetes,
    usuarios,
    clientes: [],
    ventas: [],
    devoluciones: [],
    apartados: [],
    ordenesEspera: [],
    cajas: [],
    movimientosInv: [],
    movimientos: [],
    facturas: [],
    cortesEleventa: [],
    imagenesProducto: {},
    basculaVistas: {},
    proveedores: [],
    movimientosPendientes: [],
    efectivoCasa: [],
    // Solo UI local: oculta abonos viejos en pantalla; no borra ni sube a Supabase.
    historialPantallaClientes: {}
  };
}

// Configuración por defecto de la integración con la báscula (Scale Link).
function defaultBascula() {
  return {
    // Pre-configurado para este negocio: lectura DIRECTA de la báscula activa.
    activa: true,
    ruta: "C:\\Torrey\\Scale Link\\BaseDeDatos.mdb",
    intervaloSeg: 2,
    autoTicket: true,   // crear el ticket automáticamente al llegar la venta
    avisoSonoro: true,
    // Modo DIRECTO: habla el protocolo TCP de la báscula (puerto 50036) sin
    // depender de Scale Link ni de su base Access. Es el modo recomendado.
    // Si está activo se usa `ip`/`puertoDirecto`; si no, se lee la base Access.
    modoDirecto: true,
    ip: "192.168.100.27",   // IP de la báscula #1 en la red
    ip2: "192.168.100.28",  // IP de la báscula #2 (vacío = no usar)
    puertoDirecto: 50036,   // puerto del protocolo TORREY W-LABEL
    timeoutMs: 3000,        // tiempo máx. de espera por respuesta de la báscula
    // Modo escaneo: en lugar de abrir el ticket solo al llegar la venta, el
    // cajero escanea el código de barras de la etiqueta de la báscula (que
    // lleva el FOLIO) y el POS abre el ticket completo ya descargado por Scale
    // Link. Scale Link sigue bajando la venta por WiFi; el escaneo es la
    // "llave" para abrir el ticket correcto en caja.
    modoEscaneo: false,
    // Formato del código de barras que imprime la báscula. Se decodifica para
    // extraer el FOLIO (y opcionalmente el id de báscula/departamento). Las
    // posiciones son índices 0-based dentro de los dígitos del código, SIN el
    // dígito verificador final.
    codigoBarras: {
      simbologia: "EAN13",   // EAN13 (13 dígitos) o UPC12 (12 dígitos)
      prefijos: "2",          // prefijos válidos, separados por coma (vacío = cualquiera)
      folioInicio: 3,         // índice donde empieza el folio dentro del código
      folioLargo: 6,          // cantidad de dígitos del folio
      basculaInicio: 1,       // índice donde empieza el id de báscula/departamento
      basculaLargo: 2         // dígitos del id de báscula/depto (0 = no usar)
    }
  };
}

/* ---------- Ciclo de vida ---------- */
let onPersist = null; // callback opcional (respaldo en la nube)
let silencioPersist = 0; // escritura que no debe volver a subir (datos que acaban de bajar)
const reservasId = {};
function setOnPersist(fn) { onPersist = typeof fn === "function" ? fn : null; }
function apartar(campo, valor) {
  if (valor == null || valor === "") return;
  reservasId[campo] = valor;
}
function consumir(campo, fallback) {
  if (Object.prototype.hasOwnProperty.call(reservasId, campo) && reservasId[campo] != null) {
    const v = reservasId[campo];
    delete reservasId[campo];
    return v;
  }
  return fallback;
}
function anotarBaja(tipo, id) {
  if (!db.syncBajas || typeof db.syncBajas !== "object") db.syncBajas = {};
  if (!Array.isArray(db.syncBajas[tipo])) db.syncBajas[tipo] = [];
  const v = (tipo === "proveedores" || tipo === "cajaMovs") ? String(id) : Number(id);
  if (!db.syncBajas[tipo].some((x) => x === v)) db.syncBajas[tipo].push(v);
}
function guardarSilencioso(fn) {
  silencioPersist++;
  try {
    if (typeof fn === "function") fn(db);
    persist();
  } finally {
    silencioPersist--;
  }
}
function folioVentaActual() { return Number(db.config && db.config.folioVenta) || 1; }
function folioDevolucionActual() { return Number(db.config && db.config.folioDevolucion) || 1; }
function maxIdLista(lista) {
  return (lista || []).reduce((m, x) => Math.max(m, Number(x && x.id) || 0), 0);
}

// Lee la base intentando el archivo principal y, si está corrupto, el respaldo .bak.
function cargarDeDisco() {
  const candidatos = [DB_FILE, DB_FILE + ".bak"];
  for (const f of candidatos) {
    try {
      if (fs.existsSync(f)) {
        const txt = fs.readFileSync(f, "utf8");
        const parsed = JSON.parse(txt);
        if (parsed && parsed.config) {
          if (f !== DB_FILE) console.warn("[db] Recuperado desde respaldo:", f);
          return parsed;
        }
      }
    } catch (e) {
      console.warn("[db] Archivo dañado, intento siguiente:", f, e.message);
    }
  }
  return null;
}

function init(userDataPath) {
  DATA_DIR = path.join(userDataPath, "data");
  fs.mkdirSync(DATA_DIR, { recursive: true });
  DB_FILE = path.join(DATA_DIR, "db.json");

  // Limpia un archivo temporal huérfano de un corte durante una escritura previa.
  try { if (fs.existsSync(DB_FILE + ".tmp")) fs.unlinkSync(DB_FILE + ".tmp"); } catch (e) {}

  db = cargarDeDisco();
  if (db) {
    migrar();
  } else {
    db = construirSemilla();
    persist();
  }
  return { file: DB_FILE };
}

// Asegura que bases de datos previas tengan los campos nuevos.
function migrar() {
  db.config = db.config || {};
  if (db.config.cajaActualId === undefined) db.config.cajaActualId = null;
  if (db.config.folioDevolucion === undefined) db.config.folioDevolucion = 1;
  if (db.config.folioApartado === undefined) db.config.folioApartado = 1;
  // Instalaciones existentes ya están en uso: se consideran configuradas.
  if (db.config.configurado === undefined) db.config.configurado = true;
  db.config.negocio = Object.assign({
    nombre: "Mayoreo de Carnes de Res", sucursal: "", direccion: "",
    telefono: "", rfc: "", razonSocial: "", regimenFiscal: "", codigoPostal: "",
    pie: "¡Gracias por su compra!", pie2: ""
  }, db.config.negocio || {});
  db.config.impresora = Object.assign({
    modo: "off", ip: "192.168.1.100", puerto: 9100,
    rutaWindows: "", envioWindows: "auto", anchoCols: 48,
    autoImprimir: true, abrirCajonEfectivo: true, imprimirLogo: true, pulsoCajon: 0
  }, db.config.impresora || {});
  db.config.ticket = Object.assign(defaultTicket(), db.config.ticket || {});
  db.config.respaldo = Object.assign(defaultRespaldo(), db.config.respaldo || {});
  db.config.supabase = Object.assign(defaultSupabase(), db.config.supabase || {});
  db.config.actualizaciones = mezclarActualizaciones(db.config.actualizaciones);
  // Permisos por rol. Por defecto el inventario solo lo modifican administradores
  // (los demás usuarios lo ven en solo lectura y piden clave de admin).
  db.config.permisos = Object.assign({ inventarioSoloAdmin: true }, db.config.permisos || {});
  db.config.bascula = Object.assign(defaultBascula(), db.config.bascula || {});
  db.config.bascula.codigoBarras = Object.assign(defaultBascula().codigoBarras, db.config.bascula.codigoBarras || {});
  // Facturación electrónica: fusiona conservando lo capturado por el negocio.
  const fdef = defaultFactura();
  const fprev = db.config.factura || {};
  db.config.factura = Object.assign(fdef, fprev);
  db.config.factura.ws = Object.assign(fdef.ws, fprev.ws || {});
  db.config.factura.correo = Object.assign(fdef.correo, fprev.correo || {});
  db.config.factura.whatsapp = Object.assign(fdef.whatsapp, fprev.whatsapp || {});
  db.facturas = db.facturas || [];
  db.cortesEleventa = db.cortesEleventa || [];
  db.proveedores = Array.isArray(db.proveedores) ? db.proveedores : [];
  db.movimientosPendientes = Array.isArray(db.movimientosPendientes) ? db.movimientosPendientes : [];
  db.basculaVistas = db.basculaVistas || {};
  db.cajas = db.cajas || [];
  db.movimientosInv = db.movimientosInv || [];
  db.movimientos = db.movimientos || [];
  db.devoluciones = db.devoluciones || [];
  db.apartados = db.apartados || [];
  db.ordenesEspera = db.ordenesEspera || [];
  db.usuarios = db.usuarios || [];
  db.imagenesProducto = db.imagenesProducto || {};
  db.efectivoCasa = Array.isArray(db.efectivoCasa) ? db.efectivoCasa : [];
  db.historialPantallaClientes = (db.historialPantallaClientes && typeof db.historialPantallaClientes === "object")
    ? db.historialPantallaClientes : {};
  // Ocultar notas pagadas en el estado de cuenta (SOLO esta PC; no se sincroniza).
  db.ocultarPagadasClientes = (db.ocultarPagadasClientes && typeof db.ocultarPagadasClientes === "object")
    ? db.ocultarPagadasClientes : {};
  db.ocultarPagadasProveedores = (db.ocultarPagadasProveedores && typeof db.ocultarPagadasProveedores === "object")
    ? db.ocultarPagadasProveedores : {};
  migrarEfectivoCasaDesdeMovimientos();
  // Cuadra el saldo de cada cliente con sus movimientos al abrir. El saldo es un
  // valor DERIVADO; si una sincronización previa dejó el saldo desfasado de la
  // lista de movimientos (ventas/abonos de otra PC que entraron a la lista pero
  // no al saldo), aquí se corrige. Solo con movimientos: un saldo inicial sin
  // movimientos (importado) se respeta y no se pone en cero.
  (db.clientes || []).forEach((c) => { if (c && Array.isArray(c.movimientos) && c.movimientos.length) recomputarCredito(c); });
  (db.productos || []).forEach((p) => {
    // Nunca se resetea un stock ya capturado. Solo se completa si falta el campo.
    if (p.existencia === undefined || p.existencia === null) p.existencia = 0;
    if (p.stockMin === undefined) p.stockMin = 0;
    if (p.controlaInventario === undefined) p.controlaInventario = controlaInvCat(p.cat);
    Object.assign(p, defaultsSatProducto(p)); // completa claves SAT faltantes
  });
  migrarDemoRelleno();
  migrarUsuarios();
  migrarPaquetes();
  persist();
}

// Rellena una sola vez precios y existencias ficticias en instalaciones demo
// ya creadas (sin precio o sin stock). No se ejecuta sobre datos importados.
function migrarDemoRelleno() {
  if (db.config.demoRellenado) return;
  const fict = preciosFicticios();
  (db.productos || []).forEach((p) => {
    if (p.precioCents == null) {
      if (fict[p.nombre]) { p.precioCents = toCents(fict[p.nombre].precio); if (p.unidad === "s/pedido") p.unidad = fict[p.nombre].unidad; }
      else { p.precioCents = toCents(100); if (p.unidad === "s/pedido") p.unidad = "pza"; }
    }
    if (p.unidad === "s/pedido") p.unidad = "pza";
    // Solo los productos que controlan inventario reciben existencias ficticias.
    if (p.controlaInventario) {
      if (!p.existencia) p.existencia = stockFicticio(p.unidad);
      if (!p.stockMin) p.stockMin = stockMinFicticio(p.unidad);
    } else {
      p.existencia = 0; p.stockMin = 0;
    }
  });
  db.config.demoRellenado = true;
}

// Actualiza los paquetes que estaban "por confirmar" con su definición oficial.
function migrarPaquetes() {
  const def = definicionPaquetes();
  (db.paquetes || []).forEach((pq) => {
    const d = def[pq.id];
    if (d && pq.porConfirmar) {
      pq.nombre = d.nombre;
      pq.precioCents = toCents(d.precio);
      pq.componentes = clonComp(d.comp);
      pq.porConfirmar = false;
    }
  });
}

// Deja solo el Administrador de fábrica: garantiza que exista y elimina los
// usuarios semilla antiguos que nunca fueron personalizados (mismos PIN y nombre
// por defecto). Los usuarios creados por el negocio se respetan.
function migrarUsuarios() {
  // Garantizar Administrador (pin 1234) si no hay ninguno
  let admin = db.usuarios.find((x) => x.pin === "1234") || db.usuarios.find((x) => x.rol === "Administrador");
  if (!admin) {
    const id = (db.usuarios.reduce((m, x) => Math.max(m, x.id), 0) || 0) + 1;
    db.usuarios.push({ id, pin: "1234", nombre: "Administrador", rol: "Administrador" });
  }
  // Quitar cajeros semilla sin personalizar (Usuario 1/2/3, Cajero 1, Carnicero con su PIN de fábrica)
  const semilla = new Set([
    "1111|Usuario 1", "2222|Usuario 2", "3333|Usuario 3",
    "1111|Cajero 1", "2222|Carnicero"
  ]);
  db.usuarios = db.usuarios.filter((u) => !(u.rol !== "Administrador" && semilla.has(u.pin + "|" + u.nombre)));
}

/* ---------- Alta / baja de usuarios ---------- */
function _pinValido(pin) { return /^\d{4}$/.test(String(pin || "")); }
function _listaUsuarios() { return db.usuarios.map((x) => ({ id: x.id, nombre: x.nombre, rol: x.rol, pin: x.pin })); }

function crearUsuario(nombre, pin, rol) {
  nombre = String(nombre || "").trim();
  pin = String(pin || "").trim();
  if (!nombre) return { error: "Escribe un nombre." };
  if (!_pinValido(pin)) return { error: "La contraseña debe ser de 4 dígitos." };
  if (db.usuarios.some((u) => u.pin === pin)) return { error: "Ya existe un usuario con esa contraseña. Usa otra." };
  const id = (db.usuarios.reduce((m, x) => Math.max(m, x.id), 0) || 0) + 1;
  db.usuarios.push({ id, nombre, pin, rol: rol === "Administrador" ? "Administrador" : "Cajero" });
  persist();
  return { ok: true, usuarios: _listaUsuarios() };
}

function cambiarPin(id, nuevoPin, pinActual) {
  const u = db.usuarios.find((x) => x.id === id);
  if (!u) return { error: "Usuario no encontrado." };
  // Para cambiar la contraseña se debe escribir la ACTUAL correctamente.
  if (String(pinActual || "") !== String(u.pin)) return { error: "La contraseña actual no es correcta." };
  nuevoPin = String(nuevoPin || "").trim();
  if (!_pinValido(nuevoPin)) return { error: "La contraseña debe ser de 4 dígitos." };
  if (db.usuarios.some((x) => x.id !== id && x.pin === nuevoPin)) return { error: "Ya existe un usuario con esa contraseña. Usa otra." };
  u.pin = nuevoPin;
  persist();
  return { ok: true, usuarios: _listaUsuarios() };
}

function eliminarUsuario(id) {
  const u = db.usuarios.find((x) => x.id === id);
  if (!u) return { error: "Usuario no encontrado." };
  const admins = db.usuarios.filter((x) => x.rol === "Administrador");
  if (u.rol === "Administrador" && admins.length <= 1) return { error: "Debe quedar al menos un Administrador." };
  db.usuarios = db.usuarios.filter((x) => x.id !== id);
  persist();
  return { ok: true, usuarios: _listaUsuarios() };
}

// Escritura atómica y durable: escribe en .tmp, fuerza a disco (fsync),
// conserva copia .bak de la versión previa y reemplaza con rename (atómico).
// Así un apagón nunca deja el db.json a medio escribir.
function persist() {
  const json = JSON.stringify(db, null, 2);
  const tmp = DB_FILE + ".tmp";
  try {
    const fd = fs.openSync(tmp, "w");
    try {
      fs.writeFileSync(fd, json, "utf8");
      fs.fsyncSync(fd);           // fuerza el contenido a disco físico
    } finally {
      fs.closeSync(fd);
    }
    // Respaldo de la versión anterior antes de reemplazar
    try { if (fs.existsSync(DB_FILE)) fs.copyFileSync(DB_FILE, DB_FILE + ".bak"); } catch (e) {}
    fs.renameSync(tmp, DB_FILE); // reemplazo atómico en el mismo volumen
    // Forzar que la entrada del directorio (el rename) quede en disco
    try { const dfd = fs.openSync(DATA_DIR, "r"); fs.fsyncSync(dfd); fs.closeSync(dfd); } catch (e) {}
  } catch (e) {
    // Último recurso: escritura directa (mejor guardar algo que nada)
    try { fs.writeFileSync(DB_FILE, json, "utf8"); } catch (e2) {}
  }
  if (silencioPersist > 0) return;
  if (onPersist) { try { onPersist(); } catch (e) {} }
}

// Copia completa de la base para respaldo en la nube.
function getSnapshot() {
  return { terminal: (db.config && db.config.terminal) || "Caja", ts: new Date().toISOString(), db };
}
function getRespaldoConfig() { return Object.assign(defaultRespaldo(), (db.config && db.config.respaldo) || {}); }
function getSupabaseConfig() { return Object.assign(defaultSupabase(), (db.config && db.config.supabase) || {}); }

/* ---------- Lectura ---------- */
function bootstrap() {
  return {
    config: db.config,
    categorias: db.categorias,
    productos: db.productos,
    paquetes: db.paquetes,
    usuarios: db.usuarios.map((u) => ({ id: u.id, nombre: u.nombre, rol: u.rol, pin: u.pin })),
    clientes: db.clientes
  };
}

/* ---------- Ventas ---------- */
function idProductoInvPorNombre(nombre) {
  const n = String(nombre || "").trim().toLowerCase();
  if (!n) return null;
  const p = (db.productos || []).find((x) => x.controlaInventario && String(x.nombre || "").trim().toLowerCase() === n);
  return p ? p.id : null;
}
function aplicarSalidaInventario(productoId, cant, meta) {
  const p = (db.productos || []).find((x) => x.id === productoId);
  if (!p || !p.controlaInventario) return null;
  p.existencia = r3((p.existencia || 0) - (Number(cant) || 0));
  db.movimientosInv = db.movimientosInv || [];
  db.movimientosInv.push({
    fecha: meta.fecha, productoId: p.id, tipo: "venta",
    cant, existencia: p.existencia, folio: meta.folio, usuario: meta.usuario || null
  });
  return { id: p.id, existencia: p.existencia };
}
function descontarInventarioDeItems(items, meta) {
  const out = [];
  const mark = (r) => { if (r) out.push(r); };
  for (const it of items || []) {
    if (it.tipo === "producto") {
      const id = it.productoId || idProductoInvPorNombre(it.nombre);
      if (id) mark(aplicarSalidaInventario(id, it.cant, meta));
    }
    for (const ex of (it.extras || [])) {
      const id = ex.productoId || ex.ref || idProductoInvPorNombre(ex.nombre);
      if (id) mark(aplicarSalidaInventario(id, ex.cant, meta));
    }
  }
  return out;
}

function registrarVenta(venta) {
  const folio = Number(consumir("folioVenta", db.config.folioVenta)) || db.config.folioVenta;
  const registro = {
    folio,
    fecha: new Date().toISOString(),
    cajaId: db.config.cajaActualId || null,
    ...venta
  };
  db.ventas.push(registro);
  db.config.folioVenta = folio + 1;

  // Descuenta al instante (y se guarda en el persist de abajo).
  // Solo productos con controlaInventario. Carnes de báscula no se tocan.
  const existencias = descontarInventarioDeItems(venta.items, {
    fecha: registro.fecha, folio, usuario: venta.usuario || null
  });

  // Venta a crédito: se carga el total a la cuenta del cliente (no entra al
  // efectivo del corte). La cobranza posterior se hace en la ventana de crédito.
  let saldoClienteCents = null;
  if (registro.pago === "credito" && registro.creditoClienteId != null) {
    const cli = db.clientes.find((c) => c.id === Number(registro.creditoClienteId));
    if (cli) {
      if (!Array.isArray(cli.movimientos)) cli.movimientos = [];
      cli.saldoCents = (cli.saldoCents || 0) + (registro.totalCents || 0);
      saldoClienteCents = cli.saldoCents;
      registro.saldoClienteCents = saldoClienteCents;
      cli.movimientos.push({
        uid: nuevoUid(),
        fecha: registro.fecha, tipo: "cargo", montoCents: registro.totalCents || 0,
        saldoCents: cli.saldoCents, nota: `Venta folio ${folio}`, ventaFolio: folio, usuario: venta.usuario || null
      });
    }
  }

  registrarMovimiento({
    tipo: "venta", usuario: venta.usuario || null,
    detalle: `Venta folio ${folio} por ${(registro.totalCents / 100).toFixed(2)} (${venta.pago || "s/pago"})`
  });
  persist();
  return { folio, fecha: registro.fecha, existencias, saldoClienteCents };
}

function registrarMovimiento(mov) {
  db.movimientos.push({ fecha: new Date().toISOString(), ...mov });
  persist();
  return true;
}

// Bitácora general (ventas, efectivo, inventario, crédito, caja, etc.)
function getMovimientos(filtro) {
  filtro = filtro || {};
  let lista = (db.movimientos || []).slice();
  if (filtro.tipo) lista = lista.filter((m) => m.tipo === filtro.tipo);
  if (filtro.dia) lista = lista.filter((m) => (m.fecha || "").slice(0, 10) === filtro.dia);
  return lista;
}

// Movimientos de inventario (entradas/salidas/ventas/ajustes)
function getMovimientosInv(filtro) {
  filtro = filtro || {};
  let lista = (db.movimientosInv || []).slice();
  if (filtro.dia) lista = lista.filter((m) => (m.fecha || "").slice(0, 10) === filtro.dia);
  if (filtro.productoId) lista = lista.filter((m) => m.productoId === filtro.productoId);
  return lista.map((m) => {
    const p = db.productos.find((x) => x.id === m.productoId);
    return { ...m, nombre: p ? p.nombre : ("#" + m.productoId), unidad: p ? p.unidad : "" };
  });
}

// Reemplaza toda la base (para importar un respaldo). Valida estructura mínima.
function reemplazarDatos(obj) {
  const nueva = obj && obj.db ? obj.db : obj;
  if (!nueva || !nueva.config || !Array.isArray(nueva.productos)) {
    return { error: "El archivo no parece un respaldo válido del sistema." };
  }
  db = nueva;
  migrar();
  migrarUsuarios();
  persist();
  return { ok: true };
}

// Integra un catálogo importado desde ELEVENTA (productos, clientes y
// categorías). Reemplaza inventario/clientes/categorías conservando la
// configuración, los usuarios y los paquetes del negocio.
function slug(str) {
  return String(str || "").toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "cat";
}
function importarCatalogoEleventa(datos) {
  datos = datos || {};
  const prods = Array.isArray(datos.productos) ? datos.productos : [];
  if (!prods.length) return { error: "No se encontraron productos en ELEVENTA para importar." };

  // Categorías (a partir de los departamentos de ELEVENTA).
  const catNombres = Array.isArray(datos.categorias) && datos.categorias.length
    ? datos.categorias
    : [...new Set(prods.map((p) => p.cat).filter(Boolean))];
  const nombreAId = {};
  const usados = new Set();
  const categorias = [];
  let orden = 1;
  const asegurarCat = (nombre) => {
    nombre = String(nombre || "General").trim() || "General";
    if (nombreAId[nombre]) return nombreAId[nombre];
    let id = slug(nombre), base = id, n = 2;
    while (usados.has(id)) id = base + "-" + (n++);
    usados.add(id);
    nombreAId[nombre] = id;
    categorias.push({ id, nombre, emoji: "🏷️", orden: orden++ });
    return id;
  };
  catNombres.forEach(asegurarCat);
  const catGeneral = asegurarCat("General");

  // Productos.
  let pid = 0;
  const productos = prods.map((p) => {
    const unidad = p.unidad === "kg" ? "kg" : (p.unidad || "pza");
    const controla = p.controlaInventario !== undefined ? !!p.controlaInventario : true;
    return {
      id: ++pid,
      cat: p.cat ? asegurarCat(p.cat) : catGeneral,
      nombre: String(p.nombre || "Producto").trim() || "Producto",
      codigo: p.codigo ? String(p.codigo) : undefined,
      precioCents: toCents(num0(p.precio)),
      costoCents: p.costo != null ? toCents(num0(p.costo)) : undefined,
      unidad,
      controlaInventario: controla,
      existencia: controla ? r3(num0(p.existencia)) : 0,
      stockMin: controla ? r3(num0(p.stockMin)) : 0,
      activo: true,
      manual: false
    };
  });

  // Clientes.
  let cid = 0;
  const clientes = (Array.isArray(datos.clientes) ? datos.clientes : []).map((c) =>
    _clienteNorm({
      id: ++cid,
      nombre: c.nombre,
      telefono: c.telefono,
      rfc: c.rfc,
      direccion: c.direccion,
      creditoActivo: (c.saldoCents || 0) > 0 || (c.limiteCents || 0) > 0,
      limiteCents: c.limiteCents || 0,
      saldoCents: c.saldoCents || 0,
      movimientos: []
    })
  );

  db.categorias = categorias;
  db.productos = productos;
  db.clientes = clientes;
  db.config.configurado = true;
  db.config.demoRellenado = true;
  db.config.folioVenta = 1;
  persist();
  return { ok: true, resumen: { productos: productos.length, clientes: clientes.length, categorias: categorias.length } };
}
function num0(v) { const n = parseFloat(v); return isNaN(n) ? 0 : n; }

/* ---------- Caja / corte ---------- */
// Desglosa una venta en [{metodo, montoCents}]. Para pago combinado usa v.pagos.
function desglosePagos(v) {
  if (v.pago === "combinado" && Array.isArray(v.pagos) && v.pagos.length) {
    return v.pagos.map((p) => ({ metodo: p.metodo, montoCents: p.montoCents || 0 }));
  }
  return [{ metodo: v.pago || "otro", montoCents: v.totalCents || 0 }];
}
// Monto de una venta pagado con un método específico.
function montoMetodo(v, metodo) {
  return desglosePagos(v).filter((p) => p.metodo === metodo).reduce((s, p) => s + p.montoCents, 0);
}

function catNameDe(catId) {
  const c = (db.categorias || []).find((x) => x.id === catId);
  return c ? c.nombre : "Otros";
}
function esVentaBascula(v) {
  return !!(v && (v.origenBascula || v.basculaFolio != null));
}
// Lo que NO entra a "Carnes báscula": inventario de mostrador
// (quesos, salsas, abarrotes, especialidades) y la categoría "Carnes"
// del catálogo (carne seca). Esas se quedan en ventas por categoría.
const CATS_FUERA_CARNES_BASCULA = new Set(["abarrotes", "quesos", "salsas", "especialidades", "carnes"]);
function esCategoriaFueraCarnesBascula(it) {
  if (!it || !it.productoId) return false;
  const p = (db.productos || []).find((x) => x.id === it.productoId);
  if (!p) return false;
  const id = String(p.cat || "").trim().toLowerCase();
  const nom = String(catNameDe(p.cat) || "").trim().toLowerCase();
  return CATS_FUERA_CARNES_BASCULA.has(id) || CATS_FUERA_CARNES_BASCULA.has(nom);
}
// Ticket de báscula (escaneado o automático): cortes de res.
// Quesos, salsas, especialidades, abarrotes y carne seca NO van aquí.
function esCarnesBasculaItem(v, it) {
  if (!it || it.tipo === "apartado" || it.tipo === "paquete") return false;
  if (esCategoriaFueraCarnesBascula(it)) return false;
  // Producto común (Ctrl+P): no es ticket de báscula.
  if (it.manual && !it.bascula) return false;
  if (it.bascula) return true;
  const items = (v && v.items) || [];
  if (items.some((x) => x && x.bascula)) return false;
  if (esVentaBascula(v)) return true;
  // Histórico: sin catálogo era "Varios" (casi todo carne de báscula).
  return !it.productoId;
}

function recorrerItemsCobrados(ventas, onItem) {
  for (const v of ventas || []) {
    if (v.cancelada) continue;
    const items = v.items || [];
    if (!items.length) continue;
    const total = v.totalCents || 0;
    const cred = montoMetodo(v, "credito");
    const cobrado = Math.max(0, total - cred);
    if (cobrado <= 0) continue;
    if (cred <= 0) {
      for (const it of items) onItem(v, it, it.importeCents || 0, Number(it.cant) || 0);
      continue;
    }
    const base = items.reduce((s, it) => s + (it.importeCents || 0), 0) || total || 1;
    let left = cobrado;
    items.forEach((it, i) => {
      const cant = Number(it.cant) || 0;
      const cantCobrada = Math.round(cant * cobrado / (total || base) * 1000) / 1000;
      let part;
      if (i === items.length - 1) part = left;
      else {
        part = Math.min(left, Math.round((it.importeCents || 0) * cobrado / base));
        left -= part;
      }
      onItem(v, it, part, cantCobrada);
    });
  }
}

function sumarCarnesBascula(ventas) {
  let montoCents = 0, cant = 0;
  recorrerItemsCobrados(ventas, (v, it, cents, c) => {
    if (!esCarnesBasculaItem(v, it)) return;
    montoCents += cents || 0;
    cant += c || 0;
  });
  return { montoCents, cant: Math.round(cant * 1000) / 1000 };
}

// Categorías del corte: solo lo cobrado. El fiado sin pagar no entra.
// La carne de báscula (ticket escaneado/automático) NO se mezcla aquí.
// Quesos, salsas, especialidades, abarrotes y carne seca SÍ quedan.
function sumarVentasPorDepto(ventas) {
  const deptoDe = (it) => {
    if (it.tipo === "apartado") return "Apartados";
    if (it.tipo === "paquete") return "Paquetes";
    if (it.productoId) {
      const p = db.productos.find((x) => x.id === it.productoId);
      return p ? catNameDe(p.cat) : "Varios";
    }
    return "Varios";
  };
  const depto = {};
  const nombreDe = (it) => {
    const n = String((it && it.nombre) || "").trim();
    return n || "Producto";
  };
  const add = (d, nombre, cents, cant) => {
    if (!cents && !cant) return;
    if (!depto[d]) depto[d] = { montoCents: 0, cant: 0, productos: {} };
    depto[d].montoCents += cents;
    depto[d].cant += cant;
    if (!depto[d].productos[nombre]) depto[d].productos[nombre] = { montoCents: 0, cant: 0 };
    depto[d].productos[nombre].montoCents += cents;
    depto[d].productos[nombre].cant += cant;
  };
  recorrerItemsCobrados(ventas, (v, it, cents, cant) => {
    if (esCarnesBasculaItem(v, it)) return;
    add(deptoDe(it), nombreDe(it), cents, cant);
  });
  return Object.keys(depto)
    .filter((k) => { const n = k.toLowerCase(); return n !== "varios" && n !== "paquetes"; })
    .sort((a, b) => depto[b].montoCents - depto[a].montoCents)
    .map((k) => ({
      depto: k,
      montoCents: depto[k].montoCents,
      cant: Math.round(depto[k].cant * 1000) / 1000,
      productos: Object.keys(depto[k].productos).map((n) => ({
        nombre: n,
        montoCents: depto[k].productos[n].montoCents,
        cant: Math.round(depto[k].productos[n].cant * 1000) / 1000
      })).sort((a, b) => b.montoCents - a.montoCents || a.nombre.localeCompare(b.nombre, "es"))
    }));
}

function estadoCajaInterno() {
  const id = db.config.cajaActualId;
  if (!id) return { abierta: false };
  const caja = db.cajas.find((c) => c.id === id);
  if (!caja || !caja.abierta) return { abierta: false };

  const ventas = db.ventas.filter((v) => v.cajaId === id && ventaCuentaEnCorte(v));
  const devs = (db.devoluciones || []).filter((d) => d.cajaId === id);
  const porMetodo = {};        // NETO por método (ventas − devoluciones + abonos)
  const porMetodoCobrado = {}; // BRUTO cobrado por método (sin restar devoluciones ni sumar abonos; sin crédito)
  let totalVentas = 0;
  for (const v of ventas) {
    for (const p of desglosePagos(v)) {
      porMetodo[p.metodo] = (porMetodo[p.metodo] || 0) + p.montoCents;
      if (String(p.metodo || "").toLowerCase() !== "credito") {
        porMetodoCobrado[p.metodo] = (porMetodoCobrado[p.metodo] || 0) + p.montoCents;
      }
    }
    totalVentas += v.totalCents || 0;
  }
  let totalDevoluciones = 0;
  for (const d of devs) {
    porMetodo[d.pago] = (porMetodo[d.pago] || 0) - (d.totalCents || 0);
    totalDevoluciones += d.totalCents || 0;
  }
  // Los abonos a crédito (categoría "abono") se contabilizan aparte de las
  // entradas normales, para que el corte muestre claro de dónde viene el dinero.
  let ingresos = 0, retiros = 0, abonosCents = 0, abonosOtrosCents = 0;
  const mueveCajon = (m) => {
    const fp = String(m.formaPago || "efectivo").toLowerCase();
    return fp === "efectivo" || fp === "dolares";
  };
  for (const m of caja.movimientos) {
    if (m.tipo === "ingreso" && m.categoria === "abono") {
      const fp = String(m.formaPago || "efectivo").trim().toLowerCase();
      // Efectivo casa NO va al corte ni al ticket de corte (solo estado de cuenta).
      if (fp === "ajuste" || fp === "credito" || fp === "efectivo_casa") continue;
      if (fp === "efectivo" || fp === "dolares") abonosCents += m.montoCents;
      else abonosOtrosCents += m.montoCents;
      porMetodo[fp] = (porMetodo[fp] || 0) + (m.montoCents || 0);
      continue;
    }
    // Tarjeta, transferencia y lo pendiente a crédito no tocan el cajón.
    if (!mueveCajon(m)) continue;
    if (m.tipo === "ingreso") ingresos += m.montoCents;
    else retiros += m.montoCents;
  }
  // El efectivo del arqueo incluye pagos en pesos Y en dólares (su equivalente
  // en pesos), porque ambos entran físicamente al cajón. Los abonos en efectivo
  // también entran al cajón, por eso suman al efectivo esperado.
  const METODOS_EFECTIVO = ["efectivo", "dolares"];
  const efectivoVentas = ventas.reduce((s, v) => s + METODOS_EFECTIVO.reduce((a, m) => a + montoMetodo(v, m), 0), 0);
  const efectivoDevoluciones = devs.filter((d) => METODOS_EFECTIVO.includes(d.pago)).reduce((s, d) => s + (d.totalCents || 0), 0);
  const efectivoEsperado = caja.fondoCents + efectivoVentas - efectivoDevoluciones + ingresos + abonosCents - retiros;
  const apartadosCents = ventas.filter((v) => v.esApartadoPago).reduce((s, v) => s + (v.totalCents || 0), 0);

  // Listas de entradas/salidas de efectivo del turno (para el detalle del corte).
  // Las entradas excluyen los abonos, que van en su propio apartado.
  const mapMov = (m) => ({
    motivo: m.motivo || "", proveedor: m.proveedor || "", montoCents: m.montoCents || 0,
    categoria: m.categoria || "", formaPago: m.formaPago || "efectivo", tipo: m.tipo
  });
  const entradas = caja.movimientos.filter((m) => m.tipo === "ingreso" && m.categoria !== "abono" && mueveCajon(m)).map(mapMov);
  const salidas = caja.movimientos.filter((m) => m.tipo === "retiro" && mueveCajon(m)).map(mapMov);
  const movimientosOtros = caja.movimientos
    .filter((m) => m.categoria !== "abono" && !mueveCajon(m) && String(m.formaPago || "").toLowerCase() !== "credito")
    .map(mapMov);
  const abonos = caja.movimientos
    .filter((m) => m.tipo === "ingreso" && m.categoria === "abono" && String(m.formaPago || "").toLowerCase() !== "efectivo_casa")
    .map((m) => ({ motivo: m.motivo || "", montoCents: m.montoCents || 0, hora: m.fecha, cliente: m.cliente || "", formaPago: m.formaPago || "efectivo" }));

  const ventasPorDepto = sumarVentasPorDepto(ventas);
  const carnesBascula = sumarCarnesBascula(ventas);

  // Diferido con báscula: cancelaciones + devoluciones. La báscula cuenta estas
  // operaciones como venta (no sabe que se cancelaron/devolvieron), así que aquí
  // se listan aparte para poder cuadrar contra el ticket de corte de la báscula.
  const basFolio = (v) => v.origenBascula ? v.origenBascula.folio : (v.basculaFolio != null ? v.basculaFolio : null);
  const canceladas = db.ventas.filter((v) => v.cajaId === id && v.cancelada);
  const cancelaciones = canceladas.map((v) => ({
    folio: v.folio, hora: v.fecha, montoCents: v.totalCents || 0,
    motivo: v.canceladaMotivo || "", basculaFolio: basFolio(v),
    esBascula: !!(v.origenBascula || v.basculaFolio != null)
  }));
  const totalCancelaciones = cancelaciones.reduce((s, c) => s + c.montoCents, 0);
  const devolucionesLista = devs.map((d) => ({
    folio: d.folio, ventaFolio: d.ventaFolio || null, hora: d.fecha,
    montoCents: d.totalCents || 0, motivo: d.motivo || ""
  }));
  const diferidoBascula = totalCancelaciones + totalDevoluciones;

  const cred = listaCreditos(ventas);
  const credProv = resumenCreditosProveedor(localDay(caja.aperturaFecha || new Date().toISOString()));
  const creditoVentas = cred.total;
  const creditoDev = devs
    .filter((d) => String(d.pago || "").toLowerCase() === "credito")
    .reduce((s, d) => s + (d.totalCents || 0), 0);
  const ventasCobradas = totalVentas - creditoVentas;
  const devCobradas = totalDevoluciones - creditoDev;
  const ventasNetas = ventasCobradas - devCobradas;

  return {
    abierta: true, caja, porMetodo, porMetodoCobrado, totalVentas, numVentas: ventas.length,
    totalDevoluciones, ventasNetas, ventasCobradas, devCobradas,
    creditoVentas, creditoDev, creditosLista: cred.lista,
    creditosProveedor: credProv.lista,
    creditosProveedorCents: credProv.totalCents,
    ingresos, retiros, efectivoVentas, efectivoDevoluciones, efectivoEsperado, apartadosCents,
    abonos, totalAbonosCents: abonosCents, totalAbonosOtrosCents: abonosOtrosCents,
    entradas, salidas, movimientosOtros, ventasPorDepto, carnesBascula,
    cancelaciones, totalCancelaciones, devolucionesLista, diferidoBascula,
    tipoCambio: caja.tipoCambio || 0,
    turno: caja.id, terminal: db.config.terminal || ""
  };
}

function estadoCaja() { return estadoCajaInterno(); }

function deptosTicketCorte(lista) {
  const ocultas = new Set(["varios", "paquetes"]);
  return (lista || []).filter((d) => !ocultas.has(String(d.depto || "").trim().toLowerCase()));
}

function snapshotCorteDesdeEstado(st, caja) {
  if (!st || !st.abierta || !caja) return null;
  return {
    fondoCents: caja.fondoCents,
    aperturaFecha: caja.aperturaFecha,
    porMetodo: st.porMetodo,
    porMetodoCobrado: st.porMetodoCobrado,
    efectivoVentas: st.efectivoVentas,
    efectivoDevoluciones: st.efectivoDevoluciones,
    ingresos: st.ingresos,
    retiros: st.retiros,
    efectivoEsperado: st.efectivoEsperado,
    conteoCents: caja.conteoCents || 0,
    diferenciaCents: (caja.conteoCents || 0) - (st.efectivoEsperado || 0),
    dineroEnCajaCierreCents: caja.dineroEnCajaCierreCents != null ? caja.dineroEnCajaCierreCents : null,
    entregadoCents: caja.entregadoCents != null ? caja.entregadoCents : null,
    basculaTotalManualCents: caja.basculaTotalManualCents != null ? caja.basculaTotalManualCents : (st.basculaTotalManualCents != null ? st.basculaTotalManualCents : null),
    paquetesTotalManualCents: caja.paquetesTotalManualCents != null ? caja.paquetesTotalManualCents : (st.paquetesTotalManualCents != null ? st.paquetesTotalManualCents : null),
    totalVentas: st.totalVentas,
    totalDevoluciones: st.totalDevoluciones,
    ventasNetas: st.ventasNetas,
    ventasCobradas: st.ventasCobradas,
    devCobradas: st.devCobradas,
    creditoVentas: st.creditoVentas,
    creditoDev: st.creditoDev,
    creditosLista: st.creditosLista || [],
    creditosProveedor: st.creditosProveedor || [],
    creditosProveedorCents: st.creditosProveedorCents || 0,
    apartadosCents: st.apartadosCents || 0,
    abonos: st.abonos || [],
    totalAbonosCents: st.totalAbonosCents || 0,
    totalAbonosOtrosCents: st.totalAbonosOtrosCents || 0,
    entradas: st.entradas || [],
    salidas: st.salidas || [],
    movimientosOtros: st.movimientosOtros || [],
    ventasPorDepto: st.ventasPorDepto || [],
    carnesBascula: st.carnesBascula || { montoCents: 0, cant: 0 },
    cancelaciones: st.cancelaciones || [],
    totalCancelaciones: st.totalCancelaciones || 0,
    devolucionesLista: st.devolucionesLista || [],
    diferidoBascula: st.diferidoBascula || 0,
    turno: st.turno,
    terminal: st.terminal || "",
    numVentas: st.numVentas
  };
}

// Ticket EXACTO que imprime printer.lineasCorte (misma forma en local y en Supabase).
function ticketImpresionDesdeSnapshot(t) {
  const co = (t && t.corte) || {};
  const creditoVentas = t.creditoVentas != null ? t.creditoVentas : (co.creditoVentas || 0);
  const creditoDev = t.creditoDev != null ? t.creditoDev : (co.creditoDev || 0);
  const totalVentas = co.totalVentas || 0;
  const totalDev = co.totalDevoluciones || 0;
  const lista = (t.creditos && t.creditos.length) ? t.creditos : (co.creditosLista || []);
  const cb = co.carnesBascula || {};
  const deptosTk = deptosTicketCorte(co.ventasPorDepto);
  const totalCategoriasCents = deptosTk.reduce((s, d) => s + (d.montoCents || 0), 0);
  const manBascula = co.basculaTotalManualCents != null ? Number(co.basculaTotalManualCents) : 0;
  const manPaquetes = co.paquetesTotalManualCents != null ? Number(co.paquetesTotalManualCents) : 0;
  const totalCategMasBasculaManualCents = totalCategoriasCents + manBascula + manPaquetes;
  const fechaTxt = t.cierreFecha
    ? new Date(t.cierreFecha).toLocaleString("es-MX")
    : (t.abierta ? new Date().toLocaleString("es-MX") : "");
  return {
    formato: "mayoreo-corte-v2",
    titulo: t.abierta ? "CORTE DE TURNO (ABIERTO)" : "CORTE DE TURNO",
    abrirCajon: false,
    sinArqueo: !!t.abierta,
    turno: co.turno != null ? co.turno : t.id,
    terminal: co.terminal || "",
    fecha: fechaTxt,
    cajero: t.usuario || "",
    aperturaFecha: co.aperturaFecha ? new Date(co.aperturaFecha).toLocaleString("es-MX") : "",
    fondoCents: co.fondoCents || 0,
    numVentas: co.numVentas || 0,
    porMetodo: co.porMetodo || {},
    porMetodoCobrado: co.porMetodoCobrado || null,
    entradas: co.entradas || [],
    salidas: co.salidas || [],
    movimientosOtros: co.movimientosOtros || [],
    abonos: co.abonos || [],
    totalAbonosCents: co.totalAbonosCents || 0,
    totalAbonosOtrosCents: co.totalAbonosOtrosCents || 0,
    ventasPorDepto: deptosTk,
    carnesBascula: { montoCents: cb.montoCents || 0, cant: cb.cant || 0 },
    totalCategoriasCents,
    totalCategMasBasculaManualCents,
    totalVentasCents: totalVentas,
    ventasCobradasCents: co.ventasCobradas != null ? co.ventasCobradas : (totalVentas - creditoVentas),
    apartadosCents: co.apartadosCents || 0,
    totalDevolucionesCents: totalDev,
    devCobradasCents: co.devCobradas != null ? co.devCobradas : (totalDev - creditoDev),
    ventasNetasCents: co.ventasNetas != null ? co.ventasNetas : ((totalVentas - creditoVentas) - (totalDev - creditoDev)),
    creditoVentasCents: creditoVentas,
    creditoDevCents: creditoDev,
    creditosLista: lista,
    creditosProveedor: Array.isArray(co.creditosProveedor) ? co.creditosProveedor : [],
    creditosProveedorCents: co.creditosProveedorCents || 0,
    ingresosCents: co.ingresos || 0,
    retirosCents: co.retiros || 0,
    efectivoVentasCents: co.efectivoVentas || 0,
    efectivoDevolucionesCents: co.efectivoDevoluciones || 0,
    efectivoEsperadoCents: co.efectivoEsperado || 0,
    efectivoContadoCents: t.abierta ? null : (co.conteoCents != null ? co.conteoCents : null),
    diferenciaCents: t.abierta ? 0 : (co.diferenciaCents || 0),
    dineroEnCajaCierreCents: co.dineroEnCajaCierreCents != null ? co.dineroEnCajaCierreCents : null,
    entregadoCents: co.entregadoCents != null ? co.entregadoCents : null,
    basculaTotalManualCents: co.basculaTotalManualCents != null ? co.basculaTotalManualCents : null,
    paquetesTotalManualCents: co.paquetesTotalManualCents != null ? co.paquetesTotalManualCents : null,
    diferenciaCategBasculaCents: totalCategMasBasculaManualCents - (co.ventasCobradas != null ? co.ventasCobradas : (totalVentas - creditoVentas)),
    cancelaciones: co.cancelaciones || [],
    totalCancelacionesCents: co.totalCancelaciones || 0,
    devolucionesLista: co.devolucionesLista || [],
    diferidoBasculaCents: co.diferidoBascula || 0
  };
}

function armarTicketImpresionCaja(caja) {
  if (!caja) return null;
  let corte = caja.corte || null;
  const abierta = !!caja.abierta;
  if (!corte && abierta && db.config.cajaActualId === caja.id) {
    corte = snapshotCorteDesdeEstado(estadoCajaInterno(), caja);
  }
  if (!corte) return null;
  const ventasCaja = (db.ventas || []).filter((v) => v.cajaId === caja.id && ventaCuentaEnCorte(v));
  corte = Object.assign({}, corte, {
    ventasPorDepto: sumarVentasPorDepto(ventasCaja),
    carnesBascula: sumarCarnesBascula(ventasCaja),
    basculaTotalManualCents: corte.basculaTotalManualCents != null ? corte.basculaTotalManualCents : (caja.basculaTotalManualCents != null ? caja.basculaTotalManualCents : null),
    paquetesTotalManualCents: corte.paquetesTotalManualCents != null ? corte.paquetesTotalManualCents : (caja.paquetesTotalManualCents != null ? caja.paquetesTotalManualCents : null)
  });
  return ticketImpresionDesdeSnapshot({
    id: caja.id,
    usuario: caja.usuario || "",
    cierreFecha: caja.cierreFecha || null,
    abierta,
    corte,
    creditos: corte.creditosLista,
    creditoVentas: corte.creditoVentas,
    creditoDev: corte.creditoDev
  });
}

function abrirCaja(fondoCents, usuario, tipoCambio) {
  if (db.config.cajaActualId) return { error: "Ya hay una caja abierta." };
  const id = Number(consumir("caja", (db.cajas.reduce((m, c) => Math.max(m, c.id), 0) || 0) + 1));
  const caja = {
    id, usuario: usuario || null, fondoCents: fondoCents || 0,
    // Tipo de cambio del turno (pesos por dólar). Se usa para pagos en dólares.
    tipoCambio: Number(tipoCambio) || 0,
    aperturaFecha: new Date().toISOString(), cierreFecha: null, abierta: true, movimientos: []
  };
  db.cajas.push(caja);
  db.config.cajaActualId = id;
  const tc = caja.tipoCambio ? `, dólar a ${caja.tipoCambio.toFixed(2)}` : "";
  registrarMovimiento({ tipo: "caja", usuario, detalle: `Apertura de caja. Fondo ${(caja.fondoCents / 100).toFixed(2)}${tc}` });
  persist();
  return { ok: true, caja };
}

// Captura/corrige el FONDO INICIAL de la caja abierta, SOLO si aún no tiene
// actividad (sin ventas ni movimientos). Si ya operó, obliga a cerrar y reabrir.
function setFondoInicialCaja(fondoCents, tipoCambio, usuario) {
  const id = db.config.cajaActualId;
  if (!id) return { error: "No hay caja abierta." };
  const caja = db.cajas.find((c) => c.id === id && c.abierta);
  if (!caja) return { error: "No hay caja abierta." };
  const ventas = (db.ventas || []).filter((v) => v.cajaId === id && !v.cancelada).length;
  const movs = (caja.movimientos || []).length;
  if (ventas > 0 || movs > 0) {
    return { error: "La caja ya tiene movimientos del turno; no se puede cambiar el fondo inicial. Cierra el turno (corte) y abre uno nuevo." };
  }
  caja.fondoCents = Math.max(0, Math.round(fondoCents || 0));
  if (tipoCambio != null && !isNaN(tipoCambio) && Number(tipoCambio) > 0) caja.tipoCambio = Number(tipoCambio);
  const tc = caja.tipoCambio ? `, dólar a ${caja.tipoCambio.toFixed(2)}` : "";
  registrarMovimiento({ tipo: "caja", usuario: usuario || null, detalle: `Fondo inicial capturado: ${(caja.fondoCents / 100).toFixed(2)}${tc}` });
  persist();
  return { ok: true, caja };
}

// Actualiza el tipo de cambio (pesos por dólar) del turno abierto.
function setTipoCambioCaja(tipoCambio) {
  const id = db.config.cajaActualId;
  if (!id) return { error: "No hay caja abierta." };
  const caja = db.cajas.find((c) => c.id === id);
  if (!caja || !caja.abierta) return { error: "No hay caja abierta." };
  caja.tipoCambio = Number(tipoCambio) || 0;
  persist();
  return { ok: true, tipoCambio: caja.tipoCambio };
}

// Devuelve el nombre del proveedor con la escritura (mayúsculas/minúsculas) que
// ya existe en la lista, para no crear duplicados tipo "OLY" vs "oly".
function proveedorCanonico(nombre) {
  const n = String(nombre || "").trim();
  if (!n) return n;
  const low = n.toLowerCase();
  const existente = (db.proveedores || []).find((x) => String(x).trim().toLowerCase() === low);
  return existente ? String(existente).trim() : n;
}

function recordarProveedor(nombre) {
  const n = String(nombre || "").trim();
  if (!n) return;
  db.proveedores = Array.isArray(db.proveedores) ? db.proveedores : [];
  db.proveedoresOcultos = Array.isArray(db.proveedoresOcultos) ? db.proveedoresOcultos : [];
  const low = n.toLowerCase();
  db.proveedoresOcultos = db.proveedoresOcultos.filter((x) => x !== low);
  if (db.proveedores.some((x) => String(x).toLowerCase() === low)) return;
  db.proveedores.push(n);
  // Tope razonable: los más recientes al final; si crece mucho, recorta antiguos.
  if (db.proveedores.length > 200) db.proveedores = db.proveedores.slice(-200);
}

/** Alta explícita de proveedor (para el botón en Créditos). */
function guardarProveedor(nombre) {
  const n = String(nombre || "").trim();
  if (!n) return { error: "Escribe el nombre del proveedor." };
  db.proveedores = Array.isArray(db.proveedores) ? db.proveedores : [];
  const low = n.toLowerCase();
  const ya = db.proveedores.find((x) => String(x).toLowerCase() === low);
  recordarProveedor(n);
  persist();
  return { ok: true, proveedor: ya || n, existe: !!ya, proveedores: getProveedores() };
}

function eliminarProveedor(nombre, usuario) {
  const n = String(nombre || "").trim();
  if (!n) return { error: "Elige el proveedor." };
  const key = n.toLowerCase();
  db.movimientosPendientes = Array.isArray(db.movimientosPendientes) ? db.movimientosPendientes : [];
  const deuda = db.movimientosPendientes
    .filter((x) => x.estado !== "pagado" && x.abonoDe == null && String(x.proveedor || "").trim().toLowerCase() === key)
    .reduce((s, x) => s + (x.montoCents || 0), 0);
  if (deuda > 0) return { error: "Ese proveedor todavía tiene saldo. Paga o cancela la cuenta antes de eliminarlo." };
  db.proveedores = (db.proveedores || []).filter((x) => String(x).trim().toLowerCase() !== key);
  anotarBaja("proveedores", n);
  db.proveedoresOcultos = Array.isArray(db.proveedoresOcultos) ? db.proveedoresOcultos : [];
  if (!db.proveedoresOcultos.includes(key)) db.proveedoresOcultos.push(key);
  registrarMovimiento({ tipo: "efectivo", usuario, detalle: `Proveedor quitado de la lista — ${n}` });
  persist();
  return { ok: true, proveedores: getProveedores() };
}

/** Lista de proveedores para autocompletado (sin registro formal). */
function getProveedores() {
  const set = new Map(); // lower -> display
  const add = (raw) => {
    const n = String(raw || "").trim();
    if (!n) return;
    const k = n.toLowerCase();
    if (!set.has(k)) set.set(k, n);
  };
  const ocultos = new Set((db.proveedoresOcultos || []).map((x) => String(x).toLowerCase()));
  (db.proveedores || []).forEach(add);
  for (const cj of (db.cajas || [])) {
    for (const m of (cj.movimientos || [])) add(m.proveedor);
  }
  return Array.from(set.values()).filter((n) => !ocultos.has(String(n).toLowerCase())).sort((a, b) => a.localeCompare(b, "es"));
}

function movimientoEfectivo(tipo, montoCents, motivo, usuario, proveedor, categoria, formaPago, cantidad) {
  const fp = String(formaPago || "efectivo").toLowerCase();
  if (!["efectivo", "tarjeta", "transferencia", "credito"].includes(fp)) {
    return { error: "Elige efectivo, tarjeta, transferencia o crédito." };
  }
  const prov = proveedorCanonico(proveedor);
  const mot = String(motivo || "").trim();
  if (!mot) return { error: "Escribe el concepto." };
  if ((categoria === "compra" || fp === "credito") && !prov) return { error: "Escribe el proveedor." };
  const tipoOk = tipo === "ingreso" ? "ingreso" : "retiro";
  const monto = montoCents || 0;
  if (monto <= 0) return { error: "Captura un monto mayor a cero." };

  if (fp === "credito") {
    db.movimientosPendientes = Array.isArray(db.movimientosPendientes) ? db.movimientosPendientes : [];
    const id = Number(consumir("pendiente", (db.movimientosPendientes.reduce((m, x) => Math.max(m, x.id || 0), 0) || 0) + 1));
    db.movimientosPendientes.push({
      id, fecha: new Date().toISOString(), tipo: tipoOk, categoria: categoria || "",
      montoCents: monto, motivo: mot, proveedor: prov, formaPago: "credito",
      cantidad: cantidad != null && cantidad !== "" ? Number(cantidad) : null,
      estado: "pendiente", usuario: usuario || null,
      pagoFecha: null, pagoForma: null, pagoCajaId: null, pagoMovId: null
    });
    if (prov) recordarProveedor(prov);
    registrarMovimiento({
      tipo: "efectivo", usuario,
      detalle: `Pendiente a crédito ${(monto / 100).toFixed(2)} — ${mot}${prov ? " · " + prov : ""}`
    });
    persist();
    return { ok: true, id, pendiente: true };
  }

  const st = estadoCajaInterno();
  if (!st.abierta) return { error: "No hay caja abierta." };
  const id = Number(consumir("movCaja", (st.caja.movimientos.reduce((m, x) => Math.max(m, x.id || 0), 0) || 0) + 1));
  st.caja.movimientos.push({
    id, fecha: new Date().toISOString(), tipo: tipoOk,
    montoCents: monto, motivo: mot, proveedor: prov,
    categoria: categoria || "", formaPago: fp, usuario: usuario || null
  });
  if (prov) recordarProveedor(prov);
  const etqMov = categoria === "compra" ? "compra" : tipoOk;
  registrarMovimiento({
    tipo: "efectivo", usuario,
    detalle: `${etqMov} ${fp} ${(monto / 100).toFixed(2)} — ${mot}${prov ? " · " + prov : ""}`
  });
  persist();
  return { ok: true, id };
}

function getMovimientosPendientes() {
  db.movimientosPendientes = Array.isArray(db.movimientosPendientes) ? db.movimientosPendientes : [];
  return db.movimientosPendientes.slice().sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
}

function liberarMovimientoPendiente(id, formaPago, usuario) {
  db.movimientosPendientes = Array.isArray(db.movimientosPendientes) ? db.movimientosPendientes : [];
  const p = db.movimientosPendientes.find((x) => Number(x.id) === Number(id));
  if (!p) return { error: "No se encontró esa compra." };
  if (p.estado === "pagado") return { error: "Esa compra ya está pagada." };
  const fp = String(formaPago || "").toLowerCase();
  if (!["efectivo", "tarjeta", "transferencia", "efectivo_casa"].includes(fp)) {
    return { error: "Al pagar elige efectivo, tarjeta, transferencia o efectivo casa." };
  }
  // Efectivo casa: se paga con dinero de la casa; no sale del cajón ni entra al
  // corte, por eso no exige caja abierta ni crea movimiento de caja.
  const esCasa = fp === "efectivo_casa";
  const st = estadoCajaInterno();
  if (!esCasa && !st.abierta) return { error: "Abre la caja para pagar. Así entra al corte de hoy." };
  const ahora = new Date().toISOString();
  let movId = null;
  if (!esCasa) {
    movId = Number(consumir("movCaja", (st.caja.movimientos.reduce((m, x) => Math.max(m, x.id || 0), 0) || 0) + 1));
    st.caja.movimientos.push({
      id: movId, fecha: ahora, tipo: p.tipo || "retiro",
      montoCents: p.montoCents || 0, motivo: p.motivo || "", proveedor: p.proveedor || "",
      cantidad: p.cantidad != null ? p.cantidad : null,
      categoria: p.categoria || "compra", formaPago: fp, usuario: usuario || null,
      pendienteId: p.id
    });
  }
  p.estado = "pagado";
  p.pagoFecha = ahora;
  p.pagoForma = fp;
  p.pagoCajaId = esCasa ? null : st.caja.id;
  p.pagoMovId = movId;
  registrarMovimiento({
    tipo: "efectivo", usuario,
    detalle: `Pago de compra a crédito ${esCasa ? "efectivo casa" : fp} ${((p.montoCents || 0) / 100).toFixed(2)} — ${p.motivo || ""}${p.proveedor ? " · " + p.proveedor : ""}`
  });
  persist();
  return { ok: true };
}

function resumenCreditosProveedor(diaISO) {
  db.movimientosPendientes = Array.isArray(db.movimientosPendientes) ? db.movimientosPendientes : [];
  const dia = diaISO ? String(diaISO).slice(0, 10) : "";
  const map = new Map();
  for (const p of db.movimientosPendientes) {
    if (p.estado === "pagado") continue;
    if (dia && localDay(p.fecha) !== dia) continue;
    const nombre = String(p.proveedor || "").trim() || "Sin proveedor";
    const k = nombre.toLowerCase();
    if (!map.has(k)) map.set(k, { proveedor: nombre, montoCents: 0 });
    map.get(k).montoCents += p.montoCents || 0;
  }
  const lista = Array.from(map.values()).sort((a, b) => b.montoCents - a.montoCents || a.proveedor.localeCompare(b.proveedor, "es"));
  return { lista, totalCents: lista.reduce((s, x) => s + x.montoCents, 0) };
}

// Estado de cuenta de un PROVEEDOR (lo que le debemos): reconstruye CARGOS
// (compras a crédito) y ABONOS/PAGOS con saldo corrido, con el mismo formato que
// el estado de cuenta de clientes. SOLO LECTURA: no modifica ningún dato.
function estadoCuentaProveedor(nombre) {
  db.movimientosPendientes = Array.isArray(db.movimientosPendientes) ? db.movimientosPendientes : [];
  const key = String(nombre || "").trim().toLowerCase();
  const all = db.movimientosPendientes.filter((p) => String(p.proveedor || "").trim().toLowerCase() === key);
  const display = (all.find((p) => p.proveedor) || {}).proveedor || String(nombre || "").trim();
  // Suma de abonos parciales (renglones sintéticos) por compra original.
  const hijos = {};
  for (const p of all) if (p.abonoDe != null) hijos[p.abonoDe] = (hijos[p.abonoDe] || 0) + (p.montoCents || 0);
  const eventos = [];
  for (const p of all) {
    if (p.abonoDe != null) {
      // Renglón sintético de un abono parcial → ABONO.
      eventos.push({
        id: p.id, tipo: "abono", fecha: p.pagoFecha || p.fecha, montoCents: p.montoCents || 0,
        formaPago: p.pagoForma || "", nota: String(p.motivo || "").replace(/\s*\(abono\)\s*$/i, ""), usuario: p.usuario || null
      });
    } else {
      // Compra original → CARGO por su monto ORIGINAL (restante + abonos parciales).
      const original = (p.montoCents || 0) + (hijos[p.id] || 0);
      eventos.push({
        id: p.id, tipo: "cargo", fecha: p.fecha, montoCents: original,
        restanteCents: p.estado === "pagado" ? 0 : (p.montoCents || 0),
        nota: p.motivo || "", cantidad: p.cantidad != null ? p.cantidad : null, usuario: p.usuario || null
      });
      // Compra pagada → ABONO por el RESTANTE que se liquidó al pagarse, en la
      // fecha del pago. Los abonos parciales previos ya salen como sus propios
      // renglones (abonoDe); aquí va solo lo que faltaba. (Antes se omitía este
      // abono cuando la compra ya tenía abonos parciales, por eso el saldo salía
      // bien pero el abono de liquidación no aparecía en el estado de cuenta.)
      if (p.estado === "pagado" && (p.montoCents || 0) > 0) {
        eventos.push({
          id: p.id, tipo: "abono", fecha: p.pagoFecha || p.fecha, montoCents: p.montoCents || 0,
          formaPago: p.pagoForma || "", nota: p.motivo || "", usuario: p.usuario || null
        });
      }
    }
  }
  eventos.sort((a, b) => String(a.fecha).localeCompare(String(b.fecha)) || ((a.id || 0) - (b.id || 0)) || (a.tipo === "cargo" ? -1 : 1));
  let saldo = 0;
  for (const e of eventos) { saldo += e.tipo === "cargo" ? e.montoCents : -e.montoCents; e.saldoCents = saldo; }
  // uid estable para seleccionar/reimprimir en UI (igual que el índice de clientes).
  eventos.forEach((e, i) => {
    e.uid = i;
    if (e.tipo === "cargo") {
      const pend = all.find((x) => Number(x.id) === Number(e.id) && x.abonoDe == null);
      e.cancelable = !!(pend && pend.estado !== "pagado");
    } else {
      e.cancelable = false;
    }
  });
  const saldoActual = all.filter((p) => p.estado !== "pagado").reduce((s, p) => s + (p.montoCents || 0), 0);

  // Ocultar notas (compras) 100% pagadas: igual que en clientes, solo en ESTA PC.
  // Quita de la vista y de la impresión el CARGO de cada compra pagada, su ABONO
  // de liquidación y los abonos parciales de esa compra, y recalcula el saldo
  // corrido anclado al saldo real (Saldo anterior + cargos − abonos visibles =
  // Saldo actual). No borra nada ni toca Supabase. Lo pendiente nunca se oculta.
  let movimientos = eventos;
  const ocultarPagadas = getOcultarPagadasProveedor(display);
  let saldoAnteriorCents = 0, ocultadas = 0;
  if (ocultarPagadas) {
    const pagadosIds = new Set(all.filter((p) => p.abonoDe == null && p.estado === "pagado").map((p) => Number(p.id)));
    const padreAbono = {}; // id de fila de abono parcial -> compra padre
    for (const p of all) if (p.abonoDe != null) padreAbono[Number(p.id)] = Number(p.abonoDe);
    const estaPagada = (e) => {
      if (e.tipo === "cargo") return pagadosIds.has(Number(e.id));
      // abono: de liquidación (mismo id que la compra) o parcial (por su padre)
      if (pagadosIds.has(Number(e.id))) return true;
      const padre = padreAbono[Number(e.id)];
      return padre != null && pagadosIds.has(padre);
    };
    const antes = movimientos.length;
    movimientos = movimientos.filter((e) => !estaPagada(e));
    ocultadas = antes - movimientos.length;
    const neto = (e) => (e.tipo === "cargo" ? (e.montoCents || 0) : -(e.montoCents || 0));
    const visNet = movimientos.reduce((s, e) => s + neto(e), 0);
    let corr = saldoActual - visNet; // saldo anterior (lo que traían las notas ocultas)
    saldoAnteriorCents = corr;
    movimientos.forEach((e) => { corr += neto(e); e.saldoCents = corr; });
  }
  return { proveedor: display, saldoCents: saldoActual, movimientos, ocultarPagadas, ocultadas, saldoAnteriorCents };
}

function abonarCreditoProveedor(proveedor, montoCents, formaPago, usuario, opts) {
  opts = opts || {};
  const fp = String(formaPago || "").toLowerCase();
  if (!["efectivo", "tarjeta", "transferencia", "efectivo_casa"].includes(fp)) {
    return { error: "Al abonar elige efectivo, tarjeta, transferencia o efectivo casa." };
  }
  // Efectivo casa: el dinero NO sale del cajón; baja la deuda pero no exige caja
  // abierta ni entra a caja/corte (solo queda en el estado de cuenta del proveedor).
  const esCasa = fp === "efectivo_casa";
  const st = estadoCajaInterno();
  if (!esCasa && !st.abierta) return { error: "Abre la caja para abonar. Así entra al corte de hoy." };
  const nombre = proveedorCanonico(proveedor);
  if (!nombre) return { error: "Elige el proveedor." };
  const pedido = Math.round(Number(montoCents) || 0);
  if (pedido <= 0) return { error: "Escribe un monto mayor a cero." };
  db.movimientosPendientes = Array.isArray(db.movimientosPendientes) ? db.movimientosPendientes : [];
  const key = nombre.toLowerCase();
  let lineas = db.movimientosPendientes
    .filter((x) => x.estado !== "pagado" && x.abonoDe == null && String(x.proveedor || "").trim().toLowerCase() === key)
    .sort((a, b) => String(a.fecha).localeCompare(String(b.fecha)) || ((a.id || 0) - (b.id || 0)));

  // Una compra, o solo las compras de un día (el conjunto). No toca otras deudas.
  if (opts.pendienteId != null) {
    const id = Number(opts.pendienteId);
    const una = lineas.find((x) => Number(x.id) === id);
    if (!una) return { error: "Esa compra ya no tiene saldo pendiente (elige otra o cancela)." };
    lineas = [una];
  } else if (Array.isArray(opts.pendienteIds) && opts.pendienteIds.length) {
    const ids = new Set(opts.pendienteIds.map((x) => Number(x)));
    lineas = lineas.filter((x) => ids.has(Number(x.id)));
    if (!lineas.length) return { error: "Ese día ya no tiene saldo pendiente." };
  }

  const deuda = lineas.reduce((s, x) => s + (x.montoCents || 0), 0);
  if (!lineas.length || deuda <= 0) return { error: "Ese proveedor no tiene adeudo." };
  if (pedido > deuda) {
    return {
      error: opts.pendienteId != null
        ? "El abono es mayor que el saldo de esa compra (" + (deuda / 100).toFixed(2) + ")."
        : "El abono es mayor que lo que se debe."
    };
  }
  let left = pedido;
  let pendId = Math.max(db.movimientosPendientes.reduce((m, x) => Math.max(m, x.id || 0), 0) || 0, Number(consumir("pendiente", 0)) || 0);
  let movId = esCasa ? 0 : Math.max(st.caja.movimientos.reduce((m, x) => Math.max(m, x.id || 0), 0) || 0, Number(consumir("movCaja", 0)) || 0);
  const cubiertos = [];
  const ahora = new Date().toISOString();
  for (const p of lineas) {
    if (left <= 0) break;
    const toma = Math.min(left, p.montoCents || 0);
    if (toma <= 0) continue;
    if (!esCasa) {
      movId += 1;
      st.caja.movimientos.push({
        id: movId, fecha: ahora, tipo: p.tipo || "retiro",
        montoCents: toma, motivo: opts.conjunto ? "Abono conjunto" : (p.motivo || "Abono a proveedor"), proveedor: p.proveedor || nombre,
        categoria: p.categoria || "compra", formaPago: fp, usuario: usuario || null,
        pendienteId: p.id
      });
    }
    if (toma >= (p.montoCents || 0)) {
      p.estado = "pagado";
      p.pagoFecha = ahora;
      p.pagoForma = fp;
      p.pagoCajaId = esCasa ? null : st.caja.id;
      p.pagoMovId = esCasa ? null : movId;
      cubiertos.push({ motivo: p.motivo || "", cantidad: p.cantidad, montoCents: toma, pendienteId: p.id });
    } else {
      p.montoCents = (p.montoCents || 0) - toma;
      pendId += 1;
      db.movimientosPendientes.push({
        id: pendId, fecha: p.fecha, tipo: p.tipo || "retiro",
        categoria: p.categoria || "compra",
        montoCents: toma, motivo: p.motivo || "", proveedor: p.proveedor || nombre,
        formaPago: "credito", cantidad: null, estado: "pagado",
        usuario: p.usuario || usuario || null,
        pagoFecha: ahora, pagoForma: fp, pagoCajaId: esCasa ? null : st.caja.id, pagoMovId: esCasa ? null : movId,
        abonoDe: p.id
      });
      cubiertos.push({ motivo: (p.motivo || "") + " (abono)", cantidad: null, montoCents: toma, pendienteId: p.id });
    }
    left -= toma;
  }
  const aplicado = pedido - left;
  const deudaTotalProv = db.movimientosPendientes
    .filter((x) => x.estado !== "pagado" && String(x.proveedor || "").trim().toLowerCase() === key)
    .reduce((s, x) => s + (x.montoCents || 0), 0);
  registrarMovimiento({
    tipo: "efectivo", usuario,
    detalle: `Abono a proveedor ${esCasa ? "efectivo casa" : fp} ${(aplicado / 100).toFixed(2)} — ${nombre}` +
      (opts.conjunto ? " (conjunto del día)" : (opts.pendienteId != null ? ` (compra #${opts.pendienteId})` : "")) +
      `. Saldo ${(deudaTotalProv / 100).toFixed(2)}`
  });
  persist();
  return {
    ok: true, proveedor: lineas[0].proveedor || nombre, formaPago: fp,
    aplicadoCents: aplicado, saldoCents: deudaTotalProv, lineas: cubiertos,
    destinoPendienteId: opts.pendienteId != null ? Number(opts.pendienteId) : null
  };
}

function cancelarMovimientoPendiente(id, usuario) {
  db.movimientosPendientes = Array.isArray(db.movimientosPendientes) ? db.movimientosPendientes : [];
  const idx = db.movimientosPendientes.findIndex((x) => Number(x.id) === Number(id));
  if (idx < 0) return { error: "No se encontró esa compra." };
  const p = db.movimientosPendientes[idx];
  if (p.estado === "pagado") return { error: "Ya está pagada. Si el pago es de este turno, cancélalo en los movimientos del turno." };
  anotarBaja("pendientes", p.id);
  db.movimientosPendientes.filter((x) => Number(x.abonoDe) === Number(id)).forEach((x) => anotarBaja("pendientes", x.id));
  db.movimientosPendientes.splice(idx, 1);
  // Quita abonos parciales sintéticos ligados a esa compra.
  db.movimientosPendientes = db.movimientosPendientes.filter((x) => Number(x.abonoDe) !== Number(id));
  registrarMovimiento({
    tipo: "efectivo", usuario,
    detalle: `Cancelación de pendiente a crédito ${((p.montoCents || 0) / 100).toFixed(2)} — ${p.motivo || ""}`
  });
  persist();
  return { ok: true };
}

// Cancela TODAS las compras pendientes (no pagadas) de un proveedor.
function cancelarCuentaProveedor(nombre, usuario, motivo) {
  db.movimientosPendientes = Array.isArray(db.movimientosPendientes) ? db.movimientosPendientes : [];
  const key = String(nombre || "").trim().toLowerCase();
  if (!key) return { error: "Elige el proveedor." };
  const quitar = db.movimientosPendientes.filter((x) =>
    String(x.proveedor || "").trim().toLowerCase() === key && x.estado !== "pagado" && x.abonoDe == null);
  if (!quitar.length) return { error: "Ese proveedor no tiene compras pendientes." };
  const ids = new Set(quitar.map((x) => Number(x.id)));
  const total = quitar.reduce((s, x) => s + (x.montoCents || 0), 0);
  db.movimientosPendientes.forEach((x) => {
    if (ids.has(Number(x.id)) || ids.has(Number(x.abonoDe))) anotarBaja("pendientes", x.id);
  });
  db.movimientosPendientes = db.movimientosPendientes.filter((x) =>
    !(String(x.proveedor || "").trim().toLowerCase() === key && (ids.has(Number(x.id)) || ids.has(Number(x.abonoDe)))));
  registrarMovimiento({
    tipo: "efectivo", usuario,
    detalle: `Cancelación de cuenta proveedor ${(total / 100).toFixed(2)} — ${nombre}${motivo ? " — " + motivo : ""}`
  });
  persist();
  return { ok: true, cancelados: quitar.length, totalCents: total };
}

// Cancela (elimina) un movimiento de efectivo capturado por error en el turno actual.
function cancelarMovimientoEfectivo(movId, usuario) {
  const st = estadoCajaInterno();
  if (!st.abierta) return { error: "No hay caja abierta." };
  const lista = st.caja.movimientos;
  const idx = lista.findIndex((m) => (m.id || 0) === Number(movId));
  if (idx < 0) return { error: "No se encontró el movimiento." };
  const m = lista[idx];
  anotarBaja("cajaMovs", st.caja.id + "|" + m.id);
  lista.splice(idx, 1);
  if (m.pendienteId != null) {
    db.movimientosPendientes = Array.isArray(db.movimientosPendientes) ? db.movimientosPendientes : [];
    const p = db.movimientosPendientes.find((x) => Number(x.id) === Number(m.pendienteId) && x.abonoDe == null);
    const hijo = db.movimientosPendientes.find((x) =>
      Number(x.abonoDe) === Number(m.pendienteId) && Number(x.pagoMovId) === Number(m.id));
    if (hijo) {
      if (p && p.estado !== "pagado") p.montoCents = (p.montoCents || 0) + (hijo.montoCents || 0);
      anotarBaja("pendientes", hijo.id);
      db.movimientosPendientes = db.movimientosPendientes.filter((x) => x !== hijo);
    } else if (p && p.estado === "pagado" && Number(p.pagoMovId) === Number(m.id)) {
      p.estado = "pendiente";
      p.pagoFecha = null;
      p.pagoForma = null;
      p.pagoCajaId = null;
      p.pagoMovId = null;
    }
  }
  registrarMovimiento({
    tipo: "efectivo", usuario,
    detalle: `Cancelación de ${m.tipo === "ingreso" ? "entrada" : "salida"} ${(m.montoCents / 100).toFixed(2)}${m.motivo ? " — " + m.motivo : ""}`
  });
  persist();
  return { ok: true };
}

function cerrarCaja(conteoCents, usuario, extras) {
  const st = estadoCajaInterno();
  if (!st.abierta) return { error: "No hay caja abierta." };
  const caja = st.caja;
  extras = extras || {};
  const basculaTotalManualCents = extras.basculaTotalManualCents != null
    ? Math.max(0, Math.round(Number(extras.basculaTotalManualCents) || 0))
    : null;
  const paquetesTotalManualCents = extras.paquetesTotalManualCents != null
    ? Math.max(0, Math.round(Number(extras.paquetesTotalManualCents) || 0))
    : null;
  // Dinero que FÍSICAMENTE queda en el cajón al cerrar (puede salir dinero
  // fuera de turno antes del siguiente fondo). Informativo; NO es el fondo de mañana.
  const dineroEnCajaCierreCents = extras.dineroEnCajaCierreCents != null
    ? Math.max(0, Math.round(Number(extras.dineroEnCajaCierreCents) || 0))
    : (conteoCents || 0);
  const entregadoCents = extras.entregadoCents != null
    ? Math.max(0, Math.round(Number(extras.entregadoCents) || 0))
    : null;

  caja.abierta = false;
  caja.cierreFecha = new Date().toISOString();
  caja.conteoCents = conteoCents || 0;
  caja.dineroEnCajaCierreCents = dineroEnCajaCierreCents;
  caja.entregadoCents = entregadoCents;
  caja.basculaTotalManualCents = basculaTotalManualCents;
  caja.paquetesTotalManualCents = paquetesTotalManualCents;
  caja.corte = snapshotCorteDesdeEstado(st, caja);
  if (caja.corte) {
    caja.corte.conteoCents = caja.conteoCents;
    caja.corte.diferenciaCents = caja.conteoCents - st.efectivoEsperado;
    caja.corte.dineroEnCajaCierreCents = dineroEnCajaCierreCents;
    caja.corte.entregadoCents = entregadoCents;
    caja.corte.basculaTotalManualCents = basculaTotalManualCents;
    caja.corte.paquetesTotalManualCents = paquetesTotalManualCents;
  }
  caja.ticketImpresion = ticketImpresionDesdeSnapshot({
    id: caja.id, usuario, cierreFecha: caja.cierreFecha, abierta: false,
    corte: caja.corte, creditos: caja.corte && caja.corte.creditosLista,
    creditoVentas: st.creditoVentas, creditoDev: st.creditoDev
  });
  db.config.cajaActualId = null;
  registrarMovimiento({
    tipo: "caja", usuario,
    detalle: `Cierre de caja. Esperado ${(st.efectivoEsperado / 100).toFixed(2)}, contado ${(caja.conteoCents / 100).toFixed(2)}, queda en caja ${(dineroEnCajaCierreCents / 100).toFixed(2)}, se entregó ${entregadoCents != null ? (entregadoCents / 100).toFixed(2) : "s/c"}`
  });
  persist();
  return { ok: true, corte: caja.corte, cierreFecha: caja.cierreFecha };
}

/* ---------- Inventario ---------- */
function getInventario() {
  return db.productos.map((p) => ({
    id: p.id, cat: p.cat, nombre: p.nombre, unidad: p.unidad,
    precioCents: p.precioCents, existencia: p.existencia || 0, stockMin: p.stockMin || 0,
    controlaInventario: !!p.controlaInventario
  }));
}

// Imágenes de producto (miniaturas dataURL) para el menú de ventas.
function getImagenesProducto() {
  return Object.assign({}, db.imagenesProducto || {});
}
function setImagenProducto(productoId, dataURL) {
  db.imagenesProducto = db.imagenesProducto || {};
  const key = String(productoId);
  if (dataURL) db.imagenesProducto[key] = dataURL;
  else delete db.imagenesProducto[key];
  persist();
  return { ok: true };
}

function movimientoInventario(productoId, tipo, cant, nota, usuario) {
  const p = db.productos.find((x) => x.id === productoId);
  if (!p) return { error: "Producto no encontrado." };
  cant = Number(cant) || 0;
  if (tipo === "entrada") {
    if (cant <= 0) return { error: "La cantidad a agregar debe ser mayor a cero." };
    p.existencia = r3((p.existencia || 0) + cant);
  } else if (tipo === "salida") {
    if (cant <= 0) return { error: "La cantidad a restar debe ser mayor a cero." };
    p.existencia = r3((p.existencia || 0) - cant);
  } else if (tipo === "ajuste") {
    if (cant < 0) return { error: "La existencia no puede ser negativa." };
    p.existencia = r3(cant);
  } else {
    return { error: "Tipo de movimiento inválido." };
  }
  db.movimientosInv.push({ fecha: new Date().toISOString(), productoId, tipo, cant, existencia: p.existencia, nota: nota || "", usuario: usuario || null });
  registrarMovimiento({ tipo: "inventario", usuario, detalle: `${tipo} ${cant} ${p.unidad} de ${p.nombre}` });
  persist();
  return { ok: true, existencia: p.existencia };
}

/* ---------- Devoluciones ---------- */
function registrarDevolucion(dev) {
  // El efectivo devuelto sale del cajón del turno actual: debe existir una caja abierta
  // para que la devolución quede contabilizada en su corte (cuentas exactas).
  if (!db.config.cajaActualId) {
    return { error: "Abre la caja antes de registrar una devolución para que quede en el corte del turno." };
  }
  const folio = Number(consumir("folioDevolucion", db.config.folioDevolucion || 1)) || 1;
  const registro = {
    folio,
    fecha: new Date().toISOString(),
    cajaId: db.config.cajaActualId || null,
    ...dev
  };
  db.devoluciones.push(registro);
  db.config.folioDevolucion = folio + 1;

  // Regresar los productos devueltos al inventario (solo los que controlan inventario)
  for (const it of (dev.items || [])) {
    if (it.tipo === "producto" && it.productoId) {
      const p = db.productos.find((x) => x.id === it.productoId);
      if (p && p.controlaInventario) {
        p.existencia = r3((p.existencia || 0) + (it.cant || 0));
        db.movimientosInv.push({
          fecha: registro.fecha, productoId: p.id, tipo: "devolucion",
          cant: it.cant, existencia: p.existencia, folio, usuario: dev.usuario || null
        });
      }
    }
  }

  registrarMovimiento({
    tipo: "devolucion", usuario: dev.usuario || null,
    detalle: `Devolución folio ${folio} por ${(registro.totalCents / 100).toFixed(2)} (${dev.pago || "s/pago"})`
  });
  persist();
  return { folio, fecha: registro.fecha };
}

// Detalle de un día: totales por método (netos de devoluciones) y las
// líneas de productos vendidos/devueltos para el desglose al hacer clic.
function detalleDia(fechaISO) {
  const dia = (fechaISO || localDay(new Date().toISOString())).slice(0, 10);
  const metodos = {};
  const ensure = (m) => (metodos[m] || (metodos[m] = {
    ventasCents: 0, devolucionesCents: 0, netoCents: 0, numVentas: 0, ventas: [], devoluciones: [],
    abonosCents: 0, abonos: []
  }));
  let totalVentas = 0, totalDev = 0, numVentas = 0, apartadosCents = 0;
  let creditoVentas = 0, creditoDev = 0;
  const creditos = [];

  // Devuelto por folio de venta (para marcar la venta devuelta en el detalle).
  const devPorVentaFolio = {};
  for (const d of (db.devoluciones || [])) {
    if (localDay(d.fecha) !== dia) continue;
    if (d.ventaFolio == null) continue;
    devPorVentaFolio[d.ventaFolio] = (devPorVentaFolio[d.ventaFolio] || 0) + (d.totalCents || 0);
  }

  for (const v of db.ventas) {
    if (localDay(v.fecha) !== dia) continue;
    if (!ventaCuentaEnCorte(v)) continue;
    totalVentas += v.totalCents || 0;
    numVentas++;
    if (v.esApartadoPago) apartadosCents += v.totalCents || 0;
    const hora = new Date(v.fecha).toLocaleTimeString("es-MX");
    const pagos = desglosePagos(v); // [{metodo, montoCents}] — reparte el combinado
    const combinado = v.pago === "combinado" && pagos.length > 1;
    const items = (v.items || []).map((it) => ({
      nombre: it.nombre, cant: it.cant, unidad: it.unidad,
      importeCents: it.importeCents, tipo: it.tipo
    }));
    const devueltoCents = devPorVentaFolio[v.folio] || 0;
    const creditoCents = pagos
      .filter((p) => String(p.metodo || "").toLowerCase() === "credito")
      .reduce((s, p) => s + (p.montoCents || 0), 0);
    if (creditoCents > 0) {
      creditoVentas += creditoCents;
      creditos.push({ folio: v.folio, cliente: nombreClienteVenta(v), montoCents: creditoCents, hora });
    }
    // El pago combinado NO forma su propia categoría: cada porción entra a su
    // método real (efectivo, tarjeta, transferencia, etc.).
    for (const p of pagos) {
      const m = ensure(p.metodo || "otro");
      m.ventasCents += p.montoCents || 0;
      m.numVentas++;
      m.ventas.push({
        folio: v.folio, hora, montoCents: p.montoCents || 0, cliente: v.cliente || "",
        pago: v.pago, combinado, apartado: !!v.esApartadoPago,
        devueltoCents, devuelta: devueltoCents >= (v.totalCents || 0) && devueltoCents > 0,
        comboDesglose: combinado ? pagos.map((x) => ({ metodo: x.metodo, montoCents: x.montoCents })) : null,
        items
      });
    }
  }

  for (const d of (db.devoluciones || [])) {
    if (localDay(d.fecha) !== dia) continue;
    const m = ensure(d.pago || "otro");
    m.devolucionesCents += d.totalCents || 0;
    totalDev += d.totalCents || 0;
    if (String(d.pago || "").toLowerCase() === "credito") creditoDev += d.totalCents || 0;
    const hora = new Date(d.fecha).toLocaleTimeString("es-MX");
    m.devoluciones.push({
      folio: d.folio, ventaFolio: d.ventaFolio || null, hora,
      montoCents: d.totalCents || 0, motivo: d.motivo || "",
      items: (d.items || []).map((it) => ({
        nombre: it.nombre, cant: it.cant, unidad: it.unidad, importeCents: it.importeCents
      }))
    });
  }

  // Cancelaciones del día (la báscula las cuenta como venta; aquí van al diferido).
  const basFolio = (v) => v.origenBascula ? v.origenBascula.folio : (v.basculaFolio != null ? v.basculaFolio : null);
  const cancelaciones = [];
  let totalCancel = 0;
  for (const v of db.ventas) {
    if (localDay(v.fecha) !== dia && localDay(v.canceladaFecha || v.fecha) !== dia) continue;
    if (!v.cancelada) continue;
    const monto = v.totalCents || 0;
    totalCancel += monto;
    cancelaciones.push({
      folio: v.folio, hora: new Date(v.canceladaFecha || v.fecha).toLocaleTimeString("es-MX"),
      montoCents: monto, motivo: v.canceladaMotivo || "", basculaFolio: basFolio(v),
      esBascula: !!(v.origenBascula || v.basculaFolio != null),
      items: (v.items || []).map((it) => ({ nombre: it.nombre, cant: it.cant, unidad: it.unidad, importeCents: it.importeCents }))
    });
  }

  // Lista plana de devoluciones del día (para el apartado de diferido).
  const devolucionesLista = (db.devoluciones || [])
    .filter((d) => localDay(d.fecha) === dia)
    .map((d) => ({ folio: d.folio, ventaFolio: d.ventaFolio || null, montoCents: d.totalCents || 0, motivo: d.motivo || "" }));

  // Abonos a crédito cobrados en el día (van en su propio apartado del corte).
  const abonos = [];
  let totalAbonos = 0, totalAbonosOtros = 0;
  for (const caja of (db.cajas || [])) {
    for (const m of (caja.movimientos || [])) {
      if (m.tipo === "ingreso" && m.categoria === "abono" && localDay(m.fecha) === dia) {
        const fp = String(m.formaPago || "efectivo").trim().toLowerCase();
        // Efectivo casa no va en el corte del día ni en su ticket.
        if (fp === "ajuste" || fp === "credito" || fp === "efectivo_casa") continue;
        if (fp === "efectivo" || fp === "dolares") totalAbonos += m.montoCents || 0;
        else totalAbonosOtros += m.montoCents || 0;
        const hora = new Date(m.fecha).toLocaleTimeString("es-MX");
        abonos.push({ motivo: m.motivo || "", montoCents: m.montoCents || 0, hora, cliente: m.cliente || "", formaPago: fp });
        // Cada abono suma al total de SU forma de pago para cuadrar con terminal/caja.
        const em = ensure(fp);
        em.abonosCents += m.montoCents || 0;
        em.abonos.push({ cliente: m.cliente || "", montoCents: m.montoCents || 0, hora });
      }
    }
  }

  // El neto por método incluye los abonos de esa forma de pago (así "Tarjeta"
  // cuadra con la terminal: ventas − devoluciones + abonos con tarjeta).
  Object.values(metodos).forEach((m) => { m.netoCents = m.ventasCents - m.devolucionesCents + (m.abonosCents || 0); });
  return {
    dia, metodos,
    totalVentasCents: totalVentas,
    totalDevolucionesCents: totalDev,
    ventasCobradasCents: totalVentas - creditoVentas,
    devCobradasCents: totalDev - creditoDev,
    totalNetoCents: (totalVentas - creditoVentas) - (totalDev - creditoDev),
    creditoVentasCents: creditoVentas,
    creditoDevCents: creditoDev,
    creditos,
    apartadosCents,
    numVentas,
    cancelaciones, totalCancelacionesCents: totalCancel,
    devolucionesLista,
    abonos, totalAbonosCents: totalAbonos, totalAbonosOtrosCents: totalAbonosOtros,
    diferidoBasculaCents: totalCancel + totalDev,
    // Total de báscula (manual) capturado al cerrar las cajas de ese día (para el
    // comparativo "categorías + báscula" del corte). Null si no se capturó.
    basculaTotalManualCents: (() => {
      const arr = (db.cajas || []).filter((c) => c.corte && localDay(c.cierreFecha || c.aperturaFecha) === dia && c.basculaTotalManualCents != null);
      return arr.length ? arr.reduce((s, c) => s + (c.basculaTotalManualCents || 0), 0) : null;
    })(),
    paquetesTotalManualCents: (() => {
      const arr = (db.cajas || []).filter((c) => c.corte && localDay(c.cierreFecha || c.aperturaFecha) === dia && c.paquetesTotalManualCents != null);
      return arr.length ? arr.reduce((s, c) => s + (c.paquetesTotalManualCents || 0), 0) : null;
    })(),
    ventasPorDepto: sumarVentasPorDepto(db.ventas.filter((v) => localDay(v.fecha) === dia && ventaCuentaEnCorte(v))),
    carnesBascula: sumarCarnesBascula(db.ventas.filter((v) => localDay(v.fecha) === dia && ventaCuentaEnCorte(v)))
  };
}

/* ---------- Configuración (negocio / impresora) ---------- */
function getConfig() {
  return {
    negocio: db.config.negocio,
    impresora: db.config.impresora,
    ticket: db.config.ticket,
    respaldo: getRespaldoConfig(),
    supabase: getSupabaseConfig(),
    actualizaciones: mezclarActualizaciones(db.config.actualizaciones),
    bascula: db.config.bascula,
    factura: db.config.factura || defaultFactura(),
    permisos: db.config.permisos || { inventarioSoloAdmin: true },
    terminal: db.config.terminal,
    configurado: !!db.config.configurado
  };
}

// Marca que el sistema ya pasó por la configuración inicial (primer inicio).
function marcarConfigurado() {
  db.config.configurado = true;
  persist();
  return { ok: true };
}

function setConfig(parcial) {
  if (parcial && parcial.negocio) db.config.negocio = Object.assign({}, db.config.negocio, parcial.negocio);
  if (parcial && parcial.impresora) db.config.impresora = Object.assign({}, db.config.impresora, parcial.impresora);
  if (parcial && parcial.ticket) db.config.ticket = Object.assign({}, db.config.ticket, parcial.ticket);
  if (parcial && parcial.respaldo) db.config.respaldo = Object.assign({}, db.config.respaldo, parcial.respaldo);
  if (parcial && parcial.supabase) db.config.supabase = Object.assign({}, db.config.supabase, parcial.supabase);
  if (parcial && parcial.actualizaciones) db.config.actualizaciones = mezclarActualizaciones(Object.assign({}, db.config.actualizaciones, parcial.actualizaciones));
  if (parcial && parcial.bascula) db.config.bascula = Object.assign({}, db.config.bascula, parcial.bascula);
  if (parcial && parcial.factura) {
    const f = Object.assign({}, db.config.factura, parcial.factura);
    if (parcial.factura.ws) f.ws = Object.assign({}, (db.config.factura || {}).ws, parcial.factura.ws);
    if (parcial.factura.correo) f.correo = Object.assign({}, (db.config.factura || {}).correo, parcial.factura.correo);
    if (parcial.factura.whatsapp) f.whatsapp = Object.assign({}, (db.config.factura || {}).whatsapp, parcial.factura.whatsapp);
    db.config.factura = f;
  }
  if (parcial && parcial.permisos) db.config.permisos = Object.assign({}, db.config.permisos, parcial.permisos);
  if (parcial && typeof parcial.terminal === "string") db.config.terminal = parcial.terminal;
  persist();
  return getConfig();
}

/* ---------- Tipo de cambio del dólar (cache diario) ----------
   Guarda el último tipo de cambio USD→MXN obtenido de internet, para tenerlo
   disponible aunque luego no haya conexión. */
function setFxCache(obj) {
  obj = obj || {};
  db.config.fxUSD = { rate: Number(obj.rate) || 0, dia: obj.dia || "", fuente: obj.fuente || "" };
  persist();
  return { ok: true };
}
function getFxCache() { return db.config.fxUSD || null; }

/* ---------- Integración báscula (Scale Link): control de ventas ya vistas ---------- */
// Guarda qué ventas de la báscula ya se importaron (por su clave única) para
// no volver a crear tickets repetidos.
function getBasculaVistas() {
  return Object.assign({}, db.basculaVistas || {});
}
// Marca claves como vistas. `crearTicket=false` sirve para la línea base
// inicial (marcar el histórico existente sin generar tickets).
function marcarBasculaVistas(keys) {
  if (!keys || !keys.length) return { ok: true };
  db.basculaVistas = db.basculaVistas || {};
  const ahora = new Date().toISOString();
  for (const k of keys) db.basculaVistas[k] = ahora;
  // Poda: conserva como máximo las últimas ~5000 claves.
  const ent = Object.entries(db.basculaVistas);
  if (ent.length > 5000) {
    ent.sort((a, b) => String(a[1]).localeCompare(String(b[1])));
    db.basculaVistas = {};
    for (const [k, v] of ent.slice(ent.length - 5000)) db.basculaVistas[k] = v;
  }
  persist();
  return { ok: true };
}
function reiniciarBasculaVistas() {
  db.basculaVistas = {};
  persist();
  return { ok: true };
}

// Resumen de las ventas de origen báscula tal como quedaron en el SISTEMA,
// indexado por la clave de la venta de báscula (origenBascula.key). Incluye el
// total realmente cobrado, si fue cancelada y cuánto se devolvió, para poder
// cuadrar el corte de la báscula contra el corte del sistema.
function resumenBasculaCorte() {
  const devPorFolio = {};
  for (const d of (db.devoluciones || [])) {
    if (d.ventaFolio == null) continue;
    devPorFolio[d.ventaFolio] = (devPorFolio[d.ventaFolio] || 0) + (d.totalCents || 0);
  }
  const map = {};
  for (const v of db.ventas) {
    const ob = v.origenBascula;
    if (!ob || !ob.key) continue;
    const devuelto = devPorFolio[v.folio] || 0;
    map[ob.key] = {
      posFolio: v.folio,
      basculaFolio: ob.folio != null ? ob.folio : null,
      nserie: ob.nserie || "",
      totalCents: v.totalCents || 0,
      cancelada: !!v.cancelada,
      devueltoCents: devuelto,
      netoCents: v.cancelada ? 0 : ((v.totalCents || 0) - devuelto),
      fecha: v.fecha || null
    };
  }
  return map;
}

// Tickets de báscula y “Producto común” de un día, para imprimir el corte
// comparativo cuando la báscula ya no tiene ese turno en memoria.
function detalleCorteBasculaDia(fechaISO) {
  const dia = (fechaISO || localDay(new Date().toISOString())).slice(0, 10);
  const tickets = [];
  const comunes = [];
  let ticketsCents = 0;
  let comunCents = 0;
  for (const v of db.ventas || []) {
    if (localDay(v.fecha) !== dia || v.cancelada) continue;
    const cred = montoMetodo(v, "credito");
    const cob = Math.max(0, (v.totalCents || 0) - cred);
    if (cob <= 0) continue;
    const items = v.items || [];
    const base = items.reduce((s, it) => s + (it.importeCents || 0), 0) || v.totalCents || 1;
    let left = cob;
    items.forEach((it, i) => {
      let part;
      if (cred <= 0) part = it.importeCents || 0;
      else if (i === items.length - 1) part = left;
      else {
        part = Math.min(left, Math.round((it.importeCents || 0) * cob / base));
        left -= part;
      }
      const nom = String((it && it.nombre) || "");
      const esFolio = /b[aá]scula\s*folio/i.test(nom);
      const esComun = /producto com[uú]n/i.test(nom);
      if (esFolio || it.bascula || esVentaBascula(v)) {
        const m = nom.match(/folio\s*(\d+)/i);
        tickets.push({
          posFolio: v.folio,
          etiqueta: nom || ("Báscula " + (v.basculaFolio != null ? v.basculaFolio : v.folio)),
          folioBascula: m ? m[1] : (v.basculaFolio != null ? String(v.basculaFolio) : ""),
          cents: part,
          hora: v.fecha
        });
        ticketsCents += part;
      } else if (esComun) {
        comunes.push({ posFolio: v.folio, cents: part, hora: v.fecha });
        comunCents += part;
      }
    });
  }
  const d = detalleDia(dia);
  const cb = d.carnesBascula || { montoCents: 0 };
  return {
    dia,
    tickets,
    ticketsCents,
    comunes,
    comunCents,
    carnesBasculaCents: cb.montoCents || 0,
    categoriasCents: (d.ventasPorDepto || []).reduce((s, x) => s + (x.montoCents || 0), 0),
    cobradoCents: d.ventasCobradasCents || 0,
    basculaManualCents: d.basculaTotalManualCents,
    paquetesManualCents: d.paquetesTotalManualCents,
    diferidoCents: d.diferidoBasculaCents || 0,
    cancelaciones: d.cancelaciones || [],
    diferenciaCents: (d.basculaTotalManualCents != null
      ? ((d.ventasPorDepto || []).reduce((s, x) => s + (x.montoCents || 0), 0) + d.basculaTotalManualCents + (d.paquetesTotalManualCents || 0)) - (d.ventasCobradasCents || 0)
      : null)
  };
}

/* ---------- Usuarios ---------- */
function renombrarUsuario(id, nombre, pinActual) {
  const u = db.usuarios.find((x) => x.id === id);
  if (!u) return { error: "Usuario no encontrado." };
  // Para cambiar el nombre (incluido el Administrador) se pide la contraseña.
  if (String(pinActual || "") !== String(u.pin)) return { error: "La contraseña no es correcta." };
  nombre = String(nombre || "").trim();
  if (!nombre) return { error: "El nombre no puede quedar vacío." };
  u.nombre = nombre;
  persist();
  return { ok: true, usuarios: db.usuarios.map((x) => ({ id: x.id, nombre: x.nombre, rol: x.rol, pin: x.pin })) };
}

function guardarProducto(prod) {
  if (prod.id) {
    const i = db.productos.findIndex((p) => p.id === prod.id);
    if (i >= 0) {
      const prev = db.productos[i];
      const next = { ...prev, ...prod };
      // Un guardado parcial (precio, panel, nombre) NUNCA pisa existencias
      // ni apaga el control de inventario si no vino en el payload.
      if (!Object.prototype.hasOwnProperty.call(prod, "existencia")) next.existencia = prev.existencia;
      if (!Object.prototype.hasOwnProperty.call(prod, "controlaInventario")) next.controlaInventario = prev.controlaInventario;
      if (next.controlaInventario && (next.existencia === undefined || next.existencia === null)) {
        next.existencia = prev.existencia || 0;
      }
      db.productos[i] = next;
    }
  } else {
    const nuevoId = Number(consumir("producto", db.productos.reduce((m, p) => Math.max(m, p.id), 0) + 1));
    const controla = prod.controlaInventario !== undefined ? !!prod.controlaInventario : controlaInvCat(prod.cat);
    const nuevo = { id: nuevoId, activo: true, manual: true, existencia: 0, stockMin: 0, controlaInventario: controla, ...prod };
    Object.assign(nuevo, defaultsSatProducto(nuevo));
    db.productos.push(nuevo);
  }
  persist();
  return db.productos;
}

function eliminarProducto(id) {
  const p = db.productos.find((x) => x.id === id);
  if (!p) return { error: "Producto no encontrado." };
  anotarBaja("productos", p.id);
  db.productos = db.productos.filter((x) => x.id !== id);
  persist();
  return { ok: true, productos: db.productos };
}

/* ---------- Categorías ---------- */
function _slug(s) {
  return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 24) || "cat";
}
function guardarCategoria(cat) {
  const nombre = String(cat.nombre || "").trim();
  if (!nombre) return { error: "Escribe un nombre de categoría." };
  const emoji = (cat.emoji || "🥩").trim() || "🥩";
  if (cat.id) {
    const c = db.categorias.find((x) => x.id === cat.id);
    if (!c) return { error: "Categoría no encontrada." };
    c.nombre = nombre; c.emoji = emoji;
  } else {
    let id = _slug(nombre), base = id, n = 2;
    while (db.categorias.some((x) => x.id === id)) id = base + "-" + (n++);
    const orden = (db.categorias.reduce((m, x) => Math.max(m, x.orden || 0), 0) || 0) + 1;
    db.categorias.push({ id, nombre, emoji, orden });
  }
  persist();
  return { ok: true, categorias: db.categorias };
}
/* ---------- Clientes ---------- */
function _clienteNorm(c) {
  return {
    id: c.id, nombre: c.nombre || "", telefono: c.telefono || "", rfc: c.rfc || "",
    direccion: c.direccion || "", notas: c.notas || "",
    email: c.email || "", regimenFiscal: c.regimenFiscal || "",
    usoCfdi: c.usoCfdi || "", codigoPostal: c.codigoPostal || "",
    creditoActivo: !!c.creditoActivo, limiteCents: c.limiteCents || 0,
    // Solo esta PC: no se sube a Supabase ni llega a la otra terminal.
    clienteCasa: !!c.clienteCasa,
    saldoCents: c.saldoCents || 0, movimientos: Array.isArray(c.movimientos) ? c.movimientos : []
  };
}
function esClienteCasa(c) {
  return !!(c && c.clienteCasa);
}
function getClientes() {
  return (db.clientes || []).map((c) => ({ ...c, saldoCents: c.saldoCents || 0, clienteCasa: !!c.clienteCasa }));
}
function guardarCliente(cli) {
  const nombre = String(cli.nombre || "").trim();
  if (!nombre) return { error: "Escribe un nombre de cliente." };
  if (cli.id) {
    const c = db.clientes.find((x) => x.id === cli.id);
    if (!c) return { error: "Cliente no encontrado." };
    Object.assign(c, {
      nombre, telefono: cli.telefono || "", rfc: cli.rfc || "", direccion: cli.direccion || "",
      notas: cli.notas || "", email: cli.email || "", regimenFiscal: cli.regimenFiscal || "",
      usoCfdi: cli.usoCfdi || "", codigoPostal: cli.codigoPostal || "",
      creditoActivo: !!cli.creditoActivo, limiteCents: cli.limiteCents || 0,
      clienteCasa: !!cli.clienteCasa
    });
  } else {
    const id = Number(consumir("cliente", (db.clientes.reduce((m, x) => Math.max(m, x.id || 0), 0) || 0) + 1));
    db.clientes.push(_clienteNorm({ ...cli, id, nombre, saldoCents: 0, movimientos: [] }));
  }
  persist();
  return { ok: true, clientes: getClientes() };
}
function eliminarCliente(id) {
  const c = db.clientes.find((x) => x.id === id);
  if (!c) return { error: "Cliente no encontrado." };
  if ((c.saldoCents || 0) > 0) return { error: "El cliente tiene saldo pendiente. Salda su cuenta antes de eliminarlo." };
  anotarBaja("clientes", c.id);
  db.clientes = db.clientes.filter((x) => x.id !== id);
  if (db.historialPantallaClientes) delete db.historialPantallaClientes[String(id)];
  persist();
  return { ok: true, clientes: getClientes() };
}

// Marca un corte visual: en pantalla se ocultan abonos anteriores a esta fecha.
// NO borra movimientos ni deja de sincronizarlos a Supabase.
function limpiarHistorialPantallaCliente(id) {
  const c = db.clientes.find((x) => x.id === Number(id));
  if (!c) return { error: "Cliente no encontrado." };
  db.historialPantallaClientes = db.historialPantallaClientes || {};
  const desde = new Date().toISOString();
  db.historialPantallaClientes[String(c.id)] = desde;
  persist();
  return { ok: true, desde, clientes: getClientes() };
}
function getHistorialPantallaDesde(id) {
  const mapa = db.historialPantallaClientes || {};
  return mapa[String(id)] || null;
}
// Ocultar notas ya pagadas en el estado de cuenta (bandera LOCAL por cliente;
// no se sube a Supabase ni afecta a otras PCs). Es reversible.
function getOcultarPagadasCliente(id) {
  const mapa = db.ocultarPagadasClientes || {};
  return !!mapa[String(id)];
}
function setOcultarPagadasCliente(id, valor) {
  const c = db.clientes.find((x) => x.id === Number(id));
  if (!c) return { error: "Cliente no encontrado." };
  db.ocultarPagadasClientes = db.ocultarPagadasClientes || {};
  if (valor) db.ocultarPagadasClientes[String(c.id)] = true;
  else delete db.ocultarPagadasClientes[String(c.id)];
  persist();
  return { ok: true, activo: !!valor };
}
// Igual que lo anterior, pero para PROVEEDORES (bandera LOCAL por nombre de
// proveedor; no se sube a Supabase ni afecta a otras PCs). Reversible.
function getOcultarPagadasProveedor(nombre) {
  const mapa = db.ocultarPagadasProveedores || {};
  return !!mapa[String(nombre || "").trim().toLowerCase()];
}
function setOcultarPagadasProveedor(nombre, valor) {
  const key = String(nombre || "").trim().toLowerCase();
  if (!key) return { error: "Proveedor no válido." };
  db.ocultarPagadasProveedores = db.ocultarPagadasProveedores || {};
  if (valor) db.ocultarPagadasProveedores[key] = true;
  else delete db.ocultarPagadasProveedores[key];
  persist();
  return { ok: true, activo: !!valor };
}
// Devuelve el Set de índices de movimientos que corresponden a notas 100%
// pagadas: los CARGOS saldados y los ABONOS cuyas aplicaciones cayeron todas en
// notas saldadas. (Los abonos que tocan alguna nota aún pendiente se conservan;
// el "saldo anterior" reconcilia el resto.)
function movimientosDeNotasPagadas(c) {
  const ventas = ventasCreditoCliente(c);
  const foliosPagados = new Set();
  const movIdxPagados = new Set();
  for (const v of ventas) {
    const pend = Math.max(0, (v.totalCents || 0) - (v.pagadoCents || 0));
    if (pend <= 0) {
      if (v.folio != null) foliosPagados.add(Number(v.folio));
      if (v.movIndex != null) movIdxPagados.add(Number(v.movIndex));
    }
  }
  const apPagada = (ap) => {
    if (!ap) return false;
    if (ap.folio != null) return foliosPagados.has(Number(ap.folio));
    if (ap.movIndex != null) return movIdxPagados.has(Number(ap.movIndex));
    return false;
  };
  const ocultar = new Set();
  (c.movimientos || []).forEach((m, i) => {
    if (m.tipo === "cargo") {
      const pagada = (m.ventaFolio != null) ? foliosPagados.has(Number(m.ventaFolio)) : movIdxPagados.has(i);
      if (pagada) ocultar.add(i);
    } else if (m.tipo === "abono") {
      const aps = Array.isArray(m.aplicaciones) ? m.aplicaciones : [];
      if (aps.length && aps.every(apPagada)) ocultar.add(i);
    }
  });
  return ocultar;
}
// tipo: "cargo" (aumenta deuda) | "abono" (paga deuda) | "cancelacion" (anula el adeudo)
function nuevoUid() {
  return "ec-" + Date.now().toString(36) + "-" + Math.floor(Math.random() * 1e9).toString(36);
}
function _uidMov(m, i) {
  if (m && m.uid) return String(m.uid);
  return "m-" + String(m && m.fecha || "") + "-" + String(m && m.tipo || "") + "-" + String(m && m.montoCents || 0) + "-" + i;
}
function _filaEfectivoCasa(o) {
  const c = o.cliente || {};
  return {
    id: o.id,
    clienteId: c.id != null ? Number(c.id) : (o.clienteId != null ? Number(o.clienteId) : null),
    clienteNombre: c.nombre || o.clienteNombre || "",
    fecha: o.fecha || new Date().toISOString(),
    montoCents: Math.max(0, Math.round(o.montoCents || 0)),
    saldoCents: Math.max(0, Math.round(o.saldoCents || 0)),
    comentario: o.comentario || "",
    nota: o.nota || "",
    aplicaciones: Array.isArray(o.aplicaciones) ? o.aplicaciones : [],
    usuario: o.usuario || null,
    cajaId: o.cajaMov && o.cajaMov.cajaId != null ? o.cajaMov.cajaId : (o.cajaId != null ? o.cajaId : null),
    activo: o.activo !== false
  };
}
function registrarEfectivoCasa(fila) {
  db.efectivoCasa = Array.isArray(db.efectivoCasa) ? db.efectivoCasa : [];
  if (!fila || !fila.id) return;
  const i = db.efectivoCasa.findIndex((x) => x && x.id === fila.id);
  if (i >= 0) db.efectivoCasa[i] = Object.assign({}, db.efectivoCasa[i], fila);
  else db.efectivoCasa.push(fila);
}
function marcarEfectivoCasaInactivo(uid) {
  if (!uid) return;
  const ec = (db.efectivoCasa || []).find((x) => x && x.id === uid);
  if (ec) ec.activo = false;
}
function getEfectivoCasa() {
  return (db.efectivoCasa || []).slice();
}
// Rellena el espejo local desde abonos ya guardados (no toca crédito ni caja).
function migrarEfectivoCasaDesdeMovimientos() {
  db.efectivoCasa = Array.isArray(db.efectivoCasa) ? db.efectivoCasa : [];
  const vistos = new Set(db.efectivoCasa.map((x) => x && x.id).filter(Boolean));
  for (const c of (db.clientes || [])) {
    (c.movimientos || []).forEach((m, i) => {
      if (!m || m.tipo !== "abono" || m.formaPago !== "efectivo_casa") return;
      const id = m.uid || _uidMov(m, i);
      if (vistos.has(id)) return;
      vistos.add(id);
      db.efectivoCasa.push(_filaEfectivoCasa({
        id, cliente: c, montoCents: m.montoCents, saldoCents: m.saldoCents,
        fecha: m.fecha, comentario: m.comentario, nota: m.nota,
        aplicaciones: m.aplicaciones, usuario: m.usuario, cajaMov: m.cajaMov, activo: true
      }));
    });
  }
}

function movimientoCredito(id, tipo, montoCents, nota, usuario, formaPago) {
  // Un abono ya cayó en caja (efectivo/tarjeta/transferencia): entra al corte
  // del método, aunque no liquide toda la deuda.
  if (tipo === "abono") {
    return abonarCredito(id, montoCents, {
      destino: "todas", comentario: nota || "",
      formaPago: formaPago || "efectivo", usuario
    });
  }
  const c = db.clientes.find((x) => x.id === id);
  if (!c) return { error: "Cliente no encontrado." };
  montoCents = Math.max(0, Math.round(montoCents || 0));
  if (!Array.isArray(c.movimientos)) c.movimientos = [];
  const saldoPrev = c.saldoCents || 0;
  if (tipo === "cancelacion") {
    // Anula el adeudo pendiente completo (solo si la UI lo pidió explícitamente).
    if (saldoPrev <= 0) return { error: "El cliente no tiene adeudo por cancelar." };
    montoCents = saldoPrev;
    c.saldoCents = 0;
  } else if (!montoCents) {
    return { error: "Escribe un monto válido." };
  } else if (tipo === "cargo") c.saldoCents = saldoPrev + montoCents;
  else if (tipo === "abono") c.saldoCents = Math.max(0, saldoPrev - montoCents);
  else return { error: "Movimiento inválido." };
  c.movimientos.push({ uid: nuevoUid(), fecha: new Date().toISOString(), tipo, montoCents, saldoCents: c.saldoCents, nota: nota || "", usuario: usuario || null });
  registrarMovimiento({ tipo: "credito", usuario, detalle: `${tipo} ${(montoCents / 100).toFixed(2)} — ${c.nombre}` });
  persist();
  return { ok: true, cliente: { ...c }, clientes: getClientes() };
}

/* ---------- Crédito a clientes: estado de cuenta estilo ELEVENTA ---------- */
// Deriva las ventas a crédito de un cliente (cargos con folio de venta) y calcula
// cuánto se ha pagado de cada una. Los abonos con `aplicaciones` explícitas se
// asignan a sus folios; los abonos globales/antiguos y las cancelaciones se
// reparten a las ventas más antiguas (FIFO) para saber el pendiente de cada una.
function ventasCreditoCliente(c) {
  const ventas = new Map();
  (c.movimientos || []).forEach((m, i) => {
    if (m.tipo !== "cargo") return;
    if (m.ventaFolio != null) {
      const f = Number(m.ventaFolio);
      if (!ventas.has(f)) ventas.set(f, { folio: f, movIndex: null, fecha: m.fecha, totalCents: 0, pagadoCents: 0, nota: m.nota || "" });
      const v = ventas.get(f);
      v.totalCents += m.montoCents || 0;
      if (m.nota && !v.nota) v.nota = m.nota;
    } else {
      // Cargo fiado / manual sin folio de venta: también se puede abonar en específico.
      const key = "m" + i;
      ventas.set(key, {
        folio: null, movIndex: i, fecha: m.fecha,
        totalCents: m.montoCents || 0, pagadoCents: 0, nota: m.nota || ""
      });
    }
  });
  let sinAplicar = 0;
  for (const m of (c.movimientos || [])) {
    if (m.tipo === "abono") {
      if (Array.isArray(m.aplicaciones) && m.aplicaciones.length) {
        for (const ap of m.aplicaciones) {
          if (ap && ap.movIndex != null) {
            const v = ventas.get("m" + Number(ap.movIndex));
            if (v) v.pagadoCents += ap.montoCents || 0;
          } else if (ap && ap.folio != null) {
            const v = ventas.get(Number(ap.folio));
            if (v) v.pagadoCents += ap.montoCents || 0;
          }
        }
      } else sinAplicar += m.montoCents || 0;
    } else if (m.tipo === "cancelacion") sinAplicar += m.montoCents || 0;
  }
  const lista = [...ventas.values()].sort((a, b) => new Date(a.fecha) - new Date(b.fecha));
  for (const v of lista) {
    if (sinAplicar <= 0) break;
    const pend = Math.max(0, v.totalCents - v.pagadoCents);
    const usar = Math.min(pend, sinAplicar);
    v.pagadoCents += usar; sinAplicar -= usar;
  }
  return lista.map((v) => ({
    folio: v.folio, movIndex: v.movIndex != null ? v.movIndex : null,
    fecha: v.fecha, totalCents: v.totalCents, pagadoCents: v.pagadoCents,
    saldoCents: Math.max(0, v.totalCents - v.pagadoCents),
    nota: v.nota || ""
  }));
}

// Estado de cuenta completo de un cliente: datos, saldo, movimientos (con saldo
// corrido) y sus ventas a crédito con pendiente. Base para la pantalla de Créditos.
function estadoCuentaCliente(id) {
  const c = db.clientes.find((x) => x.id === Number(id));
  if (!c) return { error: "Cliente no encontrado." };
  let movimientos = (c.movimientos || []).map((m, i) => ({
    id: i, fecha: m.fecha, tipo: m.tipo, montoCents: m.montoCents || 0, saldoCents: m.saldoCents || 0,
    nota: m.nota || "", comentario: m.comentario || "", ventaFolio: m.ventaFolio != null ? m.ventaFolio : null,
    folios: Array.isArray(m.aplicaciones) ? m.aplicaciones.map((a) => a.folio) : (m.ventaFolio != null ? [m.ventaFolio] : []),
    formaPago: m.formaPago || (m.tipo === "abono" ? "efectivo" : (m.tipo === "cargo" ? "credito" : "")),
    usuario: m.usuario || null, uid: m.uid || null, cajaMov: m.cajaMov || null
  }));
  // Mostrar SIEMPRE en orden cronológico (el arreglo guardado no se reordena por
  // la sincronización). Se conserva "id" = índice original para cancelar/ocultar.
  movimientos.sort((a, b) => {
    const d = new Date(a.fecha) - new Date(b.fecha);
    return (isNaN(d) ? 0 : d) || (a.id - b.id);
  });
  // Ocultar notas ya pagadas (solo esta PC): quita de la vista los cargos
  // saldados y sus abonos, y RECALCULA el saldo corrido de lo que queda, anclado
  // al saldo actual real. Así el documento y la impresión quedan cuadrados:
  // Saldo anterior + (cargos − abonos visibles) = Saldo actual. No cambia datos
  // ni Supabase; solo lo que se muestra/imprime en esta PC.
  const ocultarPagadas = getOcultarPagadasCliente(id);
  let saldoAnteriorCents = 0, ocultadas = 0;
  if (ocultarPagadas) {
    const ocultosSet = movimientosDeNotasPagadas(c);
    if (ocultosSet.size) {
      const antes = movimientos.length;
      movimientos = movimientos.filter((m) => !ocultosSet.has(m.id));
      ocultadas = antes - movimientos.length;
    }
    const neto = (m) => (m.tipo === "cargo" ? (m.montoCents || 0) : -(m.montoCents || 0));
    const visNet = movimientos.reduce((s, m) => s + neto(m), 0);
    let corr = (c.saldoCents || 0) - visNet; // saldo anterior (lo que traían las notas ocultas)
    saldoAnteriorCents = corr;
    movimientos.forEach((m) => { corr += neto(m); m.saldoCents = corr; });
  }
  return {
    cliente: {
      id: c.id, nombre: c.nombre, telefono: c.telefono || "",
      limiteCents: c.limiteCents || 0, creditoActivo: !!c.creditoActivo,
      clienteCasa: !!c.clienteCasa
    },
    saldoCents: c.saldoCents || 0, movimientos, ventas: ventasCreditoCliente(c),
    ocultarPagadas, ocultadas, saldoAnteriorCents
  };
}

// Registra un abono aplicándolo a las ventas pendientes.
// opciones: { destino:"todas"|"venta", ventaFolio, comentario, formaPago, usuario }
function abonarCredito(id, montoCents, opciones) {
  opciones = opciones || {};
  const c = db.clientes.find((x) => x.id === Number(id));
  if (!c) return { error: "Cliente no encontrado." };
  montoCents = Math.max(0, Math.round(montoCents || 0));
  if (montoCents <= 0) return { error: "Escribe un monto válido." };
  const saldoPrev = c.saldoCents || 0;
  if (saldoPrev <= 0) return { error: "El cliente no tiene adeudo." };
  const aplicar = Math.min(montoCents, saldoPrev);
  const formaPago = String(opciones.formaPago || "efectivo").trim().toLowerCase() || "efectivo";
  const esEfectivoCasa = formaPago === "efectivo_casa";
  // Efectivo casa baja la deuda y NO exige cajón abierto (el dinero no entra al cajón).
  // Efectivo / tarjeta / transferencia sí entran al corte y requieren caja abierta.
  if (formaPago !== "ajuste" && !esEfectivoCasa) {
    if (!db.config.cajaActualId) {
      return { error: "Abre la caja para que el abono entre al corte (efectivo, tarjeta o transferencia)." };
    }
    const cajaAbierta = db.cajas.find((x) => x.id === db.config.cajaActualId && x.abierta);
    if (!cajaAbierta) return { error: "Abre la caja para que el abono entre al corte." };
  }
  if (!Array.isArray(c.movimientos)) c.movimientos = [];

  const ventas = ventasCreditoCliente(c).filter((v) => v.saldoCents > 0);
  let restante = aplicar;
  const aplicaciones = [];
  const aplicaEn = (v, monto) => {
    monto = Math.min(monto, restante, v.saldoCents);
    if (monto <= 0) return;
    if (v.folio != null) {
      const ex = aplicaciones.find((a) => a.folio === v.folio && a.movIndex == null);
      if (ex) ex.montoCents += monto; else aplicaciones.push({ folio: v.folio, montoCents: monto });
    } else {
      const ex = aplicaciones.find((a) => a.movIndex === v.movIndex);
      if (ex) ex.montoCents += monto;
      else aplicaciones.push({ folio: null, movIndex: v.movIndex, montoCents: monto });
    }
    v.saldoCents -= monto; restante -= monto;
  };

  if (opciones.destino === "venta" && opciones.ventaFolio != null) {
    // Solo esa venta: no derrama a otras (el abono debe bajar esa deuda concreta).
    const v = ventas.find((x) => x.folio != null && Number(x.folio) === Number(opciones.ventaFolio));
    if (!v) return { error: "Esa venta ya no tiene saldo pendiente." };
    if (aplicar > v.saldoCents) {
      return { error: "El abono es mayor que el saldo de esa venta (" + (v.saldoCents / 100).toFixed(2) + ")." };
    }
    aplicaEn(v, restante);
  } else if (opciones.destino === "movimiento" && opciones.movIndex != null) {
    const v = ventas.find((x) => x.movIndex != null && Number(x.movIndex) === Number(opciones.movIndex));
    if (!v) return { error: "Ese cargo ya no tiene saldo pendiente." };
    if (aplicar > v.saldoCents) {
      return { error: "El abono es mayor que el saldo de ese cargo (" + (v.saldoCents / 100).toFixed(2) + ")." };
    }
    aplicaEn(v, restante);
  } else {
    // Cuenta general: antiguas primero (FIFO).
    for (const v of ventas) { if (restante <= 0) break; aplicaEn(v, restante); }
  }

  c.saldoCents = Math.max(0, saldoPrev - aplicar);
  const folios = [...new Set(aplicaciones.filter((a) => a.folio != null).map((a) => a.folio))];
  const refsMov = aplicaciones.filter((a) => a.movIndex != null).map((a) => Number(a.movIndex) + 1);
  const notaAuto = folios.length
    ? `Abono a ventas con folio #${folios.join(", ")}`
    : (refsMov.length ? `Abono a cargo #${refsMov.join(", ")}` : "Abono a cuenta");
  const uidAbono = nuevoUid();
  const fechaAbono = new Date().toISOString();

  // Efectivo casa: NO se anota en caja ni en el corte (ni se imprime ahí).
  // Solo baja la deuda del cliente y queda en el estado de cuenta + tabla nueva.
  let cajaMov = null;
  if (formaPago !== "ajuste" && !esEfectivoCasa) {
    const caja = db.cajas.find((x) => x.id === db.config.cajaActualId && x.abierta);
    if (!caja) return { error: "Abre la caja para que el abono entre al corte." };
    const movId = Number(consumir("movCaja", (caja.movimientos.reduce((mx, x) => Math.max(mx, x.id || 0), 0) || 0) + 1));
    caja.movimientos.push({
      id: movId, fecha: fechaAbono, tipo: "ingreso",
      montoCents: aplicar, motivo: `Abono crédito — ${c.nombre}${folios.length ? " (#" + folios.join(", ") + ")" : ""}`,
      proveedor: "", categoria: "abono", formaPago, cliente: c.nombre, usuario: opciones.usuario || null
    });
    cajaMov = { cajaId: caja.id, movId };
  }

  c.movimientos.push({
    uid: uidAbono,
    fecha: fechaAbono, tipo: "abono", montoCents: aplicar, saldoCents: c.saldoCents,
    nota: notaAuto, comentario: opciones.comentario || "", aplicaciones,
    formaPago, usuario: opciones.usuario || null, cajaMov
  });
  // Espejo dedicado: no altera credito_movimientos ni caja; se sube a tabla nueva.
  if (esEfectivoCasa) {
    registrarEfectivoCasa(_filaEfectivoCasa({
      id: uidAbono, cliente: c, montoCents: aplicar, saldoCents: c.saldoCents,
      fecha: fechaAbono, comentario: opciones.comentario || "", nota: notaAuto,
      aplicaciones, usuario: opciones.usuario || null, cajaMov: null, activo: true
    }));
  }
  registrarMovimiento({ tipo: "credito", usuario: opciones.usuario, detalle: `abono ${(aplicar / 100).toFixed(2)} — ${c.nombre}${esEfectivoCasa ? " (efectivo casa)" : ""}` });
  persist();
  return { ok: true, cliente: { ...c }, clientes: getClientes() };
}

// Recalcula saldo y saldos corridos de un cliente desde sus movimientos.
// IMPORTANTE: NO reordena el arreglo c.movimientos. La sincronización con
// Supabase indexa cada movimiento por su POSICIÓN (idx) dentro del arreglo
// —la llave es (terminal, cliente_id, idx)— y ese índice es COMPARTIDO entre
// las PCs. Si aquí reordenáramos el arreglo, cambiaría el idx de cada fila y el
// ledger de créditos se desincronizaría entre Oficina y Carnicería. Por eso el
// orden cronológico se usa SOLO para calcular el saldo corrido, dejando el
// arreglo tal cual (el saldo corrido se escribe en cada movimiento por refer.).
function recomputarCredito(c) {
  const arr = Array.isArray(c.movimientos) ? c.movimientos : (c.movimientos = []);
  // Orden cronológico estable, solo para el cálculo (no altera el arreglo).
  const orden = arr.map((_, i) => i).sort((i, j) => {
    const d = new Date(arr[i] && arr[i].fecha) - new Date(arr[j] && arr[j].fecha);
    return (isNaN(d) ? 0 : d) || (i - j);
  });
  let saldo = 0;
  for (const i of orden) {
    const m = arr[i];
    if (!m || typeof m !== "object") continue;
    if (m.tipo === "cargo") saldo += m.montoCents || 0;
    else if (m.tipo === "abono") saldo = Math.max(0, saldo - (m.montoCents || 0));
    else if (m.tipo === "cancelacion") { m.montoCents = saldo; saldo = 0; }
    m.saldoCents = saldo;
  }
  c.saldoCents = saldo;
}

// Cancela (elimina) un movimiento de crédito por su índice y recalcula el saldo.
function cancelarMovimientoCredito(clienteId, movId) {
  const c = db.clientes.find((x) => x.id === Number(clienteId));
  if (!c) return { error: "Cliente no encontrado." };
  const idx = Number(movId);
  if (!Array.isArray(c.movimientos) || idx < 0 || idx >= c.movimientos.length) return { error: "Movimiento no encontrado." };
  const m = c.movimientos[idx];
  // Si el abono había entrado a un corte abierto, quita también esa entrada de caja
  // para que el efectivo del turno siga cuadrando. Si el turno ya se cerró, no se
  // toca el corte histórico.
  if (m && m.tipo === "abono" && m.cajaMov) {
    const caja = db.cajas.find((x) => x.id === m.cajaMov.cajaId);
    if (caja && caja.abierta) {
      const i = caja.movimientos.findIndex((x) => (x.id || 0) === Number(m.cajaMov.movId));
      if (i >= 0) caja.movimientos.splice(i, 1);
    }
  }
  if (m && m.tipo === "abono" && m.formaPago === "efectivo_casa") {
    if (m.uid) marcarEfectivoCasaInactivo(m.uid);
    else {
      const ec = (db.efectivoCasa || []).find((x) => x && x.activo !== false
        && Number(x.clienteId) === Number(c.id)
        && Number(x.montoCents) === Number(m.montoCents || 0)
        && String(x.fecha || "") === String(m.fecha || ""));
      if (ec) ec.activo = false;
    }
  }
  const ventaFolio = (m && m.tipo === "cargo" && m.ventaFolio != null) ? Number(m.ventaFolio) : null;
  c.movimientos.splice(idx, 1);
  recomputarCredito(c);
  registrarMovimiento({ tipo: "credito", detalle: `cancelación de ${m ? m.tipo : "movimiento"} — ${c.nombre}` });
  persist();
  // Si el cargo venía de una venta, esa venta también queda anulada (corte e historial).
  if (ventaFolio) cancelarVenta(ventaFolio, null, "Cancelación de cargo a crédito", { omitirCredito: true });
  return { ok: true, cliente: { ...c }, clientes: getClientes() };
}

// Consulta local para auditar el negocio. No se guarda ni se sube a ningún lado.
function resumenAuditoria(periodo, ancla) {
  const modo = periodo === "mes" || periodo === "trimestre" ? periodo : "dia";
  const hoy = localDay(new Date().toISOString());
  let dia = String(ancla || hoy).slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dia) || dia > hoy) dia = hoy;
  const [y, m] = dia.split("-").map(Number);
  const pad = (n) => String(n).padStart(2, "0");
  const meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];
  let desde, hasta, etiqueta;
  if (modo === "mes") {
    desde = y + "-" + pad(m) + "-01";
    hasta = m === 12 ? (y + 1) + "-01-01" : y + "-" + pad(m + 1) + "-01";
    etiqueta = meses[m - 1] + " " + y;
  } else if (modo === "trimestre") {
    const q = Math.floor((m - 1) / 3);
    const sm = q * 3 + 1;
    const em = sm + 2;
    desde = y + "-" + pad(sm) + "-01";
    hasta = em >= 12 ? (y + 1) + "-01-01" : y + "-" + pad(em + 1) + "-01";
    etiqueta = "T" + (q + 1) + " " + y + " · " + meses[sm - 1] + " a " + meses[em - 1];
  } else {
    desde = dia;
    const dt = new Date(y, m - 1, Number(dia.slice(8, 10)) + 1);
    hasta = dt.getFullYear() + "-" + pad(dt.getMonth() + 1) + "-" + pad(dt.getDate());
    etiqueta = Number(dia.slice(8, 10)) + " de " + meses[m - 1] + " " + y;
  }
  const en = (iso) => {
    if (!iso) return false;
    const d = localDay(iso);
    return d >= desde && d < hasta;
  };
  const hora = (iso) => iso || "";

  const cortes = [];
  let ventasCents = 0, netasCents = 0, diferenciaCents = 0, numVentas = 0;
  const abiertos = [];
  for (const caja of db.cajas || []) {
    if (caja.abierta) {
      if (en(caja.aperturaFecha)) abiertos.push({ cajaId: caja.id, usuario: caja.usuario || "", apertura: caja.aperturaFecha });
      continue;
    }
    if (!en(caja.cierreFecha)) continue;
    const corte = caja.corte || {};
    const ventas = corte.totalVentas || 0;
    const netas = corte.ventasNetas || 0;
    const dif = corte.diferenciaCents || 0;
    ventasCents += ventas;
    netasCents += netas;
    diferenciaCents += dif;
    numVentas += corte.numVentas || 0;
    cortes.push({
      cajaId: caja.id, usuario: caja.usuario || "", cierre: caja.cierreFecha,
      ventasCents: ventas, netasCents: netas, diferenciaCents: dif, numVentas: corte.numVentas || 0
    });
  }
  cortes.sort((a, b) => String(b.cierre).localeCompare(String(a.cierre)));

  const creditos = [];
  for (const c of db.clientes || []) {
    for (const mov of c.movimientos || []) {
      if (mov.tipo !== "cargo" || !en(mov.fecha)) continue;
      creditos.push({
        fecha: hora(mov.fecha), quien: c.nombre || "Cliente",
        detalle: mov.nota || (mov.ventaFolio ? "Venta folio " + mov.ventaFolio : "Cargo a crédito"),
        montoCents: mov.montoCents || 0, origen: "cliente"
      });
    }
  }
  const rebajaPagada = new Map();
  for (const p of db.movimientosPendientes || []) {
    if (p.abonoDe == null) continue;
    const k = Number(p.abonoDe);
    rebajaPagada.set(k, (rebajaPagada.get(k) || 0) + (p.montoCents || 0));
  }
  for (const p of db.movimientosPendientes || []) {
    if (p.abonoDe != null || !en(p.fecha)) continue;
    creditos.push({
      fecha: hora(p.fecha), quien: p.proveedor || "Proveedor",
      detalle: p.motivo || "Compra a crédito",
      montoCents: (p.montoCents || 0) + (rebajaPagada.get(Number(p.id)) || 0),
      origen: "proveedor"
    });
  }
  creditos.sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));

  const liquidaciones = [];
  const parciales = [];
  for (const c of db.clientes || []) {
    for (const mov of c.movimientos || []) {
      if (mov.tipo !== "abono" || !en(mov.fecha)) continue;
      const item = {
        fecha: hora(mov.fecha), quien: c.nombre || "Cliente",
        detalle: mov.nota || "Abono",
        montoCents: mov.montoCents || 0, origen: "cliente",
        forma: mov.formaPago || ""
      };
      if ((mov.saldoCents || 0) === 0) liquidaciones.push(item);
      else parciales.push(item);
    }
  }
  for (const p of db.movimientosPendientes || []) {
    if (p.estado !== "pagado" || !en(p.pagoFecha)) continue;
    const item = {
      fecha: hora(p.pagoFecha), quien: p.proveedor || "Proveedor",
      detalle: p.motivo || "Pago a proveedor",
      montoCents: p.montoCents || 0, origen: "proveedor",
      forma: p.pagoForma || ""
    };
    if (p.abonoDe == null) liquidaciones.push(item);
    else parciales.push(item);
  }
  liquidaciones.sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
  parciales.sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));

  const altaCliente = (c) => {
    let min = c.fechaAlta || "";
    for (const mov of c.movimientos || []) {
      if (mov.fecha && (!min || mov.fecha < min)) min = mov.fecha;
    }
    return min;
  };
  const clientesNuevos = [];
  for (const c of db.clientes || []) {
    const fecha = altaCliente(c);
    if (!en(fecha)) continue;
    clientesNuevos.push({ fecha, nombre: c.nombre || "Sin nombre", telefono: c.telefono || "" });
  }
  clientesNuevos.sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));

  const primeraProv = new Map();
  const tocarProv = (nombre, fecha) => {
    const n = String(nombre || "").trim();
    if (!n || !fecha) return;
    const k = n.toLowerCase();
    const prev = primeraProv.get(k);
    if (!prev || fecha < prev.fecha) primeraProv.set(k, { nombre: n, fecha });
  };
  for (const p of db.movimientosPendientes || []) tocarProv(p.proveedor, p.fecha);
  for (const caja of db.cajas || []) {
    for (const mov of caja.movimientos || []) tocarProv(mov.proveedor, mov.fecha);
  }
  const proveedoresNuevos = [];
  primeraProv.forEach((p) => { if (en(p.fecha)) proveedoresNuevos.push(p); });
  proveedoresNuevos.sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));

  const eventos = [];
  for (const caja of db.cajas || []) {
    if (en(caja.aperturaFecha)) {
      eventos.push({ fecha: caja.aperturaFecha, tipo: "apertura", titulo: "Apertura de caja " + caja.id, detalle: caja.usuario || "", montoCents: caja.fondoCents || 0 });
    }
  }
  for (const v of db.ventas || []) {
    if (!v.cancelada || !en(v.canceladaFecha)) continue;
    eventos.push({
      fecha: v.canceladaFecha, tipo: "cancelacion", titulo: "Cancelación folio " + v.folio,
      detalle: v.canceladaMotivo || v.canceladaUsuario || "", montoCents: v.totalCents || 0
    });
  }
  for (const d of db.devoluciones || []) {
    if (d.cancelada || !en(d.fecha)) continue;
    eventos.push({
      fecha: d.fecha, tipo: "devolucion", titulo: "Devolución folio " + (d.folio || ""),
      detalle: d.motivo || d.pago || "", montoCents: d.totalCents || d.montoCents || 0
    });
  }
  for (const caja of db.cajas || []) {
    for (const mov of caja.movimientos || []) {
      if (!en(mov.fecha)) continue;
      if (mov.categoria === "abono") continue;
      const fp = String(mov.formaPago || "");
      if (fp === "credito") continue;
      if (mov.pendienteId != null) continue;
      eventos.push({
        fecha: mov.fecha,
        tipo: mov.tipo === "retiro" ? "salida" : "entrada",
        titulo: (mov.tipo === "retiro" ? "Salida" : "Entrada") + (fp ? " · " + fp : ""),
        detalle: [mov.motivo, mov.proveedor].filter(Boolean).join(" · "),
        montoCents: mov.montoCents || 0
      });
    }
  }
  const nombreProd = (id) => {
    const p = (db.productos || []).find((x) => x.id === id);
    return p ? p.nombre : ("#" + id);
  };
  for (const mov of db.movimientosInv || []) {
    if (!mov.tipo || mov.tipo === "venta" || mov.tipo === "devolucion" || mov.tipo === "cancelacion") continue;
    if (!en(mov.fecha)) continue;
    eventos.push({
      fecha: mov.fecha, tipo: "inventario", titulo: "Inventario · " + mov.tipo,
      detalle: nombreProd(mov.productoId) + (mov.cant != null ? " · " + mov.cant : ""),
      montoCents: 0
    });
  }
  eventos.sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));

  const recortar = (lista, n) => ({ total: lista.length, lista: lista.slice(0, n) });
  const suma = (lista) => lista.reduce((s, x) => s + (x.montoCents || 0), 0);
  return {
    periodo: modo, ancla: dia, desde, hasta, etiqueta,
    cortes: {
      cantidad: cortes.length, ventasCents, netasCents, diferenciaCents, numVentas,
      abiertos: abiertos.length, listaAbiertos: abiertos.slice(0, 10),
      ...recortar(cortes, 80)
    },
    creditosNuevos: { cantidad: creditos.length, montoCents: suma(creditos), ...recortar(creditos, 80) },
    liquidaciones: {
      cantidad: liquidaciones.length, montoCents: suma(liquidaciones),
      parciales: parciales.length, parcialesCents: suma(parciales),
      ...recortar(liquidaciones, 80),
      listaParciales: parciales.slice(0, 40), totalParciales: parciales.length
    },
    altas: {
      clientes: clientesNuevos.length, proveedores: proveedoresNuevos.length,
      listaClientes: clientesNuevos.slice(0, 40),
      listaProveedores: proveedoresNuevos.slice(0, 40)
    },
    eventos: { cantidad: eventos.length, ...recortar(eventos, 80) }
  };
}

// Resumen de saldos de todos los clientes (para el "Reporte de Saldos").
function resumenCreditos() {
  return (db.clientes || []).map((c) => {
    const movs = c.movimientos || [];
    return {
      id: c.id, nombre: c.nombre, telefono: c.telefono || "", saldoCents: c.saldoCents || 0,
      limiteCents: c.limiteCents || 0, creditoActivo: !!c.creditoActivo,
      ultimaFecha: movs.length ? movs[movs.length - 1].fecha : null, numMovs: movs.length
    };
  }).sort((a, b) => (b.saldoCents - a.saldoCents) || String(a.nombre).localeCompare(String(b.nombre)));
}

function eliminarCategoria(id) {
  const c = db.categorias.find((x) => x.id === id);
  if (!c) return { error: "Categoría no encontrada." };
  const usados = db.productos.filter((p) => p.cat === id).length;
  if (usados) return { error: `No se puede eliminar: ${usados} producto(s) usan esta categoría. Muévelos o cámbiales la categoría primero.` };
  db.categorias = db.categorias.filter((x) => x.id !== id);
  persist();
  return { ok: true, categorias: db.categorias };
}

/* ---------- Órdenes en espera ---------- */
function getEsperas() { return (db.ordenesEspera || []).slice(); }
function guardarEspera(orden) {
  db.ordenesEspera = db.ordenesEspera || [];
  if (orden.id) {
    const i = db.ordenesEspera.findIndex((x) => x.id === orden.id);
    if (i >= 0) db.ordenesEspera[i] = { ...db.ordenesEspera[i], ...orden };
  } else {
    const id = (db.ordenesEspera.reduce((m, x) => Math.max(m, x.id || 0), 0) || 0) + 1;
    db.ordenesEspera.push({ id, fecha: new Date().toISOString(), ...orden });
  }
  persist();
  return { ok: true, ordenesEspera: getEsperas() };
}
function eliminarEspera(id) {
  db.ordenesEspera = (db.ordenesEspera || []).filter((x) => x.id !== id);
  persist();
  return { ok: true, ordenesEspera: getEsperas() };
}

/* ---------- Apartados (entidad propia con abonos) ----------
   Un apartado reserva mercancía para recoger después. NO es una venta completa:
   solo lo que el cliente realmente paga (abono o liquidación) entra a la caja y
   por tanto al corte, registrado como una venta etiquetada como apartado. El
   faltante queda pendiente hasta que se abone o liquide. */
function _recalcApartado(ap) {
  ap.abonadoCents = (ap.abonos || []).reduce((s, a) => s + (a.montoCents || 0), 0);
  ap.faltanteCents = Math.max(0, (ap.totalCents || 0) - ap.abonadoCents);
  if (ap.faltanteCents <= 0 && (ap.totalCents || 0) > 0) ap.estado = "liquidado";
  else ap.estado = "pendiente";
  return ap;
}

// Registra un abono del apartado como una venta (solo el monto recibido) para
// que entre al corte del turno con su forma de pago real, etiquetada apartado.
function _registrarAbonoApartado(ap, montoCents, metodo, usuario, concepto) {
  montoCents = Math.max(0, Math.round(montoCents || 0));
  if (!montoCents) return { error: "El abono debe ser mayor a cero." };
  if (!db.config.cajaActualId) return { error: "Abre la caja para registrar el abono del apartado." };
  const venta = {
    usuario: usuario || null,
    cliente: ap.nombre || "Apartado",
    esApartado: true, esApartadoPago: true, apartadoId: ap.id, apartadoFolio: ap.folio,
    items: [{ tipo: "apartado", nombre: `🏷️ Apartado #${ap.folio} · ${concepto}`, cant: 1, unidad: "", precioCents: montoCents, importeCents: montoCents }],
    subtotalCents: montoCents, descuentoCents: 0, totalCents: montoCents,
    pago: metodo || "efectivo", recibidoCents: montoCents, cambioCents: 0
  };
  const r = registrarVenta(venta); // asigna folio y cajaId, descuenta nada (tipo apartado) y persiste
  ap.abonos.push({ fecha: new Date().toISOString(), montoCents, metodo: metodo || "efectivo", ventaFolio: r.folio, concepto: concepto || "abono", usuario: usuario || null });
  return { ok: true, ventaFolio: r.folio };
}

function crearApartado(data) {
  data = data || {};
  const total = Math.max(0, Math.round(data.totalCents || 0));
  if (total <= 0) return { error: "El apartado no tiene importe." };
  const nombre = String(data.nombre || "").trim();
  if (!nombre) return { error: "Escribe el nombre del cliente." };
  const abono = Math.max(0, Math.round(data.abonoCents || 0));
  if (abono > total) return { error: "El abono no puede ser mayor al total." };
  if (abono > 0 && !db.config.cajaActualId) return { error: "Abre la caja para registrar el abono del apartado." };

  const folio = db.config.folioApartado || 1;
  const ap = {
    id: (db.apartados.reduce((m, a) => Math.max(m, a.id || 0), 0) || 0) + 1,
    folio,
    fecha: new Date().toISOString(),
    nombre, telefono: String(data.telefono || "").trim(),
    fechaRecoleccion: data.fechaRecoleccion || null,
    items: Array.isArray(data.items) ? data.items : [],
    totalCents: total,
    abonos: [],
    abonadoCents: 0,
    faltanteCents: total,
    estado: "pendiente",
    entregado: false, entregaFecha: null,
    usuario: data.usuario || null
  };
  if (abono > 0) {
    const r = _registrarAbonoApartado(ap, abono, data.metodo || "efectivo", data.usuario, "abono inicial");
    if (r && r.error) return r;
  }
  db.config.folioApartado = folio + 1;
  db.apartados.push(ap);
  _recalcApartado(ap);
  registrarMovimiento({ tipo: "venta", usuario: data.usuario || null, detalle: `Apartado #${folio} de ${nombre} por ${(total / 100).toFixed(2)} (abono ${(abono / 100).toFixed(2)})` });
  persist();
  return { ok: true, apartado: { ...ap }, folio };
}

function abonarApartado(id, montoCents, metodo, usuario) {
  const ap = db.apartados.find((x) => x.id === Number(id));
  if (!ap) return { error: "Apartado no encontrado." };
  _recalcApartado(ap);
  if (ap.faltanteCents <= 0) return { error: "Este apartado ya está liquidado." };
  let monto = Math.max(0, Math.round(montoCents || 0));
  if (monto > ap.faltanteCents) monto = ap.faltanteCents; // no sobrepasar el faltante
  const r = _registrarAbonoApartado(ap, monto, metodo, usuario, "abono");
  if (r && r.error) return r;
  _recalcApartado(ap);
  persist();
  return { ok: true, apartado: { ...ap }, apartados: getApartados() };
}

function liquidarApartado(id, metodo, usuario) {
  const ap = db.apartados.find((x) => x.id === Number(id));
  if (!ap) return { error: "Apartado no encontrado." };
  _recalcApartado(ap);
  if (ap.faltanteCents <= 0) { ap.estado = "liquidado"; persist(); return { ok: true, apartado: { ...ap }, apartados: getApartados() }; }
  const r = _registrarAbonoApartado(ap, ap.faltanteCents, metodo, usuario, "liquidación");
  if (r && r.error) return r;
  _recalcApartado(ap);
  persist();
  return { ok: true, apartado: { ...ap }, apartados: getApartados() };
}

function getApartados() {
  return (db.apartados || []).map((ap) => {
    _recalcApartado(ap);
    return {
      id: ap.id, folio: ap.folio, fecha: ap.fecha,
      nombre: ap.nombre || "", telefono: ap.telefono || "",
      fechaRecoleccion: ap.fechaRecoleccion || null,
      items: ap.items || [], totalCents: ap.totalCents || 0,
      abonadoCents: ap.abonadoCents || 0, faltanteCents: ap.faltanteCents || 0,
      abonos: ap.abonos || [], estado: ap.estado || "pendiente",
      entregado: !!ap.entregado, entregaFecha: ap.entregaFecha || null,
      usuario: ap.usuario || null
    };
  });
}

function entregarApartado(id, entregado) {
  const ap = db.apartados.find((x) => x.id === Number(id));
  if (!ap) return { error: "Apartado no encontrado." };
  ap.entregado = entregado !== false;
  ap.entregaFecha = ap.entregado ? new Date().toISOString() : null;
  persist();
  return { ok: true, apartados: getApartados() };
}

function eliminarApartado(id) {
  const ap = db.apartados.find((x) => x.id === Number(id));
  if (!ap) return { error: "Apartado no encontrado." };
  if ((ap.abonadoCents || 0) > 0) return { error: "Este apartado ya tiene pagos registrados en caja; no se puede eliminar." };
  db.apartados = db.apartados.filter((x) => x.id !== Number(id));
  persist();
  return { ok: true, apartados: getApartados() };
}

/* ---------- Apartados antiguos (ventas etiquetadas) — compatibilidad ---------- */
function getApartadosLegacy() {
  return db.ventas.filter((v) => v.esApartado && !v.esApartadoPago && !v.cancelada).map((v) => ({
    folio: v.folio, fecha: v.fecha, cliente: v.cliente, notaApartado: v.notaApartado || "",
    entregado: !!v.entregado, entregaFecha: v.entregaFecha || null,
    totalCents: v.totalCents, pago: v.pago, numItems: (v.items || []).length
  }));
}
function marcarEntregado(folio, entregado) {
  const v = db.ventas.find((x) => Number(x.folio) === Number(folio) && x.esApartado);
  if (!v) return { error: "Apartado no encontrado." };
  v.entregado = entregado !== false;
  v.entregaFecha = v.entregado ? new Date().toISOString() : null;
  persist();
  return { ok: true, apartados: getApartados() };
}
function actualizarNotaApartado(folio, nota) {
  const v = db.ventas.find((x) => Number(x.folio) === Number(folio) && x.esApartado);
  if (!v) return { error: "Apartado no encontrado." };
  v.notaApartado = String(nota || "");
  persist();
  return { ok: true, apartados: getApartados() };
}

/* ---------- Paquetes (catálogo) ---------- */
function guardarPaquete(pq) {
  if (pq.id) {
    // Actualización (puede ser parcial, p. ej. solo el precio)
    const i = db.paquetes.findIndex((x) => x.id === pq.id);
    if (i < 0) return { error: "Paquete no encontrado." };
    if (pq.nombre !== undefined && !String(pq.nombre).trim()) return { error: "Escribe un nombre de paquete." };
    const merge = { ...db.paquetes[i], ...pq, porConfirmar: false };
    if (pq.nombre !== undefined) merge.nombre = String(pq.nombre).trim();
    db.paquetes[i] = merge;
  } else {
    const nombre = String(pq.nombre || "").trim();
    if (!nombre) return { error: "Escribe un nombre de paquete." };
    let id = "pq-" + _slug(nombre), base = id, n = 2;
    while (db.paquetes.some((x) => x.id === id)) id = base + "-" + (n++);
    db.paquetes.push({
      id, nombre, emoji: pq.emoji || "🎁", precioCents: pq.precioCents || 0,
      porConfirmar: false, componentes: Array.isArray(pq.componentes) ? pq.componentes : []
    });
  }
  persist();
  return { ok: true, paquetes: db.paquetes };
}
function eliminarPaquete(id) {
  const p = db.paquetes.find((x) => x.id === id);
  if (!p) return { error: "Paquete no encontrado." };
  db.paquetes = db.paquetes.filter((x) => x.id !== id);
  persist();
  return { ok: true, paquetes: db.paquetes };
}

// Busca una venta por folio (para reimprimir su ticket)
function getVentaPorFolio(folio) {
  const f = Number(folio);
  const v = db.ventas.find((x) => Number(x.folio) === f);
  return v ? { ...v } : null;
}

// Cancela (anula) una venta hecha por error. Regresa a inventario los productos
// que controlan existencias y la excluye del corte de caja para que cuadre.
// No se registra como devolución (las devoluciones se manejan aparte).
function cancelarVenta(folio, usuario, motivo, opts) {
  const v = db.ventas.find((x) => Number(x.folio) === Number(folio));
  if (!v) return { error: "No se encontró la venta." };
  if (v.cancelada) return { error: "Esta venta ya está cancelada." };
  v.cancelada = true;
  v.canceladaFecha = new Date().toISOString();
  v.canceladaMotivo = motivo || "";
  v.canceladaUsuario = usuario || null;
  if (!(opts && opts.omitirCredito)) quitarCargoCreditoDeVenta(v);
  for (const it of (v.items || [])) {
    if (it.tipo === "producto" && it.productoId) {
      const p = db.productos.find((x) => x.id === it.productoId);
      if (p && p.controlaInventario) {
        p.existencia = r3((p.existencia || 0) + (it.cant || 0));
        db.movimientosInv.push({
          fecha: v.canceladaFecha, productoId: p.id, tipo: "cancelacion",
          cant: it.cant, existencia: p.existencia, folio: v.folio, usuario: usuario || null
        });
      }
    }
  }
  registrarMovimiento({
    tipo: "venta", usuario,
    detalle: `Cancelación de venta folio ${v.folio} por ${((v.totalCents || 0) / 100).toFixed(2)}${motivo ? " — " + motivo : ""}`
  });
  persist();
  return { ok: true };
}

// Lista de ventas y devoluciones de un día (para reimpresión y consulta).
function ventasDelDia(fechaISO) {
  const dia = (fechaISO || localDay(new Date().toISOString())).slice(0, 10);
  const hora = (f) => new Date(f).toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" });
  const nombreCli = (c) => (c && typeof c === "object") ? (c.nombre || "") : (c || "");
  const ventas = db.ventas.filter((v) => localDay(v.fecha) === dia && ventaCuentaEnCorte(v)).map((v) => ({
    folio: v.folio, hora: hora(v.fecha), totalCents: v.totalCents || 0,
    pago: v.pago || "otro", cliente: nombreCli(v.cliente),
    apartado: !!v.esApartado, numItems: (v.items || []).length,
    basculaFolio: v.origenBascula ? v.origenBascula.folio : (v.basculaFolio != null ? v.basculaFolio : null),
    cancelada: !!v.cancelada, canceladaMotivo: v.canceladaMotivo || ""
  })).sort((a, b) => a.folio - b.folio);
  const devoluciones = (db.devoluciones || []).filter((d) => localDay(d.fecha) === dia).map((d) => ({
    folio: d.folio, ventaFolio: d.ventaFolio || null, hora: hora(d.fecha),
    totalCents: d.totalCents || 0, pago: d.pago || "otro", motivo: d.motivo || "", numItems: (d.items || []).length
  })).sort((a, b) => a.folio - b.folio);
  const totalVentas = ventas.filter((v) => !v.cancelada).reduce((s, v) => s + v.totalCents, 0);
  const totalDev = devoluciones.reduce((s, d) => s + d.totalCents, 0);
  return {
    dia, ventas, devoluciones,
    totalVentasCents: totalVentas, totalDevolucionesCents: totalDev,
    numVentas: ventas.filter((v) => !v.cancelada).length
  };
}

// Corte informativo del día (independiente de la sesión de caja)
function corteDia(fechaISO) {
  const dia = (fechaISO || new Date().toISOString()).slice(0, 10);
  const ventasDia = db.ventas.filter((v) => v.fecha.slice(0, 10) === dia && !v.cancelada);
  const porPago = {};
  let totalCents = 0;
  for (const v of ventasDia) {
    const p = v.pago || "otro";
    porPago[p] = (porPago[p] || 0) + (v.totalCents || 0);
    totalCents += v.totalCents || 0;
  }
  return { dia, numVentas: ventasDia.length, porPago, totalCents };
}

/* ---------- Facturación electrónica (CFDI 4.0) ---------- */
// Datos fiscales del emisor (negocio) tal como se timbrarán.
function emisorFiscal() {
  const n = db.config.negocio || {};
  return {
    rfc: String(n.rfc || "").toUpperCase().trim(),
    razonSocial: (n.razonSocial || n.nombre || "").trim(),
    regimenFiscal: String(n.regimenFiscal || "").trim(),
    codigoPostal: String(n.codigoPostal || "").trim()
  };
}

// Forma de pago SAT (catálogo c_FormaPago) a partir del método del POS.
function formaPagoSat(pago) {
  const m = { efectivo: "01", transferencia: "03", tarjeta: "04", vales: "05", credito: "99", combinado: "99" };
  return m[pago] || "99";
}

// Arma los conceptos CFDI (con desglose de IVA) a partir de una venta.
// Los precios del POS incluyen IVA: para tasa 16% se separa base + IVA; para
// tasa 0% / alimentos, la base es el importe pagado.
function construirConceptosVenta(folio) {
  const v = db.ventas.find((x) => Number(x.folio) === Number(folio));
  if (!v) return { error: "No se encontró la venta." };
  if (v.cancelada) return { error: "La venta está cancelada; no se puede facturar." };
  const items = (v.items || []).filter((it) => (it.importeCents || 0) > 0);
  if (!items.length) return { error: "La venta no tiene importes para facturar." };

  let subtotalCents = 0, ivaCents = 0, totalCents = 0;
  const conceptos = items.map((it) => {
    let sat = { claveProdServ: "01010101", claveUnidad: "H87", ivaTasa: 0 };
    if (it.tipo === "producto" && it.productoId) {
      const p = db.productos.find((x) => x.id === it.productoId);
      if (p) sat = defaultsSatProducto(p);
    } else if (it.tipo === "paquete") {
      sat = { claveProdServ: "50111500", claveUnidad: "H87", ivaTasa: 0 };
    } else {
      sat = { claveProdServ: "50111500", claveUnidad: "H87", ivaTasa: 0 };
    }
    const tasa = Number(sat.ivaTasa) || 0;
    const pagado = Math.round(it.importeCents || 0);
    let baseC, ivaC;
    if (tasa > 0) { baseC = Math.round(pagado / (1 + tasa)); ivaC = pagado - baseC; }
    else { baseC = pagado; ivaC = 0; }
    const cantidad = it.cant || 1;
    const valorUnitarioCents = Math.round(baseC / (cantidad || 1));
    subtotalCents += baseC; ivaCents += ivaC; totalCents += pagado;
    return {
      descripcion: it.nombre || "Producto",
      cantidad,
      unidad: it.unidad || "pza",
      claveProdServ: sat.claveProdServ,
      claveUnidad: sat.claveUnidad,
      ivaTasa: tasa,
      valorUnitarioCents,
      importeCents: baseC,      // CFDI "Importe" = base sin IVA
      ivaImporteCents: ivaC,
      totalLineaCents: pagado
    };
  });
  return { conceptos, subtotalCents, ivaCents, totalCents, formaPago: formaPagoSat(v.pago), pago: v.pago };
}

// Crea una factura en estado "pendiente" a partir de una venta y su receptor.
function crearFactura(data) {
  data = data || {};
  const folio = Number(data.folioVenta != null ? data.folioVenta : data.folio);
  if (!folio) return { error: "Falta el folio de la venta." };
  if ((db.facturas || []).some((f) => Number(f.folioVenta) === folio && f.estado !== "error")) {
    return { error: "Esa venta ya tiene una factura generada." };
  }
  const conc = construirConceptosVenta(folio);
  if (conc.error) return conc;
  const receptor = data.receptor || {};
  if (!receptor.rfc) return { error: "Falta el RFC del receptor." };
  if (!receptor.codigoPostal) return { error: "Falta el código postal del receptor." };

  const emisor = emisorFiscal();
  if (!emisor.rfc) return { error: "Configura el RFC del negocio en Configuración antes de facturar." };
  if (!emisor.codigoPostal) return { error: "Configura el código postal del negocio en Configuración." };
  if (!emisor.regimenFiscal) return { error: "Configura el régimen fiscal del negocio en Configuración." };

  db.facturas = db.facturas || [];
  db.config.factura = db.config.factura || defaultFactura();
  const fcfg = db.config.factura;
  const id = (db.facturas.reduce((m, f) => Math.max(m, f.id || 0), 0) || 0) + 1;
  const folioFactura = fcfg.folio || 1;
  const factura = {
    id,
    serie: fcfg.serie || "A",
    folioFactura,
    folioVenta: folio,
    fecha: new Date().toISOString(),
    emisor,
    receptor: {
      rfc: String(receptor.rfc || "").toUpperCase().trim(),
      nombre: (receptor.nombre || receptor.razonSocial || "").trim(),
      regimenFiscal: String(receptor.regimenFiscal || "").trim(),
      usoCfdi: (receptor.usoCfdi || "G03").trim(),
      codigoPostal: String(receptor.codigoPostal || "").trim(),
      email: (receptor.email || "").trim(),
      telefono: String(receptor.telefono || "").trim()
    },
    formaPago: conc.formaPago,
    metodoPago: "PUE",
    conceptos: conc.conceptos,
    subtotalCents: conc.subtotalCents,
    ivaCents: conc.ivaCents,
    totalCents: conc.totalCents,
    estado: "pendiente",
    intentos: 0,
    ultimoError: "",
    uuid: "",
    fechaTimbrado: null,
    xmlPath: "",
    pdfPath: "",
    ligaPublica: "",
    enviadoCorreo: false,
    enviadoWhats: false,
    usuario: data.usuario || null
  };
  db.facturas.push(factura);
  fcfg.folio = folioFactura + 1;
  registrarMovimiento({
    tipo: "factura", usuario: data.usuario || null,
    detalle: `Factura ${factura.serie}${folioFactura} (venta ${folio}) para ${factura.receptor.rfc}`
  });
  persist();
  return { ok: true, factura: JSON.parse(JSON.stringify(factura)) };
}

function getFacturas() {
  return (db.facturas || []).slice().sort((a, b) => (b.id || 0) - (a.id || 0)).map((f) => JSON.parse(JSON.stringify(f)));
}
function getFacturaPorId(id) {
  const f = (db.facturas || []).find((x) => x.id === Number(id));
  return f ? JSON.parse(JSON.stringify(f)) : null;
}
function getFacturaPorVenta(folio) {
  const f = (db.facturas || []).find((x) => Number(x.folioVenta) === Number(folio) && x.estado !== "error");
  return f ? JSON.parse(JSON.stringify(f)) : null;
}
// Aplica cambios (estado, uuid, rutas, envíos) a una factura y persiste.
function actualizarFactura(id, patch) {
  const f = (db.facturas || []).find((x) => x.id === Number(id));
  if (!f) return { error: "Factura no encontrada." };
  Object.assign(f, patch || {});
  persist();
  return { ok: true, factura: JSON.parse(JSON.stringify(f)) };
}
// Facturas por timbrar (nuevas o con error, con reintentos disponibles).
function facturasPendientes() {
  return (db.facturas || [])
    .filter((f) => f.estado === "pendiente" || (f.estado === "error" && (f.intentos || 0) < 5))
    .map((f) => JSON.parse(JSON.stringify(f)));
}

// Importa la OPERACIÓN desde ELEVENTA (clientes, ventas recientes, devoluciones,
// cortes-resumen) SIN tocar inventario/productos ni la configuración del negocio.
function importarOperativoEleventa(datos) {
  datos = datos || {};
  // ----- Clientes (reemplaza) -----
  const oldToName = {};
  let cid = 0;
  const clientes = (datos.clientes || []).map((c) => {
    cid++;
    const saldo = Math.max(0, Math.round(c.saldoCents || 0));
    const movimientos = [];
    if (saldo > 0) {
      movimientos.push({ fecha: new Date().toISOString(), tipo: "cargo", montoCents: saldo, saldoCents: saldo, nota: "Saldo inicial importado de ELEVENTA", ventaFolio: null });
    }
    const cli = _clienteNorm({
      id: cid, nombre: c.nombre, telefono: c.telefono, rfc: c.rfc, direccion: c.direccion,
      email: c.email, regimenFiscal: c.regimenFiscal, usoCfdi: "", codigoPostal: c.codigoPostal,
      creditoActivo: !!c.creditoActivo, limiteCents: c.limiteCents || 0, saldoCents: saldo, movimientos
    });
    if (c.oldId != null) oldToName[c.oldId] = cli.nombre;
    return cli;
  });

  // ----- Ventas (reemplaza) -----
  const ventas = (datos.ventas || []).map((v) => {
    const cliente = (v.clienteOldId != null && oldToName[v.clienteOldId]) ? oldToName[v.clienteOldId] : "Público en General";
    const items = (v.items || []).map((it) => ({
      tipo: "producto", nombre: it.nombre, cant: it.cant, unidad: it.unidad,
      precioCents: it.precioCents, importeCents: it.importeCents
    }));
    return {
      folio: v.folio, fecha: v.fecha || new Date().toISOString(), cajaId: null,
      cliente, usuario: null, origenEleventa: true,
      items, subtotalCents: v.subtotalCents || v.totalCents || 0, descuentoCents: 0, totalCents: v.totalCents || 0,
      pago: v.pago || "otro", pagos: (v.pagos && v.pagos.length) ? v.pagos : undefined,
      recibidoCents: v.recibidoCents || v.totalCents || 0, cambioCents: 0, cancelada: !!v.cancelada
    };
  });
  const folioMax = ventas.reduce((m, v) => Math.max(m, Number(v.folio) || 0), 0);

  // ----- Devoluciones (reemplaza) -----
  const devoluciones = (datos.devoluciones || []).map((d) => ({
    folio: d.folio, fecha: d.fecha || new Date().toISOString(), cajaId: null, ventaFolio: null,
    totalCents: d.totalCents || 0, pago: d.pago || "efectivo", motivo: d.motivo || "",
    usuario: d.usuario || null, items: [], origenEleventa: true
  }));
  const folioDevMax = devoluciones.reduce((m, d) => Math.max(m, Number(d.folio) || 0), 0);

  db.clientes = clientes;
  db.ventas = ventas;
  db.devoluciones = devoluciones;
  db.cortesEleventa = datos.cortes || [];
  db.config.folioVenta = folioMax + 1;
  db.config.folioDevolucion = folioDevMax + 1;
  // NO se tocan: productos, categorias, paquetes, usuarios, cajas ni config.
  persist();
  return { ok: true, resumen: { clientes: clientes.length, ventas: ventas.length, devoluciones: devoluciones.length, cortes: (datos.cortes || []).length } };
}
function getCortesEleventa() { return (db.cortesEleventa || []).slice(); }

// Entradas y salidas de efectivo de un día (todas las cajas). Sin folio.
function movimientosEfectivoDia(fechaISO) {
  const dia = (fechaISO || localDay(new Date().toISOString())).slice(0, 10);
  const lista = [];
  for (const caja of (db.cajas || [])) {
    for (const m of (caja.movimientos || [])) {
      if (!m || !m.fecha || localDay(m.fecha) !== dia) continue;
      if (m.categoria === "abono") continue;
      lista.push({
        id: m.id, fecha: m.fecha, tipo: m.tipo, categoria: m.categoria || "",
        motivo: m.motivo || "", proveedor: m.proveedor || "", montoCents: m.montoCents || 0,
        formaPago: m.formaPago || "efectivo",
        cajaId: caja.id, usuario: m.usuario || caja.usuario || ""
      });
    }
  }
  lista.sort((a, b) => String(a.fecha).localeCompare(String(b.fecha)));
  const deCajon = (m) => {
    const fp = String(m.formaPago || "efectivo").toLowerCase();
    return fp === "efectivo" || fp === "dolares";
  };
  const entradas = lista.filter((m) => m.tipo === "ingreso" && deCajon(m)).reduce((s, m) => s + (m.montoCents || 0), 0);
  const salidas = lista.filter((m) => m.tipo === "retiro" && deCajon(m)).reduce((s, m) => s + (m.montoCents || 0), 0);
  return { dia, movimientos: lista, entradas, salidas };
}

function creditosDeCaja(cajaId) {
  const ventas = (db.ventas || []).filter((v) => v.cajaId === cajaId);
  const cred = listaCreditos(ventas);
  const creditoDev = (db.devoluciones || [])
    .filter((d) => d.cajaId === cajaId && String(d.pago || "").toLowerCase() === "credito")
    .reduce((s, d) => s + (d.totalCents || 0), 0);
  return { lista: cred.lista, creditoVentas: cred.total, creditoDev };
}

// Cortes ya guardados de un día (por fecha, sin pedir folio) + histórico ELEVENTA.
// Lectura: ingresos netos por mes y forma de pago (ventas − devoluciones + abonos).
// No escribe nada.
function resumenIngresosMeses() {
  const map = new Map();
  const diaDe = (iso) => {
    if (!iso) return "";
    const d = localDay(iso);
    return d && d.length >= 10 ? d : "";
  };
  const bucket = (dia) => {
    if (!map.has(dia)) map.set(dia, { dia, mes: dia.slice(0, 7), metodos: {}, numVentas: 0 });
    return map.get(dia);
  };
  const add = (dia, metodo, cents, esVenta) => {
    if (!dia || !cents) return;
    const b = bucket(dia);
    if (esVenta) b.numVentas += 1;
    const k = String(metodo || "otro").trim().toLowerCase() || "otro";
    b.metodos[k] = (b.metodos[k] || 0) + cents;
  };
  for (const v of (db.ventas || [])) {
    if (!ventaCuentaEnCorte(v)) continue;
    const dia = diaDe(v.fecha);
    if (!dia) continue;
    const pagos = desglosePagos(v);
    pagos.forEach((p, i) => add(dia, p.metodo, p.montoCents || 0, i === 0));
  }
  for (const d of (db.devoluciones || [])) add(diaDe(d.fecha), d.pago, -(d.totalCents || 0), false);
  for (const caja of (db.cajas || [])) {
    for (const m of (caja.movimientos || [])) {
      if (!(m && m.tipo === "ingreso" && m.categoria === "abono")) continue;
      const fp = String(m.formaPago || "efectivo").trim().toLowerCase();
      if (fp === "ajuste" || fp === "credito") continue;
      add(diaDe(m.fecha), fp, m.montoCents || 0, false);
    }
  }
  const porMes = new Map();
  Array.from(map.values()).sort((a, b) => a.dia.localeCompare(b.dia)).forEach((d) => {
    d.totalCents = Object.keys(d.metodos).reduce((s, k) => s + (d.metodos[k] || 0), 0);
    if (!porMes.has(d.mes)) porMes.set(d.mes, { mes: d.mes, metodos: {}, numVentas: 0, dias: [] });
    const m = porMes.get(d.mes);
    m.numVentas += d.numVentas || 0;
    m.dias.push({ dia: d.dia, numVentas: d.numVentas, metodos: d.metodos, totalCents: d.totalCents });
    Object.keys(d.metodos).forEach((k) => { m.metodos[k] = (m.metodos[k] || 0) + (d.metodos[k] || 0); });
  });
  const meses = Array.from(porMes.values()).map((b) => ({
    mes: b.mes,
    numVentas: b.numVentas,
    metodos: b.metodos,
    dias: b.dias,
    totalCents: Object.keys(b.metodos).reduce((s, k) => s + (b.metodos[k] || 0), 0)
  })).sort((a, b) => a.mes.localeCompare(b.mes));
  return { meses };
}

function reimpresionDia(fechaISO) {
  const dia = (fechaISO || localDay(new Date().toISOString())).slice(0, 10);
  const turnos = (db.cajas || []).filter((c) => {
    const ref = c.cierreFecha || c.aperturaFecha;
    return c.corte && ref && localDay(ref) === dia;
  }).map((c) => {
    const cred = creditosDeCaja(c.id);
    const ventasCaja = (db.ventas || []).filter((v) => v.cajaId === c.id && ventaCuentaEnCorte(v));
    const credProv = resumenCreditosProveedor(localDay(c.aperturaFecha || c.cierreFecha || dia));
    // BRUTO cobrado por método (sin restar devoluciones ni sumar abonos; sin crédito).
    // Se recalcula aquí para que los cortes viejos (guardados sin este dato) también
    // impriman "VENTAS COBRADAS" sin restar la devolución dos veces.
    const porMetodoCobrado = {};
    for (const v of ventasCaja) {
      for (const p of desglosePagos(v)) {
        if (String(p.metodo || "").toLowerCase() === "credito") continue;
        porMetodoCobrado[p.metodo] = (porMetodoCobrado[p.metodo] || 0) + (p.montoCents || 0);
      }
    }
    const corte = Object.assign({}, c.corte, {
      ventasPorDepto: sumarVentasPorDepto(ventasCaja),
      carnesBascula: sumarCarnesBascula(ventasCaja),
      porMetodoCobrado,
      creditosProveedor: credProv.lista,
      creditosProveedorCents: credProv.totalCents
    });
    return {
      id: c.id, usuario: c.usuario || "", aperturaFecha: c.aperturaFecha, cierreFecha: c.cierreFecha,
      corte, creditos: cred.lista, creditoVentas: cred.creditoVentas, creditoDev: cred.creditoDev
    };
  });
  const eleventa = (db.cortesEleventa || []).filter((c) => String(c.dia || "").slice(0, 10) === dia);
  return { dia, turnos, eleventa, movimientos: movimientosEfectivoDia(dia) };
}

let ultimaHuellaNube = "";
function mezclarRemoto(parte, opts) {
  opts = opts || {};
  if (!parte) return { cambio: false };
  if (opts.huella && opts.huella === ultimaHuellaNube) return { cambio: false };
  silencioPersist++;
  try {
    mezclaNube.aplicar(db, parte, opts);
    // El saldo de un cliente es DERIVADO de sus movimientos. La mezcla une los
    // movimientos de todas las PCs (ledger completo), pero el campo saldoCents
    // que baja de la nube puede venir de una sola PC y quedar desfasado (p. ej.
    // ventas/abonos hechos en otra PC que entraron a la lista pero no al saldo).
    // Recalcular saldo + saldos corridos desde los movimientos deja el estado de
    // cuenta cuadrado tras sincronizar (el header "Saldo actual" coincide con el
    // pie Cargos − Abonos y con el saldo corrido de la última fila).
    (db.clientes || []).forEach((c) => { if (c && Array.isArray(c.movimientos) && c.movimientos.length) recomputarCredito(c); });
    persist();
    if (opts.huella) ultimaHuellaNube = opts.huella;
    return { cambio: true };
  } finally {
    silencioPersist--;
  }
}
function tomarBajas() {
  const b = db.syncBajas || {};
  return {
    clientes: (b.clientes || []).slice(),
    productos: (b.productos || []).slice(),
    proveedores: (b.proveedores || []).slice(),
    pendientes: (b.pendientes || []).slice()
  };
}

module.exports = {
  init,
  setOnPersist,
  apartar,
  guardarSilencioso,
  folioVentaActual,
  folioDevolucionActual,
  maxIdLista,
  mezclarRemoto,
  tomarBajas,
  getSnapshot,
  getRespaldoConfig,
  bootstrap,
  registrarVenta,
  registrarMovimiento,
  registrarDevolucion,
  detalleDia,
  resumenIngresosMeses,
  renombrarUsuario,
  crearUsuario,
  eliminarUsuario,
  cambiarPin,
  getConfig,
  setConfig,
  marcarConfigurado,
  setFxCache,
  getFxCache,
  importarCatalogoEleventa,
  importarOperativoEleventa,
  getCortesEleventa,
  movimientosEfectivoDia,
  reimpresionDia,
  armarTicketImpresionCaja,
  guardarProducto,
  eliminarProducto,
  guardarCategoria,
  eliminarCategoria,
  getClientes,
  guardarCliente,
  eliminarCliente,
  limpiarHistorialPantallaCliente,
  getHistorialPantallaDesde,
  getOcultarPagadasCliente,
  setOcultarPagadasCliente,
  getOcultarPagadasProveedor,
  setOcultarPagadasProveedor,
  movimientoCredito,
  estadoCuentaCliente,
  abonarCredito,
  getEfectivoCasa,
  cancelarMovimientoCredito,
  resumenCreditos,
  resumenAuditoria,
  getEsperas,
  guardarEspera,
  eliminarEspera,
  getApartados,
  crearApartado,
  abonarApartado,
  liquidarApartado,
  entregarApartado,
  eliminarApartado,
  marcarEntregado,
  actualizarNotaApartado,
  guardarPaquete,
  eliminarPaquete,
  getVentaPorFolio,
  cancelarVenta,
  ventasDelDia,
  getImagenesProducto,
  setImagenProducto,
  getMovimientos,
  getMovimientosInv,
  reemplazarDatos,
  corteDia,
  estadoCaja,
  abrirCaja,
  setFondoInicialCaja,
  setTipoCambioCaja,
  movimientoEfectivo,
  getMovimientosPendientes,
  liberarMovimientoPendiente,
  abonarCreditoProveedor,
  estadoCuentaProveedor,
  cancelarMovimientoPendiente,
  cancelarCuentaProveedor,
  cancelarMovimientoEfectivo,
  getProveedores,
  guardarProveedor,
  eliminarProveedor,
  cerrarCaja,
  getInventario,
  movimientoInventario,
  getBasculaVistas,
  marcarBasculaVistas,
  reiniciarBasculaVistas,
  resumenBasculaCorte,
  detalleCorteBasculaDia,
  construirConceptosVenta,
  crearFactura,
  getFacturas,
  getFacturaPorId,
  getFacturaPorVenta,
  actualizarFactura,
  facturasPendientes
};
