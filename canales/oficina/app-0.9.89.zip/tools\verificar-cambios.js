"use strict";
/**
 * Verificación rápida tras cambios en Mayoreo (sintaxis + invariantes).
 * Uso (desde resources\app): node tools/verificar-cambios.js
 */
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const root = path.join(__dirname, "..");
const files = [
  "db.js",
  "supabase.js",
  "mezcla-nube.js",
  "printer.js",
  "main.js",
  "preload.js",
  path.join("src", "js", "app.js")
];

let fallos = 0;
function ok(msg) { console.log("  OK  " + msg); }
function fail(msg) { console.error("  FAIL " + msg); fallos++; }
function leer(rel) { return fs.readFileSync(path.join(root, rel), "utf8"); }

console.log("1) Sintaxis");
for (const rel of files) {
  const p = path.join(root, rel);
  if (!fs.existsSync(p)) { fail("no existe " + rel); continue; }
  try {
    execFileSync(process.execPath, ["--check", p], { stdio: "pipe" });
    ok(rel);
  } catch (e) {
    const err = e && e.stderr ? String(e.stderr) : String(e.message || e);
    fail(rel + ": " + err.slice(0, 200));
  }
}

console.log("2) Invariantes efectivo casa / historial / IPC");
const db = leer("db.js");
const app = leer(path.join("src", "js", "app.js"));
const sb = leer("supabase.js");
const mez = leer("mezcla-nube.js");
const pr = leer("printer.js");
const main = leer("main.js");
const pre = leer("preload.js");

if (/if \(formaPago !== "ajuste" && !esEfectivoCasa\)/.test(db)) {
  ok("abonarCredito excluye efectivo_casa de caja");
} else {
  fail("abonarCredito podría estar anotando efectivo_casa en caja");
}

if (/fp === "efectivo_casa"/.test(db)) ok("corte db menciona efectivo_casa");
else fail("faltan filtros de efectivo_casa en corte (db.js)");

if (/efectivo_casa/.test(pr)) ok("printer excluye efectivo_casa");
else fail("printer.js no menciona efectivo_casa");

if (/\[\"efectivo_casa\",\s*\"terminal,id\"\]/.test(sb)) ok("supabase listaTablas incluye efectivo_casa");
else fail("supabase.js incompleto para efectivo_casa");

if (/mezclaLista\(db\.efectivoCasa[\s\S]*?false,\s*null\)/.test(mez)) {
  ok("mezcla efectivoCasa con completo=false");
} else {
  fail("mezcla-nube debe mezclar efectivoCasa con completo=false");
}

if (/if \(r\.ok && !r\.falta\) raw\.efectivo_casa/.test(sb)) {
  ok("descarga no fuerza [] si falta tabla");
} else {
  fail("descarga efectivo_casa no protege espejo local");
}

if (/limpiarHistorialPantallaCliente/.test(db) && /historialPantallaClientes/.test(db)) {
  ok("historial pantalla en db");
} else {
  fail("faltan helpers de historial pantalla");
}

for (const [nombre, src] of [["main", main], ["preload", pre]]) {
  if (/limpiarHistorialPantallaCliente/.test(src) && /getHistorialPantallaDesde/.test(src)) ok("IPC " + nombre);
  else fail("IPC incompleto en " + nombre);
}

if (/Efectivo casa \(NO va|no va al corte/i.test(app)) {
  fail("UI todavía muestra etiqueta de corte en efectivo casa");
} else if (/option value="efectivo_casa">Efectivo casa</.test(app)) {
  ok("UI efectivo casa sin etiqueta de corte");
} else {
  fail("UI efectivo casa no encontrada");
}

if (/filtrarMovsPantalla/.test(app) && /Limpiar historial en pantalla/.test(app)) {
  ok("UI limpiar historial");
} else {
  fail("UI limpiar historial incompleta");
}

if (/clienteCasa/.test(db) && /c\.clienteCasa/.test(sb) && /casaLocal/.test(mez)) {
  ok("clientes casa excluidos del sync");
} else {
  fail("faltan protecciones de clientes casa en db/supabase/mezcla");
}

if (/cle-casa/.test(app) && /Clientes casa/.test(app)) ok("UI clientes casa");
else fail("UI clientes casa incompleta");

console.log(fallos ? ("\nResultado: " + fallos + " fallo(s)") : "\nResultado: todo bien");
process.exit(fallos ? 1 : 0);
