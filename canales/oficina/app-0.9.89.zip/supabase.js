"use strict";

/* ============================================================
   Sincronización DESGLOSADA hacia Supabase (PostgREST).
   - Lee el snapshot local (db.json) y sube tablas por lotes.
   - No bloquea la venta: se dispara a mano o en segundo plano.
   - Requiere: URL del proyecto + service_role key.
   ============================================================ */

const https = require("https");
const { URL } = require("url");
const fs = require("fs");

let getConfig = () => ({});
let getDb = () => null;
let getTicketCaja = () => null;
let guardarSilencioso = () => {};
let mezclarRemoto = () => ({ cambio: false });
let cacheFile = null; // archivo local con la huella de cada fila ya subida (para deltas)
const estado = {
  enviando: false,
  ultimoOk: null,
  ultimoError: null,
  ultimoIntento: null,
  ultimoKeepAlive: null,
  progreso: null
};

function init(opts) {
  getConfig = opts.getConfig || getConfig;
  getDb = opts.getDb || getDb;
  getTicketCaja = opts.getTicketCaja || getTicketCaja;
  if (opts.guardarSilencioso) guardarSilencioso = opts.guardarSilencioso;
  if (opts.mezclarRemoto) mezclarRemoto = opts.mezclarRemoto;
  if (opts.cacheFile) cacheFile = opts.cacheFile;
}

// ---- Caché de deltas: huella (hash) por fila ya confirmada en la nube --------
// { tabla: { claveFila: huella } }. Solo se sube lo que cambió respecto a esto.
function loadCache() {
  if (!cacheFile) return {};
  try { return JSON.parse(fs.readFileSync(cacheFile, "utf8")) || {}; } catch (_) { return {}; }
}
function saveCache(c) {
  if (!cacheFile) return;
  try {
    const tmp = cacheFile + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(c));
    fs.renameSync(tmp, cacheFile);
  } catch (_) {}
}
// Huella estable de una fila (dos hashes + longitud → colisión prácticamente nula).
function hashRow(row) {
  const s = JSON.stringify(row);
  let h1 = 2166136261;
  for (let i = 0; i < s.length; i++) { h1 ^= s.charCodeAt(i); h1 = Math.imul(h1, 16777619); }
  let h2 = 5381;
  for (let i = 0; i < s.length; i++) { h2 = (Math.imul(h2, 33) ^ s.charCodeAt(i)) >>> 0; }
  return (h1 >>> 0).toString(16) + "-" + (h2 >>> 0).toString(16) + "-" + s.length;
}

function cfg() {
  const c = getConfig() || {};
  const s = c.supabase || {};
  const intervalo = parseInt(s.intervaloMin, 10);
  let retener = parseInt(s.retenerAnos, 10);
  if (!Number.isFinite(retener) || retener < 1) retener = 2;
  if (retener > 10) retener = 10;
  return {
    activo: !!s.activo,
    url: String(s.url || "").replace(/\/+$/, ""),
    key: String(s.key || "").trim(),
    // Si está activo y no pusieron intervalo, default 6 h (evita que el free se pause).
    intervaloMin: Math.max(0, Number.isFinite(intervalo) ? intervalo : 360),
    retenerAnos: retener
  };
}

function estadoActual() {
  const c = cfg();
  return {
    activo: c.activo,
    configurado: !!(c.url && c.key),
    intervaloMin: c.intervaloMin,
    ultimoOk: estado.ultimoOk,
    ultimoError: estado.ultimoError,
    ultimoIntento: estado.ultimoIntento,
    ultimoKeepAlive: estado.ultimoKeepAlive,
    enviando: estado.enviando,
    progreso: estado.progreso
  };
}

function request(method, path, body, prefer) {
  return new Promise((resolve) => {
    const c = cfg();
    if (!c.url || !c.key) return resolve({ ok: false, error: "Falta URL o API key de Supabase." });
    let url;
    try { url = new URL(c.url + "/rest/v1/" + path.replace(/^\//, "")); }
    catch (e) { return resolve({ ok: false, error: "URL de Supabase inválida." }); }

    const payload = body == null ? null : Buffer.from(JSON.stringify(body), "utf8");
    const headers = {
      "apikey": c.key,
      "Authorization": "Bearer " + c.key,
      "Content-Type": "application/json",
      "Prefer": prefer || "resolution=merge-duplicates,return=minimal"
    };
    if (payload) headers["Content-Length"] = payload.length;

    const lib = url.protocol === "http:" ? require("http") : https;
    const req = lib.request({
      method,
      hostname: url.hostname,
      port: url.port || (url.protocol === "https:" ? 443 : 80),
      path: url.pathname + url.search,
      headers,
      timeout: 120000
    }, (res) => {
      let data = "";
      res.setEncoding("utf8");
      res.on("data", (chunk) => { data += chunk; });
      res.on("end", () => {
        const ok = res.statusCode >= 200 && res.statusCode < 300;
        resolve({ ok, status: res.statusCode, body: data });
      });
    });
    req.on("timeout", () => req.destroy(new Error("Tiempo de espera agotado")));
    req.on("error", (e) => resolve({ ok: false, error: e.message }));
    if (payload) req.write(payload);
    req.end();
  });
}

function quitarColumna(rows, col) {
  return (rows || []).map((r) => {
    const n = Object.assign({}, r);
    delete n[col];
    return n;
  });
}

async function upsert(table, rows, onConflict) {
  if (!rows || !rows.length) return { ok: true, count: 0 };
  const batch = table === "corte_tickets" ? 40 : 400;
  let total = 0;
  let working = rows;
  for (let i = 0; i < working.length; i += batch) {
    let slice = working.slice(i, i + batch);
    const qs = onConflict ? ("?on_conflict=" + encodeURIComponent(onConflict)) : "";
    let r = await request("POST", table + qs, slice, "resolution=merge-duplicates,return=minimal");
    let guard = 0;
    while (!r.ok && guard < 8) {
      const msg = r.error || ("HTTP " + r.status + " " + String(r.body || "").slice(0, 400));
      if (/PGRST205|Could not find the table|does not exist/i.test(msg)) {
        return { ok: true, skipped: true, count: 0, error: msg, table };
      }
      const col = msg.match(/Could not find the '([^']+)' column/i);
      if (!col) return { ok: false, error: msg, table, count: total };
      working = quitarColumna(working, col[1]);
      slice = working.slice(i, i + batch);
      r = await request("POST", table + qs, slice, "resolution=merge-duplicates,return=minimal");
      guard++;
    }
    if (!r.ok) {
      const msg = r.error || ("HTTP " + r.status + " " + String(r.body || "").slice(0, 300));
      return { ok: false, error: msg, table, count: total };
    }
    total += slice.length;
    estado.progreso = { tabla: table, enviados: total, de: working.length };
  }
  return { ok: true, count: total };
}

async function deleteWhere(table, filter) {
  // filter ej: "terminal=eq.POS1"
  const r = await request("DELETE", table + "?" + filter, null, "return=minimal");
  if (!r.ok) return { ok: false, error: r.error || ("HTTP " + r.status + " " + String(r.body || "").slice(0, 200)) };
  return { ok: true };
}

function terminalId(db) {
  return String((db.config && db.config.terminal) || "POS-LOCAL");
}

/** Id estable (no serial) para no borrar/recrear filas en cada sync. */
function idEstable(...parts) {
  const s = parts.map((p) => (p == null ? "" : String(p))).join("|");
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  // positivo int32, nunca 0
  return (h >>> 0) || 1;
}

/** Corte de la ventana móvil (últimos N años). Lo más viejo no se sube a la nube. */
function corteRetencionMs() {
  const anos = cfg().retenerAnos || 2;
  return Date.now() - anos * 365.25 * 24 * 60 * 60 * 1000;
}

function fechaDentroVentana(fecha, corteMs) {
  if (fecha == null || fecha === "") return true;
  const t = new Date(fecha).getTime();
  if (isNaN(t)) return true;
  return t >= corteMs;
}

function mapDb(db) {
  const t = terminalId(db);
  const corteMs = corteRetencionMs();
  const out = {
    pos_terminal: [{
      terminal: t,
      negocio: Object.assign({}, (db.config && db.config.negocio) || {}, { _ocultos: db.proveedoresOcultos || [] }),
      synced_at: new Date().toISOString()
    }],
    categorias: (db.categorias || []).map((c) => ({
      terminal: t, id: String(c.id), nombre: c.nombre || "", emoji: c.emoji || "", orden: c.orden || 0
    })),
    productos: (db.productos || []).map((p) => ({
      terminal: t, id: Number(p.id), cat: p.cat || null, nombre: p.nombre || "",
      precio_cents: p.precioCents == null ? null : Number(p.precioCents),
      unidad: p.unidad || null, controla_inventario: !!p.controlaInventario,
      existencia: p.existencia == null ? null : Number(p.existencia),
      stock_min: p.stockMin == null ? null : Number(p.stockMin),
      activo: p.activo !== false, en_panel: p.enPanel == null ? null : !!p.enPanel,
      clave_prod_serv: p.claveProdServ || null, clave_unidad: p.claveUnidad || null,
      iva_tasa: p.ivaTasa == null ? null : Number(p.ivaTasa)
    })),
    paquetes: (db.paquetes || []).map((pq) => ({
      terminal: t, id: String(pq.id), nombre: pq.nombre || "", emoji: pq.emoji || "",
      precio_cents: pq.precioCents == null ? null : Number(pq.precioCents),
      componentes: pq.componentes || []
    })),
    usuarios: (db.usuarios || []).map((u) => ({
      terminal: t, id: Number(u.id), nombre: u.nombre || "", rol: u.rol || "",
      pin: u.pin != null ? String(u.pin) : null
    })),
    clientes: [],
    credito_movimientos: [],
    ventas: [],
    venta_items: [],
    venta_pagos: [],
    devoluciones: [],
    devolucion_items: [],
    cajas: [],
    caja_movimientos: [],
    movimientos_inv: [],
    movimientos: [],
    apartados: [],
    facturas: [],
    cortes_eleventa: [],
    movimientos_pendientes: [],
    corte_tickets: [],
    proveedores: [],
    proveedores_ocultos: [],
    ordenes_espera: [],
    // Tabla NUEVA: abonos "efectivo casa". No altera credito_movimientos ni caja.
    efectivo_casa: []
  };

  // Clientes y créditos: se suben completos (nunca caducan), EXCEPTO "clientes casa"
  // (solo esta PC: no van a la otra terminal ni a Supabase compartido).
  const idsCasa = new Set();
  for (const c of (db.clientes || [])) {
    if (c && c.clienteCasa) {
      if (c.id != null) idsCasa.add(Number(c.id));
      continue;
    }
    out.clientes.push({
      terminal: t, id: Number(c.id), nombre: c.nombre || "", telefono: c.telefono || "",
      rfc: c.rfc || "", direccion: c.direccion || "", notas: c.notas || "",
      email: c.email || "", regimen_fiscal: c.regimenFiscal || "", uso_cfdi: c.usoCfdi || "",
      codigo_postal: c.codigoPostal || "", credito_activo: !!c.creditoActivo,
      limite_cents: Number(c.limiteCents || 0), saldo_cents: Number(c.saldoCents || 0)
    });
    (c.movimientos || []).forEach((m, idx) => {
      const filaCred = {
        terminal: t, cliente_id: Number(c.id), idx,
        fecha: m.fecha || null, tipo: m.tipo || null,
        monto_cents: Number(m.montoCents || 0), saldo_cents: Number(m.saldoCents || 0),
        nota: m.nota || null, comentario: m.comentario || null,
        forma_pago: m.formaPago || null,
        venta_folio: m.ventaFolio == null ? null : Number(m.ventaFolio),
        usuario: m.usuario || null, aplicaciones: m.aplicaciones || null
      };
      // uid/caja_mov: columnas opcionales; si no existen en Supabase, upsert las quita solo.
      if (m.uid) filaCred.uid = String(m.uid);
      if (m.cajaMov) filaCred.caja_mov = m.cajaMov;
      out.credito_movimientos.push(filaCred);
    });
  }

  // Ventas: solo ventana móvil (últimos N años). Lo más viejo no se re-sube.
  for (const v of (db.ventas || [])) {
    if (!fechaDentroVentana(v.fecha, corteMs)) continue;
    out.ventas.push({
      terminal: t, folio: Number(v.folio), fecha: v.fecha || null,
      caja_id: v.cajaId == null ? null : Number(v.cajaId),
      cliente: v.cliente || null, usuario: v.usuario || null,
      subtotal_cents: Number(v.subtotalCents || 0), descuento_cents: Number(v.descuentoCents || 0),
      total_cents: Number(v.totalCents || 0), pago: v.pago || null,
      recibido_cents: Number(v.recibidoCents || 0), cambio_cents: Number(v.cambioCents || 0),
      cancelada: !!v.cancelada, cancelada_motivo: v.canceladaMotivo || null,
      cancelada_fecha: v.canceladaFecha || null,
      saldo_cliente_cents: v.saldoClienteCents == null ? null : Number(v.saldoClienteCents),
      tipo_cambio: v.tipoCambio == null ? null : Number(v.tipoCambio),
      dolares_recibidos: v.dolaresRecibidos == null ? null : Number(v.dolaresRecibidos),
      nota_apartado: v.notaApartado || null,
      credito_cliente_id: v.creditoClienteId == null ? null : Number(v.creditoClienteId),
      origen_eleventa: !!v.origenEleventa,
      bascula_folio: v.basculaFolio != null ? String(v.basculaFolio) : (v.origenBascula && v.origenBascula.folio != null ? String(v.origenBascula.folio) : null),
      origen_bascula: v.origenBascula || null,
      es_apartado_pago: !!v.esApartadoPago
    });
    (v.items || []).forEach((it, idx) => {
      out.venta_items.push({
        terminal: t, venta_folio: Number(v.folio), idx,
        tipo: it.tipo || null, nombre: it.nombre || null,
        cant: it.cant == null ? null : Number(it.cant),
        unidad: it.unidad || null,
        precio_cents: it.precioCents == null ? null : Number(it.precioCents),
        importe_cents: it.importeCents == null ? null : Number(it.importeCents),
        ref_id: it.ref == null ? null : Number(it.ref),
        producto_id: it.productoId == null ? (it.ref == null ? null : Number(it.ref)) : Number(it.productoId),
        bascula: !!it.bascula,
        manual: !!it.manual,
        componentes: it.componentes || null,
        extras: it.extras || null
      });
    });
    const pagos = (v.pago === "combinado" && Array.isArray(v.pagos) && v.pagos.length)
      ? v.pagos
      : [{ metodo: v.pago || "otro", montoCents: v.totalCents || 0 }];
    pagos.forEach((pg, idx) => {
      out.venta_pagos.push({
        terminal: t, venta_folio: Number(v.folio), idx,
        metodo: pg.metodo || "otro", monto_cents: Number(pg.montoCents || 0)
      });
    });
  }

  for (const d of (db.devoluciones || [])) {
    if (!fechaDentroVentana(d.fecha, corteMs)) continue;
    out.devoluciones.push({
      terminal: t, folio: Number(d.folio), fecha: d.fecha || null,
      caja_id: d.cajaId == null ? null : Number(d.cajaId),
      venta_folio: d.ventaFolio == null ? null : Number(d.ventaFolio),
      total_cents: Number(d.totalCents || 0), pago: d.pago || null,
      motivo: d.motivo || null, usuario: d.usuario || null
    });
    (d.items || []).forEach((it, idx) => {
      out.devolucion_items.push({
        terminal: t, devolucion_folio: Number(d.folio), idx,
        nombre: it.nombre || null, cant: it.cant == null ? null : Number(it.cant),
        unidad: it.unidad || null, importe_cents: it.importeCents == null ? null : Number(it.importeCents)
      });
    });
  }

  for (const cj of (db.cajas || [])) {
    // Caja abierta siempre; cerradas solo si caen en la ventana.
    const refFecha = cj.cierreFecha || cj.aperturaFecha;
    if (!cj.abierta && !fechaDentroVentana(refFecha, corteMs)) continue;
    out.cajas.push({
      terminal: t, id: Number(cj.id), usuario: cj.usuario || null,
      fondo_cents: Number(cj.fondoCents || 0), tipo_cambio: Number(cj.tipoCambio || 0) || null,
      apertura_fecha: cj.aperturaFecha || null, cierre_fecha: cj.cierreFecha || null,
      abierta: !!cj.abierta, conteo_cents: cj.conteoCents == null ? null : Number(cj.conteoCents),
      corte: cj.corte || null,
      bascula_total_manual_cents: cj.basculaTotalManualCents == null ? null : Number(cj.basculaTotalManualCents),
      paquetes_total_manual_cents: cj.paquetesTotalManualCents == null ? null : Number(cj.paquetesTotalManualCents),
      dinero_en_caja_cierre_cents: cj.dineroEnCajaCierreCents == null ? null : Number(cj.dineroEnCajaCierreCents),
      entregado_cents: cj.entregadoCents == null ? null : Number(cj.entregadoCents)
    });
    (cj.movimientos || []).forEach((m) => {
      out.caja_movimientos.push({
        terminal: t, caja_id: Number(cj.id), id: Number(m.id || 0),
        fecha: m.fecha || null, tipo: m.tipo || null,
        monto_cents: Number(m.montoCents || 0), motivo: m.motivo || null,
        proveedor: m.proveedor || null, categoria: m.categoria || null,
        forma_pago: m.formaPago || null, cliente: m.cliente || null, usuario: m.usuario || null,
        cantidad: m.cantidad == null ? null : Number(m.cantidad),
        pendiente_id: m.pendienteId == null ? null : Number(m.pendienteId)
      });
    });
    const ticket = (typeof getTicketCaja === "function" ? getTicketCaja(cj) : null) || cj.ticketImpresion;
    if (ticket) {
      const ref = cj.cierreFecha || cj.aperturaFecha;
      let dia = null;
      if (ref) {
        const d = new Date(ref);
        if (!isNaN(d.getTime())) {
          const x = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
          dia = x.toISOString().slice(0, 10);
        }
      }
      out.corte_tickets.push({
        terminal: t, caja_id: Number(cj.id),
        dia: dia || new Date().toISOString().slice(0, 10),
        abierta: !!cj.abierta,
        cajero: cj.usuario || null,
        formato: ticket.formato || "mayoreo-corte-v2",
        ticket,
        updated_at: new Date().toISOString()
      });
    }
  }

  (db.movimientosInv || []).forEach((m, i) => {
    if (!fechaDentroVentana(m.fecha, corteMs)) return;
    out.movimientos_inv.push({
      terminal: t,
      id: idEstable(t, "inv", m.fecha, m.productoId, m.tipo, m.cant, m.folio, m.nota, i),
      fecha: m.fecha || null, producto_id: m.productoId == null ? null : Number(m.productoId),
      tipo: m.tipo || null, cant: m.cant == null ? null : Number(m.cant),
      existencia: m.existencia == null ? null : Number(m.existencia),
      folio: m.folio == null ? null : Number(m.folio), nota: m.nota || null, usuario: m.usuario || null
    });
  });
  (db.movimientos || []).forEach((m, i) => {
    if (!fechaDentroVentana(m.fecha, corteMs)) return;
    out.movimientos.push({
      terminal: t,
      id: idEstable(t, "mov", m.fecha, m.tipo, m.usuario, m.detalle, i),
      fecha: m.fecha || null, tipo: m.tipo || null,
      usuario: m.usuario || null, detalle: m.detalle || null
    });
  });

  (db.apartados || []).forEach((a) => {
    const f = a.fecha || a.creado || (a.data && a.data.fecha);
    if (f && !fechaDentroVentana(f, corteMs)) return;
    out.apartados.push({ terminal: t, id: Number(a.id), data: a });
  });
  (db.facturas || []).forEach((f) => {
    const fe = f.fecha || (f.data && f.data.fecha);
    if (fe && !fechaDentroVentana(fe, corteMs)) return;
    out.facturas.push({ terminal: t, id: String(f.id), data: f });
  });
  (db.cortesEleventa || []).forEach((c) => {
    const diaRaw = c.dia || c.fecha || null;
    let dia = null;
    if (diaRaw) {
      const d = new Date(diaRaw);
      if (!isNaN(d.getTime())) dia = d.toISOString().slice(0, 10);
      else dia = String(diaRaw).slice(0, 10);
    }
    if (!dia) return;
    if (!fechaDentroVentana(dia, corteMs)) return;
    out.cortes_eleventa.push({
      terminal: t,
      dia,
      caja: Number(c.caja || c.idCaja || 1),
      total_ventas_cents: Number(c.totalVentasCents || 0),
      entradas_cents: Number(c.entradasCents || 0),
      salidas_cents: Number(c.salidasCents || 0),
      efectivo_cents: Number(c.efectivoCents || 0),
      tarjeta_cents: Number(c.tarjetaCents || 0),
      credito_cents: Number(c.creditoCents || 0),
      transferencia_cents: Number(c.transferenciaCents || 0),
      abonos_efectivo_cents: Number(c.abonosEfectivoCents || 0),
      num_ventas: Number(c.numVentas || 0)
    });
  });

  (db.proveedores || []).forEach((nombre, idx) => {
    const n = String(nombre || "").trim();
    if (!n) return;
    out.proveedores.push({ terminal: t, idx, nombre: n, clave: n.toLowerCase() });
  });
  (db.proveedoresOcultos || []).forEach((clave) => {
    const k = String(clave || "").trim().toLowerCase();
    if (!k) return;
    out.proveedores_ocultos.push({ terminal: t, clave: k });
  });
  (db.ordenesEspera || []).forEach((o) => {
    if (!o || o.id == null) return;
    out.ordenes_espera.push({ terminal: t, id: Number(o.id), data: o });
  });

  (db.movimientosPendientes || []).forEach((p) => {
    out.movimientos_pendientes.push({
      terminal: t, id: Number(p.id),
      fecha: p.fecha || null, tipo: p.tipo || null,
      categoria: p.categoria || null,
      monto_cents: Number(p.montoCents || 0),
      motivo: p.motivo || null, proveedor: p.proveedor || null,
      forma_pago: p.formaPago || null,
      cantidad: p.cantidad == null ? null : Number(p.cantidad),
      estado: p.estado || "pendiente",
      usuario: p.usuario || null,
      pago_fecha: p.pagoFecha || null,
      pago_forma: p.pagoForma || null,
      pago_caja_id: p.pagoCajaId == null ? null : Number(p.pagoCajaId),
      pago_mov_id: p.pagoMovId == null ? null : Number(p.pagoMovId),
      abono_de: p.abonoDe == null ? null : Number(p.abonoDe)
    });
  });

  // Espejo "efectivo casa": no subir filas de clientes casa (solo locales).
  for (const e of (db.efectivoCasa || [])) {
    if (!e || e.id == null) continue;
    if (e.clienteId != null && idsCasa.has(Number(e.clienteId))) continue;
    out.efectivo_casa.push({
      terminal: t,
      id: String(e.id),
      cliente_id: e.clienteId == null ? null : Number(e.clienteId),
      cliente_nombre: e.clienteNombre || null,
      fecha: e.fecha || null,
      monto_cents: Number(e.montoCents || 0),
      saldo_cents: Number(e.saldoCents || 0),
      comentario: e.comentario || null,
      nota: e.nota || null,
      aplicaciones: e.aplicaciones || null,
      usuario: e.usuario || null,
      caja_id: e.cajaId == null ? null : Number(e.cajaId),
      activo: e.activo !== false
    });
  }

  return { terminal: t, tables: out };
}

async function probar() {
  const c = cfg();
  if (!c.url || !c.key) return { ok: false, error: "Configura la URL y la API key (service_role) de Supabase." };
  // Lectura mínima: si las tablas no existen, el error lo dice claro.
  const r = await request("GET", "pos_terminal?select=terminal&limit=1", null, "return=representation");
  if (r.ok) return { ok: true };
  const msg = r.error || ("HTTP " + r.status + " " + String(r.body || "").slice(0, 400));
  if (/relation .* does not exist|Could not find the table/i.test(msg)) {
    return { ok: false, error: "Conectó a Supabase, pero faltan las tablas. Ejecuta el SQL de supabase/schema.sql en el SQL Editor." };
  }
  return { ok: false, error: msg };
}

async function keepAlive() {
  const c = cfg();
  if (!c.url || !c.key) return { ok: false, error: "Sin credenciales." };
  // Una lectura mínima basta para que Supabase Free no pause el proyecto.
  const r = await request("GET", "pos_terminal?select=terminal&limit=1", null, "return=representation");
  if (r.ok) {
    estado.ultimoKeepAlive = new Date().toISOString();
    return { ok: true };
  }
  return { ok: false, error: r.error || ("HTTP " + r.status) };
}

function listaIn(valores) {
  return (valores || []).map((v) => {
    const s = String(v);
    if (/^-?\d+$/.test(s)) return s;
    return '"' + s.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
  }).join(",");
}

// Quita de la nube filas que el sistema ya no tiene (cliente borrado, compra
// cancelada, proveedor quitado). No borra la tabla entera si la lista local viene vacía.
async function quitarFilasQueYaNoEstan(terminal, tables) {
  const avisos = [];
  const t = "terminal=eq." + encodeURIComponent(terminal);
  const intentar = async (tabla, filtro) => {
    const r = await deleteWhere(tabla, filtro);
    if (!r.ok) avisos.push(tabla + ": " + (r.error || "no se pudo limpiar"));
  };
  // Solo clientes "normales" van en tables.clientes (los casa no se suben).
  // Así, al limpiar, los que eran casa (o se borraron) salen de la nube y
  // no llegan a la otra PC.
  const clientes = (tables.clientes || []).map((c) => c.id);
  if (clientes.length) {
    await intentar("clientes", t + "&id=not.in.(" + listaIn(clientes) + ")");
    await intentar("credito_movimientos", t + "&cliente_id=not.in.(" + listaIn(clientes) + ")");
  }
  const ecIds = (tables.efectivo_casa || []).map((e) => e.id).filter(Boolean);
  if (ecIds.length) {
    await intentar("efectivo_casa", t + "&id=not.in.(" + listaIn(ecIds) + ")");
  }
  const pendientes = (tables.movimientos_pendientes || []).map((p) => p.id);
  if (pendientes.length) {
    await intentar("movimientos_pendientes", t + "&id=not.in.(" + listaIn(pendientes) + ")");
  }
  const nombres = (tables.proveedores || []).map((p) => p.nombre).filter(Boolean);
  if (nombres.length) {
    await intentar("proveedores", t + "&nombre=not.in.(" + listaIn(nombres) + ")");
  }
  return avisos;
}

async function limpiarHistorialNube() {
  const c = cfg();
  const anos = c.retenerAnos || 2;
  // RPC: limpia solo historial de ventas/cortes/cajas viejos.
  // NUNCA toca clientes ni credito_movimientos.
  const r = await request("POST", "rpc/limpiar_historial_pos", { p_anos: anos }, "return=representation");
  if (!r.ok) {
    // Si aún no corrieron el SQL, no fallar la sync.
    const msg = r.error || ("HTTP " + r.status + " " + String(r.body || "").slice(0, 200));
    return { ok: false, error: msg };
  }
  let detalle = null;
  try { detalle = r.body ? JSON.parse(r.body) : null; } catch (_) { detalle = r.body; }
  return { ok: true, detalle };
}

async function sincronizarTodo(opts) {
  opts = opts || {};
  const full = !!opts.full; // true = reenvía TODO (ignora la caché de deltas)
  if (bajando) return { ok: false, ocupado: true, error: "Bajando cambios.", ...estadoActual() };
  if (estado.enviando) return { ok: false, error: "Ya hay una sincronización en curso.", ...estadoActual() };
  const c = cfg();
  if (!c.url || !c.key) return { ok: false, error: "Configura URL y API key de Supabase.", ...estadoActual() };
  const dbPre = getDb();
  if (dbPre && dbPre.config && dbPre.config.sincronizarNube === false) {
    return { ok: false, error: "Esperando la descarga inicial.", ...estadoActual() };
  }

  const db = getDb();
  if (!db) return { ok: false, error: "Base local no disponible.", ...estadoActual() };

  estado.enviando = true;
  estado.ultimoIntento = new Date().toISOString();
  estado.ultimoError = null;
  estado.progreso = { etapa: "preparando" };
  const started = estado.ultimoIntento;
  const resumen = {};

  try {
    const { terminal, tables } = mapDb(db);

    // Upsert de TODAS las tablas (incluye movimientos). Nunca se hace DELETE masivo:
    // un apagón a media sync no deja la nube vacía.
    const order = listaTablas();

    // DELTA: solo se suben las filas nuevas o modificadas respecto a la última
    // sincronización confirmada. Los meses viejos (que no cambian) no se re-suben.
    const cache = full ? {} : loadCache();
    const nextCache = {};
    for (const [tbl, conflict] of order) {
      const rows = tables[tbl] || [];
      const keys = conflict.split(",");
      const prev = cache[tbl] || {};
      const cur = {};
      const changed = [];
      for (const row of rows) {
        const k = keys.map((col) => String(row[col])).join("\u0001");
        const h = hashRow(row);
        cur[k] = h;
        if (prev[k] !== h) changed.push(row);
      }
      estado.progreso = { etapa: "subiendo", tabla: tbl, de: changed.length };
      const r = await upsert(tbl, changed, conflict);
      if (!r.ok) throw new Error(tbl + ": " + r.error);
      if (r.skipped) {
        nextCache[tbl] = prev;
        resumen[tbl] = 0;
        resumen.faltan_tablas = (resumen.faltan_tablas || []).concat(tbl);
        continue;
      }
      nextCache[tbl] = cur;
      resumen[tbl] = r.count;
    }
    // Se guarda la caché SOLO cuando todas las tablas subieron bien; si algo
    // falla, la próxima corrida reintenta desde lo último confirmado.
    saveCache(nextCache);

    const avisos = await borrarSoloLoQueEstaPcQuito(terminal);
    if (avisos.length) resumen.avisos_limpieza = avisos;

    // Ventana móvil: al sincronizar, limpia en la nube lo más viejo que 2 años
    // (ventas/cortes/cajas…). Clientes y créditos NO se tocan.
    estado.progreso = { etapa: "limpieza", tabla: "historial>" + (c.retenerAnos || 2) + "a" };
    const limpia = await limpiarHistorialNube();
    if (limpia.ok) resumen.limpieza = limpia.detalle;
    else resumen.limpieza_aviso = limpia.error;

    const finMio = new Date().toISOString();
    await request("POST", "sync_log", [{
      terminal, started_at: started, finished_at: finMio,
      ok: true, detalle: resumen
    }], "return=minimal");
    ultimoFinishedMio = finMio;

    // Keep-alive implícito al sincronizar
    estado.ultimoKeepAlive = new Date().toISOString();
    estado.ultimoOk = new Date().toISOString();
    estado.progreso = null;
    return { ok: true, resumen, ...estadoActual() };
  } catch (e) {
    estado.ultimoError = String(e && e.message ? e.message : e);
    estado.progreso = null;
    try {
      await request("POST", "sync_log", [{
        terminal: terminalId(db), started_at: started, finished_at: new Date().toISOString(),
        ok: false, detalle: { error: estado.ultimoError }
      }], "return=minimal");
    } catch (_) {}
    return { ok: false, error: estado.ultimoError, ...estadoActual() };
  } finally {
    estado.enviando = false;
  }
}

async function listarTicketsCorte(filtro) {
  filtro = filtro || {};
  const db = getDb() || {};
  const t = filtro.terminal || terminalId(db);
  let q = "corte_tickets?select=terminal,caja_id,dia,abierta,cajero,formato,ticket,updated_at&order=dia.desc,caja_id.desc&limit=120";
  if (filtro.todas) {
    /* sin filtro de terminal: la otra PC ve todos los cortes subidos */
  } else if (t) {
    q += "&terminal=eq." + encodeURIComponent(t);
  }
  if (filtro.dia) q += "&dia=eq." + encodeURIComponent(String(filtro.dia).slice(0, 10));
  const r = await request("GET", q, null, "return=representation");
  if (!r.ok) {
    const msg = r.error || ("HTTP " + r.status + " " + String(r.body || "").slice(0, 300));
    if (/Could not find the table|relation .* does not exist/i.test(msg)) {
      return { ok: false, error: "Falta la tabla corte_tickets. Ejecuta el SQL nuevo en Supabase y sincroniza." };
    }
    return { ok: false, error: msg };
  }
  let rows = [];
  try { rows = r.body ? JSON.parse(r.body) : []; } catch (_) { rows = []; }
  return { ok: true, tickets: Array.isArray(rows) ? rows : [] };
}

function listaTablas() {
  return [
    ["pos_terminal", "terminal"],
    ["categorias", "terminal,id"],
    ["productos", "terminal,id"],
    ["paquetes", "terminal,id"],
    ["usuarios", "terminal,id"],
    ["clientes", "terminal,id"],
    ["credito_movimientos", "terminal,cliente_id,idx"],
    ["cajas", "terminal,id"],
    ["caja_movimientos", "terminal,caja_id,id"],
    ["ventas", "terminal,folio"],
    ["venta_items", "terminal,venta_folio,idx"],
    ["venta_pagos", "terminal,venta_folio,idx"],
    ["devoluciones", "terminal,folio"],
    ["devolucion_items", "terminal,devolucion_folio,idx"],
    ["movimientos_inv", "terminal,id"],
    ["movimientos", "terminal,id"],
    ["apartados", "terminal,id"],
    ["facturas", "terminal,id"],
    ["proveedores", "terminal,idx"],
    ["proveedores_ocultos", "terminal,clave"],
    ["ordenes_espera", "terminal,id"],
    ["movimientos_pendientes", "terminal,id"],
    ["corte_tickets", "terminal,caja_id"],
    ["cortes_eleventa", "terminal,dia,caja"],
    ["efectivo_casa", "terminal,id"]
  ];
}

function claveFila(row, conflict) {
  return conflict.split(",").map((col) => String(row[col])).join("\u0001");
}

function suciasCrudas() {
  const db = getDb();
  const sucias = {};
  if (!db) return sucias;
  const { tables } = mapDb(db);
  const cache = loadCache();
  listaTablas().forEach(([tbl, conflict]) => {
    const prev = cache[tbl];
    if (!prev || !Object.keys(prev).length) return;
    (tables[tbl] || []).forEach((row) => {
      const k = claveFila(row, conflict);
      if (prev[k] !== hashRow(row)) {
        if (!sucias[tbl]) sucias[tbl] = {};
        sucias[tbl][k] = true;
      }
    });
  });
  return sucias;
}

function protegerLocal() {
  const sucias = suciasCrudas();
  const toma = (tbl, idx) => {
    const o = {};
    Object.keys(sucias[tbl] || {}).forEach((k) => { o[k.split("\u0001")[idx]] = true; });
    return o;
  };
  const ventas = toma("ventas", 1);
  Object.keys(sucias.venta_items || {}).forEach((k) => { ventas[k.split("\u0001")[1]] = true; });
  Object.keys(sucias.venta_pagos || {}).forEach((k) => { ventas[k.split("\u0001")[1]] = true; });
  const clientes = toma("clientes", 1);
  Object.keys(sucias.credito_movimientos || {}).forEach((k) => { clientes[k.split("\u0001")[1]] = true; });
  const movs = {};
  Object.keys(sucias.caja_movimientos || {}).forEach((k) => {
    const p = k.split("\u0001");
    movs[p[1] + "|" + p[2]] = true;
  });
  return {
    categorias: toma("categorias", 1),
    productos: toma("productos", 1),
    paquetes: toma("paquetes", 1),
    usuarios: toma("usuarios", 1),
    clientes,
    ventas,
    cajas: toma("cajas", 1),
    movs,
    pendientes: toma("movimientos_pendientes", 1),
    devoluciones: toma("devoluciones", 1),
    apartados: toma("apartados", 1),
    proveedores: sucias.proveedores || {},
    pos_terminal: sucias.pos_terminal || {}
  };
}

function reconciliarCache(sucias) {
  const db = getDb();
  if (!db) return;
  const { tables } = mapDb(db);
  const prev = loadCache();
  const next = {};
  listaTablas().forEach(([tbl, conflict]) => {
    const viejo = prev[tbl] || {};
    const marcadas = (sucias && sucias[tbl]) || {};
    const cur = {};
    (tables[tbl] || []).forEach((row) => {
      const k = claveFila(row, conflict);
      if (marcadas[k]) {
        if (viejo[k] !== undefined) cur[k] = viejo[k];
      } else {
        cur[k] = hashRow(row);
      }
    });
    next[tbl] = cur;
  });
  saveCache(next);
}

async function leerTabla(tabla, filtro) {
  const out = [];
  const page = 1000;
  for (let offset = 0; ; offset += page) {
    let q = tabla + "?select=*";
    if (filtro) q += "&" + filtro;
    q += "&limit=" + page + "&offset=" + offset;
    const r = await request("GET", q, null, "return=representation");
    if (!r.ok) {
      const msg = r.error || String(r.body || "");
      if (/PGRST205|Could not find the table|does not exist/i.test(msg)) return { ok: true, rows: [], falta: true };
      return { ok: false, error: msg.slice(0, 240), rows: out };
    }
    let rows = [];
    try { rows = JSON.parse(r.body || "[]"); } catch (e) { return { ok: false, error: "Respuesta inválida", rows: out }; }
    if (!Array.isArray(rows)) return { ok: false, error: "Respuesta inválida", rows: out };
    out.push.apply(out, rows);
    if (rows.length < page) break;
  }
  return { ok: true, rows: out };
}

function num(v) { const n = Number(v); return Number.isFinite(n) ? n : 0; }
function fechaIso(v) { return v || null; }

function armarParte(raw, completo) {
  const itemsPor = {};
  (raw.venta_items || []).forEach((it) => {
    const f = String(it.venta_folio);
    (itemsPor[f] || (itemsPor[f] = [])).push(it);
  });
  const pagosPor = {};
  (raw.venta_pagos || []).forEach((pg) => {
    const f = String(pg.venta_folio);
    (pagosPor[f] || (pagosPor[f] = [])).push(pg);
  });
  const credPor = {};
  (raw.credito_movimientos || []).forEach((m) => {
    const id = String(m.cliente_id);
    (credPor[id] || (credPor[id] = [])).push(m);
  });
  const movCaja = {};
  (raw.caja_movimientos || []).forEach((m) => {
    const id = String(m.caja_id);
    (movCaja[id] || (movCaja[id] = [])).push(m);
  });
  const tickets = {};
  (raw.corte_tickets || []).forEach((t) => { tickets[String(t.caja_id)] = t.ticket || null; });

  const ventas = (raw.ventas || []).filter((v) => v.pago !== "reserva" && v.cancelada_motivo !== "reserva").map((v) => {
    const folio = num(v.folio);
    const items = (itemsPor[String(folio)] || []).sort((a, b) => num(a.idx) - num(b.idx)).map((it) => ({
      tipo: it.tipo || null,
      nombre: it.nombre || "",
      cant: it.cant == null ? null : Number(it.cant),
      unidad: it.unidad || null,
      precioCents: it.precio_cents == null ? null : num(it.precio_cents),
      importeCents: it.importe_cents == null ? null : num(it.importe_cents),
      ref: it.ref_id == null ? null : num(it.ref_id),
      productoId: it.producto_id == null ? null : num(it.producto_id),
      bascula: !!it.bascula,
      manual: !!it.manual,
      componentes: it.componentes || null,
      extras: it.extras || null
    }));
    const venta = {
      folio, fecha: fechaIso(v.fecha), cajaId: v.caja_id == null ? null : num(v.caja_id),
      cliente: v.cliente || null, usuario: v.usuario || null,
      subtotalCents: num(v.subtotal_cents), descuentoCents: num(v.descuento_cents), totalCents: num(v.total_cents),
      pago: v.pago || null, recibidoCents: num(v.recibido_cents), cambioCents: num(v.cambio_cents),
      cancelada: !!v.cancelada, canceladaMotivo: v.cancelada_motivo || null,
      canceladaFecha: v.cancelada_fecha || null,
      saldoClienteCents: v.saldo_cliente_cents == null ? null : num(v.saldo_cliente_cents),
      tipoCambio: v.tipo_cambio == null ? null : Number(v.tipo_cambio),
      dolaresRecibidos: v.dolares_recibidos == null ? null : Number(v.dolares_recibidos),
      notaApartado: v.nota_apartado || null,
      creditoClienteId: v.credito_cliente_id == null ? null : num(v.credito_cliente_id),
      origenEleventa: !!v.origen_eleventa,
      basculaFolio: v.bascula_folio || null,
      origenBascula: v.origen_bascula || null,
      esApartadoPago: !!v.es_apartado_pago,
      items
    };
    ["canceladaFecha", "saldoClienteCents", "tipoCambio", "dolaresRecibidos", "notaApartado", "basculaFolio", "origenBascula"].forEach((k) => {
      if (venta[k] == null || venta[k] === "") delete venta[k];
    });
    venta.items.forEach((it) => {
      if (it.componentes == null) delete it.componentes;
      if (it.extras == null) delete it.extras;
    });
    const pagos = (pagosPor[String(folio)] || []).sort((a, b) => num(a.idx) - num(b.idx));
    if (venta.pago === "combinado" && pagos.length) {
      venta.pagos = pagos.map((p) => ({ metodo: p.metodo, montoCents: num(p.monto_cents) }));
    }
    return venta;
  });

  const clientes = (raw.clientes || []).filter((c) => c.nombre !== "reserva").map((c) => ({
    id: num(c.id), nombre: c.nombre || "", telefono: c.telefono || "", rfc: c.rfc || "",
    direccion: c.direccion || "", notas: c.notas || "", email: c.email || "",
    regimenFiscal: c.regimen_fiscal || "", usoCfdi: c.uso_cfdi || "", codigoPostal: c.codigo_postal || "",
    creditoActivo: !!c.credito_activo, limiteCents: num(c.limite_cents), saldoCents: num(c.saldo_cents),
    movimientos: (credPor[String(c.id)] || []).sort((a, b) => num(a.idx) - num(b.idx)).map((m) => {
      const mov = {
        fecha: fechaIso(m.fecha), tipo: m.tipo, montoCents: num(m.monto_cents), saldoCents: num(m.saldo_cents),
        nota: m.nota || "", comentario: m.comentario || "", formaPago: m.forma_pago || null,
        ventaFolio: m.venta_folio == null ? null : num(m.venta_folio), usuario: m.usuario || null,
        aplicaciones: m.aplicaciones || null
      };
      if (m.uid) mov.uid = String(m.uid);
      if (m.caja_mov) mov.cajaMov = m.caja_mov;
      return mov;
    })
  }));

  const cajas = (raw.cajas || []).filter((cj) => cj.usuario !== "reserva").map((cj) => {
    const id = num(cj.id);
    const corte = cj.corte || null;
    const caja = {
      id, usuario: cj.usuario || null, fondoCents: num(cj.fondo_cents),
      tipoCambio: cj.tipo_cambio == null ? 0 : Number(cj.tipo_cambio),
      aperturaFecha: fechaIso(cj.apertura_fecha), cierreFecha: fechaIso(cj.cierre_fecha),
      abierta: !!cj.abierta, conteoCents: cj.conteo_cents == null ? null : num(cj.conteo_cents),
      corte,
      basculaTotalManualCents: cj.bascula_total_manual_cents == null
        ? (corte && corte.basculaTotalManualCents != null ? num(corte.basculaTotalManualCents) : null)
        : num(cj.bascula_total_manual_cents),
      paquetesTotalManualCents: cj.paquetes_total_manual_cents == null
        ? (corte && corte.paquetesTotalManualCents != null ? num(corte.paquetesTotalManualCents) : null)
        : num(cj.paquetes_total_manual_cents),
      dineroEnCajaCierreCents: cj.dinero_en_caja_cierre_cents == null ? null : num(cj.dinero_en_caja_cierre_cents),
      entregadoCents: cj.entregado_cents == null ? null : num(cj.entregado_cents),
      ticketImpresion: tickets[String(id)] || null,
      movimientos: (movCaja[String(id)] || []).map((m) => ({
        id: num(m.id), fecha: fechaIso(m.fecha), tipo: m.tipo, montoCents: num(m.monto_cents),
        motivo: m.motivo || "", proveedor: m.proveedor || "", categoria: m.categoria || "",
        formaPago: m.forma_pago || null, cliente: m.cliente || null, usuario: m.usuario || null,
        cantidad: m.cantidad == null ? null : Number(m.cantidad),
        pendienteId: m.pendiente_id == null ? null : num(m.pendiente_id)
      })).filter((m) => m.motivo !== "reserva")
    };
    if (caja.basculaTotalManualCents == null) delete caja.basculaTotalManualCents;
    if (caja.paquetesTotalManualCents == null) delete caja.paquetesTotalManualCents;
    if (!caja.ticketImpresion) delete caja.ticketImpresion;
    return caja;
  });

  const devItems = {};
  (raw.devolucion_items || []).forEach((it) => {
    const f = String(it.devolucion_folio);
    (devItems[f] || (devItems[f] = [])).push(it);
  });
  const devoluciones = (raw.devoluciones || []).filter((d) => d.motivo !== "reserva").map((d) => ({
    folio: num(d.folio), fecha: fechaIso(d.fecha), cajaId: d.caja_id == null ? null : num(d.caja_id),
    ventaFolio: d.venta_folio == null ? null : num(d.venta_folio), totalCents: num(d.total_cents),
    pago: d.pago || null, motivo: d.motivo || "", usuario: d.usuario || null,
    items: (devItems[String(d.folio)] || []).sort((a, b) => num(a.idx) - num(b.idx)).map((it) => ({
      nombre: it.nombre || "", cant: it.cant == null ? null : Number(it.cant),
      unidad: it.unidad || null, importeCents: it.importe_cents == null ? null : num(it.importe_cents)
    }))
  }));

  let negocio = null;
  let ocultos = null;
  if (raw.pos_terminal && raw.pos_terminal[0] && raw.pos_terminal[0].negocio) {
    negocio = Object.assign({}, raw.pos_terminal[0].negocio);
    if (Array.isArray(negocio._ocultos)) ocultos = negocio._ocultos.slice();
  }

  return {
    categorias: (raw.categorias || []).map((c) => ({ id: String(c.id), nombre: c.nombre || "", emoji: c.emoji || "", orden: num(c.orden) })),
    productos: (raw.productos || []).filter((p) => p.nombre !== "reserva").map((p) => ({
      id: num(p.id), cat: p.cat || null, nombre: p.nombre || "", precioCents: p.precio_cents == null ? null : num(p.precio_cents),
      unidad: p.unidad || null, controlaInventario: !!p.controla_inventario,
      existencia: p.existencia == null ? null : Number(p.existencia), stockMin: p.stock_min == null ? null : Number(p.stock_min),
      activo: p.activo !== false, enPanel: p.en_panel == null ? null : !!p.en_panel,
      claveProdServ: p.clave_prod_serv || null, claveUnidad: p.clave_unidad || null,
      ivaTasa: p.iva_tasa == null ? null : Number(p.iva_tasa)
    })),
    paquetes: (raw.paquetes || []).map((p) => ({
      id: String(p.id), nombre: p.nombre || "", emoji: p.emoji || "",
      precioCents: p.precio_cents == null ? null : num(p.precio_cents), componentes: p.componentes || []
    })),
    usuarios: (raw.usuarios || []).map((u) => ({ id: num(u.id), nombre: u.nombre || "", rol: u.rol || "", pin: u.pin != null ? String(u.pin) : "" })),
    clientes,
    proveedores: (raw.proveedores || []).slice().sort((a, b) => num(a.idx) - num(b.idx)).map((p) => p.nombre).filter(Boolean),
    proveedoresOcultos: ocultos,
    cajas,
    movimientosPendientes: (raw.movimientos_pendientes || []).filter((p) => p.motivo !== "reserva").map((p) => ({
      id: num(p.id), fecha: fechaIso(p.fecha), tipo: p.tipo, categoria: p.categoria || "",
      montoCents: num(p.monto_cents), motivo: p.motivo || "", proveedor: p.proveedor || "",
      formaPago: p.forma_pago || null, cantidad: p.cantidad == null ? null : Number(p.cantidad),
      estado: p.estado || "pendiente", usuario: p.usuario || null, pagoFecha: p.pago_fecha || null,
      pagoForma: p.pago_forma || null, pagoCajaId: p.pago_caja_id == null ? null : num(p.pago_caja_id),
      pagoMovId: p.pago_mov_id == null ? null : num(p.pago_mov_id),
      abonoDe: p.abono_de == null ? null : num(p.abono_de)
    })),
    ventas,
    devoluciones,
    movimientos: (raw.movimientos || []).map((m) => ({ id: num(m.id), fecha: fechaIso(m.fecha), tipo: m.tipo, usuario: m.usuario || null, detalle: m.detalle || "" })),
    movimientosInv: (raw.movimientos_inv || []).map((m) => ({
      id: num(m.id), fecha: fechaIso(m.fecha), productoId: m.producto_id == null ? null : num(m.producto_id),
      tipo: m.tipo, cant: m.cant == null ? null : Number(m.cant), existencia: m.existencia == null ? null : Number(m.existencia),
      folio: m.folio == null ? null : num(m.folio), nota: m.nota || "", usuario: m.usuario || null
    })),
    apartados: (raw.apartados || []).map((a) => a.data || a).filter((a) => a && a.id != null),
    ordenesEspera: (raw.ordenes_espera || []).map((o) => o.data || o).filter((o) => o && o.id != null),
    facturas: (raw.facturas || []).map((f) => f.data || f).filter((f) => f && f.id != null),
    cortesEleventa: completo ? (raw.cortes_eleventa || []).map((c) => ({
      dia: c.dia, caja: num(c.caja), totalVentasCents: num(c.total_ventas_cents),
      entradasCents: num(c.entradas_cents), salidasCents: num(c.salidas_cents),
      efectivoCents: num(c.efectivo_cents), tarjetaCents: num(c.tarjeta_cents),
      creditoCents: num(c.credito_cents), transferenciaCents: num(c.transferencia_cents),
      abonosEfectivoCents: num(c.abonos_efectivo_cents), numVentas: num(c.num_ventas)
    })) : null,
    // Solo si la tabla se leyó de verdad (undefined = no tocar el espejo local).
    efectivoCasa: Array.isArray(raw.efectivo_casa) ? raw.efectivo_casa.map((e) => ({
      id: String(e.id),
      clienteId: e.cliente_id == null ? null : num(e.cliente_id),
      clienteNombre: e.cliente_nombre || "",
      fecha: fechaIso(e.fecha),
      montoCents: num(e.monto_cents),
      saldoCents: num(e.saldo_cents),
      comentario: e.comentario || "",
      nota: e.nota || "",
      aplicaciones: e.aplicaciones || [],
      usuario: e.usuario || null,
      cajaId: e.caja_id == null ? null : num(e.caja_id),
      activo: e.activo !== false
    })) : undefined,
    negocio
  };
}

function firmaParte(parte) {
  const liviano = Object.assign({}, parte, {
    cajas: (parte.cajas || []).map((c) => Object.assign({}, c, {
      ticketImpresion: c.ticketImpresion ? (c.ticketImpresion.formato || "ticket") : null
    }))
  });
  return hashRow(liviano);
}

let bajando = false;
let ultimoBajado = null;
let ultimaHuellaDescarga = "";
// Control de egress: solo se baja la base cuando la OTRA PC subió algo nuevo.
// Se detecta con una consulta mínima (unos bytes) a sync_log, en vez de
// re-descargar todas las tablas cada ciclo (lo que agotaba la cuota gratis).
let ultimoSyncLogVisto = "";  // finished_at más reciente ya incorporado
let ultimoFinishedMio = "";   // finished_at de MI propio último envío (no bajar por mis cambios)

// Consulta diminuta: el finished_at más reciente registrado en sync_log.
// Devuelve { hay: true, marca } si se pudo leer; { hay: null } si no (offline/error).
async function novedadRemota() {
  const r = await request("GET", "sync_log?select=finished_at&order=finished_at.desc&limit=1", null, "return=representation");
  if (!r.ok) return { hay: null };
  let rows = [];
  try { rows = JSON.parse(r.body || "[]"); } catch (_) { return { hay: null }; }
  const marca = (rows[0] && rows[0].finished_at) ? String(rows[0].finished_at) : "";
  return { hay: true, marca };
}

// Baja SOLO si sync_log avanzó respecto a lo ya incorporado. Para la copia en
// vivo (que no escribe), baja en cuanto la caja sube algo. Para la caja, evita
// re-bajar sus propios envíos. Si no hay nube/no se pudo sondear, no baja.
async function descargarSiHayNovedad() {
  if (bajando || estado.enviando) return { ok: false, ocupado: true };
  const c = cfg();
  if (!c.activo || !c.url || !c.key) return { ok: false };
  const n = await novedadRemota();
  if (n.hay !== true) return { ok: false, desconocido: true };
  const marca = n.marca || "";
  if (marca && marca === ultimoSyncLogVisto) return { ok: true, cambio: false };
  // Lo más nuevo es mi propio envío (que ya tengo local): no hace falta bajar.
  if (marca && marca === ultimoFinishedMio) { ultimoSyncLogVisto = marca; return { ok: true, cambio: false }; }
  const r = await descargarYMezclar();
  if (r && r.ok && marca) ultimoSyncLogVisto = marca;
  return r;
}

async function borrarSoloLoQueEstaPcQuito(terminal) {
  const db = getDb();
  const avisos = [];
  if (!db || typeof db.tomarBajas !== "function") {
    // tomarBajas vive en db.js; si no está en el snapshot, leer syncBajas directo.
  }
  const b = (db && db.syncBajas) || {};
  const t = "terminal=eq." + encodeURIComponent(terminal);
  const intentar = async (tabla, filtro) => {
    const r = await deleteWhere(tabla, filtro);
    if (!r.ok) avisos.push(tabla + ": " + (r.error || "no se pudo borrar"));
    return r.ok;
  };
  let ok = true;
  if (b.clientes && b.clientes.length) {
    ok = await intentar("clientes", t + "&id=in.(" + listaIn(b.clientes) + ")") && ok;
    ok = await intentar("credito_movimientos", t + "&cliente_id=in.(" + listaIn(b.clientes) + ")") && ok;
  }
  if (b.productos && b.productos.length) {
    ok = await intentar("productos", t + "&id=in.(" + listaIn(b.productos) + ")") && ok;
  }
  if (b.pendientes && b.pendientes.length) {
    ok = await intentar("movimientos_pendientes", t + "&id=in.(" + listaIn(b.pendientes) + ")") && ok;
  }
  if (b.proveedores && b.proveedores.length) {
    ok = await intentar("proveedores", t + "&nombre=in.(" + listaIn(b.proveedores) + ")") && ok;
  }
  for (const key of (b.cajaMovs || [])) {
    const partes = String(key).split("|");
    if (partes.length !== 2) continue;
    ok = await intentar("caja_movimientos", t + "&caja_id=eq." + encodeURIComponent(partes[0]) + "&id=eq." + encodeURIComponent(partes[1])) && ok;
  }
  if (ok) guardarSilencioso((base) => { base.syncBajas = { clientes: [], productos: [], proveedores: [], pendientes: [], cajaMovs: [] }; });
  return avisos;
}

async function reclamarNumero(tabla, columna, minimo, extra, opts) {
  opts = opts || {};
  const c = cfg();
  const db = getDb() || {};
  const t = terminalId(db);
  let n = Number(minimo) || 1;
  if (!c.url || !c.key) return n;
  const conflicto = opts.conflicto || ("terminal," + columna);
  let filtro = "terminal=eq." + encodeURIComponent(t);
  if (opts.filtro) filtro += "&" + opts.filtro;
  try {
    const top = await request("GET", tabla + "?select=" + columna + "&" + filtro + "&order=" + columna + ".desc&limit=1", null, "return=representation");
    if (top.ok) {
      const rows = JSON.parse(top.body || "[]");
      if (rows[0] && rows[0][columna] != null) n = Math.max(n, Number(rows[0][columna]) + 1);
    }
  } catch (_) {}
  for (let i = 0; i < 8; i++) {
    const row = Object.assign({ terminal: t }, extra || {});
    row[columna] = n;
    const r = await request("POST", tabla + "?on_conflict=" + encodeURIComponent(conflicto), [row], "resolution=ignore-duplicates,return=representation");
    let body = [];
    try { body = JSON.parse(r.body || "[]"); } catch (_) { body = []; }
    if (Array.isArray(body) && body.some((x) => Number(x[columna]) === n)) return n;
    if (!r.ok) return n;
    n++;
  }
  return n;
}

async function descargarYMezclar() {
  if (bajando || estado.enviando) return { ok: false, ocupado: true };
  const c = cfg();
  if (!c.activo || !c.url || !c.key) return { ok: false };
  const db = getDb();
  if (!db) return { ok: false };
  bajando = true;
  estado.progreso = { etapa: "bajando" };
  try {
    const t = encodeURIComponent(terminalId(db));
    const filtro = "terminal=eq." + t;
    const completo = !(db.config && db.config.nubeCompleta) && !((db.ventas || []).length > 500);
    const desdeMs = Date.now() - 7 * 24 * 60 * 60 * 1000;
    const desde = new Date(desdeMs).toISOString();
    const maxFolio = (db.ventas || []).reduce((m, v) => Math.max(m, Number(v.folio) || 0), 0);
    const tablasFijas = ["categorias", "productos", "paquetes", "usuarios", "clientes", "credito_movimientos", "proveedores", "cajas", "caja_movimientos", "movimientos_pendientes", "devoluciones", "devolucion_items", "apartados", "facturas", "ordenes_espera", "corte_tickets", "pos_terminal"];
    const raw = {};
    for (const tabla of tablasFijas) {
      const r = await leerTabla(tabla, filtro);
      if (!r.ok) throw new Error(tabla + ": " + r.error);
      raw[tabla] = r.rows;
    }
    // Tabla nueva: si falta el SQL o falló la lectura, NO mandar arreglo vacío
    // (mezclar [] con completo=true borraría el espejo local de efectivo casa).
    {
      const r = await leerTabla("efectivo_casa", filtro);
      if (r.ok && !r.falta) raw.efectivo_casa = r.rows;
    }
    const oc = await leerTabla("proveedores_ocultos", filtro);
    raw.proveedores_ocultos = oc.ok ? oc.rows : [];
    if (completo) {
      for (const tabla of ["ventas", "venta_items", "venta_pagos", "movimientos", "movimientos_inv", "cortes_eleventa"]) {
        const r = await leerTabla(tabla, filtro);
        if (!r.ok) throw new Error(tabla + ": " + r.error);
        raw[tabla] = r.rows;
      }
    } else {
      const fv = "terminal=eq." + t + "&or=(fecha.gte." + encodeURIComponent(desde) + ",folio.gt." + Math.max(0, maxFolio - 30) + ")";
      const ventas = await leerTabla("ventas", fv);
      if (!ventas.ok) throw new Error("ventas: " + ventas.error);
      raw.ventas = ventas.rows;
      const folios = raw.ventas.map((v) => v.folio).filter((f) => f != null);
      raw.venta_items = [];
      raw.venta_pagos = [];
      for (let i = 0; i < folios.length; i += 120) {
        const lote = folios.slice(i, i + 120);
        if (!lote.length) break;
        const inn = "terminal=eq." + t + "&venta_folio=in.(" + listaIn(lote) + ")";
        const it = await leerTabla("venta_items", inn);
        const pg = await leerTabla("venta_pagos", inn);
        if (!it.ok) throw new Error("venta_items: " + it.error);
        if (!pg.ok) throw new Error("venta_pagos: " + pg.error);
        raw.venta_items.push.apply(raw.venta_items, it.rows);
        raw.venta_pagos.push.apply(raw.venta_pagos, pg.rows);
      }
      const fm = "terminal=eq." + t + "&fecha=gte." + encodeURIComponent(desde);
      const mov = await leerTabla("movimientos", fm);
      const inv = await leerTabla("movimientos_inv", fm);
      if (!mov.ok) throw new Error("movimientos: " + mov.error);
      if (!inv.ok) throw new Error("movimientos_inv: " + inv.error);
      raw.movimientos = mov.rows;
      raw.movimientos_inv = inv.rows;
    }
    const parte = armarParte(raw, completo);
    if (!parte.proveedoresOcultos && raw.proveedores_ocultos && raw.proveedores_ocultos.length) {
      parte.proveedoresOcultos = raw.proveedores_ocultos.map((x) => x.clave).filter(Boolean);
    }
    const huella = firmaParte(parte);
    if (huella === ultimaHuellaDescarga) {
      ultimoBajado = new Date().toISOString();
      estado.progreso = null;
      return { ok: true, cambio: false, completo };
    }
    const crudas = suciasCrudas();
    const r = mezclarRemoto(parte, {
      completo,
      desdeMs,
      huella,
      proteger: protegerLocal(),
      habilitarEnvio: completo || (db.config && db.config.sincronizarNube === false)
    });
    if (r && r.cambio) reconciliarCache(crudas);
    ultimaHuellaDescarga = huella;
    ultimoBajado = new Date().toISOString();
    estado.progreso = null;
    return { ok: true, cambio: !!(r && r.cambio), completo };
  } catch (e) {
    estado.ultimoError = String(e && e.message ? e.message : e);
    estado.progreso = null;
    return { ok: false, error: estado.ultimoError };
  } finally {
    bajando = false;
  }
}

const estadoPrevio = estadoActual;
function estadoActualBidi() {
  const e = estadoPrevio();
  e.bajando = bajando;
  e.ultimoBajado = ultimoBajado;
  return e;
}

module.exports = {
  init, probar, sincronizarTodo, estadoActual: estadoActualBidi, keepAlive, limpiarHistorialNube,
  listarTicketsCorte, mapDb, cfg, reclamarNumero, descargarYMezclar, descargarSiHayNovedad, protegerLocal
};