"use strict";

/* ============================================================
   Servicio de impresión de tickets y apertura de cajón.
   Compatible con impresoras térmicas ESC/POS (p. ej. Hostech 80 mm).

   Transportes soportados (config.modo):
     - "red"     : envío por TCP a IP:puerto (RAW 9100). RECOMENDADO.
     - "windows" : escribe RAW a una impresora COMPARTIDA de Windows
                   por su ruta UNC (\\\\localhost\\NOMBRE_COMPARTIDO).
     - "off"     : no imprime (solo vista previa en pantalla).

   El cajón de dinero se abre con el pulso ESC/POS que la impresora
   envía por su puerto RJ11 (no requiere driver aparte).
   ============================================================ */

const net = require("net");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { execFile } = require("child_process");

// Logo del negocio en bitmap 1-bit (generado con tools/genlogo.js)
let LOGO = null;
try { LOGO = require("./assets/logo-ticket.json"); } catch (e) { LOGO = null; }

// Comando ESC/POS de imagen raster (GS v 0) con el logo
function logoRasterBuffer() {
  if (!LOGO || !LOGO.data) return null;
  const data = Buffer.from(LOGO.data, "base64");
  const xL = LOGO.bytesPerRow & 0xff, xH = (LOGO.bytesPerRow >> 8) & 0xff;
  const yL = LOGO.height & 0xff, yH = (LOGO.height >> 8) & 0xff;
  const header = Buffer.from([0x1d, 0x76, 0x30, 0x00, xL, xH, yL, yH]);
  return Buffer.concat([header, data]);
}

// --- Comandos ESC/POS ---
const ESC = 0x1b, GS = 0x1d;
const CMD = {
  init: [ESC, 0x40],
  alignLeft: [ESC, 0x61, 0x00],
  alignCenter: [ESC, 0x61, 0x01],
  alignRight: [ESC, 0x61, 0x02],
  boldOn: [ESC, 0x45, 0x01],
  boldOff: [ESC, 0x45, 0x00],
  doubleOn: [GS, 0x21, 0x11],   // ancho+alto x2
  normal: [GS, 0x21, 0x00],
  feed: (n) => [ESC, 0x64, n],  // avanzar n líneas
  cutPartial: [GS, 0x56, 0x42, 0x00],
  // Pulso de cajón: ESC p m t1 t2  (pin 0, ~25ms on, ~250ms off)
  kick: [ESC, 0x70, 0x00, 0x19, 0xfa]
};

// Pulso de cajón según el pin configurado (0 = estándar, 1 = alterno). Algunos
// cajones responden al pin 1 en lugar del 0.
function kickBytes(config) {
  const pin = (config && Number(config.pulsoCajon) === 1) ? 0x01 : 0x00;
  return [ESC, 0x70, pin, 0x19, 0xfa];
}

// Transliteración a ASCII para evitar caracteres corruptos sin haber
// fijado la página de códigos en el equipo real (se puede afinar luego).
function ascii(str) {
  return String(str == null ? "" : str)
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/ñ/g, "n").replace(/Ñ/g, "N")
    .replace(/[^\x00-\x7f]/g, "");
}

// Constructor de buffers ESC/POS
function Builder() {
  const chunks = [];
  const api = {
    raw(arr) { chunks.push(Buffer.from(arr)); return api; },
    text(s) { chunks.push(Buffer.from(ascii(s), "latin1")); return api; },
    line(s = "") { return api.text(s + "\n"); },
    build() { return Buffer.concat(chunks); }
  };
  return api;
}

const rep = (ch, n) => ch.repeat(Math.max(0, n));

// Línea "izquierda ............ derecha" ajustada al ancho de columnas
function lr(izq, der, cols) {
  izq = ascii(izq); der = ascii(der);
  const espacio = cols - izq.length - der.length;
  if (espacio >= 1) return izq + rep(" ", espacio) + der;
  // Si no cabe, recorta la izquierda
  const maxIzq = Math.max(0, cols - der.length - 1);
  return izq.slice(0, maxIzq) + " " + der;
}

const money = (cents) => "$" + ((Number(cents) || 0) / 100).toFixed(2);
const fmtCant = (n, unidad) =>
  unidad === "kg" ? (+Number(n || 0).toFixed(3)).toString() : String(Math.round(Number(n || 0)));

/* ---------- Construcción del ticket ---------- */
function construirTicketBuffer(t, config) {
  const cols = (config && config.anchoCols) || 48;
  const neg = (config && config.negocio) || {};
  const tk = Object.assign({
    mostrarLogo: true, mostrarNombre: true, mostrarSucursal: true, mostrarDireccion: true,
    mostrarTelefono: true, mostrarRFC: false, lineasEncabezado: [], mostrarFolio: true,
    mostrarFecha: true, mostrarCajero: true, mostrarCliente: true, etiquetaCajero: "Atiende",
    etiquetaCliente: "Cliente", mostrarPrecioUnitario: true, mostrarFormaPago: true, lineasPie: []
  }, (config && config.ticket) || {});
  const b = Builder();

  b.raw(CMD.init);

  // Cajón PRIMERO: el pulso de apertura va al INICIO del ticket para que la caja
  // salte al instante, sin esperar a que se imprima y corte todo el ticket
  // (antes iba al final y por eso se sentía lento).
  if (t.abrirCajon) b.raw(kickBytes(config));

  // Logo (bitmap) centrado
  if (LOGO && tk.mostrarLogo && (!config || config.imprimirLogo !== false)) {
    const raster = logoRasterBuffer();
    if (raster) b.raw(CMD.alignCenter).raw(raster).raw([0x0a]);
  }

  // Encabezado
  if (tk.mostrarNombre) {
    b.raw(CMD.alignCenter).raw(CMD.doubleOn).raw(CMD.boldOn)
      .line(neg.nombre || "Mayoreo de Carne de Res")
      .raw(CMD.normal).raw(CMD.boldOff);
  } else {
    b.raw(CMD.alignCenter);
  }
  if (tk.mostrarSucursal && neg.sucursal) b.line(neg.sucursal);
  if (tk.mostrarDireccion && neg.direccion) b.line(neg.direccion);
  if (tk.mostrarTelefono && neg.telefono) b.line("Tel: " + neg.telefono);
  if (tk.mostrarRFC && neg.rfc) b.line("RFC: " + neg.rfc);
  (tk.lineasEncabezado || []).forEach((ln) => { if (ln) b.line(ln); });

  b.raw(CMD.alignLeft).line(rep("-", cols));

  // Etiqueta de apartado
  if (t.apartado) {
    b.raw(CMD.alignCenter).raw(CMD.boldOn).line("*** APARTADO - ENTREGA PENDIENTE ***").raw(CMD.boldOff);
    if (t.notaApartado) b.line("Nota: " + t.notaApartado);
    b.raw(CMD.alignLeft);
  }

  // Datos de la venta
  if (tk.mostrarFolio || tk.mostrarFecha) {
    b.line(lr(tk.mostrarFolio ? "Folio: " + (t.folio != null ? t.folio : "-") : "",
             tk.mostrarFecha ? (t.fecha || "") : "", cols));
  }
  if (tk.mostrarCajero && t.cajero) b.line((tk.etiquetaCajero || "Atiende") + ": " + t.cajero);
  if (tk.mostrarCliente && t.cliente) b.line((tk.etiquetaCliente || "Cliente") + ": " + t.cliente);
  b.line(rep("-", cols));

  // Encabezado de columnas
  b.raw(CMD.boldOn).line(lr("Cant  Producto", "Importe", cols)).raw(CMD.boldOff);

  // Renglones
  (t.items || []).forEach((it) => {
    const cant = fmtCant(it.cant, it.unidad) + (it.unidad ? it.unidad : "");
    const nombre = ascii(it.nombre);
    const izq = (cant + "  " + nombre);
    b.line(lr(izq, money(it.importeCents), cols));
    // Detalle precio unitario si aplica
    if (tk.mostrarPrecioUnitario && it.precioCents != null && it.tipo !== "paquete") {
      b.line("     @ " + money(it.precioCents) + "/" + (it.unidad || "u"));
    }
  });

  b.line(rep("-", cols));

  // Totales
  if (t.descuentoCents > 0) {
    b.line(lr("Subtotal", money(t.subtotalCents != null ? t.subtotalCents : (t.totalCents + t.descuentoCents)), cols));
    b.line(lr("Descuento", "-" + money(t.descuentoCents), cols));
  }
  b.raw(CMD.doubleOn).raw(CMD.boldOn)
    .line(lr("TOTAL", money(t.totalCents), Math.floor(cols / 2)))
    .raw(CMD.normal).raw(CMD.boldOff);

  if (tk.mostrarFormaPago) {
    b.line(lr("Forma de pago", t.pagoLabel || t.pago || "", cols));
    if (t.pago === "combinado" && Array.isArray(t.pagos)) {
      t.pagos.forEach((p) => b.line(lr("  " + (p.label || p.metodo), money(p.montoCents), cols)));
      if (t.cambioCents > 0) {
        b.line(lr("  Efectivo recibido", money(t.efectivoRecibidoCents || t.recibidoCents), cols));
        b.line(lr("  Cambio", money(t.cambioCents), cols));
      }
    }
    if (t.pago === "efectivo") {
      b.line(lr("Recibido", money(t.recibidoCents), cols));
      b.line(lr("Cambio", money(t.cambioCents), cols));
    }
    if (t.pago === "dolares") {
      if (t.tipoCambio) b.line(lr("Tipo de cambio", "$" + Number(t.tipoCambio).toFixed(2) + "/USD", cols));
      if (t.dolaresRecibidos) b.line(lr("Recibido USD", "$" + (t.dolaresRecibidos / 100).toFixed(2), cols));
      b.line(lr("Equivale (MXN)", money(t.recibidoCents), cols));
      b.line(lr("Cambio (MXN)", money(t.cambioCents), cols));
    }
  }

  // Solo ventas a crédito: adeudo + firma del cliente.
  if (String(t.pago || "").toLowerCase() === "credito") {
    const centerTxt = (s) => {
      s = ascii(String(s || ""));
      const pad = Math.max(0, Math.floor((cols - s.length) / 2));
      return rep(" ", pad) + s;
    };
    b.line(rep("-", cols));
    b.raw(CMD.alignCenter).raw(CMD.boldOn).line("*** VENTA A CREDITO ***").raw(CMD.boldOff);
    b.raw(CMD.alignLeft);
    if (t.cliente) b.line(lr("Cliente", ascii(t.cliente), cols));
    b.line(lr("Cargo de esta venta", money(t.totalCents), cols));
    if (t.saldoClienteCents != null) {
      b.raw(CMD.boldOn).line(lr("SALDO QUE DEBE", money(t.saldoClienteCents), cols)).raw(CMD.boldOff);
    }
    b.line("");
    b.line("FIRMA DEL CLIENTE:");
    b.line("");
    b.line("");
    b.raw(CMD.alignCenter).line(centerTxt("____________________________"));
    if (t.cliente) b.line(centerTxt(String(t.cliente).toUpperCase()));
    b.raw(CMD.alignLeft);
  }

  b.line(rep("-", cols));
  b.raw(CMD.alignCenter);
  if (neg.pie) b.line(neg.pie);
  if (neg.pie2) b.line(neg.pie2);
  (tk.lineasPie || []).forEach((ln) => { if (ln) b.line(ln); });

  b.raw(CMD.feed(3));
  b.raw(CMD.cutPartial);

  return b.build();
}

/* ---------- Envío ---------- */
function enviarRed(buffer, ip, puerto, timeoutMs = 4000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let terminado = false;
    const fin = (res) => { if (!terminado) { terminado = true; try { socket.destroy(); } catch (e) {} resolve(res); } };
    socket.setTimeout(timeoutMs);
    socket.on("timeout", () => fin({ error: "Tiempo de espera agotado al conectar con la impresora." }));
    socket.on("error", (e) => fin({ error: "No se pudo conectar con la impresora: " + e.message }));
    socket.connect(puerto || 9100, ip, () => {
      socket.write(buffer, () => { socket.end(); fin({ ok: true }); });
    });
  });
}

function enviarWindows(buffer, rutaUNC) {
  return new Promise((resolve) => {
    try {
      // Escribe RAW directo a la impresora compartida (\\\\localhost\\NOMBRE)
      fs.writeFile(rutaUNC, buffer, (err) => {
        if (err) resolve({ error: "No se pudo enviar a la impresora de Windows: " + err.message });
        else resolve({ ok: true });
      });
    } catch (e) {
      resolve({ error: e.message });
    }
  });
}

// Envía RAW a una impresora de Windows POR SU NOMBRE (sin compartir), usando el
// spooler (winspool) vía PowerShell. Ideal para impresoras USB térmicas ESC/POS.
// --- Impresión RAW RÁPIDA: ayudante compilado UNA sola vez (evita compilar en
//     cada ticket, que era lo que hacía lento imprimir/abrir cajón). ---
const HELPER_DIR = path.join(process.env.LOCALAPPDATA || os.tmpdir(), "mayoreo-pos");
const HELPER_EXE = path.join(HELPER_DIR, "posrawprint.exe");
const CS_RAWPRINT = [
  "using System; using System.IO; using System.Runtime.InteropServices;",
  "public class PosRaw {",
  "  [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]",
  "  struct DI { [MarshalAs(UnmanagedType.LPWStr)] public string n; [MarshalAs(UnmanagedType.LPWStr)] public string o; [MarshalAs(UnmanagedType.LPWStr)] public string t; }",
  "  [DllImport(\"winspool.Drv\", EntryPoint=\"OpenPrinterW\", SetLastError=true, CharSet=CharSet.Unicode)] static extern bool OpenPrinter(string s, out IntPtr h, IntPtr p);",
  "  [DllImport(\"winspool.Drv\", EntryPoint=\"ClosePrinter\", SetLastError=true)] static extern bool ClosePrinter(IntPtr h);",
  "  [DllImport(\"winspool.Drv\", EntryPoint=\"StartDocPrinterW\", SetLastError=true, CharSet=CharSet.Unicode)] static extern bool StartDocPrinter(IntPtr h, int l, ref DI d);",
  "  [DllImport(\"winspool.Drv\", EntryPoint=\"EndDocPrinter\", SetLastError=true)] static extern bool EndDocPrinter(IntPtr h);",
  "  [DllImport(\"winspool.Drv\", EntryPoint=\"StartPagePrinter\", SetLastError=true)] static extern bool StartPagePrinter(IntPtr h);",
  "  [DllImport(\"winspool.Drv\", EntryPoint=\"EndPagePrinter\", SetLastError=true)] static extern bool EndPagePrinter(IntPtr h);",
  "  [DllImport(\"winspool.Drv\", EntryPoint=\"WritePrinter\", SetLastError=true)] static extern bool WritePrinter(IntPtr h, byte[] b, int c, out int w);",
  "  public static int Main(string[] a){",
  "    if(a.Length<2) return 2;",
  "    byte[] bytes = File.ReadAllBytes(a[1]);",
  "    IntPtr h; if(!OpenPrinter(a[0], out h, IntPtr.Zero)) return 3;",
  "    DI d = new DI(); d.n=\"POS Ticket\"; d.t=\"RAW\"; int rc=1;",
  "    if(StartDocPrinter(h,1,ref d)){ if(StartPagePrinter(h)){ int w; if(WritePrinter(h,bytes,bytes.Length,out w)) rc=0; EndPagePrinter(h);} EndDocPrinter(h);}",
  "    ClosePrinter(h); return rc;",
  "  }",
  "}"
].join("\n");

let _helperPromise = null;
function asegurarHelper() {
  if (_helperPromise) return _helperPromise;
  _helperPromise = new Promise((resolve) => {
    try { if (fs.existsSync(HELPER_EXE)) return resolve(true); } catch (e) {}
    try { fs.mkdirSync(HELPER_DIR, { recursive: true }); } catch (e) {}
    const cs = path.join(HELPER_DIR, "posrawprint.cs");
    try { fs.writeFileSync(cs, CS_RAWPRINT, "utf8"); } catch (e) { return resolve(false); }
    const psCmd = 'Add-Type -OutputType ConsoleApplication -OutputAssembly "' + HELPER_EXE + '" -Path "' + cs + '"';
    execFile("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", psCmd],
      { windowsHide: true, timeout: 40000 }, () => resolve(fs.existsSync(HELPER_EXE)));
  });
  return _helperPromise;
}
// Precompila en segundo plano al cargar el módulo (la 1ra impresión ya sale rápida).
try { asegurarHelper(); } catch (e) {}

function enviarWindowsRaw(buffer, printerName) {
  return new Promise(async (resolve) => {
    let tmpBin = "";
    try {
      tmpBin = path.join(os.tmpdir(), "pos_ticket_" + Date.now() + "_" + Math.floor(Math.random() * 1e6) + ".bin");
      fs.writeFileSync(tmpBin, buffer);
    } catch (e) { return resolve({ error: "No se pudo preparar la impresión: " + e.message }); }
    const limpiar = () => { try { fs.unlinkSync(tmpBin); } catch (e) {} };

    let usarExe = false;
    try { usarExe = await asegurarHelper(); } catch (e) { usarExe = false; }
    if (usarExe && fs.existsSync(HELPER_EXE)) {
      // Camino RÁPIDO: ejecuta el ayudante ya compilado (~100 ms).
      execFile(HELPER_EXE, [printerName, tmpBin], { windowsHide: true, timeout: 15000 }, (err, so, se) => {
        limpiar();
        if (!err) return resolve({ ok: true });
        return resolve({ error: "No se pudo imprimir: " + (String(se).trim() || err.message) });
      });
      return;
    }
    // Fallback: método PowerShell inline (más lento, por si no se pudo compilar).
    let tmpPs = "";
    try { tmpPs = path.join(os.tmpdir(), "pos_print_" + Date.now() + ".ps1"); fs.writeFileSync(tmpPs, PS_RAW_PRINT, "utf8"); }
    catch (e) { limpiar(); return resolve({ error: "No se pudo preparar la impresión: " + e.message }); }
    execFile("powershell.exe",
      ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", tmpPs, "-Printer", printerName, "-DataFile", tmpBin],
      { windowsHide: true, timeout: 20000 }, (err, stdout, stderr) => {
        limpiar(); try { fs.unlinkSync(tmpPs); } catch (e) {}
        if (err) return resolve({ error: "No se pudo imprimir: " + (String(stderr).trim() || err.message) });
        if (/OK/.test(String(stdout))) return resolve({ ok: true });
        return resolve({ error: "La impresora respondió: " + (String(stdout).trim() || "sin respuesta") });
      });
  });
}

// Script PowerShell que manda bytes RAW a la impresora por nombre (winspool).
const PS_RAW_PRINT = `param([string]$Printer,[string]$DataFile)
$ErrorActionPreference = "Stop"
$bytes = [System.IO.File]::ReadAllBytes($DataFile)
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class PosRaw {
  [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
  public struct DOCINFO { [MarshalAs(UnmanagedType.LPWStr)] public string pDocName; [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile; [MarshalAs(UnmanagedType.LPWStr)] public string pDataType; }
  [DllImport("winspool.Drv", EntryPoint="OpenPrinterW", SetLastError=true, CharSet=CharSet.Unicode)] public static extern bool OpenPrinter(string src, out IntPtr h, IntPtr pd);
  [DllImport("winspool.Drv", EntryPoint="ClosePrinter", SetLastError=true)] public static extern bool ClosePrinter(IntPtr h);
  [DllImport("winspool.Drv", EntryPoint="StartDocPrinterW", SetLastError=true, CharSet=CharSet.Unicode)] public static extern bool StartDocPrinter(IntPtr h, int level, ref DOCINFO di);
  [DllImport("winspool.Drv", EntryPoint="EndDocPrinter", SetLastError=true)] public static extern bool EndDocPrinter(IntPtr h);
  [DllImport("winspool.Drv", EntryPoint="StartPagePrinter", SetLastError=true)] public static extern bool StartPagePrinter(IntPtr h);
  [DllImport("winspool.Drv", EntryPoint="EndPagePrinter", SetLastError=true)] public static extern bool EndPagePrinter(IntPtr h);
  [DllImport("winspool.Drv", EntryPoint="WritePrinter", SetLastError=true)] public static extern bool WritePrinter(IntPtr h, byte[] buf, int count, out int written);
  public static string Send(string printer, byte[] bytes){
    IntPtr h;
    if(!OpenPrinter(printer, out h, IntPtr.Zero)) return "ERR open " + Marshal.GetLastWin32Error();
    DOCINFO di = new DOCINFO(); di.pDocName="POS Ticket"; di.pDataType="RAW";
    string r = "OK";
    if(StartDocPrinter(h,1,ref di)){ if(StartPagePrinter(h)){ int w; if(!WritePrinter(h,bytes,bytes.Length,out w)) r="ERR write "+Marshal.GetLastWin32Error(); EndPagePrinter(h);} else { r="ERR startpage"; } EndDocPrinter(h);} else { r="ERR startdoc "+Marshal.GetLastWin32Error(); }
    ClosePrinter(h); return r;
  }
}
"@
[PosRaw]::Send($Printer, $bytes)`;

// HP DeskJet / láser / PDF no entienden bytes ESC/POS RAW: hay que mandar texto
// por el driver de Windows. Las térmicas (80mm KARSTCOM, Hostech, etc.) sí usan RAW.
function esImpresoraOficina(nombre) {
  const n = String(nombre || "").toLowerCase();
  if (!n) return false;
  if (/80mm|58mm|karst|hostech|xprinter|rongta|thermal|t[eé]rmica|epson\s*tm|pos-?\d/.test(n)) return false;
  return /deskjet|laserjet|officejet|envy|pixma|brother|lexmark|canon|pdf|onenote|microsoft print|\bhp\b/.test(n);
}
function debeUsarTextoWindows(config) {
  if (((config && config.modo) || "") !== "windows") return false;
  const destino = String((config && config.rutaWindows) || "").trim();
  if (!destino || destino.startsWith("\\\\")) return false;
  const envio = String((config && config.envioWindows) || "auto").toLowerCase();
  if (envio === "texto") return true;
  if (envio === "raw") return false;
  return esImpresoraOficina(destino);
}
function enviarWindowsTexto(texto, printerName) {
  return new Promise((resolve) => {
    let tmp = "";
    try {
      tmp = path.join(os.tmpdir(), "pos_ticket_" + Date.now() + "_" + Math.floor(Math.random() * 1e6) + ".txt");
      fs.writeFileSync(tmp, String(texto || "").replace(/\r?\n/g, "\r\n"), "utf8");
    } catch (e) {
      return resolve({ error: "No se pudo preparar la impresión: " + e.message });
    }
    // Nombres embebidos con JSON para no romper si tienen espacios (HP DeskJet…).
    const pLit = JSON.stringify(String(printerName || ""));
    const fLit = JSON.stringify(tmp);
    const ps = [
      "$ErrorActionPreference='Stop'",
      "$p=" + pLit,
      "$f=" + fLit,
      "if(-not (Get-Printer -Name $p -ErrorAction SilentlyContinue)){ Write-Output ('ERR no existe la impresora: '+$p); exit 1 }",
      "$t=[IO.File]::ReadAllText($f)",
      "try { $t | Out-Printer -Name $p; Write-Output 'OK' } catch { Write-Output ('ERR '+$_.Exception.Message); exit 1 }"
    ].join("; ");
    execFile("powershell.exe",
      ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
      { windowsHide: true, timeout: 60000 }, (err, stdout, stderr) => {
        try { fs.unlinkSync(tmp); } catch (e) {}
        const out = String(stdout || "").trim();
        if (!err && /^OK/m.test(out)) return resolve({ ok: true });
        const msg = out.replace(/^ERR\s*/i, "").trim() || String(stderr || "").trim() || (err && err.message) || "sin respuesta";
        return resolve({ error: "No se pudo imprimir: " + msg });
      });
  });
}
function listarImpresorasWindows() {
  return new Promise((resolve) => {
    const ps = "Get-Printer | Select-Object -ExpandProperty Name | ForEach-Object { $_ }";
    execFile("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
      { windowsHide: true, timeout: 20000 }, (err, stdout) => {
        if (err) return resolve({ ok: false, error: String(err.message || err), impresoras: [] });
        const impresoras = String(stdout || "").split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
        resolve({ ok: true, impresoras });
      });
  });
}

async function enviar(buffer, config) {
  const modo = (config && config.modo) || "off";
  if (modo === "off") return { error: "La impresora está desactivada (modo vista previa)." };
  if (modo === "red") {
    if (!config.ip) return { error: "Falta configurar la IP de la impresora." };
    return enviarRed(buffer, config.ip, config.puerto);
  }
  if (modo === "windows") {
    const destino = (config.rutaWindows || "").trim();
    if (!destino) return { error: "Falta el nombre de la impresora de Windows (o la ruta compartida)." };
    if (/^80mm\b/i.test(destino) || /\bKARSTCOM\b/i.test(destino)) {
      return { error: "El nombre \"" + destino + "\" no es una impresora de esta PC. En Configuración elige el nombre exacto (ej. HP DeskJet 2300 series)." };
    }
    // Si es una ruta UNC (\\\\PC\\Compartido) usa la impresora compartida; si es
    // un nombre simple, imprime RAW por nombre con el spooler (sin compartir).
    if (destino.startsWith("\\\\")) return enviarWindows(buffer, destino);
    return enviarWindowsRaw(buffer, destino);
  }
  return { error: "Modo de impresión no reconocido: " + modo };
}

/* ---------- API pública ---------- */
async function imprimirTicket(ticket, config) {
  if (debeUsarTextoWindows(config)) {
    return enviarWindowsTexto(vistaPrevia(ticket, config), (config.rutaWindows || "").trim());
  }
  const buffer = construirTicketBuffer(ticket, config);
  return enviar(buffer, config);
}

async function abrirCajon(config) {
  // DeskJet / oficina: no hay puerto de cajón; no mandar ESC/POS RAW.
  if (debeUsarTextoWindows(config)) return { ok: true, omitido: true };
  const res = await enviar(Buffer.from(kickBytes(config)), config);
  return res;
}

async function probar(config) {
  const ticket = {
    folio: "PRUEBA",
    fecha: new Date().toLocaleString("es-MX"),
    cajero: "Prueba de impresión",
    items: [
      { nombre: "Producto de prueba", cant: 1, unidad: "kg", precioCents: 12345, importeCents: 12345, tipo: "producto" }
    ],
    totalCents: 12345,
    pago: "efectivo",
    pagoLabel: "Efectivo",
    recibidoCents: 20000,
    cambioCents: 7655,
    abrirCajon: false
  };
  return imprimirTicket(ticket, config);
}

// Texto de vista previa (para mostrar en pantalla sin dispositivo)
function vistaPrevia(ticket, config) {
  const cols = (config && config.anchoCols) || 48;
  const neg = (config && config.negocio) || {};
  const tk = Object.assign({
    mostrarLogo: true, mostrarNombre: true, mostrarSucursal: true, mostrarDireccion: true,
    mostrarTelefono: true, mostrarRFC: false, lineasEncabezado: [], mostrarFolio: true,
    mostrarFecha: true, mostrarCajero: true, mostrarCliente: true, etiquetaCajero: "Atiende",
    etiquetaCliente: "Cliente", mostrarPrecioUnitario: true, mostrarFormaPago: true, lineasPie: []
  }, (config && config.ticket) || {});
  const L = [];
  const center = (s) => { s = ascii(s); const pad = Math.max(0, Math.floor((cols - s.length) / 2)); return rep(" ", pad) + s; };
  if (LOGO && tk.mostrarLogo && (!config || config.imprimirLogo !== false)) L.push(center("[ LOGO MAYOREO DE CARNE DE RES ]"));
  if (tk.mostrarNombre) L.push(center((neg.nombre || "Mayoreo de Carne de Res").toUpperCase()));
  if (tk.mostrarSucursal && neg.sucursal) L.push(center(neg.sucursal));
  if (tk.mostrarDireccion && neg.direccion) L.push(center(neg.direccion));
  if (tk.mostrarTelefono && neg.telefono) L.push(center("Tel: " + neg.telefono));
  if (tk.mostrarRFC && neg.rfc) L.push(center("RFC: " + neg.rfc));
  (tk.lineasEncabezado || []).forEach((ln) => { if (ln) L.push(center(ln)); });
  L.push(rep("-", cols));
  if (ticket.apartado) {
    L.push(center("*** APARTADO - ENTREGA PENDIENTE ***"));
    if (ticket.notaApartado) L.push("Nota: " + ascii(ticket.notaApartado));
  }
  if (tk.mostrarFolio || tk.mostrarFecha) {
    L.push(lr(tk.mostrarFolio ? "Folio: " + (ticket.folio != null ? ticket.folio : "-") : "",
             tk.mostrarFecha ? (ticket.fecha || "") : "", cols));
  }
  if (tk.mostrarCajero && ticket.cajero) L.push((tk.etiquetaCajero || "Atiende") + ": " + ascii(ticket.cajero));
  if (tk.mostrarCliente && ticket.cliente) L.push((tk.etiquetaCliente || "Cliente") + ": " + ascii(ticket.cliente));
  L.push(rep("-", cols));
  L.push(lr("Cant  Producto", "Importe", cols));
  (ticket.items || []).forEach((it) => {
    const cant = fmtCant(it.cant, it.unidad) + (it.unidad || "");
    L.push(lr(cant + "  " + ascii(it.nombre), money(it.importeCents), cols));
    if (tk.mostrarPrecioUnitario && it.precioCents != null && it.tipo !== "paquete") {
      L.push("     @ " + money(it.precioCents) + "/" + (it.unidad || "u"));
    }
  });
  L.push(rep("-", cols));
  if (ticket.descuentoCents > 0) {
    L.push(lr("Subtotal", money(ticket.subtotalCents != null ? ticket.subtotalCents : (ticket.totalCents + ticket.descuentoCents)), cols));
    L.push(lr("Descuento", "-" + money(ticket.descuentoCents), cols));
  }
  L.push(lr("TOTAL", money(ticket.totalCents), cols));
  if (tk.mostrarFormaPago) {
    L.push(lr("Forma de pago", ticket.pagoLabel || ticket.pago || "", cols));
    if (ticket.pago === "combinado" && Array.isArray(ticket.pagos)) {
      ticket.pagos.forEach((p) => L.push(lr("  " + (p.label || p.metodo), money(p.montoCents), cols)));
      if (ticket.cambioCents > 0) {
        L.push(lr("  Efectivo recibido", money(ticket.efectivoRecibidoCents || ticket.recibidoCents), cols));
        L.push(lr("  Cambio", money(ticket.cambioCents), cols));
      }
    }
    if (ticket.pago === "efectivo") {
      L.push(lr("Recibido", money(ticket.recibidoCents), cols));
      L.push(lr("Cambio", money(ticket.cambioCents), cols));
    }
    if (ticket.pago === "dolares") {
      if (ticket.tipoCambio) L.push(lr("Tipo de cambio", "$" + Number(ticket.tipoCambio).toFixed(2) + "/USD", cols));
      if (ticket.dolaresRecibidos) L.push(lr("Recibido USD", "$" + (ticket.dolaresRecibidos / 100).toFixed(2), cols));
      L.push(lr("Equivale (MXN)", money(ticket.recibidoCents), cols));
      L.push(lr("Cambio (MXN)", money(ticket.cambioCents), cols));
    }
  }
  if (String(ticket.pago || "").toLowerCase() === "credito") {
    L.push(rep("-", cols));
    L.push(center("*** VENTA A CREDITO ***"));
    if (ticket.cliente) L.push(lr("Cliente", ascii(ticket.cliente), cols));
    L.push(lr("Cargo de esta venta", money(ticket.totalCents), cols));
    if (ticket.saldoClienteCents != null) {
      L.push(lr("SALDO QUE DEBE", money(ticket.saldoClienteCents), cols));
    }
    L.push("");
    L.push("FIRMA DEL CLIENTE:");
    L.push("");
    L.push("");
    L.push(center("____________________________"));
    if (ticket.cliente) L.push(center(String(ticket.cliente).toUpperCase()));
  }
  L.push(rep("-", cols));
  if (neg.pie) L.push(center(neg.pie));
  if (neg.pie2) L.push(center(neg.pie2));
  (tk.lineasPie || []).forEach((ln) => { if (ln) L.push(center(ln)); });
  return L.join("\n");
}

/* ---------- Corte de caja ---------- */
function encabezadoCorte(add, c, config, cols, centrar) {
  const neg = (config && config.negocio) || {};
  centrar((neg.nombre || "Mayoreo de Carne de Res").toUpperCase());
  if (neg.sucursal) centrar(neg.sucursal);
  if (neg.direccion) centrar(neg.direccion);
  if (neg.telefono) centrar("Tel: " + neg.telefono);
  add("");
  centrar(c.titulo || "CORTE DE TURNO");
  if (c.turno != null) centrar("Turno #" + c.turno);
  add(rep("-", cols));
  add(lr("Realizado:", c.fecha || "", cols));
  if (c.cajero) add(lr("Cajero:", ascii(c.cajero), cols));
  if (c.terminal) add(lr("Caja:", ascii(c.terminal), cols));
  if (c.aperturaFecha) add(lr("Apertura:", ascii(c.aperturaFecha), cols));
}

function lineasCorte(add, c, cols) {
  const ctr = (s) => { s = ascii(s); const pad = Math.max(0, Math.floor((cols - s.length) / 2)); add(rep(" ", pad) + s); };
  const pm = c.porMetodo || {};
  // BRUTO cobrado por método (sin restar devoluciones ni sumar abonos). Se usa en
  // "VENTAS COBRADAS" para que los métodos SUMEN el TOTAL COBRADO y la devolución
  // se reste UNA sola vez. Cortes viejos sin este dato caen a porMetodo (neto).
  const pmc = c.porMetodoCobrado || c.porMetodo || {};
  const pmcEsBruto = !!c.porMetodoCobrado;
  const abonosPorMetodo = {};
  for (const a of (c.abonos || [])) {
    const fp = String(a.formaPago || "efectivo").trim().toLowerCase();
    // Efectivo casa no va en el ticket de corte (solo estado de cuenta del cliente).
    if (!fp || fp === "ajuste" || fp === "credito" || fp === "efectivo_casa") continue;
    abonosPorMetodo[fp] = (abonosPorMetodo[fp] || 0) + (a.montoCents || 0);
  }
  // porMetodo neto ya trae abonos; porMetodoCobrado (bruto) no: hay que sumarlos.
  const cobradoMetodo = (id) => (pmc[id] || 0) + (pmcEsBruto ? (abonosPorMetodo[id] || 0) : 0);
  const totalAbonosTodos = Object.keys(abonosPorMetodo).reduce((s, k) => s + abonosPorMetodo[k], 0);
  const credLista = c.creditosLista || [];
  const creditoVentas = c.creditoVentasCents != null
    ? c.creditoVentasCents
    : credLista.reduce((s, x) => s + (x.montoCents || 0), 0);
  const creditoDev = c.creditoDevCents || 0;
  const cobrado = c.ventasCobradasCents != null
    ? c.ventasCobradasCents
    : Math.max(0, (c.totalVentasCents || 0) - creditoVentas);
  const devCobradas = c.devCobradasCents != null
    ? c.devCobradasCents
    : Math.max(0, (c.totalDevolucionesCents || 0) - creditoDev);

  // Resumen del turno: el fiado no entra a lo cobrado
  add(rep("-", cols));
  add(lr("VENTAS COBRADAS:", money(cobrado), cols));
  add(String(c.numVentas || 0) + " ventas en el turno.");

  // Dinero en caja (efectivo). El resumen por fecha no trae arqueo.
  if (!c.sinArqueo) {
    add("");
    ctr("== DINERO EN CAJA ==");
    add(lr("Fondo de caja:", money(c.fondoCents), cols));
    add(lr("Ventas en efectivo:", "+" + money(c.efectivoVentasCents || 0), cols));
    if (c.efectivoDevolucionesCents) add(lr("Devol. en efectivo:", "-" + money(c.efectivoDevolucionesCents), cols));
    add(lr("Entradas:", "+" + money(c.ingresosCents || 0), cols));
    if (c.totalAbonosCents) add(lr("Abonos credito:", "+" + money(c.totalAbonosCents), cols));
    add(lr("Salidas efectivo:", "-" + money(c.retirosCents || 0), cols));
    add(rep("-", cols));
    add(lr("EFECTIVO EN CAJA", "= " + money(c.efectivoEsperadoCents || 0), cols));
  }

  const fpMov = (m) => String((m && m.formaPago) || "efectivo").trim().toLowerCase();
  const esCajonMov = (m) => { const f = fpMov(m); return f === "efectivo" || f === "dolares"; };
  const etiquetaSalida = (m) => {
    const et = m.categoria === "compra" ? " (compra)" : "";
    const nom = m.proveedor ? ((m.motivo || "") + " " + m.proveedor) : (m.motivo || "(salida)");
    return ascii(nom + et);
  };
  const salidasEfe = (c.salidas || []).filter(esCajonMov);
  const salidasDig = []
    .concat((c.salidas || []).filter((m) => !esCajonMov(m) && fpMov(m) !== "credito"))
    .concat((c.movimientosOtros || []).filter((m) => m.tipo === "retiro" && !esCajonMov(m) && fpMov(m) !== "credito"));
  const entradasDig = (c.movimientosOtros || []).filter((m) => m.tipo === "ingreso" && !esCajonMov(m) && fpMov(m) !== "credito");
  const totSalEfe = salidasEfe.reduce((s, m) => s + (m.montoCents || 0), 0);

  // Entradas de efectivo (detalle)
  add("");
  ctr("== ENTRADAS EFECTIVO ==");
  (c.entradas || []).filter(esCajonMov).forEach((m) => add(lr(ascii(m.motivo || "(entrada)"), money(m.montoCents), cols)));
  add(lr("TOTAL ENTRADAS", "= " + money(c.ingresosCents || 0), cols));

  add("");
  ctr("== SALIDAS EFECTIVO ==");
  add("(solo dinero que sale del cajon)");
  if (salidasEfe.length) {
    salidasEfe.forEach((m) => {
      const izq = etiquetaSalida(m);
      add(lr(izq.length > cols - 12 ? izq.slice(0, cols - 12) : izq, money(m.montoCents), cols));
    });
  } else add("(sin salidas de efectivo)");
  add(lr("TOTAL SALIDAS EFECTIVO", "= " + money(totSalEfe || c.retirosCents || 0), cols));

  if (salidasDig.length) {
    add("");
    ctr("== SALIDAS DIGITALES ==");
    add("(transferencia / tarjeta: NO salen del cajon)");
    let tTar = 0, tTra = 0;
    salidasDig.forEach((m) => {
      const fp = fpMov(m);
      if (fp === "tarjeta") tTar += m.montoCents || 0;
      else tTra += m.montoCents || 0;
      const pref = fp === "tarjeta" ? "TARJ " : "TRANSF ";
      const izq = pref + etiquetaSalida(m);
      add(lr(izq.length > cols - 12 ? izq.slice(0, cols - 12) : izq, money(m.montoCents), cols));
    });
    if (tTra) add(lr("TOTAL TRANSFERENCIA", "= " + money(tTra), cols));
    if (tTar) add(lr("TOTAL TARJETA", "= " + money(tTar), cols));
  }

  if (entradasDig.length) {
    add("");
    ctr("== ENTRADAS DIGITALES ==");
    add("(no entran al cajon)");
    entradasDig.forEach((m) => {
      const fp = fpMov(m);
      const pref = fp === "tarjeta" ? "TARJ " : "TRANSF ";
      const izq = pref + ascii(m.motivo || "(entrada)");
      add(lr(izq.length > cols - 12 ? izq.slice(0, cols - 12) : izq, money(m.montoCents), cols));
    });
  }

  // Abonos a crédito (cobranza de fiado). Efectivo va al cajón; tarjeta/transf. NO.
  const abonosCorte = (c.abonos || []).filter((a) => {
    const fp = String(a.formaPago || "efectivo").trim().toLowerCase();
    return fp && fp !== "ajuste" && fp !== "credito" && fp !== "efectivo_casa";
  });
  if (abonosCorte.length) {
    add("");
    ctr("== ABONOS A CREDITO ==");
    abonosCorte.forEach((a) => {
      const fp = String(a.formaPago || "efectivo").toUpperCase();
      add(lr(ascii((a.cliente || a.motivo || "(abono)") + " [" + fp + "]"), money(a.montoCents), cols));
    });
    add(lr("Abonos efectivo (cajon):", "= " + money(c.totalAbonosCents || 0), cols));
    if (c.totalAbonosOtrosCents) add(lr("Abonos tarj/transf:", "= " + money(c.totalAbonosOtrosCents), cols));
  }

  // Ventas cobradas (el crédito va en su propio apartado, no suma aquí)
  add("");
  ctr("== VENTAS COBRADAS ==");
  const orden = [["efectivo", "En efectivo:"], ["dolares", "En dolares:"], ["tarjeta", "Con tarjeta:"], ["transferencia", "Transferencia:"], ["vales", "Con vales:"]];
  const vistos = { credito: true };
  orden.forEach(([id, label]) => { vistos[id] = true; add(lr(label, money(cobradoMetodo(id)), cols)); });
  Object.keys(pmc).concat(Object.keys(abonosPorMetodo)).forEach((id) => {
    if (!vistos[id] && cobradoMetodo(id)) add(lr(ascii(id) + ":", money(cobradoMetodo(id)), cols));
  });
  add(rep("-", cols));
  add(lr("TOTAL COBRADO", "= " + money(cobrado + totalAbonosTodos), cols));
  if (totalAbonosTodos) add(lr("  incl. abonos credito", money(totalAbonosTodos), cols));
  if (c.apartadosCents) add(lr("  de las cuales apartados", money(c.apartadosCents), cols));
  // Nota: las devoluciones ya se listan en INGRESOS / CANCELACIONES; no se repiten aquí.

  add("");
  ctr("== CREDITO CLIENTES ==");
  if (!credLista.length && !creditoVentas && !creditoDev) {
    add("(sin ventas a credito)");
  } else if (!credLista.length) {
    add(lr("A credito", money(creditoVentas), cols));
  } else {
    credLista.forEach((x) => {
      const izq = ascii(x.cliente || "Sin nombre");
      add(lr(izq.length > cols - 12 ? izq.slice(0, cols - 12) : izq, money(x.montoCents), cols));
    });
  }
  if (creditoDev) add(lr("Devoluciones credito:", "-" + money(creditoDev), cols));
  add(rep("-", cols));
  add(lr("TOTAL CREDITOS", "= " + money(Math.max(0, creditoVentas - creditoDev)), cols));
  add("(clientes; no entra a lo cobrado ni al neto)");

  if (Array.isArray(c.creditosProveedor)) {
    add("");
    ctr("== CREDITO PROVEEDOR ==");
    add("(solo lo ingresado este dia)");
    add("(no sale del cajon hasta que se pague)");
    if (!c.creditosProveedor.length) {
      add("(sin adeudo a proveedores)");
    } else {
      c.creditosProveedor.forEach((x) => {
        const izq = ascii(x.proveedor || "Sin proveedor");
        add(lr(izq.length > cols - 12 ? izq.slice(0, cols - 12) : izq, money(x.montoCents), cols));
      });
    }
    add(rep("-", cols));
    add(lr("TOTAL POR PAGAR", "= " + money(c.creditosProveedorCents || 0), cols));
  }

  // Ingresos y cancelaciones (NO se mezcla la báscula: su total se totaliza al
  // final de "Ventas por categoría").
  add("");
  ctr("== INGRESOS / CANCELACIONES ==");
  add(lr("Ingresos (entradas):", money(c.ingresosCents || 0), cols));
  add(lr("Cancelaciones:", "-" + money(c.totalCancelacionesCents || 0), cols));
  (c.cancelaciones || []).forEach((x) => {
    const et = x.basculaFolio != null ? (" B" + x.basculaFolio) : "";
    add(lr("  #" + x.folio + et + ascii(x.motivo ? " " + x.motivo : ""), "-" + money(x.montoCents), cols));
  });
  if ((c.devolucionesLista || []).length) {
    add(lr("Devoluciones:", "-" + money(c.totalDevolucionesCents || 0), cols));
    (c.devolucionesLista || []).forEach((x) => {
      const vf = x.ventaFolio ? (" (v#" + x.ventaFolio + ")") : "";
      add(lr("  #" + x.folio + vf + ascii(x.motivo ? " " + x.motivo : ""), "-" + money(x.montoCents), cols));
    });
  }
  add(rep("-", cols));
  add(lr("TOTAL DIFERIDO", "-" + money(c.diferidoBasculaCents || 0), cols));

  // Carnes báscula = tickets de báscula (escaneados/automáticos) SIN quesos,
  // salsas, especialidades, abarrotes ni carne seca. No se suma a categorías.
  const cantDepto = (d) => {
    const cant = d && d.cant != null ? Number(d.cant) : null;
    if (cant == null || cant === 0) return "";
    return " x" + (Math.abs(cant - Math.round(cant)) < 0.001 ? String(Math.round(cant)) : cant.toFixed(3).replace(/0+$/, "").replace(/\.$/, ""));
  };
  const lineaDepto = (d) => {
    const izq = ascii(d.depto) + cantDepto(d);
    add(lr(izq.length > cols - 12 ? izq.slice(0, cols - 12) : izq, money(d.montoCents), cols));
  };
  const deptos = (c.ventasPorDepto || []).filter((d) => {
    const n = String(d.depto || "").toLowerCase();
    return n !== "varios" && n !== "paquetes";
  });
  const cb = c.carnesBascula || {};
  const totalCarnesBascula = cb.montoCents || 0;
  const cantCarnesBascula = cb.cant != null ? Number(cb.cant) : 0;
  const sumaCat = deptos.reduce((s, d) => s + (d.montoCents || 0), 0);
  const basculaManual = c.basculaTotalManualCents;
  const paquetesManual = c.paquetesTotalManualCents;
  const categMasBascula = sumaCat + (basculaManual || 0) + (paquetesManual || 0);
  const lineaProd = (p) => {
    const izq = "  " + ascii(p.nombre || "Producto") + cantDepto(p);
    add(lr(izq.length > cols - 12 ? izq.slice(0, cols - 12) : izq, money(p.montoCents), cols));
  };

  if (totalCarnesBascula || deptos.length || basculaManual != null || paquetesManual != null) {
    add("");
    ctr("== VENTAS POR CATEGORIA ==");
    add("(sin creditos no pagados)");
    add("(bascula sin desglose)");
    if (deptos.length) {
      deptos.forEach((d) => {
        add("");
        add(ascii(d.depto).toUpperCase());
        const prods = d.productos || [];
        if (prods.length) prods.forEach(lineaProd);
        else lineaDepto(d);
        add(lr("TOTAL " + ascii(d.depto).toUpperCase(), "= " + money(d.montoCents), cols));
      });
    } else add("(sin categorias de mostrador)");
    add(rep("-", cols));
    add(lr("TOTAL CATEGORIAS", "= " + money(sumaCat), cols));
    if (basculaManual != null) {
      add(lr("TOTAL BASCULA (manual)", "= " + money(basculaManual), cols));
    } else {
      add("TOTAL BASCULA (manual): (sin capturar)");
    }
    if (paquetesManual != null) {
      add(lr("TOTAL PAQUETES (manual)", "= " + money(paquetesManual), cols));
    } else {
      add("TOTAL PAQUETES (manual): (sin capturar)");
    }
    add(rep("-", cols));
    add(lr("TOTAL CATEG+BASC+PAQ", "= " + money(categMasBascula), cols));
    add("(categorias + bascula manual");
    add("+ paquetes manual;");
    add("carnes bascula NO suma aqui)");
    add(lr("VENTAS COBRADAS", money(cobrado), cols));
    const difCat = categMasBascula - cobrado;
    add(lr("DIFERENCIA", (difCat > 0 ? "+" : "") + money(difCat), cols));
    add("(categ+basc+paq menos cobrado)");
    add("");
    ctr("== CARNES BASCULA ==");
    add("(dato; no suma en categorias)");
    add("(sin quesos/salsas/especialidades/");
    add("abarrotes/carne seca)");
    const etqCb = "TOTAL CARNES BASCULA" + (cantCarnesBascula
      ? (" x" + (Math.abs(cantCarnesBascula - Math.round(cantCarnesBascula)) < 0.001
        ? String(Math.round(cantCarnesBascula))
        : cantCarnesBascula.toFixed(3).replace(/0+$/, "").replace(/\.$/, "")))
      : "");
    add(lr(etqCb, "= " + money(totalCarnesBascula), cols));
  }

  // Ingresos recibidos de contado (efectivo + transferencia)
  add("");
  ctr("== INGRESOS DE CONTADO ==");
  const ingEfe = (c.efectivoVentasCents || 0) + (abonosPorMetodo.efectivo || 0) + (abonosPorMetodo.dolares || 0);
  const ingTar = cobradoMetodo("tarjeta");
  const ingTra = cobradoMetodo("transferencia");
  add(lr("Efectivo:", money(ingEfe), cols));
  if (ingTar) add(lr("Tarjeta:", money(ingTar), cols));
  if (ingTra) add(lr("Transferencia:", money(ingTra), cols));
  add(lr("TOTAL INGRESOS", "= " + money(ingEfe + ingTar + ingTra), cols));

  // Conteo físico y dinero que queda en caja al cierre
  if (c.efectivoContadoCents != null) {
    add("");
    ctr("== ARQUEO DE CAJA ==");
    add(lr("Efectivo esperado:", money(c.efectivoEsperadoCents || 0), cols));
    add(lr("Efectivo contado:", money(c.efectivoContadoCents), cols));
    const dif = c.diferenciaCents || 0;
    add(lr("Diferencia:", (dif > 0 ? "+" : "") + money(dif), cols));
    if (c.dineroEnCajaCierreCents != null) {
      add(rep("-", cols));
      add(lr("Queda en caja:", money(c.dineroEnCajaCierreCents), cols));
      add("(referencia; el fondo de manana");
      add("se captura al abrir el turno)");
    }
    if (c.entregadoCents != null) {
      add(lr("Se entrego:", money(c.entregadoCents), cols));
    }
  }
}

function construirCorteBuffer(c, config) {
  const cols = (config && config.anchoCols) || 48;
  const b = Builder();
  b.raw(CMD.init).raw(CMD.alignCenter);
  // Logo (bitmap) del negocio, igual que en el ticket de venta.
  if (LOGO && (!config || config.imprimirLogo !== false)) {
    const raster = logoRasterBuffer();
    if (raster) b.raw(CMD.alignCenter).raw(raster).raw([0x0a]);
  }
  const centrar = (s) => { const pad = Math.max(0, Math.floor((cols - ascii(s).length) / 2)); b.line(rep(" ", pad) + ascii(s)); };
  encabezadoCorte((s) => b.line(s), c, config, cols, centrar);
  b.raw(CMD.alignLeft);
  lineasCorte((s) => b.line(s), c, cols);
  b.raw(CMD.feed(3)).raw(CMD.cutPartial);
  // Abrir cajón al hacer/imprimir el corte (si corresponde).
  if (c.abrirCajon) b.raw(kickBytes(config));
  return b.build();
}

async function imprimirCorte(corte, config) {
  if (debeUsarTextoWindows(config)) {
    return enviarWindowsTexto(vistaPreviaCorte(corte, config), (config.rutaWindows || "").trim());
  }
  return enviar(construirCorteBuffer(corte, config), config);
}

function vistaPreviaCorte(c, config) {
  const cols = (config && config.anchoCols) || 48;
  const L = [];
  const centrar = (s) => { const pad = Math.max(0, Math.floor((cols - ascii(s).length) / 2)); L.push(rep(" ", pad) + ascii(s)); };
  if (LOGO && (!config || config.imprimirLogo !== false)) centrar("[ LOGO MAYOREO DE CARNE DE RES ]");
  encabezadoCorte((s) => L.push(s), c, config, cols, centrar);
  lineasCorte((s) => L.push(s), c, cols);
  return L.join("\n");
}

/* ---------- Listados / notas genéricas ---------- */
function encabezadoLista(add, titulo, config, cols, centrar) {
  const neg = (config && config.negocio) || {};
  centrar((neg.nombre || "Mayoreo de Carne de Res").toUpperCase());
  if (neg.sucursal) centrar(neg.sucursal);
  if (titulo) centrar(titulo);
  centrar(new Date().toLocaleString("es-MX"));
  add(rep("-", cols));
}
function construirTextoBuffer(titulo, lineas, config) {
  const cols = (config && config.anchoCols) || 48;
  const b = Builder();
  b.raw(CMD.init).raw(CMD.alignCenter);
  const centrar = (s) => { const pad = Math.max(0, Math.floor((cols - ascii(s).length) / 2)); b.line(rep(" ", pad) + ascii(s)); };
  encabezadoLista((s) => b.line(s), titulo, config, cols, centrar);
  b.raw(CMD.alignLeft);
  (lineas || []).forEach((ln) => b.line(ln));
  b.raw(CMD.feed(3)).raw(CMD.cutPartial);
  return b.build();
}
async function imprimirTexto(titulo, lineas, config) {
  if (debeUsarTextoWindows(config)) {
    return enviarWindowsTexto(vistaPreviaTexto(titulo, lineas, config), (config.rutaWindows || "").trim());
  }
  return enviar(construirTextoBuffer(titulo, lineas, config), config);
}
function vistaPreviaTexto(titulo, lineas, config) {
  const cols = (config && config.anchoCols) || 48;
  const L = [];
  const centrar = (s) => { const pad = Math.max(0, Math.floor((cols - ascii(s).length) / 2)); L.push(rep(" ", pad) + ascii(s)); };
  encabezadoLista((s) => L.push(s), titulo, config, cols, centrar);
  (lineas || []).forEach((ln) => L.push(ln));
  return L.join("\n");
}

/* ---------- Documento hoja carta (DeskJet / oficina, estilo Word) ----------
   Usa Electron BrowserWindow.print para aprovechar toda la hoja con tipografía
   grande y tablas. No aplica a térmicas ESC/POS. */
function imprimirHtmlDocumento(html, config) {
  return new Promise((resolve) => {
    let BrowserWindow;
    try { BrowserWindow = require("electron").BrowserWindow; } catch (e) {
      return resolve({ error: "Impresión de documento no disponible fuera de Electron." });
    }
    if (!BrowserWindow) return resolve({ error: "Impresión de documento no disponible." });
    const destino = String((config && config.rutaWindows) || "").trim();
    let tmp = "";
    try {
      tmp = path.join(os.tmpdir(), "pos_doc_" + Date.now() + "_" + Math.floor(Math.random() * 1e6) + ".html");
      fs.writeFileSync(tmp, String(html || ""), "utf8");
    } catch (e) {
      return resolve({ error: "No se pudo preparar el documento: " + e.message });
    }
    const win = new BrowserWindow({
      show: false,
      width: 900,
      height: 1100,
      webPreferences: { sandbox: true, contextIsolation: true }
    });
    let finished = false;
    const fin = (r) => {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);
      try { if (!win.isDestroyed()) win.close(); } catch (e) {}
      try { if (tmp) fs.unlinkSync(tmp); } catch (e) {}
      resolve(r);
    };
    const timeout = setTimeout(() => {
      fin({ error: "Tiempo de espera agotado al imprimir el documento." });
    }, 90000);
    win.webContents.on("did-fail-load", (_e, code, desc) => {
      fin({ error: "No se pudo cargar el documento: " + (desc || code) });
    });
    win.webContents.on("did-finish-load", () => {
      setTimeout(() => {
        if (finished) return;
        const opts = {
          silent: true,
          printBackground: true,
          margins: { marginType: "printableArea" }
        };
        if (destino && !destino.startsWith("\\\\")) opts.deviceName = destino;
        try {
          win.webContents.print(opts, (ok, failureReason) => {
            if (ok) fin({ ok: true, documento: true });
            else fin({ error: failureReason || "La impresora rechazó el documento." });
          });
        } catch (e) {
          fin({ error: "No se pudo imprimir el documento: " + (e && e.message ? e.message : e) });
        }
      }, 250);
    });
    win.loadFile(tmp).catch((e) => {
      fin({ error: "No se pudo abrir el documento: " + (e && e.message ? e.message : e) });
    });
  });
}

module.exports = {
  imprimirTicket, abrirCajon, probar, vistaPrevia, construirTicketBuffer,
  imprimirCorte, vistaPreviaCorte, construirCorteBuffer,
  imprimirTexto, vistaPreviaTexto, construirTextoBuffer,
  imprimirHtmlDocumento,
  listarImpresorasWindows, debeUsarTextoWindows, esImpresoraOficina
};
