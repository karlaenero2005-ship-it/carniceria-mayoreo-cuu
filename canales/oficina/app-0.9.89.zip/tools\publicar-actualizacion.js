#!/usr/bin/env node
/* ============================================================
   publicar-actualizacion.js — Publica una actualización a un canal
   ------------------------------------------------------------
   SE CORRE EN LA PC DE SISTEMAS (donde editas el código).

   Qué hace:
     1) Sube la versión en package.json (o usa la que indiques).
     2) Empaqueta SOLO el código de resources/app (sin node_modules
        ni datos) en un .zip.
     3) Calcula su sha256 y arma update.json.
     4) Lo deja en tools/dist-actualizacion/<canal>/ y, si defines
        un token de GitHub, lo SUBE al repositorio público.

   Uso:
     node tools/publicar-actualizacion.js --canal oficina --notas "Arreglo de abonos"
     node tools/publicar-actualizacion.js --canal carniceria --notas "..." --version 0.9.90
     node tools/publicar-actualizacion.js --canal ambos --notas "..."

   Para que SUBA solo a GitHub, define estas variables de entorno
   (o un archivo tools/publicar.config.json con {owner,repo,rama,token}):
     set GH_OWNER=mi-usuario
     set GH_REPO=mayoreo-updates
     set GH_TOKEN=ghp_xxxxxxxxxxxxxxxx     (Personal Access Token con permiso "Contents: write")
     set GH_RAMA=main
   Si NO defines token, solo genera los archivos y te dice qué subir a mano.
   ============================================================ */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const https = require("https");
const { execFileSync } = require("child_process");

const APP_DIR = path.resolve(__dirname, "..");            // resources/app
const DIST_DIR = path.join(__dirname, "dist-actualizacion");
const PKG = path.join(APP_DIR, "package.json");

// Archivos/carpetas que NUNCA van en la actualización.
const EXCLUIR = new Set([
  "node_modules", ".git", ".gitignore", "datos-nube",
  "dist-actualizacion", "publicar.config.json", ".env"
]);
const EXCLUIR_EXT = new Set([".log"]);

/* ---------- argumentos ---------- */
function parseArgs(argv) {
  const out = {};
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const k = a.slice(2);
      const v = (i + 1 < argv.length && !argv[i + 1].startsWith("--")) ? argv[++i] : true;
      out[k] = v;
    }
  }
  return out;
}

function bumpPatch(v) {
  const p = String(v || "0.0.0").split(".").map((n) => parseInt(n, 10) || 0);
  while (p.length < 3) p.push(0);
  p[2] += 1;
  return p.join(".");
}

/* ---------- empaquetado ---------- */
function copiarFiltrado(src, dst, esRaiz) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    if (esRaiz && EXCLUIR.has(e.name)) continue;
    if (e.name === "node_modules" || e.name === ".git") continue;
    // dist-actualizacion vive dentro de tools/, así que su exclusión por nombre
    // (que solo aplica en la raíz) no basta: hay que saltarla a cualquier nivel.
    // Si no, el publicador se copia a sí mismo dentro del paquete y entra en
    // recursión infinita.
    if (e.name === "dist-actualizacion") continue;
    const ext = path.extname(e.name).toLowerCase();
    if (EXCLUIR_EXT.has(ext)) continue;
    const s = path.join(src, e.name);
    const d = path.join(dst, e.name);
    if (path.resolve(s) === DIST_DIR) continue;
    if (e.isDirectory()) copiarFiltrado(s, d, false);
    else fs.copyFileSync(s, d);
  }
}

function zipDir(dirOrigen, zipDestino) {
  if (fs.existsSync(zipDestino)) fs.unlinkSync(zipDestino);
  const esc = (s) => s.replace(/'/g, "''");
  const ps =
    "Add-Type -AssemblyName System.IO.Compression.FileSystem; " +
    "[System.IO.Compression.ZipFile]::CreateFromDirectory('" + esc(dirOrigen) + "','" + esc(zipDestino) +
    "',[System.IO.Compression.CompressionLevel]::Optimal,$false)";
  execFileSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps], { stdio: "inherit" });
}

function sha256File(p) {
  return crypto.createHash("sha256").update(fs.readFileSync(p)).digest("hex");
}

/* ---------- GitHub Contents API ---------- */
function ghConfig() {
  let cfg = {};
  const f = path.join(__dirname, "publicar.config.json");
  if (fs.existsSync(f)) { try { cfg = JSON.parse(fs.readFileSync(f, "utf8")); } catch (_) {} }
  return {
    owner: process.env.GH_OWNER || cfg.owner || "",
    repo: process.env.GH_REPO || cfg.repo || "",
    rama: process.env.GH_RAMA || cfg.rama || "main",
    token: process.env.GH_TOKEN || cfg.token || ""
  };
}

function ghRequest(metodo, ruta, bodyObj, token) {
  return new Promise((resolve, reject) => {
    const data = bodyObj ? Buffer.from(JSON.stringify(bodyObj)) : null;
    const req = https.request(
      {
        host: "api.github.com",
        path: ruta,
        method: metodo,
        headers: {
          "User-Agent": "Mayoreo-Publisher",
          "Authorization": "token " + token,
          "Accept": "application/vnd.github+json",
          "Content-Type": "application/json",
          "Content-Length": data ? data.length : 0
        }
      },
      (res) => {
        const chunks = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => {
          const txt = Buffer.concat(chunks).toString("utf8");
          let json = null; try { json = JSON.parse(txt); } catch (_) {}
          resolve({ status: res.statusCode, json, txt });
        });
      }
    );
    req.on("error", reject);
    if (data) req.write(data);
    req.end();
  });
}

async function ghPutFile(gh, rutaRepo, contenidoBuffer, mensaje) {
  const base = "/repos/" + gh.owner + "/" + gh.repo + "/contents/" + rutaRepo;
  // ¿existe? -> necesitamos su sha para reemplazar
  const get = await ghRequest("GET", base + "?ref=" + encodeURIComponent(gh.rama), null, gh.token);
  const sha = (get.status === 200 && get.json && get.json.sha) ? get.json.sha : undefined;
  const body = {
    message: mensaje,
    content: contenidoBuffer.toString("base64"),
    branch: gh.rama
  };
  if (sha) body.sha = sha;
  const put = await ghRequest("PUT", base, body, gh.token);
  if (put.status >= 200 && put.status < 300) return { ok: true };
  return { ok: false, error: "HTTP " + put.status + " " + (put.json && put.json.message ? put.json.message : put.txt) };
}

/* ---------- principal ---------- */
async function main() {
  const args = parseArgs(process.argv);
  const canalArg = String(args.canal || "").toLowerCase();
  const canales = canalArg === "ambos" ? ["oficina", "carniceria"]
    : (canalArg === "oficina" || canalArg === "carniceria") ? [canalArg] : null;
  if (!canales) {
    console.error("ERROR: indica --canal oficina | carniceria | ambos");
    process.exit(1);
  }
  const notas = typeof args.notas === "string" ? args.notas : "";

  const pkg = JSON.parse(fs.readFileSync(PKG, "utf8"));
  const nuevaVersion = (typeof args.version === "string" && args.version) ? args.version : bumpPatch(pkg.version);
  pkg.version = nuevaVersion;
  fs.writeFileSync(PKG, JSON.stringify(pkg, null, 2) + "\n");
  console.log("Versión a publicar: " + nuevaVersion);

  // 1) empaquetar
  fs.mkdirSync(DIST_DIR, { recursive: true });
  const stage = path.join(DIST_DIR, "_stage");
  try { fs.rmSync(stage, { recursive: true, force: true }); } catch (_) {}
  console.log("Empaquetando código (sin node_modules ni datos)…");
  copiarFiltrado(APP_DIR, stage, true);
  const zipName = "app-" + nuevaVersion + ".zip";
  const zipTmp = path.join(DIST_DIR, zipName);
  zipDir(stage, zipTmp);
  try { fs.rmSync(stage, { recursive: true, force: true }); } catch (_) {}
  const sha = sha256File(zipTmp);
  const tamMB = (fs.statSync(zipTmp).size / 1048576).toFixed(2);
  console.log("ZIP: " + zipName + " (" + tamMB + " MB)  sha256=" + sha);

  const manifiesto = {
    version: nuevaVersion,
    zip: zipName,
    sha256: sha,
    notas: notas,
    fecha: new Date().toISOString()
  };

  // 2) dejar por canal en dist-actualizacion/<canal>/
  for (const canal of canales) {
    const dir = path.join(DIST_DIR, canal);
    fs.mkdirSync(dir, { recursive: true });
    fs.copyFileSync(zipTmp, path.join(dir, zipName));
    fs.writeFileSync(path.join(dir, "update.json"), JSON.stringify(manifiesto, null, 2));
  }
  fs.unlinkSync(zipTmp);
  console.log("Listo en: " + DIST_DIR);

  // 3) subir a GitHub si hay token
  const gh = ghConfig();
  if (!gh.token || !gh.owner || !gh.repo) {
    console.log("\nNo hay token/owner/repo configurados: NO se subió a GitHub.");
    console.log("Sube a mano estos archivos al repositorio (uno por canal):");
    for (const canal of canales) {
      console.log("  canales/" + canal + "/" + zipName);
      console.log("  canales/" + canal + "/update.json");
    }
    return;
  }
  console.log("\nSubiendo a GitHub " + gh.owner + "/" + gh.repo + " (" + gh.rama + ")…");
  for (const canal of canales) {
    const dir = path.join(DIST_DIR, canal);
    const zipBuf = fs.readFileSync(path.join(dir, zipName));
    const manBuf = fs.readFileSync(path.join(dir, "update.json"));
    let r = await ghPutFile(gh, "canales/" + canal + "/" + zipName, zipBuf, "update " + canal + " v" + nuevaVersion);
    if (!r.ok) { console.error("  ✗ " + canal + " zip: " + r.error); continue; }
    r = await ghPutFile(gh, "canales/" + canal + "/update.json", manBuf, "manifest " + canal + " v" + nuevaVersion);
    if (!r.ok) { console.error("  ✗ " + canal + " update.json: " + r.error); continue; }
    console.log("  ✓ " + canal + " publicado (v" + nuevaVersion + ")");
  }
  console.log("\nHecho. Las PCs del canal recibirán el aviso en su próxima revisión.");
}

main().catch((e) => { console.error("ERROR:", e.message); process.exit(1); });
