"use strict";

/* ============================================================
   Motor de dinero — todo se calcula en CENTAVOS (enteros).
   Evita los errores clásicos de punto flotante
   (ej. 0.1 + 0.2 !== 0.3) en sumas, restas y multiplicaciones.
   ============================================================ */

const Money = {
  // Pesos (número) -> centavos (entero)
  toCents(pesos) {
    if (pesos == null || pesos === "") return 0;
    return Math.round(Number(pesos) * 100);
  },

  // Centavos (entero) -> pesos (número)
  toPesos(cents) {
    return (Number(cents) || 0) / 100;
  },

  // Precio (centavos/unidad) x cantidad (puede ser decimal: kg) -> centavos (entero)
  // Se redondea SIEMPRE al centavo más cercano de forma determinista.
  multiplicar(precioCents, cantidad) {
    const c = Number(cantidad);
    if (!isFinite(c) || c <= 0) return 0;
    return Math.round(Number(precioCents) * c);
  },

  // Suma exacta de una lista de centavos
  sumar(listaCents) {
    return listaCents.reduce((acc, n) => acc + (Number(n) || 0), 0);
  },

  // Resta exacta
  restar(aCents, bCents) {
    return (Number(aCents) || 0) - (Number(bCents) || 0);
  },

  // Formato para mostrar: 12345 -> "$123.45"
  formato(cents) {
    const n = (Number(cents) || 0) / 100;
    return "$" + n.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = Money;
}
