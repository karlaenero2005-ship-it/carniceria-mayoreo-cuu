"use strict";
/*
  Lectura DIRECTA de ventas desde básculas TORREY W-LABEL, sin Scale Link.

  Este módulo habla el protocolo propietario de la báscula por TCP (puerto
  50036) — el mismo que usa Scale Link por debajo — para descargar las ventas
  acumuladas (folios, productos, pesos, precios) en tiempo real. NO depende de
  la base Access de Scale Link ni de que Scale Link esté abierto.

  Protocolo (descubierto por ingeniería inversa del SDK de TORREY):
    - Se abre un socket TCP a la báscula en el puerto 50036.
    - Los comandos son texto (codepage 437 / ASCII) con el formato:
          <payload> <checksum> \r
      donde el checksum es un caracter calculado por la báscula. Como los
      comandos de LECTURA son fijos, sus checksums son constantes (ver CMD_*).
    - Secuencia de lectura (NO destructiva y SILENCIOSA; nunca se envían el
      bloqueo 'bXXX' ni los comandos de corte/borrado 'S'/'D', así que la
      báscula conserva sus ventas y NO entra en modo "actualizando" ni pita):
          1) "LvXX"  -> encabezados de venta (folio, total, fecha/hora).
          2) "LdXX"  -> detalle por línea (producto, peso, precio, total).
      Cada dataset llega en bloques; entre bloque y bloque se envía el ACK
      "XXOk" hasta recibir un registro "<Tipo>00End". (Antes se enviaba "bXXX"
      como saludo, pero ese comando BLOQUEA la báscula; se comprobó que la
      lectura funciona igual sin él, dejándola libre para el operador.)
    - Los campos de cada registro van separados por TAB (0x09) y los registros
      por salto de línea (0x0A). El detalle se enlaza al encabezado por id_Venta.

  Devuelve la MISMA forma que bascula.js (probar/leerVentas) para ser un
  reemplazo directo del puente basado en Access.
*/

const net = require("net");

const PUERTO_DEFECTO = 50036;
const IP_DEFECTO = "192.168.100.28";
const CR = "\r";

/*
  Checksum del protocolo TORREY (reproduce ScalelinkPC.CheckSum.ChkSum).
  Recorre el payload hasta el último salto de línea (incluido) sumando cada
  byte por un peso que arranca en 2 y cicla 2..8 (al llegar a 9 vuelve a 2).
  El resultado es (suma*10) % 11 + '0' → un caracter entre '0' y ':'.
  Verificado contra la báscula/binario real para todos los comandos.
*/
function checksum(payload) {
  let fin = payload.lastIndexOf("\n") + 1;
  if (fin <= 0) fin = payload.length;
  let suma = 0, i = 2;
  for (let j = 0; j < fin; j++) {
    suma += payload.charCodeAt(j) * i;
    i++;
    if (i === 9) i = 2;
  }
  return String.fromCharCode(((suma * 10) % 11) + 48);
}

// Enmarca un payload: payload + checksum + CR (listo para enviar).
function frame(payload) { return payload + checksum(payload) + CR; }

// Comandos de LECTURA (payload sin enmarcar; se enmarcan al enviar).
// OJO: "bXXX" bloquea la báscula (modo "actualizando"/pitido). NO se usa: la
// lectura de ventas funciona sin bloquear.
const CMD_LV = "LvXX\t\n"; // encabezados de venta
const CMD_LD = "LdXX\t\n"; // detalle de venta
const ACK    = "XXOk\t\n"; // pedir siguiente bloque

function ip(cfg) { return String((cfg && cfg.ip) || IP_DEFECTO).trim(); }
function puerto(cfg) {
  const p = parseInt(cfg && cfg.puertoDirecto, 10);
  return p > 0 ? p : PUERTO_DEFECTO;
}

/*
  Ejecuta una sesión TCP con la báscula: abre, corre `pasos` y cierra.
  `pasos(api)` recibe helpers { enviar, leerBloques } y debe resolver con el
  resultado. Todo el manejo de socket/timeout queda encapsulado aquí.
*/
function sesion(cfg, pasos) {
  return new Promise((resolve, reject) => {
    const host = ip(cfg);
    const port = puerto(cfg);
    const socket = new net.Socket();
    // Sin algoritmo de Nagle: los comandos y ACK del protocolo (ping-pong de
    // bloques) se envían al instante en vez de esperar a agruparlos. Es la
    // mejora de latencia más importante por WiFi. KeepAlive detecta cortes.
    socket.setNoDelay(true);
    try { socket.setKeepAlive(true, 4000); } catch (_) {}
    let cerrado = false;
    let colaResolvers = [];   // lectores esperando datos
    let buffer = Buffer.alloc(0);

    const timeoutMs = Math.max(2000, Math.min(20000, parseInt(cfg && cfg.timeoutMs, 10) || 6000));
    socket.setTimeout(timeoutMs);

    function finalizar(err, val) {
      if (cerrado) return;
      cerrado = true;
      try { socket.destroy(); } catch (_) {}
      colaResolvers = [];
      if (err) reject(err); else resolve(val);
    }

    // Entrega datos crudos a quien esté esperando una lectura.
    function bombear() {
      while (colaResolvers.length && buffer.length) {
        const r = colaResolvers.shift();
        const chunk = buffer;
        buffer = Buffer.alloc(0);
        r(chunk.toString("latin1")); // codepage 437 ~ latin1 para bytes de datos
      }
    }

    socket.on("data", (d) => { buffer = Buffer.concat([buffer, d]); bombear(); });
    socket.on("timeout", () => {
      // Un timeout de lectura no siempre es error: puede ser fin de datos.
      const r = colaResolvers.shift();
      if (r) r(null);
      else finalizar(new Error("TIMEOUT_BASCULA"));
    });
    socket.on("error", (e) => finalizar(e));
    socket.on("close", () => {
      const r = colaResolvers.shift();
      if (r) r(null);
    });

    function enviar(datos) {
      return new Promise((res, rej) => {
        socket.write(Buffer.from(datos, "latin1"), (e) => (e ? rej(e) : res()));
      });
    }
    // Espera el próximo trozo de datos (o null si timeout/cierre).
    function leer() {
      if (buffer.length) {
        const chunk = buffer; buffer = Buffer.alloc(0);
        return Promise.resolve(chunk.toString("latin1"));
      }
      return new Promise((res) => colaResolvers.push(res));
    }

    // Lee bloques de un dataset hasta encontrar "End" (o agotar reintentos).
    async function leerDataset(cmd) {
      await enviar(frame(cmd));
      let acum = "";
      for (let i = 0; i < 60; i++) {
        const t = await leer();
        if (t == null) break;              // timeout/cierre => fin
        acum += t;
        if (/End/.test(t)) break;          // marcador de fin de dataset
        await enviar(frame(ACK));          // pedir siguiente bloque
      }
      return acum;
    }

    socket.connect(port, host, async () => {
      try {
        const val = await pasos({ enviar, leer, leerDataset });
        finalizar(null, val);
      } catch (e) {
        finalizar(e);
      }
    });
  });
}

function num(v) { const n = parseFloat(String(v).replace(/\s+/g, "")); return isNaN(n) ? 0 : n; }
function cents(v) { return Math.round(num(v) * 100); }

// Extrae registros (arreglos de campos) de un dataset crudo.
//  - Quita el prefijo de tipo "Xx99" del inicio de cada bloque.
//  - Separa por salto de línea y cada registro por TAB.
//  - Descarta líneas de control (contadores, checksums, "End").
function extraerRegistros(raw, tipo) {
  if (!raw) return [];
  // Normaliza: elimina CR y separa por LF.
  const lineas = raw.replace(/\r/g, "\n").split("\n");
  const regs = [];
  const rePrefijo = new RegExp("^" + tipo + "\\d{2}");
  for (let linea of lineas) {
    if (!linea) continue;
    // Quita el encabezado de bloque "Lv07", "Ld08", etc. si viene pegado.
    linea = linea.replace(rePrefijo, "");
    if (!linea) continue;
    if (/End/.test(linea)) continue;
    const campos = linea.split("\t");
    // Un registro real tiene varios campos y su primer campo es numérico.
    if (campos.length >= 4 && /^\d+$/.test(campos[0].trim())) {
      regs.push(campos.map((c) => c.trim()));
    }
  }
  return regs;
}

// Convierte los datasets Lv (encabezados) y Ld (detalle) en ventas agrupadas.
function armarVentas(lvRaw, ldRaw) {
  const encabezados = extraerRegistros(lvRaw, "Lv");
  const detalles = extraerRegistros(ldRaw, "Ld");

  const ventas = new Map(); // idVenta -> venta
  for (const f of encabezados) {
    // f: [idVenta, nSerie, depto, idCorte, vendedor, folio, ?, cantidad,
    //     granTotal, subtotal, desc, efvo, cambio, fecha, hora, oferta, imp]
    const idVenta = f[0];
    const nserie = f[1] || "";
    const folio = f[5] || idVenta;
    const granTotal = f[8];
    const fecha = f[13] || "";
    const hora = f[14] || "";
    const key = [nserie, folio, fecha, hora].join("|");
    ventas.set(idVenta, {
      key,
      idBascula: 1,
      idVenta,
      folio,
      fecha,
      hora,
      nserie,
      lineas: [],
      totalCents: cents(granTotal)
    });
  }

  for (const f of detalles) {
    // f: [linea, idVenta, lineaNo, codigo, plu, nombre, dev, tipoPLU, peso,
    //     precio, total, ?, ?, subtotal, imp, desc, depto, ?]
    const idVenta = f[1];
    const venta = ventas.get(idVenta);
    if (!venta) continue;
    const tipoPLU = f[7];
    const peso = num(f[8]);
    const esPeso = String(tipoPLU) === "1" && peso > 0;
    const dev = num(f[6]) !== 0;
    const linea = {
      codigo: (f[3] || "").trim(),
      noPlu: (f[4] || "").trim(),
      nombre: (f[5] || "").trim() || "Producto",
      cant: esPeso ? peso : (peso > 0 ? peso : 1),
      unidad: esPeso ? "kg" : "pza",
      precioCents: cents(f[9]),
      importeCents: cents(f[10]),
      devolucion: dev
    };
    venta.lineas.push(linea);
  }

  // Si el encabezado no traía total, recomputa desde las líneas.
  const arr = Array.from(ventas.values());
  for (const v of arr) {
    if (!v.totalCents) {
      v.totalCents = v.lineas.reduce((s, l) => s + (l.devolucion ? -l.importeCents : l.importeCents), 0);
    }
  }
  return arr;
}

/* ---------------- API pública (mismo contrato que bascula.js) ---------------- */

// Diagnóstico SILENCIOSO: pide los encabezados de venta y confirma que la
// báscula responde con datos "Lv" (sin bloquearla).
async function probar(cfg) {
  cfg = cfg || {};
  try {
    const info = await sesion(cfg, async ({ enviar, leer }) => {
      await enviar(frame(CMD_LV));
      const resp = await leer();
      return { resp: resp || "" };
    });
    const ok = /Lv\d|Lv00End|End/.test(info.resp || "");
    if (!ok) return { error: "La báscula respondió pero no con datos de venta. Verifica IP/puerto." };
    return {
      ok: true,
      ip: ip(cfg),
      puerto: puerto(cfg),
      basculas: [{ id: 1, ip: ip(cfg), puerto: puerto(cfg), conexion: "TCP directa" }]
    };
  } catch (e) {
    return { error: traducirError(e && e.message, cfg) };
  }
}

// Lee las ventas acumuladas en la báscula (encabezado + detalle), agrupadas.
async function leerVentas(cfg) {
  cfg = cfg || {};
  try {
    const { lv, ld } = await sesion(cfg, async ({ leerDataset }) => {
      // Lectura directa y silenciosa (sin bloquear la báscula).
      const lv = await leerDataset(CMD_LV);
      const ld = await leerDataset(CMD_LD);
      return { lv, ld };
    });
    return { ok: true, ventas: armarVentas(lv, ld) };
  } catch (e) {
    return { error: traducirError(e && e.message, cfg) };
  }
}

// Lectura LIGERA: solo los encabezados (Lv) para detectar ventas nuevas por su
// `key`, sin bajar el detalle (Ld). Se usa en el sondeo periódico para que cada
// ciclo sea rápido; el detalle completo solo se baja cuando aparece algo nuevo.
async function leerEncabezados(cfg) {
  cfg = cfg || {};
  // La lectura ligera usa un timeout MÁS CORTO que el detalle: detecta rápido
  // si hay ventas nuevas. Como cada báscula corre en paralelo e independiente,
  // este tiempo solo afecta a SU propio ciclo (no frena a la otra báscula), así
  // que damos un margen razonable para WiFi con señal intermitente.
  cfg = Object.assign({}, cfg, { timeoutMs: Math.min(parseInt(cfg.timeoutMs, 10) || 6000, 3500) });
  try {
    const lv = await sesion(cfg, async ({ leerDataset }) => leerDataset(CMD_LV));
    return { ok: true, ventas: armarVentas(lv, "") };
  } catch (e) {
    return { error: traducirError(e && e.message, cfg) };
  }
}

/* ---------------- FASE 2: programar precios/productos en la báscula ----------------

  Comandos de ESCRITURA descubiertos por ingeniería inversa (verificados contra
  ScalelinkPC.Conexion.Envio_Dato / Envia_Dato.vActualizar_Bascula_Precio):

    Precio (por red / TCP):
        payload = "Gp0" + <cantidad> + [ por producto: <id_producto>\t<precio>\t\n ]
      donde <precio> se formatea con 2 decimales y punto (ej. 199.90) — idéntico a
      String.Format(es-MX, "{0:##0.#0}", precio). La báscula responde con "...Ok..."
      si aceptó los cambios. El enmarcado (payload+checksum+CR) es el mismo `frame`.

  IMPORTANTE: la báscula identifica el producto por su `id_producto` interno (no por
  el PLU impreso). Usa `leerProductos` para descargar el catálogo y mapear.
*/

const CMD_LP = "LP\t\n"; // leer catálogo de productos (getAll)

// Formatea un precio en PESOS como lo espera la báscula: 2 decimales, punto.
function fmtPrecio(pesos) {
  const n = num(pesos);
  return n.toFixed(2);
}

// Normaliza items -> [{ id, precio(pesos) }]. Acepta precioCents o precio.
function normalizarItems(items) {
  const out = [];
  for (const it of items || []) {
    if (!it) continue;
    const id = String(it.id != null ? it.id : it.idProducto != null ? it.idProducto : "").trim();
    if (!id || !/^\d+$/.test(id)) continue;
    let pesos;
    if (it.precio != null) pesos = num(it.precio);
    else if (it.precioCents != null) pesos = num(it.precioCents) / 100;
    else continue;
    out.push({ id, precio: pesos });
  }
  return out;
}

/*
  Programa (actualiza) el precio de uno o varios productos en la báscula.
  `items`: [{ id: <id_producto en báscula>, precio: <pesos> }] (o { precioCents }).
  Devuelve { ok, enviados, respuesta } o { error }.
*/
async function programarPrecios(cfg, items) {
  cfg = cfg || {};
  const lista = normalizarItems(items);
  if (!lista.length) return { error: "No hay precios válidos para enviar (falta id_producto o precio)." };
  try {
    const respuesta = await sesion(cfg, async ({ enviar, leer }) => {
      let tramas = "";
      for (const it of lista) {
        tramas += it.id + "\t" + fmtPrecio(it.precio) + "\t\n";
      }
      const payload = "Gp0" + lista.length + tramas;
      await enviar(frame(payload));
      // La báscula contesta con un ACK (framed). Puede llegar en 1-2 trozos.
      let resp = "";
      for (let i = 0; i < 4; i++) {
        const t = await leer();
        if (t == null) break;
        resp += t;
        if (/Ok/i.test(resp) || /\r/.test(resp)) break;
      }
      return resp;
    });
    const ok = /Ok/i.test(respuesta || "");
    if (!ok) return { error: "La báscula no confirmó la actualización de precios (resp: " + JSON.stringify(respuesta) + ")." };
    return { ok: true, enviados: lista.length, respuesta };
  } catch (e) {
    return { error: traducirError(e && e.message, cfg) };
  }
}

async function programarPrecio(cfg, id, precio) {
  return programarPrecios(cfg, [{ id, precio }]);
}

/*
  Lee el catálogo de productos de la báscula (comando "LP"), para poder mapear
  cada producto del POS con su `id_producto` interno. Devuelve { ok, productos }
  donde cada producto = { id, codigo, plu, nombre, precio, campos }.
  NOTA: el orden de campos sigue el de la trama de producto; conviene verificarlo
  contra la báscula real la primera vez (los campos crudos van en `campos`).
*/
async function leerProductos(cfg) {
  cfg = cfg || {};
  try {
    const raw = await sesion(cfg, async ({ leerDataset }) => {
      return await leerDataset(CMD_LP);
    });
    const regs = extraerRegistros(raw, "LP");
    const productos = regs.map((f) => ({
      id: (f[0] || "").trim(),
      codigo: (f[1] || "").trim(),
      plu: (f[2] || "").trim(),
      nombre: (f[3] || "").trim(),
      precio: num(f[4]),
      campos: f
    }));
    return { ok: true, productos };
  } catch (e) {
    return { error: traducirError(e && e.message, cfg) };
  }
}

function traducirError(m, cfg) {
  m = String(m || "");
  const destino = ip(cfg) + ":" + puerto(cfg);
  if (/ECONNREFUSED/i.test(m)) return "La báscula rechazó la conexión en " + destino + ". ¿Está encendida y en red?";
  if (/EHOSTUNREACH|ENETUNREACH|ETIMEDOUT|TIMEOUT_BASCULA/i.test(m)) return "No se pudo contactar la báscula en " + destino + " (sin respuesta). Revisa IP/red/WiFi.";
  if (/ECONNRESET/i.test(m)) return "La báscula cerró la conexión inesperadamente. Se reintentará.";
  return "Error al leer la báscula directa (" + destino + "): " + m;
}

module.exports = {
  probar,
  leerVentas,
  leerEncabezados,
  programarPrecios,
  programarPrecio,
  leerProductos,
  // utilidades expuestas para pruebas/otros módulos
  checksum,
  frame,
  fmtPrecio,
  PUERTO_DEFECTO,
  IP_DEFECTO
};
