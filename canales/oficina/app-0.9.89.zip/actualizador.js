/* ============================================================
   actualizador.js — Canal de actualizaciones por GitHub (público)
   ------------------------------------------------------------
   - SIN Supabase. Cada PC tiene un "canal" (oficina / carniceria).
   - Lee un manifiesto diminuto (update.json) del canal de ESTA PC,
     compara la versión con la instalada y, si el encargado confirma,
     baja un zip con SOLO el código, lo verifica por sha256, respalda
     el código actual y lo deja listo para aplicarse al reiniciar.
   - NUNCA toca datos-nube ni el .exe / runtime de Electron.
   ============================================================ */
const https = require("https");
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { execFile } = require("child_process");

/* ---------- utilidades ---------- */

// Compara versiones "x.y.z" -> 1 si a>b, -1 si a<b, 0 iguales.
function cmpVer(a, b) {
  const pa = String(a || "0").split(".").map((n) => parseInt(n, 10) || 0);
  const pb = String(b || "0").split(".").map((n) => parseInt(n, 10) || 0);
  const n = Math.max(pa.length, pb.length);
  for (let i = 0; i < n; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

// GET con seguimiento de redirecciones. binario=true devuelve Buffer.
function httpGet(url, binario, maxRedir) {
  maxRedir = maxRedir == null ? 5 : maxRedir;
  return new Promise((resolve, reject) => {
    const lib = String(url).startsWith("http://") ? http : https;
    const req = lib.get(
      url,
      { headers: { "User-Agent": "Mayoreo-Updater", "Cache-Control": "no-cache" } },
      (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume();
          if (maxRedir <= 0) { reject(new Error("Demasiadas redirecciones")); return; }
          let next;
          try { next = new URL(res.headers.location, url).toString(); }
          catch (e) { reject(new Error("Redirección inválida")); return; }
          httpGet(next, binario, maxRedir - 1).then(resolve, reject);
          return;
        }
        if (res.statusCode !== 200) {
          res.resume();
          reject(new Error("HTTP " + res.statusCode));
          return;
        }
        const chunks = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => {
          const buf = Buffer.concat(chunks);
          resolve(binario ? buf : buf.toString("utf8"));
        });
      }
    );
    req.on("error", reject);
    req.setTimeout(20000, () => { req.destroy(new Error("Tiempo de espera agotado")); });
  });
}

function sha256Buf(buf) { return crypto.createHash("sha256").update(buf).digest("hex"); }

function rmrf(p) {
  try { fs.rmSync(p, { recursive: true, force: true }); }
  catch (e) { try { fs.rmdirSync(p, { recursive: true }); } catch (_) {} }
}

function baseRaw(cfg) {
  const owner = String(cfg.owner || "").trim();
  const repo = String(cfg.repo || "").trim();
  const rama = String(cfg.rama || "main").trim() || "main";
  if (!owner || !repo) return "";
  return "https://raw.githubusercontent.com/" + owner + "/" + repo + "/" + rama;
}
function canalSlug(cfg) { return String(cfg.canal || "").trim().toLowerCase(); }

function urlManifiesto(cfg) {
  const base = baseRaw(cfg);
  const canal = canalSlug(cfg);
  if (!base || !canal) return "";
  return base + "/canales/" + canal + "/update.json?t=" + Date.now();
}

/* ---------- revisar si hay novedad (barato: solo el manifiesto) ---------- */

async function revisar(cfg, versionActual) {
  cfg = cfg || {};
  if (!cfg.activo) return { ok: false, motivo: "inactivo", versionActual };
  const url = urlManifiesto(cfg);
  if (!url) return { ok: false, motivo: "sin-config", versionActual };
  let txt;
  try { txt = await httpGet(url, false); }
  catch (e) { return { ok: false, motivo: "red", error: e.message, versionActual }; }
  let man;
  try { man = JSON.parse(txt); }
  catch (e) { return { ok: false, motivo: "manifiesto-invalido", versionActual }; }
  const version = String(man.version || "").trim();
  if (!version) return { ok: false, motivo: "manifiesto-invalido", versionActual };
  const hay = cmpVer(version, versionActual) > 0;
  return {
    ok: true,
    hay,
    version,
    versionActual,
    notas: String(man.notas || ""),
    zip: String(man.zip || ""),
    sha256: String(man.sha256 || "").toLowerCase(),
    fecha: man.fecha || "",
    canal: canalSlug(cfg)
  };
}

/* ---------- descarga del zip y preparación en "staging" ---------- */

function extraerZip(zipPath, destDir) {
  return new Promise((resolve, reject) => {
    rmrf(destDir);
    const esc = (s) => s.replace(/'/g, "''");
    const ps =
      "Add-Type -AssemblyName System.IO.Compression.FileSystem; " +
      "[System.IO.Compression.ZipFile]::ExtractToDirectory('" + esc(zipPath) + "','" + esc(destDir) + "')";
    execFile(
      "powershell.exe",
      ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps],
      { windowsHide: true, maxBuffer: 1024 * 1024 * 8 },
      (err, so, se) => {
        if (err) { reject(new Error("No se pudo descomprimir: " + (se || err.message))); return; }
        resolve();
      }
    );
  });
}

// Copia recursiva tipo "merge" (no borra lo que no venga en el origen).
// Cada archivo se escribe en un temporal y se renombra encima (atómico).
function copiarMerge(srcDir, dstDir) {
  fs.mkdirSync(dstDir, { recursive: true });
  const ents = fs.readdirSync(srcDir, { withFileTypes: true });
  for (const e of ents) {
    const s = path.join(srcDir, e.name);
    const d = path.join(dstDir, e.name);
    if (e.isDirectory()) copiarMerge(s, d);
    else {
      const tmp = d + ".tmp-upd";
      fs.copyFileSync(s, tmp);
      try { fs.renameSync(tmp, d); }
      catch (_) { fs.copyFileSync(s, d); try { fs.unlinkSync(tmp); } catch (__) {} }
    }
  }
}

// Respalda del appDir SOLO los archivos que van a ser sobrescritos por stageDir.
function respaldarAfectados(stageDir, appDir, bakDir) {
  const ents = fs.readdirSync(stageDir, { withFileTypes: true });
  for (const e of ents) {
    const sStage = path.join(stageDir, e.name);
    const sApp = path.join(appDir, e.name);
    const sBak = path.join(bakDir, e.name);
    if (e.isDirectory()) {
      if (fs.existsSync(sApp)) respaldarAfectados(sStage, sApp, sBak);
    } else if (fs.existsSync(sApp)) {
      fs.mkdirSync(path.dirname(sBak), { recursive: true });
      fs.copyFileSync(sApp, sBak);
    }
  }
}

function podarBackups(dir, max) {
  try {
    const items = fs.readdirSync(dir).filter((n) => n.startsWith("app-")).sort();
    while (items.length > max) { const old = items.shift(); rmrf(path.join(dir, old)); }
  } catch (_) {}
}

// Descarga + verifica + extrae + valida + deja listo en stagingDir para que
// aplicarPendiente() lo instale al próximo arranque.
async function descargarYPreparar(opts) {
  const { cfg, info, stagingDir } = opts;
  if (!info || !info.hay) return { ok: false, error: "No hay actualización disponible." };
  const base = baseRaw(cfg);
  const canal = canalSlug(cfg);
  if (!base || !canal) return { ok: false, error: "Falta configurar el canal de actualizaciones." };

  const zipName = info.zip || ("app-" + info.version + ".zip");
  const zipUrl = base + "/canales/" + canal + "/" + zipName + "?t=" + Date.now();

  let buf;
  try { buf = await httpGet(zipUrl, true); }
  catch (e) { return { ok: false, error: "No se pudo descargar la actualización: " + e.message }; }

  if (info.sha256) {
    const h = sha256Buf(buf);
    if (h !== info.sha256) {
      return { ok: false, error: "La verificación de integridad (sha256) falló. Se canceló por seguridad." };
    }
  }

  // Limpia staging y arma estructura temporal.
  rmrf(stagingDir);
  const tmpDir = path.join(stagingDir, "_tmp");
  fs.mkdirSync(tmpDir, { recursive: true });
  const zipPath = path.join(tmpDir, zipName);
  fs.writeFileSync(zipPath, buf);

  const extractDir = path.join(tmpDir, "x");
  try { await extraerZip(zipPath, extractDir); }
  catch (e) { rmrf(stagingDir); return { ok: false, error: e.message }; }

  // El zip trae los archivos de resources/app en su raíz; si viniera dentro de
  // una sola subcarpeta, la detectamos.
  let rootDir = extractDir;
  if (!fs.existsSync(path.join(rootDir, "package.json"))) {
    let subs = [];
    try { subs = fs.readdirSync(extractDir, { withFileTypes: true }).filter((e) => e.isDirectory()); } catch (_) {}
    if (subs.length === 1 && fs.existsSync(path.join(extractDir, subs[0].name, "package.json"))) {
      rootDir = path.join(extractDir, subs[0].name);
    }
  }

  let pkg;
  try { pkg = JSON.parse(fs.readFileSync(path.join(rootDir, "package.json"), "utf8")); }
  catch (e) { rmrf(stagingDir); return { ok: false, error: "El paquete no trae un package.json válido." }; }

  // Seguridad: debe ser más nuevo y contener los archivos clave.
  if (cmpVer(pkg.version, info.versionActual) <= 0) {
    rmrf(stagingDir);
    return { ok: false, error: "El paquete no es más nuevo que la versión instalada." };
  }
  const claves = ["main.js", "db.js", "preload.js"];
  for (const f of claves) {
    if (!fs.existsSync(path.join(rootDir, f))) {
      rmrf(stagingDir);
      return { ok: false, error: "El paquete está incompleto (falta " + f + ")." };
    }
  }

  // Deja el código nuevo en stagingDir/app y escribe el marcador.
  const appStage = path.join(stagingDir, "app");
  rmrf(appStage);
  fs.renameSync(rootDir, appStage);
  fs.writeFileSync(
    path.join(stagingDir, "pendiente.json"),
    JSON.stringify({ version: pkg.version, canal, cuando: new Date().toISOString() }, null, 2)
  );
  rmrf(tmpDir);
  return { ok: true, version: pkg.version };
}

/* ---------- aplicar al arranque (antes de cargar el resto) ---------- */

// Se llama al inicio de main.js. Si hay staging pendiente: respalda los
// archivos que se van a tocar y copia el código nuevo encima de appDir.
// Devuelve { aplicado:true, version } si instaló algo.
function aplicarPendiente(opts) {
  const { appDir, stagingDir, backupsDir } = opts;
  try {
    const marker = path.join(stagingDir, "pendiente.json");
    const appStage = path.join(stagingDir, "app");
    if (!fs.existsSync(marker) || !fs.existsSync(appStage)) return { aplicado: false };

    let meta = {};
    try { meta = JSON.parse(fs.readFileSync(marker, "utf8")); } catch (_) {}

    // 1) Respaldo de lo que se va a sobrescribir (si falla, abortamos).
    try {
      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      const bak = path.join(backupsDir, "app-" + stamp);
      fs.mkdirSync(bak, { recursive: true });
      respaldarAfectados(appStage, appDir, bak);
      podarBackups(backupsDir, 5);
    } catch (e) {
      return { aplicado: false, error: "No se pudo respaldar antes de actualizar: " + e.message };
    }

    // 2) Aplicar (merge sobre appDir).
    copiarMerge(appStage, appDir);

    // 3) Limpiar staging.
    rmrf(stagingDir);
    return { aplicado: true, version: meta.version };
  } catch (e) {
    return { aplicado: false, error: e.message };
  }
}

module.exports = {
  cmpVer,
  revisar,
  descargarYPreparar,
  aplicarPendiente,
  // export interno para pruebas
  _copiarMerge: copiarMerge
};
