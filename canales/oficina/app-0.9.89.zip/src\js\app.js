"use strict";

/* ============================================================
   Mayoreo de Carnes de Res — Punto de Venta
   Interfaz local. Lee/escribe en la base de datos local (offline).
   Todos los cálculos de dinero se hacen en CENTAVOS (ver money.js).
   ============================================================ */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const fmt = (cents) => Money.formato(cents);
// Busca por folio o por total ($150.50, 150.50, 150, 15050 en centavos).
function parsearBusquedaMontoCents(q) {
  let s = String(q || "").trim().replace(/[$\s]/g, "");
  if (!s) return null;
  if (/^\d{1,3}(,\d{3})+(\.\d{1,2})?$/.test(s)) s = s.replace(/,/g, "");
  else if (/^\d+,\d{1,2}$/.test(s)) s = s.replace(",", ".");
  else s = s.replace(/,/g, "");
  if (!/^\d+(\.\d{1,2})?$/.test(s)) return null;
  const n = parseFloat(s);
  if (!Number.isFinite(n)) return null;
  return Math.round(n * 100);
}
function coincideFolioOTotal(qRaw, folios, totalCents, textos) {
  const q = String(qRaw || "").trim().toLowerCase();
  if (!q) return true;
  const listaFol = (Array.isArray(folios) ? folios : [folios]).filter((f) => f != null && f !== "");
  if (listaFol.some((f) => String(f).toLowerCase().includes(q))) return true;
  if ((textos || []).some((t) => String(t || "").toLowerCase().includes(q))) return true;
  const cents = Number(totalCents) || 0;
  const qMonto = q.replace(/[$\s]/g, "").replace(/,/g, "");
  const plano = fmt(cents).toLowerCase().replace(/[$\s,]/g, "");
  if (qMonto && (fmt(cents).toLowerCase().includes(q) || plano.includes(qMonto))) return true;
  const parsed = parsearBusquedaMontoCents(q);
  if (parsed != null && parsed === cents) return true;
  if (/^\d+$/.test(qMonto) && parseInt(qMonto, 10) === cents) return true;
  return false;
}
// Cantidad legible (kg con hasta 3 decimales, piezas enteras)
const fmtCant = (n, unidad) =>
  unidad === "kg" ? (+Number(n || 0).toFixed(3)).toString() : String(Math.round(Number(n || 0)));
const METODO_EXTRA = { combinado: { emoji: "🧩", label: "Combinado" }, credito: { emoji: "📒", label: "Crédito" }, dolares: { emoji: "💵", label: "Dólares" } };
const pagoLabel = (id) => (PAGOS.find((p) => p.id === id) || METODO_EXTRA[id] || { label: id }).label;

// Un keydown NUNCA debe ser interceptado por atajos o por el lector de código de
// barras si el foco está en un campo editable o dentro de un modal de captura.
// Garantiza que SIEMPRE se pueda escribir a mano en cualquier campo del sistema.
function esCampoEditable(el) {
  if (!el || !el.tagName) return false;
  const tag = el.tagName;
  if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || tag === "OPTION") return true;
  if (el.isContentEditable) return true;
  if (typeof el.closest === "function" &&
      el.closest('input, textarea, select, [contenteditable=""], [contenteditable="true"], .modal-back')) return true;
  return false;
}

// Estado
let DATA = null;
let resumenFiltro = { periodo: "dia", ancla: "" };
let resumenTab = "general";
let copiaEnVivo = false;
let IMGS = {}; // { productoId: dataURL } miniaturas para el menú de ventas
let CFG = null;
let usuarioActual = null;
let catActiva = "paquetes";
const CLIENTE_DEFAULT = "Al mostrador / Público";
let tickets = [];            // [{ id, nombre, cart:[], cliente }]
let ticketActivoId = null;
let ticketSeq = 0;
let cart = [];               // referencia al carrito del ticket activo
let cajaAbierta = false;
let borradorCredito = [];
let cajaVacia = false;        // caja abierta pero SIN ventas ni movimientos (permite capturar fondo)
let cajaFondoActual = 0;      // fondo de la caja abierta (para precargar al corregir)
let clienteActual = CLIENTE_DEFAULT;
let ultimoTicket = null;
let basculaPendientes = [];  // ventas de báscula llegadas antes de iniciar sesión
// Pool de ventas de báscula ya descargadas por Scale Link, indexadas por folio
// (llave que trae el código de barras de la etiqueta). Permite abrir el ticket
// completo al escanear. Clave: folioKey(idBascula, folio).
const ventasBasculaPorFolio = new Map();
// Escaneos hechos antes de que llegara la venta (se abren en cuanto Scale Link
// la descargue). Clave: folioKey normalizada → timestamp.
const escaneosPendientesBascula = new Map();

const AVATAR = { Administrador: "👤", Cajero: "🧑‍💼", Despacho: "🔪" };

// ---- Permisos por rol ----
// Admin puede todo. Cajero/Despacho pueden AGREGAR existencias, pero NO bajar
// stock ni cambiar precios (para eso: clave de admin / desbloqueo temporal).
let invDesbloqueado = false;
function esAdmin() { return !!(usuarioActual && usuarioActual.rol === "Administrador"); }
function invProtegido() { return !(CFG && CFG.permisos && CFG.permisos.inventarioSoloAdmin === false); }
function puedeEditarInventario() { return esAdmin() || invDesbloqueado || !invProtegido(); }
/** Sumar existencias (entradas): permitido a cualquier usuario logueado. */
function puedeSumarInventario() { return !!usuarioActual; }
/** Cambiar precios / bajar stock / editar catálogo: solo admin o desbloqueado. */
function puedeEditarPrecios() { return puedeEditarInventario(); }

// Pide la clave (PIN) de un administrador. Resuelve true si es correcta.
function pedirPinAdmin(motivo) {
  return new Promise((resolve) => {
    const admins = (DATA && DATA.usuarios || []).filter((u) => u.rol === "Administrador");
    const back = document.createElement("div");
    back.className = "modal-back";
    back.innerHTML = `
      <div class="modal modal--qty">
        <h3>🔒 Clave de administrador</h3>
        <p class="qty-hint">${motivo || "Esta acción requiere autorización de un administrador."}</p>
        <div class="qty-field"><label>PIN de administrador</label>
          <input type="password" id="pa-pin" inputmode="numeric" maxlength="4" placeholder="••••" /></div>
        <p class="qty-hint" id="pa-msg"></p>
        <div class="modal__foot">
          <button class="btn" data-cerrar="1">Cancelar</button>
          <button class="btn btn--primary" id="pa-ok">Autorizar</button>
        </div>
      </div>`;
    document.body.appendChild(back);
    const cerrar = (val) => { back.remove(); resolve(val); };
    const intentar = () => {
      const pin = ($("#pa-pin", back).value || "").trim();
      if (admins.some((u) => String(u.pin) === pin)) return cerrar(true);
      $("#pa-msg", back).innerHTML = '<span class="tk-warn">PIN incorrecto.</span>';
      $("#pa-pin", back).value = ""; $("#pa-pin", back).focus();
    };
    $("#pa-ok", back).addEventListener("click", intentar);
    back.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); cerrar(false); } if (e.key === "Enter") { e.preventDefault(); intentar(); } });
    back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(false); });
    setTimeout(() => { const el = $("#pa-pin", back); if (el) el.focus(); }, 30);
  });
}

// Ventana de captura genérica (reemplaza a window.prompt, que Electron NO soporta).
// Resuelve con el texto capturado, o null si se cancela.
function pedirValorModal(opts) {
  opts = opts || {};
  return new Promise((resolve) => {
    const tipo = opts.tipo === "number" ? "number" : "text";
    const extra = tipo === "number" ? 'min="0" step="0.01" inputmode="decimal"' : "";
    const back = document.createElement("div");
    back.className = "modal-back";
    back.innerHTML = `
      <div class="modal modal--qty">
        <h3>${escapeHtml(opts.titulo || "Dato")}</h3>
        ${opts.hint ? `<p class="qty-hint">${opts.hint}</p>` : ""}
        <div class="qty-field"><label>${escapeHtml(opts.label || "")}</label>
          <input type="${tipo}" ${extra} id="pv-input" placeholder="${attr(opts.placeholder || "")}" /></div>
        <p class="qty-hint" id="pv-msg"></p>
        <div class="modal__foot">
          <button class="btn" data-cerrar="1">Cancelar</button>
          <button class="btn btn--primary" id="pv-ok">${escapeHtml(opts.okLabel || "Aceptar")}</button>
        </div>
      </div>`;
    document.body.appendChild(back);
    const cerrar = (val) => { back.remove(); resolve(val); };
    const ok = () => {
      const raw = ($("#pv-input", back).value || "").trim();
      if (raw === "" && !opts.permitirVacio) { $("#pv-msg", back).innerHTML = '<span class="tk-warn">Escribe un valor.</span>'; return; }
      cerrar(raw);
    };
    $("#pv-ok", back).addEventListener("click", ok);
    back.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); cerrar(null); } if (e.key === "Enter") { e.preventDefault(); ok(); } });
    back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(null); });
    setTimeout(() => { const i = $("#pv-input", back); if (i) { i.focus(); i.select && i.select(); } }, 30);
  });
}

const PAGOS = [
  { id: "efectivo", label: "Efectivo", emoji: "💵" },
  { id: "transferencia", label: "Transferencia", emoji: "🏦" },
  { id: "tarjeta", label: "Tarjeta", emoji: "💳" },
  { id: "vales", label: "Vales", emoji: "🎟️" }
];

// Formas de pago del cobro SIMPLE: las estándar + dólares + crédito. El pago
// COMBINADO sigue usando solo PAGOS (efectivo/transferencia/tarjeta/vales).
const PAGO_DOLARES = { id: "dolares", label: "Dólares", emoji: "💵" };
const PAGO_CREDITO = { id: "credito", label: "Crédito", emoji: "📒" };
const PAGOS_SIMPLE = PAGOS.concat([PAGO_DOLARES, PAGO_CREDITO]);

const MODULOS = {
  resumen: { icon: "📊", title: "Resumen del negocio" },
  corte: { icon: "🧾", title: "Corte de caja" },
  movimientos: { icon: "💸", title: "Registrar movimientos" },
  entrada: { icon: "⬆️", title: "Entrada de efectivo" },
  salida: { icon: "⬇️", title: "Salida de efectivo" },
  inventario: { icon: "📦", title: "Inventario y catálogo" },
  devoluciones: { icon: "↩️", title: "Devoluciones" },
  apartados: { icon: "🏷️", title: "Apartados" },
  espera: { icon: "⏸️", title: "Órdenes en espera" },
  productos: { icon: "📦", title: "Productos" },
  paquetes: { icon: "🎁", title: "Paquetes" },
  categorias: { icon: "🗂️", title: "Categorías" },
  clientes: { icon: "👥", title: "Clientes" },
  creditos: { icon: "💳", title: "Crédito a clientes" },
  usuarios: { icon: "🔐", title: "Usuarios y movimientos" },
  facturacion: { icon: "🧮", title: "Facturación" },
  config: { icon: "⚙️", title: "Configuración" }
};

/* ---------------- Carga de datos ---------------- */
async function loadData() {
  if (window.api && window.api.db) {
    DATA = await window.api.db.bootstrap();
    try { CFG = await window.api.db.getConfig(); } catch (e) { CFG = null; }
    try { IMGS = (await window.api.db.getImagenesProducto()) || {}; } catch (e) { IMGS = {}; }
    aplicarTerminalUI();
  } else {
    DATA = {
      categorias: [], productos: [], paquetes: [],
      usuarios: [{ id: 1, nombre: "Administrador", rol: "Administrador", pin: "1234" }],
      clientes: [], config: { terminal: "Caja Principal" }
    };
  }
}

function aplicarTerminalUI() {
  const nombre = (CFG && CFG.terminal) || "Caja Principal";
  $$(".login__hint b").forEach((b) => { b.textContent = nombre; });
}

/* ---------------- Login ---------------- */
function renderUsers() {
  const grid = $("#user-grid");
  grid.innerHTML = "";
  const soloUnAdmin = DATA.usuarios.filter((x) => x.rol === "Administrador").length <= 1;
  DATA.usuarios.forEach((u) => {
    const card = document.createElement("div");
    card.className = "user-card";
    const puedeEliminar = !(u.rol === "Administrador" && soloUnAdmin);
    card.innerHTML =
      `<span class="user-card__edit" title="Cambiar nombre">✎</span>` +
      `<span class="user-card__pin" title="Cambiar contraseña">🔑</span>` +
      (puedeEliminar ? `<span class="user-card__del" title="Eliminar usuario">🗑</span>` : "") +
      `<div class="user-card__ava">${AVATAR[u.rol] || "👤"}</div>` +
      `<div class="user-card__name">${escapeHtml(u.nombre)}</div>` +
      `<div class="user-card__role">${u.rol}</div>`;
    card.addEventListener("click", () => openPinpad(u));
    card.querySelector(".user-card__edit").addEventListener("click", (e) => {
      e.stopPropagation();
      editarNombreUsuario(u);
    });
    card.querySelector(".user-card__pin").addEventListener("click", (e) => {
      e.stopPropagation();
      cambiarPinFlujo(u);
    });
    const del = card.querySelector(".user-card__del");
    if (del) del.addEventListener("click", (e) => { e.stopPropagation(); eliminarUsuarioFlujo(u); });
    grid.appendChild(card);
  });

  // Ocultar la pista del PIN demo si el administrador ya cambió su contraseña
  const demo = document.querySelector(".login__demo");
  if (demo) {
    const admin = DATA.usuarios.find((x) => x.rol === "Administrador");
    demo.style.display = (admin && admin.pin === "1234") ? "" : "none";
  }
}

function cambiarPinFlujo(u) {
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>Cambiar contraseña</h3>
      <p class="sub">${escapeHtml(u.nombre)}</p>
      <div class="qty-field"><label>Contraseña actual</label>
        <input type="password" id="cp-actual" inputmode="numeric" maxlength="4" placeholder="••••" /></div>
      <div class="qty-field"><label>Nueva contraseña (4 dígitos)</label>
        <input type="password" id="cp-pin" inputmode="numeric" maxlength="4" placeholder="••••" /></div>
      <div class="qty-field"><label>Confirmar contraseña</label>
        <input type="password" id="cp-pin2" inputmode="numeric" maxlength="4" placeholder="••••" /></div>
      <p class="qty-hint" id="cp-msg"></p>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="cp-ok">Guardar</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const actual = $("#cp-actual", back), pin = $("#cp-pin", back), pin2 = $("#cp-pin2", back), msg = $("#cp-msg", back);
  [actual, pin, pin2].forEach((i) => i.addEventListener("input", () => { i.value = i.value.replace(/\D/g, "").slice(0, 4); }));
  const cerrar = () => back.remove();
  const guardar = async () => {
    if (!/^\d{4}$/.test(actual.value)) { msg.innerHTML = '<span class="tk-warn">Escribe la contraseña actual.</span>'; actual.focus(); return; }
    if (!/^\d{4}$/.test(pin.value)) { msg.innerHTML = '<span class="tk-warn">La nueva contraseña debe ser de 4 dígitos.</span>'; pin.focus(); return; }
    if (pin.value !== pin2.value) { msg.innerHTML = '<span class="tk-warn">Las contraseñas no coinciden.</span>'; pin2.focus(); return; }
    if (!tienenDB()) {
      if (actual.value !== u.pin) { msg.innerHTML = '<span class="tk-warn">La contraseña actual no es correcta.</span>'; actual.focus(); return; }
      u.pin = pin.value; cerrar(); return;
    }
    const r = await window.api.db.cambiarPin(u.id, pin.value, actual.value);
    if (r.error) { msg.innerHTML = `<span class="tk-warn">${escapeHtml(r.error)}</span>`; if (/actual/.test(r.error)) actual.focus(); return; }
    DATA.usuarios = r.usuarios;
    cerrar();
    renderUsers();
  };
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#cp-ok", back).addEventListener("click", guardar);
  back.addEventListener("keydown", (e) => { if (e.key === "Escape") cerrar(); if (e.key === "Enter") { e.preventDefault(); guardar(); } });
  setTimeout(() => actual.focus(), 30);
}

async function eliminarUsuarioFlujo(u) {
  if (!confirm(`¿Eliminar al usuario "${u.nombre}"? Esta acción no se puede deshacer.`)) return;
  if (!tienenDB()) { DATA.usuarios = DATA.usuarios.filter((x) => x.id !== u.id); return renderUsers(); }
  const r = await window.api.db.eliminarUsuario(u.id);
  if (r.error) return alert(r.error);
  DATA.usuarios = r.usuarios;
  renderUsers();
}

// Crear usuario nuevo: solo nombre + contraseña (PIN de 4 dígitos).
function crearUsuarioFlujo() {
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>Crear usuario</h3>
      <div class="qty-field"><label>Nombre</label>
        <input type="text" id="nu-nombre" placeholder="Ej. Juan" /></div>
      <div class="qty-field"><label>Contraseña (4 dígitos)</label>
        <input type="password" id="nu-pin" inputmode="numeric" maxlength="4" placeholder="••••" /></div>
      <div class="qty-field"><label>Rol</label>
        <select id="nu-rol"><option value="Cajero">Cajero</option><option value="Administrador">Administrador</option></select></div>
      <p class="qty-hint" id="nu-msg">La contraseña se teclea con el teclado numérico al entrar.</p>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="nu-ok">Crear</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const nombre = $("#nu-nombre", back);
  const pin = $("#nu-pin", back);
  const msg = $("#nu-msg", back);
  pin.addEventListener("input", () => { pin.value = pin.value.replace(/\D/g, "").slice(0, 4); });
  const cerrar = () => back.remove();
  const crear = async () => {
    const nom = nombre.value.trim();
    const p = pin.value.trim();
    if (!nom) { msg.innerHTML = '<span class="tk-warn">Escribe un nombre.</span>'; nombre.focus(); return; }
    if (!/^\d{4}$/.test(p)) { msg.innerHTML = '<span class="tk-warn">La contraseña debe ser de 4 dígitos.</span>'; pin.focus(); return; }
    if (!tienenDB()) { DATA.usuarios.push({ id: Date.now(), nombre: nom, pin: p, rol: $("#nu-rol", back).value }); cerrar(); return renderUsers(); }
    const r = await window.api.db.crearUsuario(nom, p, $("#nu-rol", back).value);
    if (r.error) { msg.innerHTML = `<span class="tk-warn">${escapeHtml(r.error)}</span>`; return; }
    DATA.usuarios = r.usuarios;
    cerrar();
    renderUsers();
  };
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#nu-ok", back).addEventListener("click", crear);
  back.addEventListener("keydown", (e) => {
    if (e.key === "Escape") cerrar();
    if (e.key === "Enter") { e.preventDefault(); crear(); }
  });
  setTimeout(() => nombre.focus(), 30);
}

async function editarNombreUsuario(u) {
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>Cambiar nombre de usuario</h3>
      <p class="sub">${escapeHtml(u.nombre)} · ${escapeHtml(u.rol)}</p>
      <div class="qty-field"><label>Nuevo nombre</label>
        <input type="text" id="en-nombre" value="${attr(u.nombre)}" placeholder="Nombre del usuario" /></div>
      <div class="qty-field"><label>Contraseña de este usuario (para confirmar)</label>
        <input type="password" id="en-pin" inputmode="numeric" maxlength="4" placeholder="••••" /></div>
      <p class="qty-hint" id="en-msg"></p>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="en-ok">Guardar</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const nombreI = $("#en-nombre", back), pinI = $("#en-pin", back), msg = $("#en-msg", back);
  pinI.addEventListener("input", () => { pinI.value = pinI.value.replace(/\D/g, "").slice(0, 4); });
  const cerrar = () => back.remove();
  const guardar = async () => {
    const nombre = nombreI.value.trim();
    if (!nombre) { msg.innerHTML = '<span class="tk-warn">Escribe un nombre.</span>'; nombreI.focus(); return; }
    if (!/^\d{4}$/.test(pinI.value)) { msg.innerHTML = '<span class="tk-warn">Escribe la contraseña para confirmar.</span>'; pinI.focus(); return; }
    if (!tienenDB()) {
      if (pinI.value !== u.pin) { msg.innerHTML = '<span class="tk-warn">La contraseña no es correcta.</span>'; pinI.focus(); return; }
      u.nombre = nombre; cerrar(); return renderUsers();
    }
    const r = await window.api.db.renombrarUsuario(u.id, nombre, pinI.value);
    if (r.error) { msg.innerHTML = `<span class="tk-warn">${escapeHtml(r.error)}</span>`; if (/contraseña/.test(r.error)) pinI.focus(); return; }
    DATA.usuarios = r.usuarios;
    cerrar();
    renderUsers();
  };
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#en-ok", back).addEventListener("click", guardar);
  back.addEventListener("keydown", (e) => { if (e.key === "Escape") cerrar(); if (e.key === "Enter") { e.preventDefault(); guardar(); } });
  setTimeout(() => nombreI.focus(), 30);
}

let pinUser = null;
let pinBuffer = "";
function openPinpad(user) {
  pinUser = user; pinBuffer = "";
  $("#user-grid").classList.add("hidden");
  const acc = $("#login-actions"); if (acc) acc.classList.add("hidden");
  $("#pin-user").textContent = user.nombre;
  $("#pinpad").classList.remove("hidden");
  $("#pin-error").classList.add("hidden");
  renderPinDots();
}
function renderPinDots() {
  const dots = $("#pin-dots");
  dots.innerHTML = "";
  for (let i = 0; i < 4; i++) {
    const d = document.createElement("i");
    if (i < pinBuffer.length) d.classList.add("on");
    dots.appendChild(d);
  }
}
function pinKey(k) {
  if (k === "cancel") { $("#pinpad").classList.add("hidden"); $("#user-grid").classList.remove("hidden"); const a = $("#login-actions"); if (a) a.classList.remove("hidden"); return; }
  if (k === "back") { pinBuffer = pinBuffer.slice(0, -1); renderPinDots(); return; }
  if (pinBuffer.length >= 4) return;
  pinBuffer += k;
  renderPinDots();
  if (pinBuffer.length === 4) setTimeout(tryLogin, 120);
}
function tryLogin() {
  if (pinBuffer === pinUser.pin) { usuarioActual = pinUser; enterApp(); }
  else { $("#pin-error").classList.remove("hidden"); pinBuffer = ""; renderPinDots(); }
}

async function enterApp() {
  $("#view-login").classList.add("hidden");
  // Oculta el teclado numérico del login para que su captura de teclas no
  // interfiera con la escritura dentro del sistema.
  $("#pinpad").classList.add("hidden");
  pinBuffer = "";
  $("#view-app").classList.remove("hidden");
  $("#chip-user-name").textContent = usuarioActual.nombre;
  $("#chip-user-role").textContent = usuarioActual.rol;
  if (!tickets.length) nuevoTicket();
  else activarTicket(ticketActivoId || tickets[0].id);
  renderCats();
  renderProducts();
  renderCart();
  actualizarUltimaVenta();
  // El buscador de productos queda activo para escribir de inmediato.
  setTimeout(() => { const s = $("#entry-search"); if (s) s.focus(); }, 60);
  await refreshCajaStatus();
  // Procesa ventas de báscula que hayan llegado antes de iniciar sesión.
  if (basculaPendientes.length) {
    const p = basculaPendientes; basculaPendientes = [];
    procesarLoteBascula(p);
  }
  // Primera instalación: se elige entre datos de ejemplo o importar una base.
  if (CFG && CFG.configurado === false) {
    pedirSetupInicial(() => { if (!cajaAbierta) pedirAperturaCaja(); });
  } else if (!cajaAbierta) {
    // Al iniciar el turno, si la caja está cerrada se pide el fondo inicial.
    pedirAperturaCaja();
  } else if (cajaVacia) {
    // Caja abierta pero SIN actividad (recién abierta): permite capturar/corregir
    // el fondo inicial (antes decía "caja abierta" y no dejaba ingresarlo).
    pedirAperturaCaja();
  }
}

// Recarga datos y catálogos tras una importación.
async function recargarDatos() {
  await loadData();
  renderCats();
  renderProducts();
  renderCart();
  await refreshCajaStatus();
}
function logout() {
  usuarioActual = null;
  invDesbloqueado = false;   // vuelve a proteger el inventario al cerrar sesión
  tickets = []; ticketActivoId = null; ticketSeq = 0; cart = [];
  $("#view-app").classList.add("hidden");
  $("#view-login").classList.remove("hidden");
  $("#pinpad").classList.add("hidden");
  $("#user-grid").classList.remove("hidden");
  const acc = $("#login-actions"); if (acc) acc.classList.remove("hidden");
}

/* ---------------- Categorías ---------------- */
function tabs() {
  return [{ id: "paquetes", nombre: "Paquetes", emoji: "🎁" }, ...DATA.categorias];
}
function catEmoji(catId) {
  const c = DATA.categorias.find((x) => x.id === catId);
  return c ? c.emoji : "🥩";
}
// Las pestañas de categorías se eliminaron del menú de ventas: ahora solo se
// muestran paquetes + complementos en una sola vista. Se conserva la función
// (vacía y segura) para no romper las llamadas existentes.
function renderCats() {
  const cont = $("#cat-tabs");
  if (cont) cont.innerHTML = "";
}

/* ---------------- Grid de productos / paquetes ----------------
   Menú de ventas simplificado: sin pestañas. Muestra en una sola vista los
   paquetes (1 al 6) + los complementos individuales (productos que controlan
   inventario / granel). Las carnes son "siempre disponibles" y entran por la
   báscula, por lo que ya no se listan aquí. */
// Productos que se muestran en el PANEL de ventas (con ícono). Se controla con
// la bandera `enPanel`; si no está definida (productos antiguos), se usa el
// comportamiento anterior (los que controlan inventario) para no cambiar nada.
function productoConInventario(p) { return !!(p && p.controlaInventario); }
function mostrarEnPanel(p) {
  if (!productoConInventario(p)) return false;
  return p.enPanel !== false;
}
function complementosVenta() {
  return (DATA.productos || []).filter(mostrarEnPanel);
}

function renderProducts(filtro) {
  const grid = $("#products-grid");
  grid.innerHTML = "";
  const q = (filtro || "").trim().toLowerCase();
  const complementos = complementosVenta();

  if (q) {
    const lista = complementos.filter((p) => p.nombre.toLowerCase().includes(q));
    $("#item-count").textContent = lista.length + " resultados";
    if (!lista.length) {
      grid.innerHTML = '<p style="color:#94a3b8;font-size:13px;padding:20px">Sin resultados. Usa “＋ Producto manual” para algo fuera del catálogo.</p>';
      return;
    }
    lista.forEach((p) => grid.appendChild(cardProducto(p)));
    programarAjusteGrid();
    return;
  }

  // Abarrotes se quedan en la cuadrícula. Los paquetes viven en el botón desplegable.
  complementos.forEach((p) => grid.appendChild(cardProducto(p)));
  $("#item-count").textContent = `${complementos.length} productos`;
  programarAjusteGrid();
}

// Orden fijo de los paquetes en la pantalla de ventas: #1..#6, Arrachera,
// Discada (1 y 2) y Barbacoa; cualquier otro paquete nuevo va al final.
const ORDEN_PAQUETES = [
  "pq-1", "pq-2", "pq-3", "pq-4", "pq-5", "pq-6",
  "pq-arrachera", "pq-discada1", "pq-discada2", "pq-barbacoa"
];
function paquetesOrdenados() {
  const idx = (id) => { const i = ORDEN_PAQUETES.indexOf(id); return i === -1 ? 999 : i; };
  return (DATA.paquetes || []).slice().sort((a, b) => idx(a.id) - idx(b.id));
}

// Ajuste automático de la cuadrícula de ventas: calcula cuántas columnas y
// filas caben en el espacio disponible para que TODAS las tarjetas se vean
// en una sola pantalla, sin barra de desplazamiento, en cualquier resolución.
let _gridFitRaf = 0;
function programarAjusteGrid() {
  if (_gridFitRaf) cancelAnimationFrame(_gridFitRaf);
  _gridFitRaf = requestAnimationFrame(() => { _gridFitRaf = 0; ajustarGridProductos(); });
}
// Tamaño de referencia de una tarjeta: ancho estándar y proporción alto/ancho
// fija. Al mantener SIEMPRE la misma proporción, las tarjetas nunca se ven
// deformes (ni muy anchas al buscar, ni estiradas). Solo cambian de escala.
const CARD_STD_W = 168;   // ancho ideal (px)
const CARD_AR = 0.94;     // alto = ancho * CARD_AR
const CARD_MIN_W = 62;    // no encoger por debajo de esto (legibilidad)

function ajustarGridProductos() {
  const scroll = document.querySelector("#view-venta .products-scroll");
  const grid = document.getElementById("products-grid");
  if (!scroll || !grid) return;
  const cards = grid.querySelectorAll(".pcard");
  const n = cards.length;
  if (!n) {
    grid.style.gridTemplateColumns = ""; grid.style.gridAutoRows = "";
    grid.style.alignContent = ""; grid.style.justifyContent = "";
    return;
  }
  const W = scroll.clientWidth;
  const H = scroll.clientHeight;
  if (W < 40 || H < 40) return; // vista oculta o sin medir aún
  const gap = 10;

  // Busca el mayor ancho de tarjeta (hasta el estándar) con el que TODAS las
  // tarjetas caben en el alto visible => nunca hay barra de desplazamiento.
  // Como la proporción es fija, encoger el ancho encoge también el alto y todo
  // el conjunto se reacomoda de forma uniforme al agregar más productos.
  let w = CARD_MIN_W, cols = 1;
  for (let cand = CARD_STD_W; cand >= CARD_MIN_W; cand -= 2) {
    const c = Math.max(1, Math.floor((W + gap) / (cand + gap)));
    const rows = Math.ceil(n / c);
    const totalH = rows * (cand * CARD_AR) + (rows - 1) * gap;
    if (totalH <= H) { w = cand; cols = c; break; }
    if (cand - 2 < CARD_MIN_W) { // ni con el mínimo cabe: usa el mínimo igualmente
      w = CARD_MIN_W;
      cols = Math.max(1, Math.floor((W + gap) / (CARD_MIN_W + gap)));
    }
  }

  cols = Math.min(cols, n);
  const h = Math.round(w * CARD_AR);
  // Columnas de ancho FIJO (no 1fr): así, con pocos resultados, las tarjetas
  // conservan su tamaño estándar en vez de estirarse a lo ancho.
  grid.style.gridTemplateColumns = `repeat(${cols}, ${w}px)`;
  grid.style.gridAutoRows = h + "px";
  grid.style.justifyContent = "center";
  grid.style.alignContent = "start";

  // Centra la última fila si queda incompleta.
  cards.forEach((el) => { el.style.gridColumnStart = ""; });
  const rem = n % cols;
  if (rem > 0 && cols > rem) {
    const offset = Math.floor((cols - rem) / 2);
    const first = cards[n - rem];
    if (offset > 0 && first) first.style.gridColumnStart = String(1 + offset);
  }
}

function cardProducto(p) {
  const card = document.createElement("button");
  const esPedido = p.precioCents == null;
  card.className = "pcard" + (esPedido ? " pcard--pedido" : "");
  const precioHtml = esPedido
    ? `<div class="pcard__price">Precio manual</div>`
    : `<div class="pcard__price">${fmt(p.precioCents)} <small>/ ${p.unidad}</small></div>`;
  const img = IMGS[p.id];
  const mediaHtml = img
    ? `<div class="pcard__media"><img class="pcard__img" src="${attr(img)}" alt="" /></div>`
    : `<div class="pcard__media"><span class="pcard__emoji">${catEmoji(p.cat)}</span></div>`;
  const existHtml = productoConInventario(p)
    ? `<div class="pcard__exist ${(p.existencia || 0) <= (p.stockMin || 0) ? "low" : ""}">${fmtCant(p.existencia, p.unidad)} ${p.unidad}</div>`
    : "";
  card.innerHTML =
    `<div class="pcard__badge">${(esPedido ? "PZA" : p.unidad).toUpperCase()}</div>` +
    mediaHtml +
    `<div class="pcard__name">${p.nombre}</div>` +
    precioHtml + existHtml;
  card.addEventListener("click", () => addProducto(p));
  return card;
}

function cardPaquete(pq) {
  const card = document.createElement("button");
  card.className = "pcard pcard--paquete";
  const aviso = pq.porConfirmar ? '<div class="pcard__warn">⚠ armar</div>' : "";
  card.innerHTML =
    `<div class="pcard__badge">PAQUETE</div>` +
    `<div class="pcard__media"><span class="pcard__emoji">🎁</span></div>` +
    `<div class="pcard__name">${pq.nombre}</div>` +
    `<div class="pcard__price">${fmt(pq.precioCents)}</div>` + aviso;
  card.addEventListener("click", () => addPaquete(pq));
  return card;
}

/* ---------------- Carrito ---------------- */
// Precio individual de un componente del paquete: usa el precio guardado en el
// componente y, si no lo tiene, lo busca en el catálogo por nombre.
function precioComponente(c) {
  if (c && c.precioCents != null) return c.precioCents;
  const n = (c && c.nombre ? c.nombre : "").trim().toLowerCase();
  if (!n) return null;
  let p = (DATA.productos || []).find((x) => x.precioCents != null && x.nombre.trim().toLowerCase() === n);
  if (!p) p = (DATA.productos || []).find((x) => x.precioCents != null &&
    (n.includes(x.nombre.trim().toLowerCase()) || x.nombre.trim().toLowerCase().includes(n)));
  return p ? p.precioCents : null;
}

function recalc(item) {
  if (item.tipo === "paquete") {
    const base = Money.multiplicar(item.basePrecioCents, item.cant);
    const extras = Money.sumar((item.extras || []).map((e) => e.importeCents));
    // Al quitar un componente incluido se descuenta su precio individual.
    const quitadoUnit = Money.sumar((item.componentes || [])
      .filter((c) => !c.incluido && precioComponente(c) != null)
      .map((c) => Money.multiplicar(precioComponente(c), c.cant)));
    const quitado = Money.multiplicar(quitadoUnit, item.cant);
    item.importeCents = Math.max(0, base + extras - quitado);
  } else {
    item.importeCents = Money.multiplicar(item.precioCents, item.cant);
  }
  return item.importeCents;
}

function addProducto(prod, cantInicial) {
  const unidad = prod.unidad === "s/pedido" ? "pza" : prod.unidad;
  pedirCantidad({
    nombre: prod.nombre,
    unidad,
    precioCents: prod.precioCents,      // puede ser null (precio manual)
    ref: prod.id,
    cantInicial: cantInicial != null ? cantInicial : 1,
    permitirPrecio: prod.precioCents == null
  });
}

// Producto manual / ajeno al negocio (nombre y precio a mano)
// "Producto común" (manual) — ventana compacta al estilo ELEVENTA. Siempre se
// agrega como PIEZA (no se muestra el selector de unidad). Se abre con Ctrl+P
// (o F3). El texto queda activo y seleccionado; con Enter se avanza campo por
// campo: Descripción → Cantidad → Precio → Aceptar, y el último Enter (sobre
// Aceptar) agrega el producto y cierra la ventana.
function addProductoManual() {
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--pcomun">
      <div class="pcomun__bar"><span>Producto Común</span><button class="pcomun__x" data-cerrar="1" title="Cerrar">✕</button></div>
      <div class="pcomun__title">PRODUCTO COMÚN</div>
      <div class="pcomun__grid">
        <div class="pcomun__main">
          <label class="pcomun__lbl">Descripción del Producto:</label>
          <input type="text" id="pc-nombre" class="pcomun__desc" autocomplete="off" value="Producto común" />
          <div class="pcomun__row">
            <div class="pcomun__cell">
              <label class="pcomun__lbl">Cantidad:</label>
              <input type="number" id="pc-cant" min="0" step="1" value="1" />
            </div>
            <div class="pcomun__mult">x</div>
            <div class="pcomun__cell">
              <label class="pcomun__lbl">Precio:</label>
              <input type="number" id="pc-precio" min="0" step="0.01" value="0.00" />
            </div>
          </div>
        </div>
        <div class="pcomun__actions">
          <button class="btn btn--primary" id="pc-ok">✔ Aceptar</button>
          <button class="btn" data-cerrar="1">Cancelar</button>
        </div>
      </div>
    </div>`;
  document.body.appendChild(back);

  const inpNombre = $("#pc-nombre", back);
  const inpCant = $("#pc-cant", back);
  const inpPrecio = $("#pc-precio", back);
  const btnOk = $("#pc-ok", back);

  const cerrar = () => back.remove();
  const confirmar = () => {
    const nombre = (inpNombre.value || "").trim() || "Producto común";
    const cant = parseFloat(String(inpCant.value).replace(",", ".")) || 0;
    if (cant <= 0) { inpCant.focus(); inpCant.select(); return; }
    const precioCents = Money.toCents(parseFloat(String(inpPrecio.value).replace(",", ".")) || 0) || 0;
    if (precioCents <= 0) { inpPrecio.focus(); inpPrecio.select(); return; }
    const item = { tipo: "producto", ref: null, nombre, unidad: "pza", precioCents, cant, importeCents: 0, manual: true };
    recalc(item);
    cart.push(item);
    renderCart();
    cerrar();
  };

  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  btnOk.addEventListener("click", confirmar);

  // Enter avanza campo por campo y, al llegar a Aceptar, confirma y cierra.
  back.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { e.preventDefault(); cerrar(); return; }
    if (e.key !== "Enter") return;
    e.preventDefault();
    const a = document.activeElement;
    if (a === inpNombre) { inpCant.focus(); inpCant.select(); }
    else if (a === inpCant) { inpPrecio.focus(); inpPrecio.select(); }
    else if (a === inpPrecio) { btnOk.focus(); }
    else { confirmar(); }   // foco en Aceptar (o botón): agrega y cierra
  });

  // El texto de la descripción queda activo y seleccionado de inmediato.
  setTimeout(() => { inpNombre.focus(); inpNombre.select(); }, 30);
}

// Ventana rápida: cantidad (y precio/nombre si aplica). Pensada para teclado.
function pedirCantidad(opts) {
  const o = Object.assign({ cantInicial: 1, permitirPrecio: false, permitirNombre: false, permitirUnidad: false }, opts);
  const back = document.createElement("div");
  back.className = "modal-back";
  const step = o.unidad === "kg" ? "0.001" : "1";
  const precioIni = o.precioCents != null ? (o.precioCents / 100).toFixed(2) : "";

  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>${o.titulo ? o.titulo : escapeHtml(o.nombre)}</h3>
      ${o.permitirNombre ? `
        <div class="qty-field"><label>Descripción</label>
          <input type="text" id="q-nombre" placeholder="Ej. Refresco 600ml" value="${attr(o.nombre)}" /></div>` : ""}
      ${o.permitirUnidad ? `
        <div class="qty-field"><label>Unidad</label>
          <select id="q-unidad"><option value="pza">pieza</option><option value="kg">kilogramo</option></select></div>` : ""}
      ${(o.permitirPrecio) ? `
        <div class="qty-field"><label>Precio ${o.unidad ? "por " + escapeHtml(o.unidad) : ""}</label>
          <input type="number" id="q-precio" min="0" step="0.01" value="${precioIni}" placeholder="0.00" /></div>`
        : `<div class="qty-price">${fmt(o.precioCents)} <small>/ ${escapeHtml(o.unidad)}</small></div>`}
      <div class="qty-field">
        <label>Cantidad ${o.permitirUnidad ? "" : "(" + escapeHtml(o.unidad) + ")"}</label>
        <input type="number" id="q-cant" min="0" step="${step}" value="${o.cantInicial}" />
      </div>
      <div class="qty-quick" id="q-quick"></div>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="q-ok">Agregar</button>
      </div>
      <p class="qty-hint">Enter para agregar · Esc para cancelar</p>
    </div>`;
  document.body.appendChild(back);

  const inpNombre = $("#q-nombre", back);
  const selUnidad = $("#q-unidad", back);
  const inpPrecio = $("#q-precio", back);
  const inpCant = $("#q-cant", back);

  // Botones rápidos de cantidad según unidad
  const quick = $("#q-quick", back);
  const setUnidadUI = () => {
    const u = selUnidad ? selUnidad.value : o.unidad;
    inpCant.step = u === "kg" ? "0.001" : "1";
    const vals = u === "kg" ? [0.25, 0.5, 1, 1.5, 2, 3] : [1, 2, 3, 5, 10];
    quick.innerHTML = vals.map((v) => `<button type="button" data-q="${v}">${v}</button>`).join("");
    $$("[data-q]", quick).forEach((b) => b.addEventListener("click", () => { inpCant.value = b.dataset.q; inpCant.focus(); }));
  };
  setUnidadUI();
  if (selUnidad) selUnidad.addEventListener("change", setUnidadUI);

  const cerrar = () => back.remove();
  const confirmar = () => {
    const nombre = inpNombre ? inpNombre.value.trim() : o.nombre;
    if (o.permitirNombre && !nombre) { inpNombre.focus(); return; }
    const unidad = selUnidad ? selUnidad.value : o.unidad;
    let precioCents = o.precioCents;
    if (inpPrecio) {
      precioCents = Money.toCents(parseFloat(String(inpPrecio.value).replace(",", ".")) || 0) || 0;
      if (precioCents <= 0) { inpPrecio.focus(); return; }
    }
    let cant = parseFloat(String(inpCant.value).replace(",", ".")) || 0;
    if (cant <= 0) { inpCant.focus(); return; }
    const item = { tipo: "producto", ref: o.ref, nombre, unidad, precioCents, cant, importeCents: 0, manual: o.ref == null };
    recalc(item);
    cart.push(item);
    renderCart();
    cerrar();
  };

  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#q-ok", back).addEventListener("click", confirmar);
  back.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { e.preventDefault(); cerrar(); }
    if (e.key === "Enter") {
      e.preventDefault();
      if (inpNombre && document.activeElement === inpNombre) { (inpPrecio || inpCant).focus(); return; }
      if (inpPrecio && document.activeElement === inpPrecio) { inpCant.focus(); inpCant.select(); return; }
      confirmar();
    }
  });

  // Foco inicial: nombre → precio → cantidad
  const primero = inpNombre || inpPrecio || inpCant;
  setTimeout(() => { primero.focus(); if (primero.select) primero.select(); }, 30);
}

// Pide la cantidad de un producto que se agrega a un paquete, adaptando el
// campo al tipo de producto: por kilo/granel (decimales) o por pieza.
function pedirCantidadComp(prod, cb) {
  const back = document.createElement("div");
  back.className = "modal-back";
  const esKg = prod.unidad === "kg";
  const step = esKg ? "0.001" : "1";
  const vals = esKg ? [0.25, 0.5, 1, 1.5, 2, 3] : [1, 2, 3, 5, 10];
  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>${escapeHtml(prod.nombre)}</h3>
      <div class="qty-price">${fmt(prod.precioCents)} <small>/ ${escapeHtml(prod.unidad)}</small></div>
      <div class="qty-field">
        <label>Cantidad ${esKg ? "(kg)" : "(" + escapeHtml(prod.unidad) + ")"}</label>
        <input type="number" id="qc-cant" min="0" step="${step}" value="1" />
      </div>
      <div class="qty-quick" id="qc-quick">${vals.map((v) => `<button type="button" data-q="${v}">${v}</button>`).join("")}</div>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="qc-ok">Agregar</button>
      </div>
      <p class="qty-hint">Enter para agregar · Esc para cancelar</p>
    </div>`;
  document.body.appendChild(back);
  const inp = $("#qc-cant", back);
  $$("[data-q]", back).forEach((b) => b.addEventListener("click", () => { inp.value = b.dataset.q; inp.focus(); }));
  const cerrar = () => back.remove();
  const ok = () => {
    let c = parseFloat(String(inp.value).replace(",", ".")) || 0;
    if (c <= 0) { inp.focus(); return; }
    cerrar(); cb(c);
  };
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#qc-ok", back).addEventListener("click", ok);
  back.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); cerrar(); } if (e.key === "Enter") { e.preventDefault(); ok(); } });
  setTimeout(() => { inp.focus(); inp.select(); }, 30);
}

function addPaquete(pq) {
  const item = {
    tipo: "paquete", ref: pq.id, nombre: pq.nombre, unidad: "paq",
    basePrecioCents: pq.precioCents, cant: 1,
    componentes: (pq.componentes || []).map((c) => ({ ...c, incluido: true, precioCents: c.precioCents != null ? c.precioCents : precioComponente(c) })),
    extras: [], importeCents: 0
  };
  recalc(item);
  cart.push(item);
  renderCart();
}

function removeItem(idx) { cart.splice(idx, 1); renderCart(); }
function setCant(idx, valor) {
  const item = cart[idx];
  let c = parseFloat(String(valor).replace(",", "."));
  if (!isFinite(c) || c <= 0) c = item.unidad === "kg" ? 0.001 : 1;
  item.cant = c;
  recalc(item);
  renderTotales();
}

/* ---------------- Tickets simultáneos (pestañas) ---------------- */
function ticketActual() { return tickets.find((t) => t.id === ticketActivoId) || null; }

function nuevoTicket(activar = true) {
  ticketSeq += 1;
  const t = { id: ticketSeq, nombre: `Ticket ${ticketSeq}`, cart: [], cliente: CLIENTE_DEFAULT, descuentoCents: 0 };
  tickets.push(t);
  if (activar) activarTicket(t.id);
  else renderTicketTabs();
  return t;
}

function activarTicket(id) {
  const t = tickets.find((x) => x.id === id);
  if (!t) return;
  ticketActivoId = id;
  cart = t.cart;               // el resto del código sigue usando `cart`
  clienteActual = t.cliente;
  const cn = $("#cliente-actual");
  if (cn) cn.textContent = t.cliente;
  renderTicketTabs();
  renderCart();
}

function cerrarTicket(id) {
  const idx = tickets.findIndex((x) => x.id === id);
  if (idx === -1) return;
  const t = tickets[idx];
  if (t.cart.length && !confirm(`"${t.nombre}" tiene productos. ¿Cerrar de todos modos?`)) return;
  tickets.splice(idx, 1);
  if (!tickets.length) { nuevoTicket(); return; }
  if (ticketActivoId === id) activarTicket(tickets[Math.max(0, idx - 1)].id);
  else renderTicketTabs();
}

/* ---------------- Integración báscula (Scale Link) ---------------- */
// Recibe un lote de ventas nuevas desde el proceso principal. Si aún no hay
// sesión iniciada, las guarda para procesarlas al entrar.
function recibirVentasBascula(lote) {
  if (!Array.isArray(lote) || !lote.length) return;
  if (!usuarioActual) { basculaPendientes.push(...lote); return; }
  procesarLoteBascula(lote);
}

function procesarLoteBascula(lote) {
  const cfg = (CFG && CFG.bascula) || {};

  // Siempre guardamos las ventas en el pool por folio, para poder abrirlas al
  // escanear el código de barras (aunque el modo automático esté activo).
  for (const venta of lote) registrarVentaBasculaEnPool(venta);

  // Si hay escaneos hechos antes de que llegara la venta, ábrelos ahora.
  let abiertoPorEscaneo = false;
  for (const venta of lote) {
    const k = folioKey(venta.idBascula, venta.folio);
    if (escaneosPendientesBascula.has(k)) {
      escaneosPendientesBascula.delete(k);
      const t = abrirTicketDesdeVentaBascula(venta);
      if (t) abiertoPorEscaneo = true;
    }
  }
  if (abiertoPorEscaneo) { if (cfg.avisoSonoro) beepBascula(); return; }

  // Modo escaneo: NO crear tickets automáticamente; el cajero abre el ticket
  // escaneando la etiqueta de la báscula.
  if (cfg.modoEscaneo) {
    basculaToast(`⚖️ ${lote.length} venta(s) de báscula lista(s). Escanea la etiqueta para abrir el ticket.`);
    if (cfg.avisoSonoro) beepBascula();
    return;
  }

  if (cfg.autoTicket === false) {
    // Modo manual: solo avisar (no crear tickets automáticamente).
    basculaToast(`⚖️ ${lote.length} venta(s) de báscula disponibles.`);
    return;
  }
  let creados = 0;
  for (const venta of lote) {
    const t = crearTicketBascula(venta);
    if (t) { creados++; }
  }
  if (!creados) return;
  // Cada venta abre su propia pestaña (Ticket 2 en adelante). NO cambiamos de
  // pestaña: la inicial (Ticket 1) queda activa/lista para venta manual y el
  // cajero da clic en la pestaña de báscula cuando la va a cobrar.
  renderTicketTabs();
  basculaToast(`⚖️ ${creados === 1 ? "Venta de báscula recibida" : creados + " ventas de báscula recibidas"}. Da clic en la pestaña para cobrar.`);
  if (cfg.avisoSonoro) beepBascula();
}

// Clave única de una venta de báscula por (báscula + folio). Se normaliza el
// folio a dígitos para que coincida con lo decodificado del código de barras.
function folioKey(idBascula, folio) {
  const b = String(idBascula == null ? "" : idBascula).trim();
  const f = String(folio == null ? "" : folio).replace(/\D/g, "").replace(/^0+/, "") || "0";
  return b + "#" + f;
}

function registrarVentaBasculaEnPool(venta) {
  if (!venta) return;
  const k = folioKey(venta.idBascula, venta.folio);
  ventasBasculaPorFolio.set(k, venta);
  // También indexamos solo por folio (sin báscula) como respaldo, por si el
  // código de barras no lleva el id de báscula/departamento.
  const soloFolio = "#" + (String(venta.folio == null ? "" : venta.folio).replace(/\D/g, "").replace(/^0+/, "") || "0");
  if (!ventasBasculaPorFolio.has(soloFolio)) ventasBasculaPorFolio.set(soloFolio, venta);
  // Evita que el pool crezca sin control.
  if (ventasBasculaPorFolio.size > 4000) {
    const it = ventasBasculaPorFolio.keys();
    for (let i = 0; i < 1000; i++) { const n = it.next(); if (n.done) break; ventasBasculaPorFolio.delete(n.value); }
  }
}

// Abre (o reactiva) el ticket completo de una venta de báscula ya descargada.
// Si ya existe un ticket abierto para esa venta, lo activa en vez de duplicar.
function abrirTicketDesdeVentaBascula(venta) {
  if (!venta) return null;
  const existente = tickets.find((t) => t.origenBascula && t.origenBascula.key === venta.key);
  if (existente) {
    activarTicket(existente.id);
    basculaToast(`⚖️ Ticket de báscula (Folio ${venta.folio}) abierto.`);
    return existente;
  }
  const t = crearTicketBascula(venta);
  if (!t) return null;
  renderTicketTabs();
  activarTicket(t.id);
  const n = (venta.lineas || []).filter((l) => !l.devolucion).length;
  basculaToast(`⚖️ Ticket de báscula (Folio ${venta.folio}) con ${n} producto(s). Revisa y cobra.`);
  return t;
}

// Decodifica el código de barras de la etiqueta de la báscula y devuelve el
// folio (y el id de báscula/depto si el formato lo incluye). Devuelve null si
// no corresponde al formato configurado.
function decodificarCodigoBascula(code) {
  const cfg = (CFG && CFG.bascula && CFG.bascula.codigoBarras) || {};
  let s = String(code || "").trim().replace(/\D/g, "");
  const esperado = cfg.simbologia === "UPC12" ? 12 : 13;
  if (s.length !== esperado) return null;
  // El último dígito es el verificador; trabajamos sobre el resto.
  const cuerpo = s.slice(0, esperado - 1);
  // Validación de prefijo (si se configuró).
  const prefijos = String(cfg.prefijos || "").split(",").map((x) => x.trim()).filter(Boolean);
  if (prefijos.length) {
    const ok = prefijos.some((p) => cuerpo.startsWith(p));
    if (!ok) return null;
  }
  const fIni = Math.max(0, parseInt(cfg.folioInicio, 10) || 0);
  const fLen = Math.max(1, parseInt(cfg.folioLargo, 10) || 6);
  const folioRaw = cuerpo.substr(fIni, fLen);
  if (!folioRaw) return null;
  const folio = String(parseInt(folioRaw, 10));
  let idBascula = "";
  const bLen = parseInt(cfg.basculaLargo, 10) || 0;
  if (bLen > 0) {
    const bIni = Math.max(0, parseInt(cfg.basculaInicio, 10) || 0);
    idBascula = String(parseInt(cuerpo.substr(bIni, bLen), 10) || "");
  }
  // Datos embebidos opcionales (modo respaldo offline): importe, peso y código
  // de producto/PLU. Permiten armar la venta con solo el código si la báscula
  // no logró enviar la venta por red.
  let importeCents = 0, pesoGramos = 0, codigo = "";
  const impLen = parseInt(cfg.importeLargo, 10) || 0;
  if (impLen > 0) {
    const impIni = Math.max(0, parseInt(cfg.importeInicio, 10) || 0);
    importeCents = parseInt(cuerpo.substr(impIni, impLen), 10) || 0; // ya en centavos (2 decimales)
  }
  const pesoLen = parseInt(cfg.pesoLargo, 10) || 0;
  if (pesoLen > 0) {
    const pesoIni = Math.max(0, parseInt(cfg.pesoInicio, 10) || 0);
    pesoGramos = parseInt(cuerpo.substr(pesoIni, pesoLen), 10) || 0; // kg con 3 decimales -> gramos
  }
  const codLen = parseInt(cfg.codLargo, 10) || 0;
  if (codLen > 0) {
    const codIni = Math.max(0, parseInt(cfg.codInicio, 10) || 0);
    codigo = String(parseInt(cuerpo.substr(codIni, codLen), 10) || "");
  }
  return { folio, idBascula, importeCents, pesoGramos, codigo };
}

// Intenta abrir el ticket de báscula a partir de un código escaneado.
function abrirVentaBasculaPorCodigo(code) {
  const dec = decodificarCodigoBascula(code);
  if (!dec) return false;
  // ETIQUETA CON IMPORTE EMBEBIDO (el caso de esta tienda): el importe del código
  // ES la fuente exacta de la venta escaneada. Se arma la línea directo del código
  // y NO se cruza contra el pool por "folio": en este formato ese campo es el
  // número de ARTÍCULO, no el folio de venta, y cruzarlo abría un ticket que no
  // corresponde (síntoma: "escanea datos falsos que no concuerdan"). El nombre y
  // el peso reales se toman del pool por importe dentro de agregarLineaBasculaOffline.
  if (dec.importeCents > 0) { agregarLineaBasculaOffline(dec); return true; }
  // ETIQUETA SIN IMPORTE (folio de venta real): se resuelve contra el pool por folio.
  let venta = null;
  if (dec.idBascula) venta = ventasBasculaPorFolio.get(folioKey(dec.idBascula, dec.folio));
  if (!venta) venta = ventasBasculaPorFolio.get(folioKey("", dec.folio));
  if (!venta) venta = ventasBasculaPorFolio.get("#" + (dec.folio.replace(/^0+/, "") || "0"));
  if (venta) { abrirTicketDesdeVentaBascula(venta); return true; }
  // La venta aún no llega. La dejamos pendiente para abrirla en cuanto llegue.
  escaneosPendientesBascula.set(folioKey(dec.idBascula, dec.folio), Date.now());
  escaneosPendientesBascula.set(folioKey("", dec.folio), Date.now());
  basculaToast(`⚖️ Folio ${dec.folio} escaneado. Esperando que la báscula lo envíe…`);
  return true;
}

// Busca en el pool de ventas de la báscula una LÍNEA cuyo importe coincida con el
// escaneado (y, de ser posible, el mismo código/PLU de artículo). Sirve para tomar
// el NOMBRE y el PESO reales de la báscula cuando la etiqueta solo trae el importe,
// de modo que el ticket escaneado quede idéntico al de la venta automática.
function buscarLineaBasculaPorImporte(importeCents, codigoArt) {
  if (!(importeCents > 0)) return null;
  const cod = String(codigoArt || "").replace(/^0+/, "");
  let mejor = null;      // último (más reciente) que coincide por importe
  let mejorCod = null;   // último que coincide por importe Y código/PLU
  const vistos = new Set();
  for (const venta of ventasBasculaPorFolio.values()) {
    if (!venta || vistos.has(venta.key)) continue;
    vistos.add(venta.key);
    for (const l of (venta.lineas || [])) {
      if (l.devolucion) continue;
      if ((l.importeCents || 0) !== importeCents) continue;
      mejor = l;
      const lc = String(l.codigo || l.noPlu || "").replace(/^0+/, "");
      if (cod && lc && lc === cod) mejorCod = l;
    }
  }
  const l = mejorCod || mejor;
  if (!l) return null;
  return {
    nombre: l.nombre || "", cant: l.cant || 1, unidad: l.unidad || "kg",
    precioCents: l.precioCents || 0, importeCents: l.importeCents || importeCents
  };
}

// Arma una línea de venta a partir del código de barras escaneado. El PRECIO
// (importe) siempre viene EXACTO de la etiqueta; el nombre y el peso reales se
// toman del pool de la báscula si esa venta ya llegó por WiFi (mismo importe),
// para que el ticket escaneado coincida con la venta de la báscula.
function agregarLineaBasculaOffline(dec) {
  const importeCents = dec.importeCents || 0;
  if (!ticketActual()) nuevoTicket(true);
  // 1) Nombre/peso REALES desde el pool (venta ya recibida por WiFi con ese importe).
  const real = buscarLineaBasculaPorImporte(importeCents, dec.codigo);
  if (real) {
    const cant = real.cant > 0 ? real.cant : 1;
    const precioCents = real.precioCents > 0 ? real.precioCents
      : (cant > 0 ? Math.round(importeCents / cant) : importeCents);
    cart.push({
      tipo: "producto", ref: null,
      nombre: real.nombre || (dec.folio ? "Báscula folio " + dec.folio : "Producto báscula"),
      unidad: real.unidad || "kg",
      precioCents, cant,
      importeCents: importeCents > 0 ? importeCents : (real.importeCents || 0),
      manual: true, bascula: true
    });
    renderCart();
    return;
  }
  // 2) Sin coincidencia en el pool: se arma con lo embebido (precio EXACTO de la
  //    etiqueta; nombre por catálogo solo si el código existiera).
  const prods = (DATA && DATA.productos) || [];
  const cod = (dec.codigo || "").trim();
  const prod = cod ? prods.find((x) => x.codigo != null && String(x.codigo).trim() === cod) : null;
  // Cantidad HONESTA: solo el peso real si la etiqueta lo trae; si no, 1 unidad.
  let cant = (dec.pesoGramos > 0) ? Math.round((dec.pesoGramos / 1000) * 1000) / 1000 : 1;
  if (cant <= 0) cant = 1;
  const precioCents = importeCents > 0 ? Math.round(importeCents / cant) : (prod ? (prod.precioCents || 0) : 0);
  cart.push({
    tipo: "producto", ref: prod ? prod.id : null,
    nombre: prod ? prod.nombre : (dec.folio ? "Báscula folio " + dec.folio : "Producto báscula"),
    unidad: prod ? (prod.unidad || "kg") : "kg",
    precioCents, cant,
    importeCents: importeCents > 0 ? importeCents : Money.multiplicar(precioCents, cant),
    manual: !prod, bascula: true
  });
  renderCart();
}

// Crea un ticket nuevo con las líneas pesadas de una venta de báscula.
function crearTicketBascula(venta) {
  const t = nuevoTicket(false);
  const etq = venta.folio != null && venta.folio !== "" ? ("Folio " + venta.folio) : "Báscula";
  t.nombre = "⚖️ " + etq;
  t.origenBascula = {
    key: venta.key, folio: venta.folio, nserie: venta.nserie,
    idBascula: venta.idBascula, idCorte: venta.idCorte, idVenta: venta.idVenta
  };
  for (const l of (venta.lineas || [])) {
    if (l.devolucion) continue; // las devoluciones se manejan por separado
    const prod = matchProductoBascula(l);
    let precioCents = l.precioCents || (prod ? prod.precioCents : 0) || 0;
    const importeCents = l.importeCents || 0;
    // Si la báscula no envió precio unitario, se deriva del total.
    if (precioCents <= 0 && importeCents > 0 && l.cant > 0) {
      precioCents = Math.round(importeCents / l.cant);
    }
    const item = {
      tipo: "producto",
      ref: prod ? prod.id : null,
      nombre: l.nombre || (prod && prod.nombre) || "Producto",
      unidad: l.unidad || (prod && prod.unidad) || "kg",
      precioCents,
      cant: l.cant || 1,
      importeCents: importeCents > 0 ? importeCents : Money.multiplicar(precioCents, l.cant || 1),
      manual: !prod,
      bascula: true
    };
    t.cart.push(item);
  }
  return t;
}

// Empareja una línea de báscula con un producto del catálogo (por código,
// PLU o, en último caso, por nombre).
function matchProductoBascula(l) {
  const prods = (DATA && DATA.productos) || [];
  const cod = (l.codigo || "").trim();
  const plu = (l.noPlu || "").trim();
  let p = null;
  if (cod) p = prods.find((x) => x.codigo != null && String(x.codigo).trim() === cod);
  if (!p && plu) p = prods.find((x) => x.codigo != null && String(x.codigo).trim() === plu);
  if (!p) {
    const n = (l.nombre || "").trim().toLowerCase();
    if (n) p = prods.find((x) => (x.nombre || "").trim().toLowerCase() === n);
  }
  return p || null;
}

// Aviso flotante no intrusivo (no usa alert para no bloquear el flujo).
function basculaToast(msg) {
  let cont = document.getElementById("bascula-toasts");
  if (!cont) {
    cont = document.createElement("div");
    cont.id = "bascula-toasts";
    cont.className = "bascula-toasts";
    document.body.appendChild(cont);
  }
  const el = document.createElement("div");
  el.className = "bascula-toast";
  el.textContent = msg;
  cont.appendChild(el);
  setTimeout(() => { el.classList.add("is-out"); setTimeout(() => el.remove(), 350); }, 4200);
}

// Cuando el usuario cierra el aviso con la "X", se silencia el letrero para
// poder trabajar SIN conexión con básculas. Se vuelve a habilitar al reconectar
// o al pulsar "Probar/Buscar básculas" en Configuración.
let basculaAlertSilenciada = false;

// Letrero grande de "Básculas desconectadas" con botón Reintentar. Se muestra
// tras varios intentos fallidos; el botón inicia otra ronda de reintentos.
function bascAlertEl() {
  let el = document.getElementById("bascula-desconectada");
  if (!el) {
    el = document.createElement("div");
    el.id = "bascula-desconectada";
    el.className = "bascula-alert";
    el.innerHTML =
      '<div class="bascula-alert__box">' +
      '<button class="bascula-alert__close" id="bascula-alert-close" title="Cerrar y trabajar sin básculas">✕</button>' +
      '<div class="bascula-alert__icon">⚠️</div>' +
      '<div class="bascula-alert__title">Básculas desconectadas</div>' +
      '<div class="bascula-alert__msg" id="bascula-alert-msg">Contactar al programador.</div>' +
      '<button class="btn btn--primary" id="bascula-alert-retry">🔄 Reintentar</button>' +
      '<div class="bascula-alert__hint">Puedes cerrar (✕) para seguir trabajando sin básculas. Para reconectar: <b>⚙️ Configuración → Probar conexión</b>.</div>' +
      '</div>';
    document.body.appendChild(el);
    el.querySelector("#bascula-alert-retry").addEventListener("click", async () => {
      const b = el.querySelector("#bascula-alert-retry");
      const m = el.querySelector("#bascula-alert-msg");
      b.disabled = true; if (m) m.textContent = "Reintentando conexión…";
      try { await window.api.bascula.reintentar(); } catch (e) {}
      setTimeout(() => { b.disabled = false; }, 5000);
    });
    // "X": cierra el aviso y deja de intentar/mostrar hasta reconectar manual.
    el.querySelector("#bascula-alert-close").addEventListener("click", () => {
      basculaAlertSilenciada = true;
      el.classList.remove("is-show");
      basculaToast("⚖️ Modo sin básculas. Reconecta en ⚙️ Configuración cuando quieras.");
    });
  }
  return el;
}
function onBasculaConexion(info) {
  info = info || {};
  if (info.estado === "desconectada") {
    // Si el usuario cerró el aviso (trabajar sin básculas), no lo re-mostramos.
    if (basculaAlertSilenciada) return;
    const el = bascAlertEl();
    const m = el.querySelector("#bascula-alert-msg");
    if (m) m.textContent = "Contactar al programador.";
    const b = el.querySelector("#bascula-alert-retry"); if (b) b.disabled = false;
    el.classList.add("is-show");
  } else if (info.estado === "reconectada") {
    basculaAlertSilenciada = false;          // vuelve a avisar si se cae otra vez
    const el = document.getElementById("bascula-desconectada");
    if (el) el.classList.remove("is-show");
    basculaToast("⚖️ Básculas reconectadas.");
  } else if (info.estado === "reintentando") {
    const el = document.getElementById("bascula-desconectada");
    if (el && el.classList.contains("is-show")) {
      const m = el.querySelector("#bascula-alert-msg");
      if (m) m.textContent = info.intentos ? `Reintentando… (intento ${info.intentos}/${info.max || 10})` : "Reintentando conexión…";
    }
    if (info.hallazgo) basculaToast("⚖️ Básculas encontradas en " + info.hallazgo);
  }
}

function beepBascula() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.type = "sine"; o.frequency.value = 880;
    g.gain.setValueAtTime(0.001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
    o.start(); o.stop(ctx.currentTime + 0.36);
    setTimeout(() => { try { ctx.close(); } catch (e) {} }, 600);
  } catch (e) {}
}

// Edición en línea del nombre de la pestaña (el diálogo del navegador no funciona aquí).
function renombrarTicket(id) {
  const t = tickets.find((x) => x.id === id);
  if (!t) return;
  // Activar primero (reconstruye las pestañas) y luego tomar el nodo ya renderizado.
  if (id !== ticketActivoId) activarTicket(id);
  const cont = $("#ticket-tabs");
  const tab = cont && cont.querySelector(`.tk-tab[data-tk="${id}"]`);
  if (!tab) return;
  const nameEl = tab.querySelector(".tk-tab__name");
  if (!nameEl || tab.querySelector(".tk-tab__input")) return;

  const input = document.createElement("input");
  input.className = "tk-tab__input";
  input.value = t.nombre;
  input.maxLength = 24;
  nameEl.replaceWith(input);
  input.focus();
  input.select();

  let cerrado = false;
  const commit = (guardar) => {
    if (cerrado) return;
    cerrado = true;
    if (guardar) { const v = input.value.trim(); if (v) t.nombre = v; }
    renderTicketTabs();
  };
  input.addEventListener("click", (e) => e.stopPropagation());
  input.addEventListener("dblclick", (e) => e.stopPropagation());
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); commit(true); }
    else if (e.key === "Escape") { e.preventDefault(); commit(false); }
  });
  input.addEventListener("blur", () => commit(true));
}

function renderTicketTabs() {
  const cont = $("#ticket-tabs");
  if (!cont) return;
  cont.innerHTML =
    tickets.map((t) => {
      const n = t.cart.length;
      const act = t.id === ticketActivoId;
      return `<div class="tk-tab ${act ? "is-active" : ""}" data-tk="${t.id}" title="Clic para cambiar · usa ✎ para renombrar">
          <span class="tk-tab__name">${escapeHtml(t.nombre)}</span>
          ${n ? `<span class="tk-tab__badge">${n}</span>` : ""}
          <button class="tk-tab__edit" data-tkedit="${t.id}" title="Renombrar pestaña">✎</button>
          <button class="tk-tab__close" data-tkclose="${t.id}" title="Cerrar pestaña">✕</button>
        </div>`;
    }).join("") +
    `<button class="tk-tab tk-tab--add" id="tk-add" title="Nueva pestaña de venta">＋</button>`;

  $$("[data-tk]", cont).forEach((el) => {
    el.addEventListener("click", (e) => {
      if (e.target.closest("[data-tkclose]") || e.target.closest("[data-tkedit]") || e.target.closest(".tk-tab__input")) return;
      activarTicket(+el.dataset.tk);
    });
    el.addEventListener("dblclick", (e) => {
      if (e.target.closest("[data-tkclose]")) return;
      renombrarTicket(+el.dataset.tk);
    });
  });
  $$("[data-tkedit]", cont).forEach((b) =>
    b.addEventListener("click", (e) => { e.stopPropagation(); renombrarTicket(+b.dataset.tkedit); }));
  $$("[data-tkclose]", cont).forEach((b) =>
    b.addEventListener("click", (e) => { e.stopPropagation(); cerrarTicket(+b.dataset.tkclose); }));
  const add = $("#tk-add", cont);
  if (add) add.addEventListener("click", () => nuevoTicket());
}

function renderCart() {
  const body = $("#cart-body");
  renderTicketTabs();
  if (!cart.length) {
    body.innerHTML =
      '<div class="order__empty"><div class="big">🧾</div>' +
      "<h4>Carrito de venta vacío</h4>" +
      "<p>Busca productos arriba o selecciónalos del catálogo.</p></div>";
    renderTotales();
    return;
  }
  body.innerHTML = "";
  cart.forEach((it, idx) => {
    const row = document.createElement("div");
    row.className = "cart-item";
    const step = it.unidad === "kg" ? "0.001" : "1";
    let meta;
    if (it.tipo === "paquete") {
      const extras = it.extras || [];
      const comps = it.componentes || [];
      const nExtras = extras.length;
      meta = `Paquete${nExtras ? " · +" + nExtras + " extra" : ""}` +
             (comps.some((c) => !c.incluido) ? " · modificado" : "");
    } else {
      meta = `${fmt(it.precioCents)} / ${it.unidad}`;
    }
    row.innerHTML =
      `<div class="ci-main">
         <div class="cart-item__name">${it.nombre}</div>
         <div class="cart-item__meta">${meta}</div>
         ${it.tipo === "paquete" ? `<button class="ci-edit" data-edit="${idx}">✏️ Editar paquete</button>` : ""}
       </div>
       <div class="ci-qty">
         <input type="number" min="0" step="${step}" value="${it.cant}" data-qty="${idx}" />
         <small>${it.unidad}</small>
       </div>
       <div class="cart-item__amt">${fmt(it.importeCents)}</div>
       <button class="ci-del" data-del="${idx}" title="Quitar">✕</button>`;
    body.appendChild(row);
  });

  $$("[data-del]", body).forEach((b) => b.addEventListener("click", () => removeItem(+b.dataset.del)));
  $$("[data-edit]", body).forEach((b) => b.addEventListener("click", () => openPaqueteEditor(+b.dataset.edit)));
  $$("[data-qty]", body).forEach((inp) => {
    inp.addEventListener("change", () => { setCant(+inp.dataset.qty, inp.value); renderCart(); });
  });
  renderTotales();
}

function subtotalCart() { return Money.sumar(cart.map((it) => it.importeCents)); }
function descuentoTicket() {
  const t = ticketActual();
  return Math.max(0, Math.min(subtotalCart(), (t && t.descuentoCents) || 0));
}
function totalTicket() { return Math.max(0, subtotalCart() - descuentoTicket()); }

function renderTotales() {
  const sub = subtotalCart();
  const desc = descuentoTicket();
  const total = sub - desc;
  const row = $("#t-desc-row");
  if (desc > 0) {
    if (row) row.style.display = "";
    const d = $("#t-descuento"); if (d) d.textContent = "-" + fmt(desc);
  } else if (row) row.style.display = "none";
  $("#t-total").textContent = fmt(total);
  $("#art-count").textContent = cart.length + (cart.length === 1 ? " artículo" : " artículos");
  const bd = $("#btn-descuento");
  if (bd) bd.textContent = desc > 0 ? "Descuento: -" + fmt(desc) : "Descuento";
}

/* ---------------- Descuento por ticket ---------------- */
function descuentoFlujo() {
  const sub = subtotalCart();
  if (sub <= 0) return alert("El carrito está vacío.");
  const t = ticketActual();
  const actual = (t && t.descuentoCents) || 0;
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>Descuento del ticket</h3>
      <div class="qty-hint">Subtotal actual: <b>${fmt(sub)}</b></div>
      <div class="cobro-tabs" id="desc-tabs">
        <button class="cobro-tab is-active" data-modo="monto">Monto $</button>
        <button class="cobro-tab" data-modo="pct">Porcentaje %</button>
      </div>
      <input type="number" id="desc-val" class="qty-field" min="0" step="0.01" value="${actual ? (actual / 100).toFixed(2) : ""}" placeholder="0.00" />
      <div class="qty-hint" id="desc-res">Total con descuento: <b>${fmt(sub - Math.min(sub, actual))}</b></div>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        ${actual ? '<button class="btn btn--sec" id="desc-quitar">Quitar descuento</button>' : ""}
        <button class="btn btn--primary" id="desc-ok">Aplicar</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  let modo = "monto";
  const val = $("#desc-val", back), res = $("#desc-res", back);
  const calc = () => {
    const n = parseFloat(val.value) || 0;
    let cents = modo === "pct" ? Math.round(sub * Math.min(100, Math.max(0, n)) / 100) : Money.toCents(n);
    cents = Math.max(0, Math.min(sub, cents));
    res.innerHTML = `Descuento: <b>${fmt(cents)}</b> · Total: <b>${fmt(sub - cents)}</b>`;
    return cents;
  };
  const cerrar = () => back.remove();
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $$("#desc-tabs .cobro-tab", back).forEach((b) => b.addEventListener("click", () => {
    modo = b.dataset.modo;
    $$("#desc-tabs .cobro-tab", back).forEach((x) => x.classList.toggle("is-active", x === b));
    val.placeholder = modo === "pct" ? "0 a 100" : "0.00";
    calc();
  }));
  val.addEventListener("input", calc);
  const quitar = $("#desc-quitar", back);
  if (quitar) quitar.addEventListener("click", () => { const tk = ticketActual(); if (tk) tk.descuentoCents = 0; cerrar(); renderCart(); });
  $("#desc-ok", back).addEventListener("click", () => {
    const cents = calc();
    const tk = ticketActual(); if (tk) tk.descuentoCents = cents;
    cerrar(); renderCart();
  });
  val.focus(); val.select();
}

/* ---------------- Editor de paquete ---------------- */
function openPaqueteEditor(idx) {
  const item = cart[idx];
  const back = document.createElement("div");
  back.className = "modal-back";
  document.body.appendChild(back);

  let busq = "";   // texto del buscador de productos a agregar

  function render() {
    const compRows = item.componentes.length ? item.componentes.map((c, i) => {
      const pc = precioComponente(c);
      const valor = pc != null ? Money.multiplicar(pc, c.cant) : null;
      const precioTxt = pc != null
        ? `<span class="pk-cprice ${c.incluido ? "" : "neg"}">${c.incluido ? fmt(valor) : "− " + fmt(valor)}</span>`
        : `<span class="pk-cprice muted" title="Sin precio individual: no descuenta al quitarlo">—</span>`;
      return `<div class="pk-row ${c.incluido ? "" : "pk-row--off"}">
               <label><input type="checkbox" data-comp="${i}" ${c.incluido ? "checked" : ""}/> ${c.cant} ${c.unidad} · ${escapeHtml(c.nombre)}</label>
               ${precioTxt}
             </div>`;
    }).join("") : '<div class="pk-empty">Este paquete no tiene componentes cargados todavía.</div>';

    const q = busq.trim().toLowerCase();
    const resultados = q
      ? DATA.productos.filter((p) => productoConInventario(p) && p.precioCents != null && p.nombre.toLowerCase().includes(q)).slice(0, 8)
      : [];
    const resHtml = q
      ? (resultados.length
          ? resultados.map((p) => `<button class="pk-res" data-add="${p.id}">${escapeHtml(p.nombre)} <b>${fmt(p.precioCents)}/${p.unidad}</b></button>`).join("")
          : '<div class="pk-empty">Sin coincidencias.</div>')
      : "";

    back.innerHTML = `
      <div class="modal modal--wide">
        <h3>${escapeHtml(item.nombre)}</h3>
        <p class="sub">Quita lo que no lleve (se descuenta su precio) o agrega productos (se suman al total).</p>

        <div class="pk-price">
          <label>Precio del paquete</label>
          <input type="number" min="0" step="0.01" id="pk-base" value="${(item.basePrecioCents / 100).toFixed(2)}" />
        </div>

        <div class="pk-section">Incluye</div>
        <div class="pk-list">${compRows}</div>

        <div class="pk-section">Extras (se suman al total)</div>
        <div class="pk-list">
          ${item.extras.length ? item.extras.map((e, i) =>
            `<div class="pk-row">
               <span>${e.cant} ${e.unidad} · ${escapeHtml(e.nombre)} — ${fmt(e.importeCents)}</span>
               <button class="pk-del" data-extra="${i}">✕</button>
             </div>`).join("")
          : '<div class="pk-empty">Sin extras.</div>'}
        </div>

        <div class="pk-section">Agregar producto</div>
        <div class="pk-add">
          <input type="text" id="pk-search" placeholder="Buscar producto por nombre…" value="${attr(busq)}" style="flex:1" />
        </div>
        <p class="qty-hint">Al elegir un producto se te pedirá la cantidad (kg o piezas según el producto).</p>
        <div class="pk-results" id="pk-results">${resHtml}</div>

        <div class="modal__foot">
          <b class="pk-total">Total: ${fmt(item.importeCents)}</b>
          <button class="btn btn--primary" id="pk-ok">Listo</button>
        </div>
      </div>`;

    $("#pk-base", back).addEventListener("change", (e) => {
      item.basePrecioCents = Money.toCents(parseFloat(e.target.value.replace(",", ".")) || 0);
      recalc(item); render();
    });
    // Quitar/incluir componente: recalcula y refresca el total al instante.
    $$("[data-comp]", back).forEach((chk) =>
      chk.addEventListener("change", () => {
        item.componentes[+chk.dataset.comp].incluido = chk.checked;
        recalc(item); render();
      }));
    $$("[data-extra]", back).forEach((b) =>
      b.addEventListener("click", () => { item.extras.splice(+b.dataset.extra, 1); recalc(item); render(); }));

    const search = $("#pk-search", back);
    search.addEventListener("input", (e) => { busq = e.target.value; render(); });
    $$("[data-add]", back).forEach((b) => b.addEventListener("click", () => {
      const p = DATA.productos.find((x) => x.id === +b.dataset.add);
      if (!p) return;
      pedirCantidadComp(p, (cant) => {
        const importe = Money.multiplicar(p.precioCents, cant);
        item.extras.push({ productoId: p.id, nombre: p.nombre, cant, unidad: p.unidad, precioCents: p.precioCents, importeCents: importe });
        busq = ""; recalc(item); render();
      });
    }));

    $("#pk-ok", back).addEventListener("click", () => { back.remove(); renderCart(); });
    back.addEventListener("click", (e) => { if (e.target === back) { back.remove(); renderCart(); } });

    // Mantiene el foco en el buscador mientras se escribe.
    if (busq) { const s = $("#pk-search", back); if (s) { s.focus(); s.setSelectionRange(s.value.length, s.value.length); } }
  }
  // Enter siempre confirma el paquete con "Listo".
  back.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    const ok = $("#pk-ok", back);
    if (ok) { e.preventDefault(); ok.click(); }
  });
  render();
  // El buscador queda activo al abrir para escribir sin dar clic.
  setTimeout(() => { const s = $("#pk-search", back); if (s) s.focus(); }, 30);
}

/* ---------------- Cobro ---------------- */
async function abrirCobro(opts) {
  opts = opts || {};
  if (!cart.length) { alert("El carrito está vacío."); return; }
  const subtotalCents = subtotalCart();
  const descuentoCents = descuentoTicket();
  const total = subtotalCents - descuentoCents;
  let modo = "simple";           // "simple" | "combinado"
  let pagoSel = "efectivo";       // preseleccionado: el campo de monto queda activo al abrir
  let recibidoCents = 0;
  let combos = [{ metodo: "efectivo", montoCents: total }];
  // Estado para pagos en dólares y a crédito.
  let usdCents = 0;              // dólares recibidos (centavos de dólar)
  let tipoCambio = 0;           // pesos por dólar (del turno abierto)
  let creditoCliente = null;    // { id, nombre } al pagar a crédito
  if (window.api && window.api.db) {
    try { const st = await window.api.db.estadoCaja(); if (st && st.tipoCambio) tipoCambio = st.tipoCambio; } catch (e) {}
    try { await cargarClientes(); } catch (e) {}
  }
  // Si el turno no tiene tipo de cambio, se toma automáticamente el del día
  // (de internet). Queda editable en el propio cobro.
  if (!tipoCambio && window.api && window.api.fx) {
    try { const r = await window.api.fx.usdMxn(); if (r && r.rate) tipoCambio = r.rate; } catch (e) {}
  }
  // Equivalente en pesos (centavos) de los dólares recibidos: usdCents son
  // centavos de dólar y tipoCambio es pesos por dólar, así que pesoCents = usdCents * tc.
  const pesosDeUsd = () => Math.round(usdCents * (tipoCambio || 0));

  const back = document.createElement("div");
  back.className = "modal-back";
  document.body.appendChild(back);

  // Enter cobra directamente si el botón está habilitado (monto suficiente).
  // Si está deshabilitado, se deja el comportamiento normal (p. ej. activar el
  // botón enfocado) para no bloquear la selección con teclado.
  back.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    const ok = $("#cobro-ok", back);
    if (ok && !ok.disabled) { e.preventDefault(); ok.click(); }
  });

  function render() {
    back.innerHTML = `
      <div class="modal modal--cobro">
        <h3>${opts.apartado ? "Registrar apartado" : "Registrar cobro"}</h3>
        ${opts.apartado ? `<p class="sub">🏷️ Este cobro se etiquetará como <b>APARTADO</b> (entrega pendiente).</p>` : ""}
        ${descuentoCents > 0 ? `<div class="cobro-desc">Subtotal ${fmt(subtotalCents)} · Descuento -${fmt(descuentoCents)}</div>` : ""}
        <div class="cobro-total">Total a cobrar <b>${fmt(total)}</b></div>
        <div class="cobro-tabs">
          <button class="cobro-tab ${modo === "simple" ? "is-active" : ""}" data-modo="simple">Pago simple</button>
          <button class="cobro-tab ${modo === "combinado" ? "is-active" : ""}" data-modo="combinado">Pago combinado</button>
        </div>
        ${modo === "simple" ? renderSimple() : renderCombinado()}
      </div>`;

    $$("[data-modo]", back).forEach((b) => b.addEventListener("click", () => {
      modo = b.dataset.modo;
      if (modo === "combinado" && combos.length === 1 && combos[0].montoCents === 0) combos[0].montoCents = total;
      render();
    }));
    $$("[data-cerrar]", back).forEach((b) => b.addEventListener("click", () => back.remove()));

    if (modo === "simple") bindSimple(); else bindCombinado();
  }

  /* ---- Modo simple ---- */
  function renderSimple() {
    const esEfectivo = pagoSel === "efectivo";
    const esDolares = pagoSel === "dolares";
    const esCredito = pagoSel === "credito";
    const cambio = recibidoCents - total;
    const pesoUsd = pesosDeUsd();
    const cambioUsd = pesoUsd - total;
    let puede;
    if (esEfectivo) puede = recibidoCents >= total;
    else if (esDolares) puede = (tipoCambio > 0) && (pesoUsd >= total);
    else if (esCredito) puede = !!creditoCliente;
    else puede = !!pagoSel;

    let panel = "";
    if (esEfectivo) {
      panel = `
      <div class="cobro-cash">
        <label>Monto recibido</label>
        <input type="number" min="0" step="0.01" id="cobro-recibido" value="${recibidoCents ? (recibidoCents / 100).toFixed(2) : ""}" placeholder="0.00" />
        <div class="cash-quick">
          <button data-exact="1">Exacto</button>
          <button data-add="10000">+$100</button>
          <button data-add="20000">+$200</button>
          <button data-add="50000">+$500</button>
          <button data-add="100000">+$1000</button>
        </div>
        <div class="cobro-cambio ${cambio < 0 ? "neg" : ""}">Cambio <b>${fmt(Math.max(0, cambio))}</b></div>
      </div>`;
    } else if (esDolares) {
      panel = `
      <div class="cobro-cash">
        <div class="cf-2col">
          <div class="mv-field"><label>Tipo de cambio (pesos/dólar)</label>
            <input type="number" min="0" step="0.01" id="cobro-tc" value="${tipoCambio ? tipoCambio.toFixed(2) : ""}" placeholder="Ej. 17.50" /></div>
          <div class="mv-field"><label>Dólares recibidos (USD)</label>
            <input type="number" min="0" step="0.01" id="cobro-usd" value="${usdCents ? (usdCents / 100).toFixed(2) : ""}" placeholder="0.00" /></div>
        </div>
        <div class="cobro-desc" id="cobro-usd-eq">${tipoCambio > 0 ? `Equivale a <b>${fmt(pesoUsd)}</b> (total ${fmt(total)})` : "Captura el tipo de cambio del dólar."}</div>
        <div class="cobro-cambio ${cambioUsd < 0 ? "neg" : ""}" id="cobro-usd-cambio">Cambio (pesos) <b>${fmt(Math.max(0, cambioUsd))}</b></div>
      </div>`;
    } else if (esCredito) {
      const cli = creditoCliente;
      panel = `
      <div class="cobro-cash">
        <label>Cliente al que se le fía</label>
        <input type="search" id="cobro-cli-buscar" placeholder="Buscar cliente por nombre…" autocomplete="off" value="${cli ? attr(cli.nombre) : ""}" />
        <div id="cobro-cli-lista" class="cobro-cli-lista"></div>
        ${cli
          ? `<div class="cobro-desc">Se cargará <b>${fmt(total)}</b> a la cuenta de <b>${escapeHtml(cli.nombre)}</b>${cli.saldoCents ? ` (saldo actual ${fmt(cli.saldoCents)})` : ""}.</div>`
          : `<div class="cobro-cambio neg">Elige el cliente para fiarle esta venta.</div>`}
      </div>`;
    }
    return `
      <p class="sub">Selecciona la forma de pago</p>
      <div class="pay-grid pay-grid--6">
        ${PAGOS_SIMPLE.map((p) =>
          `<button class="pay-btn ${pagoSel === p.id ? "is-active" : ""}" data-pago="${p.id}">
             <span>${p.emoji}</span>${p.label}</button>`).join("")}
      </div>
      ${panel}
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="cobro-ok" ${puede ? "" : "disabled"}>${esCredito ? "Fiar" : "Cobrar"} ${fmt(total)}</button>
      </div>`;
  }

  function bindSimple() {
    $$("[data-pago]", back).forEach((b) =>
      b.addEventListener("click", () => { pagoSel = b.dataset.pago; if (pagoSel !== "efectivo") recibidoCents = 0; render(); }));
    // Efectivo
    const inp = $("#cobro-recibido", back);
    if (inp) {
      inp.addEventListener("input", (e) => { recibidoCents = Money.toCents(parseFloat(e.target.value.replace(",", ".")) || 0) || 0; actualizarCambio(); });
      inp.focus();
    }
    $$("[data-add]", back).forEach((b) => b.addEventListener("click", () => { recibidoCents += +b.dataset.add; render(); }));
    const exact = $("[data-exact]", back);
    if (exact) exact.addEventListener("click", () => { recibidoCents = total; render(); });
    // Dólares (recalcula sin re-renderizar para no perder el foco)
    const recomputeUsd = () => {
      const pesoUsd = pesosDeUsd();
      const cambioUsd = pesoUsd - total;
      const eq = $("#cobro-usd-eq", back);
      if (eq) eq.innerHTML = tipoCambio > 0 ? `Equivale a <b>${fmt(pesoUsd)}</b> (total ${fmt(total)})` : "Captura el tipo de cambio del dólar.";
      const cam = $("#cobro-usd-cambio", back);
      if (cam) { cam.classList.toggle("neg", cambioUsd < 0); cam.innerHTML = `Cambio (pesos) <b>${fmt(Math.max(0, cambioUsd))}</b>`; }
      const ok = $("#cobro-ok", back);
      if (ok) ok.disabled = !((tipoCambio > 0) && (pesoUsd >= total));
    };
    const tc = $("#cobro-tc", back);
    if (tc) tc.addEventListener("input", (e) => { tipoCambio = parseFloat(String(e.target.value).replace(",", ".")) || 0; recomputeUsd(); });
    const usd = $("#cobro-usd", back);
    if (usd) { usd.addEventListener("input", (e) => { usdCents = Money.toCents(parseFloat(String(e.target.value).replace(",", ".")) || 0) || 0; recomputeUsd(); }); usd.focus(); }
    // Crédito: buscador de cliente (solo actualiza la lista, no re-renderiza)
    const cb = $("#cobro-cli-buscar", back);
    if (cb) {
      const pintar = () => {
        const q = (cb.value || "").trim().toLowerCase();
        const box = $("#cobro-cli-lista", back);
        if (!box) return;
        // No se muestra ningún nombre hasta que se empieza a escribir: así la
        // lista no crece de más cuando hay muchos clientes. Se filtra al teclear.
        if (!q) { box.innerHTML = ""; return; }
        const lista = (DATA.clientes || []).filter((c) => c.creditoActivo || (c.saldoCents || 0) > 0)
          .filter((c) => (c.nombre + " " + (c.telefono || "")).toLowerCase().includes(q)).slice(0, 8);
        box.innerHTML = lista.length
          ? lista.map((c) => `<button class="cobro-cli-item" data-cli="${c.id}">👤 ${escapeHtml(c.nombre)}${(c.saldoCents || 0) > 0 ? ` · saldo ${fmt(c.saldoCents)}` : ""}</button>`).join("")
          : `<div class="muted" style="padding:6px">Sin coincidencias.</div>`;
        $$(".cobro-cli-item", box).forEach((it) => it.addEventListener("click", () => {
          const c = (DATA.clientes || []).find((x) => x.id === +it.dataset.cli);
          creditoCliente = c ? { id: c.id, nombre: c.nombre, saldoCents: c.saldoCents || 0 } : null;
          render();
        }));
      };
      cb.addEventListener("input", pintar);
      pintar();
      cb.focus();
    }
    const ok = $("#cobro-ok", back);
    if (ok) ok.addEventListener("click", async () => {
      back.remove();
      if (pagoSel === "dolares") {
        const pesoUsd = pesosDeUsd();
        if (tipoCambio > 0 && window.api && window.api.db) { try { await window.api.db.setTipoCambioCaja(tipoCambio); } catch (e) {} }
        await finalizarVenta({
          pago: "dolares", totalCents: total, subtotalCents, descuentoCents,
          recibidoCents: pesoUsd, cambioCents: Math.max(0, pesoUsd - total),
          dolaresRecibidos: usdCents, tipoCambio, apartado: opts.apartado, notaApartado: opts.nota
        });
      } else if (pagoSel === "credito") {
        await finalizarVenta({
          pago: "credito", totalCents: total, subtotalCents, descuentoCents,
          recibidoCents: total, cambioCents: 0,
          creditoClienteId: creditoCliente ? creditoCliente.id : null,
          clienteNombre: creditoCliente ? creditoCliente.nombre : null,
          apartado: opts.apartado, notaApartado: opts.nota
        });
      } else {
        const cambioCents = pagoSel === "efectivo" ? Math.max(0, recibidoCents - total) : 0;
        await finalizarVenta({ pago: pagoSel, totalCents: total, subtotalCents, descuentoCents, recibidoCents: pagoSel === "efectivo" ? recibidoCents : total, cambioCents, apartado: opts.apartado, notaApartado: opts.nota });
      }
    });
  }

  function actualizarCambio() {
    const cambio = recibidoCents - total;
    const el = $(".cobro-cambio", back);
    if (el) { el.classList.toggle("neg", cambio < 0); el.innerHTML = `Cambio <b>${fmt(Math.max(0, cambio))}</b>`; }
    const ok = $("#cobro-ok", back);
    if (ok) ok.disabled = !(recibidoCents >= total);
  }

  /* ---- Modo combinado ----
     El efectivo se toma como "recibido": puede exceder y se devuelve cambio.
     Las formas sin efectivo (tarjeta/transferencia) son montos exactos. */
  function calcCombo() {
    const efectivo = combos.reduce((s, c) => s + (c.metodo === "efectivo" ? c.montoCents : 0), 0);
    const sinEfectivo = combos.reduce((s, c) => s + (c.metodo !== "efectivo" ? c.montoCents : 0), 0);
    const asignado = efectivo + sinEfectivo;
    const cambio = asignado - total;                 // >0 => hay cambio (solo del efectivo)
    const hayEfectivo = combos.some((c) => c.metodo === "efectivo" && c.montoCents > 0);
    const todasConMonto = combos.every((c) => c.montoCents > 0);
    let estado = "ok", msg = "Completo ✓", valido = false;
    if (!todasConMonto) { estado = "neg"; msg = "Escribe el monto de cada forma"; }
    else if (sinEfectivo > total) { estado = "neg"; msg = "Tarjeta/transferencia excede el total"; }
    else if (asignado < total) { estado = "neg"; msg = "Falta " + fmt(total - asignado); }
    else if (cambio > 0) {
      if (!hayEfectivo) { estado = "neg"; msg = "El excedente solo puede ser en efectivo"; }
      else { estado = "ok"; msg = "Cambio " + fmt(cambio); valido = true; }
    } else { estado = "ok"; msg = "Completo ✓"; valido = true; }
    return { efectivo, sinEfectivo, asignado, cambio: Math.max(0, cambio), estado, msg, valido };
  }

  function renderCombinado() {
    const r = calcCombo();
    return `
      <p class="sub">Divide el total en 2 o más formas de pago. El efectivo puede exceder y se da cambio.</p>
      <div class="combo-rows">
        ${combos.map((c, i) => `
          <div class="combo-row">
            <select data-metodo="${i}">
              ${PAGOS.map((p) => `<option value="${p.id}" ${c.metodo === p.id ? "selected" : ""}>${p.emoji} ${p.label}</option>`).join("")}
            </select>
            <input type="number" min="0" step="0.01" inputmode="decimal" data-monto="${i}" ${c.metodo === "efectivo" ? 'data-efectivo="1"' : ""} value="${c.montoCents ? (c.montoCents / 100).toFixed(2) : ""}" placeholder="0.00" />
            <button class="combo-del" data-del="${i}" ${combos.length <= 1 ? "disabled" : ""}>✕</button>
          </div>`).join("")}
      </div>
      <button class="btn btn--sec combo-add" id="combo-add">＋ Agregar forma de pago</button>
      <div class="combo-sum">
        <span>Asignado <b>${fmt(r.asignado)}</b></span>
        <span class="${r.estado}">${r.msg}</span>
      </div>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="cobro-ok" ${r.valido ? "" : "disabled"}>Cobrar ${fmt(total)}</button>
      </div>`;
  }

  function bindCombinado() {
    $$("[data-metodo]", back).forEach((s) =>
      s.addEventListener("change", () => { combos[+s.dataset.metodo].metodo = s.value; actualizarCombo(); }));
    $$("[data-monto]", back).forEach((inp) => {
      inp.addEventListener("input", () => {
        combos[+inp.dataset.monto].montoCents = Money.toCents(parseFloat(String(inp.value).replace(",", ".")) || 0) || 0;
        actualizarCombo();
      });
      // Al enfocar, selecciona todo para poder sobrescribir sin borrar.
      inp.addEventListener("focus", () => inp.select());
    });
    // El campo de efectivo queda activo y seleccionado de inmediato.
    const efe = $('[data-efectivo="1"]', back) || $("[data-monto]", back);
    if (efe) { efe.focus(); efe.select(); }
    $$("[data-del]", back).forEach((b) =>
      b.addEventListener("click", () => { combos.splice(+b.dataset.del, 1); render(); }));
    $("#combo-add", back).addEventListener("click", () => {
      const usados = combos.map((c) => c.metodo);
      const libre = (PAGOS.find((p) => !usados.includes(p.id)) || PAGOS[1]).id;
      const asignado = combos.reduce((s, c) => s + c.montoCents, 0);
      combos.push({ metodo: libre, montoCents: Math.max(0, total - asignado) });
      render();
    });
    const ok = $("#cobro-ok", back);
    if (ok) ok.addEventListener("click", async () => {
      const r = calcCombo();
      if (!r.valido) return;
      // Montos aplicados (que suman EXACTO al total): efectivo = total - sinEfectivo
      const efectivoAplicado = total - r.sinEfectivo;                 // >=0
      const pagos = combos.filter((c) => c.metodo !== "efectivo" && c.montoCents > 0)
        .map((c) => ({ metodo: c.metodo, montoCents: c.montoCents }));
      if (efectivoAplicado > 0) pagos.push({ metodo: "efectivo", montoCents: efectivoAplicado });
      back.remove();
      await finalizarVenta({
        pago: "combinado", totalCents: total, pagos,
        apartado: opts.apartado, notaApartado: opts.nota,
        efectivoRecibidoCents: r.efectivo, cambioCents: r.cambio
      });
    });
  }

  function actualizarCombo() {
    const r = calcCombo();
    const sum = $(".combo-sum", back);
    if (sum) sum.innerHTML =
      `<span>Asignado <b>${fmt(r.asignado)}</b></span>` +
      `<span class="${r.estado}">${r.msg}</span>`;
    const ok = $("#cobro-ok", back);
    if (ok) ok.disabled = !r.valido;
  }

  back.addEventListener("click", (e) => { if (e.target === back) back.remove(); });
  // La tecla Enter dispara el botón "Cobrar"/"Fiar" cuando ya está habilitado
  // (datos completos), para cerrar la venta rápido sin usar el mouse.
  back.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    const ok = $("#cobro-ok", back);
    if (ok && !ok.disabled) { e.preventDefault(); ok.click(); }
  });
  render();
}

async function finalizarVenta(pago) {
  if (pago.pago === "credito" && !pago.creditoClienteId) { alert("Elige un cliente para la venta a crédito."); return; }
  const totalCents = pago.totalCents;
  const descuentoCents = pago.descuentoCents || 0;
  const subtotalCents = pago.subtotalCents != null ? pago.subtotalCents : totalCents;
  const esCombinado = pago.pago === "combinado";
  // El cajón se abre con pagos en efectivo O en dólares (ambos dejan billetes).
  const tieneEfectivo = pago.pago === "efectivo" || pago.pago === "dolares" ||
    (esCombinado && (pago.pagos.some((p) => p.metodo === "efectivo") || (pago.efectivoRecibidoCents || 0) > 0));
  const cambioCents = pago.cambioCents || 0;
  const efectivoRecibidoCents = esCombinado ? (pago.efectivoRecibidoCents || 0) : 0;
  // En crédito el "cliente" de la venta es el que se fía.
  const clienteVenta = (pago.pago === "credito" && pago.clienteNombre) ? pago.clienteNombre : clienteActual;
  // Origen de báscula: conserva el folio/serie del ticket físico de la báscula
  // para poder localizar esta venta cuando el cliente lo traiga de vuelta.
  const _tkActivo = ticketActual();
  const origenBascula = _tkActivo && _tkActivo.origenBascula ? _tkActivo.origenBascula : null;

  const venta = {
    usuario: usuarioActual ? usuarioActual.nombre : null,
    cliente: clienteVenta,
    creditoClienteId: pago.pago === "credito" ? (pago.creditoClienteId || null) : undefined,
    dolaresRecibidos: pago.pago === "dolares" ? (pago.dolaresRecibidos || 0) : undefined,
    tipoCambio: pago.pago === "dolares" ? (pago.tipoCambio || 0) : undefined,
    origenBascula: origenBascula || undefined,
    basculaFolio: origenBascula ? origenBascula.folio : undefined,
    items: cart.map((it) => ({
      tipo: it.tipo,
      productoId: it.tipo === "producto" ? it.ref : undefined,
      nombre: it.nombre, cant: it.cant, unidad: it.unidad,
      precioCents: it.tipo === "paquete" ? it.basePrecioCents : it.precioCents,
      importeCents: it.importeCents,
      componentes: it.tipo === "paquete" ? it.componentes : undefined,
      extras: it.tipo === "paquete" ? it.extras : undefined,
      bascula: !!it.bascula,
      manual: !!it.manual
    })),
    subtotalCents,
    descuentoCents,
    totalCents,
    pago: pago.pago,
    pagos: esCombinado ? pago.pagos : undefined,
    recibidoCents: esCombinado ? (efectivoRecibidoCents || totalCents) : (pago.recibidoCents != null ? pago.recibidoCents : totalCents),
    cambioCents,
    esApartado: !!pago.apartado,
    entregado: pago.apartado ? false : undefined,
    notaApartado: pago.apartado ? (pago.notaApartado || "") : undefined
  };
  let folio = "—";
  let saldoClienteCents = null;
  if (window.api && window.api.db) {
    try {
      const r = await window.api.db.registrarVenta(venta);
      folio = r.folio;
      if (r.saldoClienteCents != null) saldoClienteCents = r.saldoClienteCents;
      if (Array.isArray(r.existencias) && DATA.productos) {
        for (const x of r.existencias) {
          const p = DATA.productos.find((y) => y.id === x.id);
          if (p) p.existencia = x.existencia;
        }
      }
      // Actualiza saldo local del cliente (crédito) para que la UI lo refleje al instante.
      if (pago.pago === "credito" && pago.creditoClienteId != null && DATA.clientes) {
        const cli = DATA.clientes.find((c) => c.id === Number(pago.creditoClienteId));
        if (cli && saldoClienteCents != null) cli.saldoCents = saldoClienteCents;
      }
    } catch (e) { /* offline safe */ }
  }

  // El cajón se abre SOLO si hay efectivo/dólares en el pago (config aparte).
  // El ticket NUNCA se imprime solo: siempre se muestra el modal con "Imprimir"
  // (igual que crédito), para todas las formas de pago.
  const abrirCajonCfg = !(CFG && CFG.impresora && CFG.impresora.abrirCajonEfectivo === false);
  const abrirCajonAuto = abrirCajonCfg && tieneEfectivo;
  const ticket = {
    folio,
    fecha: new Date().toLocaleString("es-MX"),
    cajero: usuarioActual ? usuarioActual.nombre : "",
    cliente: clienteVenta,
    items: cart.map((it) => ({
      nombre: it.nombre, cant: it.cant, unidad: it.unidad, tipo: it.tipo,
      precioCents: it.tipo === "paquete" ? null : it.precioCents,
      importeCents: it.importeCents
    })),
    subtotalCents,
    descuentoCents,
    totalCents,
    pago: pago.pago,
    pagoLabel: esCombinado ? "Combinado" : pagoLabel(pago.pago),
    pagos: esCombinado ? pago.pagos.map((p) => ({ metodo: p.metodo, label: pagoLabel(p.metodo), montoCents: p.montoCents })) : undefined,
    recibidoCents: (pago.pago === "efectivo" || pago.pago === "dolares") ? venta.recibidoCents : (esCombinado ? efectivoRecibidoCents : totalCents),
    efectivoRecibidoCents: esCombinado ? efectivoRecibidoCents : 0,
    dolaresRecibidos: pago.pago === "dolares" ? (pago.dolaresRecibidos || 0) : undefined,
    tipoCambio: pago.pago === "dolares" ? (pago.tipoCambio || 0) : undefined,
    // En el ticket NO se manda kick: el cajón ya se abre aparte tras el cobro.
    cambioCents, abrirCajon: false,
    apartado: !!pago.apartado, notaApartado: pago.notaApartado || "",
    origenBascula: origenBascula || undefined,
    basculaFolio: origenBascula ? origenBascula.folio : undefined,
    // Solo crédito: saldo adeudado para el apartado de firma.
    saldoClienteCents: pago.pago === "credito" ? saldoClienteCents : undefined
  };
  ultimoTicket = ticket;
  actualizarUltimaVenta();
  // No se abre el panel flotante de "última venta" automáticamente: se queda
  // minimizado y el cajero lo abre con clic (botón "Última venta") cuando quiera.

  // Cajón automático (efectivo/dólares), independiente de imprimir el ticket.
  if (abrirCajonAuto && window.api && window.api.printer) {
    try { await window.api.printer.abrirCajon(); } catch (e) { /* best-effort */ }
  }

  // Vaciar el ticket cobrado (y cerrarlo si hay más pestañas abiertas)
  const activo = ticketActual();
  if (activo) { activo.cart.length = 0; activo.cliente = CLIENTE_DEFAULT; activo.descuentoCents = 0; }
  if (tickets.length > 1 && activo) {
    cerrarTicket(activo.id);
  } else {
    clienteActual = CLIENTE_DEFAULT;
    const cn = $("#cliente-actual"); if (cn) cn.textContent = CLIENTE_DEFAULT;
    renderCart();
  }

  try { await recargarCatalogo(); } catch (e) { /* el stock local ya se actualizó */ }

  // Todas las formas de pago: modal con vista previa + clic en Imprimir.
  const modo = CFG && CFG.impresora ? CFG.impresora.modo : "off";
  await mostrarTicket(ticket, { impreso: false, errImp: null, modo, cajonAbierto: abrirCajonAuto });
}

/* ---------------- Ticket / vista previa ---------------- */
async function mostrarTicket(ticket, estado) {
  let texto = "";
  if (window.api && window.api.printer) {
    try { texto = await window.api.printer.vistaPrevia(ticket); } catch (e) { texto = ""; }
  }
  if (!texto) texto = vistaPreviaLocal(ticket);

  let nota;
  if (estado.impreso) nota = `<span class="tk-ok">✅ Ticket enviado a la impresora</span>`;
  else if (estado.modo === "off") nota = `<span class="tk-info">🖨️ Impresora en modo vista previa (aún no conectada). Configúrala en Administración → Configuración.</span>`;
  else if (estado.errImp) nota = `<span class="tk-warn">⚠️ No se pudo imprimir: ${estado.errImp}</span>`;
  else if (estado.reimpresion) nota = `<span class="tk-info">Vista previa del ticket.</span>`;
  else {
    const cajon = estado.cajonAbierto ? " · Cajón abierto" : "";
    nota = `<span class="tk-info">🖨️ ¿Imprimir este ticket? Da clic en Imprimir.${cajon}</span>`;
  }

  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--ticket">
      <h3>Ticket — Folio ${ticket.folio}</h3>
      ${nota}
      <pre class="ticket-preview">${escapeHtml(texto)}</pre>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cerrar</button>
        <button class="btn btn--primary" id="tk-imprimir">🖨️ Imprimir</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#tk-imprimir", back).addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    if (btn.disabled) return;                 // evita doble clic -> doble ticket
    if (!(window.api && window.api.printer)) return alert("Impresión no disponible.");
    btn.disabled = true; const txt = btn.textContent; btn.textContent = "Imprimiendo…";
    // Al reimprimir NO se abre el cajón; en la venta original sí (según config).
    const t = estado && estado.reimpresion ? Object.assign({}, ticket, { abrirCajon: false }) : ticket;
    let r; try { r = await window.api.printer.imprimir(t); } catch (err) { r = { error: String(err) }; }
    if (r && r.ok) { cerrar(); }
    else { btn.disabled = false; btn.textContent = txt; alert(r && r.error ? r.error : "No se pudo imprimir."); }
  });
}

/* ---------------- Impresión de corte de caja ---------------- */
function corteDesdeEstado(st, extra) {
  const c = st.caja || {};
  const metodos = Object.keys(st.porMetodo || {})
    .filter((id) => st.porMetodo[id])
    .map((id) => ({ label: pagoLabel(id), montoCents: st.porMetodo[id] }));
  return Object.assign({
    titulo: "CORTE DE TURNO",
    abrirCajon: true,
    turno: st.turno != null ? st.turno : c.id,
    terminal: st.terminal || "",
    fecha: new Date().toLocaleString("es-MX"),
    cajero: c.usuario || (usuarioActual ? usuarioActual.nombre : ""),
    aperturaFecha: c.aperturaFecha ? new Date(c.aperturaFecha).toLocaleString("es-MX") : "",
    fondoCents: c.fondoCents || 0,
    numVentas: st.numVentas || 0,
    metodos,
    porMetodo: st.porMetodo || {},
    porMetodoCobrado: st.porMetodoCobrado || null,
    entradas: st.entradas || [],
    salidas: st.salidas || [],
    movimientosOtros: st.movimientosOtros || [],
    abonos: st.abonos || [],
    totalAbonosCents: st.totalAbonosCents || 0,
    totalAbonosOtrosCents: st.totalAbonosOtrosCents || 0,
    ventasPorDepto: deptosCorte(st.ventasPorDepto),
    carnesBascula: datoCarnesBascula(st),
    totalVentasCents: st.totalVentas || 0,
    ventasCobradasCents: st.ventasCobradas != null ? st.ventasCobradas : (st.totalVentas || 0),
    apartadosCents: st.apartadosCents || 0,
    totalDevolucionesCents: st.totalDevoluciones || 0,
    devCobradasCents: st.devCobradas != null ? st.devCobradas : (st.totalDevoluciones || 0),
    ventasNetasCents: st.ventasNetas || 0,
    creditoVentasCents: st.creditoVentas || 0,
    creditoDevCents: st.creditoDev || 0,
    creditosLista: st.creditosLista || [],
    creditosProveedor: st.creditosProveedor || [],
    creditosProveedorCents: st.creditosProveedorCents || 0,
    ingresosCents: st.ingresos || 0,
    retirosCents: st.retiros || 0,
    efectivoVentasCents: st.efectivoVentas || 0,
    efectivoDevolucionesCents: st.efectivoDevoluciones || 0,
    efectivoEsperadoCents: st.efectivoEsperado || 0,
    cancelaciones: st.cancelaciones || [],
    totalCancelacionesCents: st.totalCancelaciones || 0,
    devolucionesLista: st.devolucionesLista || [],
    diferidoBasculaCents: st.diferidoBascula || 0,
    basculaTotalManualCents: st.basculaTotalManualCents != null ? st.basculaTotalManualCents : null,
    paquetesTotalManualCents: st.paquetesTotalManualCents != null ? st.paquetesTotalManualCents : null,
    dineroEnCajaCierreCents: st.dineroEnCajaCierreCents != null ? st.dineroEnCajaCierreCents : null
  }, extra || {});
}

function deptosCorte(lista) {
  const ocultas = new Set(["varios", "paquetes"]);
  return (lista || []).filter((d) => !ocultas.has(String(d.depto || "").trim().toLowerCase()));
}
function datoCarnesBascula(obj) {
  const x = obj && obj.carnesBascula;
  return { montoCents: (x && x.montoCents) || 0, cant: (x && x.cant) || 0 };
}

async function imprimirCorteFlujo(corte) {
  let impreso = false, errImp = null;
  const modo = CFG && CFG.impresora ? CFG.impresora.modo : "off";
  if (window.api && window.api.printer && modo !== "off") {
    try { const r = await window.api.printer.imprimirCorte(corte); if (r && r.ok) impreso = true; else errImp = r && r.error; }
    catch (e) { errImp = String(e); }
  }
  let texto = "";
  if (window.api && window.api.printer) { try { texto = await window.api.printer.vistaPreviaCorte(corte); } catch (e) { texto = ""; } }
  let nota;
  if (impreso) nota = `<span class="tk-ok">✅ Corte enviado a la impresora</span>`;
  else if (modo === "off") nota = `<span class="tk-info">🖨️ Impresora en modo vista previa. Configúrala en Administración → Configuración.</span>`;
  else if (errImp) nota = `<span class="tk-warn">⚠️ No se pudo imprimir: ${errImp}</span>`;
  else nota = `<span class="tk-info">Vista previa del corte.</span>`;

  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--ticket">
      <h3>Corte de caja</h3>
      ${nota}
      <pre class="ticket-preview">${escapeHtml(texto || "(sin vista previa)")}</pre>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cerrar</button>
        <button class="btn btn--primary" id="ct-imprimir">🖨️ Imprimir corte</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#ct-imprimir", back).addEventListener("click", async () => {
    if (!(window.api && window.api.printer)) return alert("Impresión no disponible.");
    const r = await window.api.printer.imprimirCorte(corte);
    if (r && r.ok) cerrar(); else alert(r && r.error ? r.error : "No se pudo imprimir.");
  });
}

function ticketDesdeCorteGuardado(t) {
  const co = t.corte || {};
  const creditoVentas = t.creditoVentas || co.creditoVentas || 0;
  const creditoDev = t.creditoDev || co.creditoDev || 0;
  const totalVentas = co.totalVentas || 0;
  const totalDev = co.totalDevoluciones || 0;
  const lista = (t.creditos && t.creditos.length) ? t.creditos : (co.creditosLista || []);
  return {
    titulo: "CORTE DEL DIA",
    abrirCajon: false,
    turno: co.turno || t.id,
    terminal: co.terminal || "",
    fecha: t.cierreFecha ? new Date(t.cierreFecha).toLocaleString("es-MX") : "",
    cajero: t.usuario || "",
    aperturaFecha: co.aperturaFecha ? new Date(co.aperturaFecha).toLocaleString("es-MX") : "",
    fondoCents: co.fondoCents || 0,
    numVentas: co.numVentas || 0,
    porMetodo: co.porMetodo || {},
    porMetodoCobrado: co.porMetodoCobrado || null,
    entradas: co.entradas || [],
    salidas: co.salidas || [],
    movimientosOtros: co.movimientosOtros || [],
    abonos: co.abonos || [],
    totalAbonosCents: co.totalAbonosCents || 0,
    totalAbonosOtrosCents: co.totalAbonosOtrosCents || 0,
    ventasPorDepto: deptosCorte(co.ventasPorDepto),
    carnesBascula: datoCarnesBascula(co),
    totalVentasCents: totalVentas,
    ventasCobradasCents: totalVentas - creditoVentas,
    apartadosCents: co.apartadosCents || 0,
    totalDevolucionesCents: totalDev,
    devCobradasCents: totalDev - creditoDev,
    ventasNetasCents: (totalVentas - creditoVentas) - (totalDev - creditoDev),
    creditoVentasCents: creditoVentas,
    creditoDevCents: creditoDev,
    creditosLista: lista,
    creditosProveedor: Array.isArray(co.creditosProveedor) ? co.creditosProveedor : null,
    creditosProveedorCents: co.creditosProveedorCents || 0,
    ingresosCents: co.ingresos || 0,
    retirosCents: co.retiros || 0,
    efectivoVentasCents: co.efectivoVentas || 0,
    efectivoDevolucionesCents: co.efectivoDevoluciones || 0,
    efectivoEsperadoCents: co.efectivoEsperado || 0,
    efectivoContadoCents: co.conteoCents,
    diferenciaCents: co.diferenciaCents || 0,
    dineroEnCajaCierreCents: co.dineroEnCajaCierreCents != null ? co.dineroEnCajaCierreCents : null,
    entregadoCents: co.entregadoCents != null ? co.entregadoCents : null,
    basculaTotalManualCents: co.basculaTotalManualCents != null ? co.basculaTotalManualCents : null,
    paquetesTotalManualCents: co.paquetesTotalManualCents != null ? co.paquetesTotalManualCents : null,
    cancelaciones: co.cancelaciones || [],
    totalCancelacionesCents: co.totalCancelaciones || 0,
    devolucionesLista: co.devolucionesLista || [],
    diferidoBasculaCents: co.diferidoBascula || 0
  };
}

function ticketDesdeDetalle(d, mov) {
  const porMetodo = {};        // NETO por método
  const porMetodoCobrado = {}; // BRUTO cobrado por método (sin restar devoluciones; sin crédito)
  Object.keys(d.metodos || {}).forEach((id) => {
    const m = d.metodos[id];
    porMetodo[id] = (m.ventasCents || 0) - (m.devolucionesCents || 0) + (m.abonosCents || 0);
    if (String(id).toLowerCase() !== "credito") porMetodoCobrado[id] = m.ventasCents || 0;
  });
  const met = (id) => d.metodos[id] || {};
  const esCajonFp = (fp) => {
    const x = String(fp || "efectivo").trim().toLowerCase();
    return x === "efectivo" || x === "dolares";
  };
  const mapMovT = (m, fallback) => ({
    motivo: m.motivo || fallback, montoCents: m.montoCents || 0,
    categoria: m.categoria || "", formaPago: String(m.formaPago || "efectivo").toLowerCase(),
    tipo: m.tipo, proveedor: m.proveedor || ""
  });
  const todosMov = (mov && mov.movimientos) || [];
  const entradas = todosMov.filter((m) => m.tipo === "ingreso" && esCajonFp(m.formaPago)).map((m) => mapMovT(m, "(entrada)"));
  const salidas = todosMov.filter((m) => m.tipo === "retiro" && esCajonFp(m.formaPago)).map((m) => mapMovT(m, "(salida)"));
  const movimientosOtros = todosMov
    .filter((m) => !esCajonFp(m.formaPago) && String(m.formaPago || "").toLowerCase() !== "credito")
    .map((m) => mapMovT(m, m.tipo === "retiro" ? "(salida)" : "(entrada)"));
  return {
    titulo: "CORTE DEL DIA",
    abrirCajon: false,
    sinArqueo: true,
    turno: d.dia,
    fecha: d.dia,
    numVentas: d.numVentas || 0,
    porMetodo,
    porMetodoCobrado,
    entradas,
    salidas,
    movimientosOtros,
    abonos: d.abonos || [],
    totalAbonosCents: d.totalAbonosCents || 0,
    totalAbonosOtrosCents: d.totalAbonosOtrosCents || 0,
    totalVentasCents: d.totalVentasCents || 0,
    ventasCobradasCents: d.ventasCobradasCents != null ? d.ventasCobradasCents : (d.totalVentasCents || 0),
    apartadosCents: d.apartadosCents || 0,
    totalDevolucionesCents: d.totalDevolucionesCents || 0,
    devCobradasCents: d.devCobradasCents != null ? d.devCobradasCents : (d.totalDevolucionesCents || 0),
    ventasNetasCents: d.totalNetoCents || 0,
    creditoVentasCents: d.creditoVentasCents || 0,
    creditoDevCents: d.creditoDevCents || 0,
    creditosLista: d.creditos || [],
    ingresosCents: mov ? mov.entradas : 0,
    retirosCents: mov ? mov.salidas : 0,
    efectivoVentasCents: (met("efectivo").ventasCents || 0) + (met("dolares").ventasCents || 0),
    efectivoDevolucionesCents: (met("efectivo").devolucionesCents || 0) + (met("dolares").devolucionesCents || 0),
    cancelaciones: d.cancelaciones || [],
    totalCancelacionesCents: d.totalCancelacionesCents || 0,
    devolucionesLista: d.devolucionesLista || [],
    diferidoBasculaCents: d.diferidoBasculaCents || 0,
    basculaTotalManualCents: d.basculaTotalManualCents != null ? d.basculaTotalManualCents : null,
    paquetesTotalManualCents: d.paquetesTotalManualCents != null ? d.paquetesTotalManualCents : null,
    ventasPorDepto: deptosCorte(d.ventasPorDepto),
    carnesBascula: datoCarnesBascula(d)
  };
}

function ticketEleventa(c, creditos) {
  const credito = c.creditoCents || 0;
  const total = c.totalVentasCents || 0;
  return {
    titulo: "CORTE DEL DIA",
    abrirCajon: false,
    sinArqueo: true,
    turno: String(c.dia || "").slice(0, 10) + (c.caja != null ? " caja " + c.caja : ""),
    fecha: String(c.dia || "").slice(0, 10),
    numVentas: c.numVentas || 0,
    porMetodo: {
      efectivo: c.efectivoCents || 0,
      tarjeta: c.tarjetaCents || 0,
      transferencia: c.transferenciaCents || 0,
      credito
    },
    entradas: c.entradasCents ? [{ motivo: "Entradas del dia", montoCents: c.entradasCents }] : [],
    salidas: c.salidasCents ? [{ motivo: "Salidas del dia", montoCents: c.salidasCents }] : [],
    abonos: c.abonosEfectivoCents ? [{ cliente: "Abonos en efectivo", montoCents: c.abonosEfectivoCents, formaPago: "efectivo" }] : [],
    totalAbonosCents: c.abonosEfectivoCents || 0,
    totalVentasCents: total,
    ventasCobradasCents: Math.max(0, total - credito),
    ventasNetasCents: Math.max(0, total - credito),
    creditoVentasCents: credito,
    creditosLista: creditos || [],
    ingresosCents: c.entradasCents || 0,
    retirosCents: c.salidasCents || 0,
    efectivoVentasCents: c.efectivoCents || 0
  };
}

async function imprimirCorteDelDia(fecha) {
  const dia = fecha || hoyISO();
  const info = await window.api.db.reimpresionDia(dia);
  const d = await window.api.db.detalleDia(dia);
  const tickets = [];
  if (info && info.turnos && info.turnos.length) {
    info.turnos.forEach((t) => tickets.push(ticketDesdeCorteGuardado(t)));
  } else if (info && info.eleventa && info.eleventa.length) {
    const nombres = (d && d.creditos) || [];
    info.eleventa.forEach((c) => tickets.push(ticketEleventa(c, nombres)));
  } else if (d) {
    tickets.push(ticketDesdeDetalle(d, info && info.movimientos));
  }
  if (!tickets.length) return alert("Ese día no tiene corte ni ventas.");
  return mostrarTicketsCorte(dia, tickets, tickets.length + " turnos de este día. Se imprimen juntos, sin folio.");
}

async function mostrarTicketsCorte(dia, tickets, nota) {
  if (!tickets.length) return;
  if (tickets.length === 1) return imprimirCorteFlujo(tickets[0]);
  const modo = CFG && CFG.impresora ? CFG.impresora.modo : "off";
  const textos = [];
  for (const t of tickets) {
    let texto = "";
    if (window.api && window.api.printer) {
      try { texto = await window.api.printer.vistaPreviaCorte(t); } catch (e) { texto = ""; }
    }
    textos.push(texto || "(sin vista previa)");
  }
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--ticket">
      <h3>Cortes del ${escapeHtml(dia)}</h3>
      <p class="qty-hint">${escapeHtml(nota || (tickets.length + " turnos. Se imprimen juntos, sin folio."))}</p>
      <pre class="ticket-preview">${escapeHtml(textos.join("\n\n----------------\n\n"))}</pre>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cerrar</button>
        <button class="btn btn--primary" id="ct-imprimir">🖨️ Imprimir</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#ct-imprimir", back).addEventListener("click", async () => {
    if (modo === "off") return alert("La impresora está en vista previa. Actívala en Configuración.");
    if (!(window.api && window.api.printer)) return alert("Impresión no disponible.");
    for (const t of tickets) {
      const r = await window.api.printer.imprimirCorte(t);
      if (!(r && r.ok)) return alert(r && r.error ? r.error : "No se pudo imprimir.");
    }
    cerrar();
  });
}

/* ---------------- Impresión de listados / notas ---------------- */
async function mostrarListaFlujo(titulo, lineas, opts) {
  opts = opts || {};
  const autoImprimir = !!opts.autoImprimir;
  let impreso = false, errImp = null;
  const modo = CFG && CFG.impresora ? CFG.impresora.modo : "off";
  if (autoImprimir && window.api && window.api.printer && modo !== "off") {
    try { const r = await window.api.printer.imprimirTexto(titulo, lineas); if (r && r.ok) impreso = true; else errImp = r && r.error; }
    catch (e) { errImp = String(e); }
  }
  let texto = "";
  if (window.api && window.api.printer) { try { texto = await window.api.printer.vistaPreviaTexto(titulo, lineas); } catch (e) { texto = ""; } }
  if (!texto) texto = (titulo || "") + "\n" + (lineas || []).join("\n");
  let nota;
  if (!autoImprimir) nota = `<span class="tk-info">Vista en pantalla · no se envió a la impresora.</span>`;
  else if (impreso) nota = `<span class="tk-ok">✅ Enviado a la impresora</span>`;
  else if (modo === "off") nota = `<span class="tk-info">🖨️ Impresora en modo vista previa. Configúrala en Administración → Configuración.</span>`;
  else if (errImp) nota = `<span class="tk-warn">⚠️ No se pudo imprimir: ${escapeHtml(errImp)}</span>`;
  else nota = `<span class="tk-info">Vista previa.</span>`;

  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--ticket">
      <h3>${escapeHtml(titulo || "Listado")}</h3>
      ${nota}
      <pre class="ticket-preview">${escapeHtml(texto)}</pre>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cerrar</button>
        <button class="btn btn--primary" id="lt-imprimir">🖨️ Imprimir</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#lt-imprimir", back).addEventListener("click", async () => {
    if (!(window.api && window.api.printer)) return alert("Impresión no disponible.");
    const r = await window.api.printer.imprimirTexto(titulo, lineas);
    if (r && r.ok) cerrar(); else alert(r && r.error ? r.error : "No se pudo imprimir.");
  });
}
async function imprimirListaFlujo(titulo, lineas) {
  return mostrarListaFlujo(titulo, lineas, { autoImprimir: true });
}

/* ---------------- Reimpresión de tickets ---------------- */
async function imprimirHistorialDiaFlujo(data) {
  if (!data) return;
  const dia = data.dia || hoyISO();
  const ventas = data.ventas || [];
  const devs = data.devoluciones || [];
  if (!ventas.length && !devs.length) return alert("No hay ventas ni devoluciones en este día.");
  const n = ventas.length + devs.length;
  if (!confirm(`¿Imprimir el historial del ${dia}?\n${ventas.length} venta(s) y ${devs.length} devolución(es).\n\nEs UN solo listado (no reimprime cada ticket uno por uno).`)) return;

  const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
  const lr = (a, b) => { a = String(a); b = String(b); const s = cols - a.length - b.length; return s >= 1 ? a + " ".repeat(s) + b : (a + " " + b); };
  const L = [];
  L.push("Fecha: " + dia);
  L.push("Cajero: " + (usuarioActual ? usuarioActual.nombre : "—"));
  L.push("Caja: " + ((CFG && CFG.terminal) || "Caja Principal"));
  L.push("-".repeat(cols));
  L.push(lr("VENTAS", String(ventas.filter((v) => !v.cancelada).length)));
  ventas.forEach((v) => {
    const marca = v.cancelada ? " CANC" : (v.apartado ? " APART" : "");
    const bas = v.basculaFolio != null ? " B" + v.basculaFolio : "";
    const izq = `${v.hora || ""} #${v.folio}${bas}${marca} ${(v.cliente || "").slice(0, 14)}`.trim();
    const der = v.cancelada ? "0.00" : fmt(v.totalCents);
    L.push(lr(izq.slice(0, Math.max(1, cols - der.length - 1)), der));
    if (v.pago) L.push(("  " + pagoLabel(v.pago)).slice(0, cols));
  });
  L.push("-".repeat(cols));
  L.push(lr("TOTAL VENTAS", fmt(data.totalVentasCents || 0)));
  if (devs.length) {
    L.push("");
    L.push(lr("DEVOLUCIONES", String(devs.length)));
    devs.forEach((d) => {
      const izq = `${d.hora || ""} DEV#${d.folio}` + (d.ventaFolio != null ? ` (v#${d.ventaFolio})` : "");
      const der = "-" + fmt(d.totalCents);
      L.push(lr(izq.slice(0, Math.max(1, cols - der.length - 1)), der));
    });
    L.push(lr("TOTAL DEVOLUCIONES", "-" + fmt(data.totalDevolucionesCents || 0)));
  }
  L.push("-".repeat(cols));
  const neto = (data.totalVentasCents || 0) - (data.totalDevolucionesCents || 0);
  L.push(lr("NETO DEL DIA", fmt(neto)));
  L.push("(" + n + " movimiento(s) listados)");
  await imprimirListaFlujo("HISTORIAL " + dia, L);
}

function ticketDesdeVenta(v) {
  let saldoClienteCents = v.saldoClienteCents;
  if (saldoClienteCents == null && String(v.pago || "").toLowerCase() === "credito" && v.creditoClienteId != null && DATA && DATA.clientes) {
    const cli = DATA.clientes.find((c) => c.id === Number(v.creditoClienteId));
    if (cli) saldoClienteCents = cli.saldoCents || 0;
  }
  return {
    folio: v.folio,
    fecha: new Date(v.fecha).toLocaleString("es-MX"),
    cajero: v.usuario || "",
    cliente: (v.cliente && typeof v.cliente === "object") ? (v.cliente.nombre || "") : (v.cliente || ""),
    items: (v.items || []).map((it) => ({
      nombre: it.nombre, cant: it.cant, unidad: it.unidad, tipo: it.tipo,
      precioCents: it.tipo === "paquete" ? null : it.precioCents,
      importeCents: it.importeCents
    })),
    subtotalCents: v.subtotalCents,
    descuentoCents: v.descuentoCents || 0,
    totalCents: v.totalCents,
    pago: v.pago,
    pagoLabel: v.pago === "combinado" ? "Combinado" : pagoLabel(v.pago),
    pagos: Array.isArray(v.pagos) ? v.pagos.map((p) => ({ metodo: p.metodo, label: pagoLabel(p.metodo), montoCents: p.montoCents })) : undefined,
    recibidoCents: v.recibidoCents,
    efectivoRecibidoCents: v.recibidoCents,
    cambioCents: v.cambioCents || 0,
    abrirCajon: false,
    reimpresion: true,
    saldoClienteCents: String(v.pago || "").toLowerCase() === "credito" ? saldoClienteCents : undefined
  };
}

async function reimprimirTicketFlujo(folioPre) {
  if (!tienenDB()) return alert("Reimpresión no disponible.");
  let folio = folioPre;
  if (folio == null) {
    const val = await pedirValorModal({ titulo: "Reimprimir ticket", label: "Folio del ticket", tipo: "number", okLabel: "Buscar" });
    if (val == null || val === "") return;
    folio = parseInt(val, 10);
  }
  const v = await window.api.db.getVentaPorFolio(folio);
  if (!v) return alert("No se encontró una venta con ese folio.");
  await mostrarTicket(ticketDesdeVenta(v), { modo: CFG && CFG.impresora ? CFG.impresora.modo : "off", reimpresion: true });
}

// Ventana de ventas y devoluciones por día (calendario). Permite reimprimir
// cualquier ticket y cancelar (anular) una venta hecha por error.
// Ventana emergente estilo ELEVENTA: "Historial de ventas".
// Panel izquierdo con la lista de tickets del día; panel derecho con el
// detalle del ticket seleccionado y la acción "Devolver artículo seleccionado".
async function abrirHistorialTickets(fecha) {
  if (!tienenDB()) return alert("Historial no disponible.");
  let dia = fecha || hoyISO();
  let data = await window.api.db.ventasDelDia(dia);

  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--historial hist2">
      <div class="hist2__head">
        <h3>🧾 Historial de ventas</h3>
        <div class="hist2__tools">
          <label class="hist-fecha">Del día <input type="date" id="hist-dia" max="${hoyISO()}" /></label>
          <button class="btn btn--sec" id="hist-hoy">Hoy</button>
          <button class="btn btn--sec" id="hist-print-dia" title="Imprime el listado del día (no reimprime cada ticket)">🖨️ Imprimir día</button>
          <button class="iconbtn" data-cerrar="1" title="Cerrar">✕</button>
        </div>
      </div>
      <div class="hist2__body">
        <div class="hist2__list">
          <input type="search" id="hist-buscar" class="mv-search" placeholder="Buscar por folio o total…" autocomplete="off" />
          <div class="hist2__list-wrap hist-scroll">
            <table class="mv-table hist2__table">
              <thead><tr><th>Folio</th><th class="num">Arts</th><th>Hora</th><th class="num">Total</th></tr></thead>
              <tbody id="hist-filas"></tbody>
            </table>
          </div>
          <div class="hist2__resumen">
            Ventas <b>${data.numVentas}</b> · Total <b>${fmt(data.totalVentasCents)}</b>
            · Devoluciones <b class="neg">-${fmt(data.totalDevolucionesCents)}</b>
          </div>
        </div>
        <div class="hist2__detail" id="hist-detalle">
          <div class="empty-state"><span>🧾</span><p>Selecciona un ticket de la izquierda para ver su detalle.</p></div>
        </div>
      </div>
      <div class="modal__foot">
        <span class="qty-hint">Imprimir día = un solo listado del historial. Imprimir copia = ticket individual. Cancelar anula la venta completa. Devolver artículo requiere caja abierta.</span>
        <button class="btn" data-cerrar="1">Cerrar</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar !== undefined) cerrar(); });
  const diaInp = $("#hist-dia", back);
  diaInp.value = dia;
  diaInp.addEventListener("change", (e) => { const nd = e.target.value; if (nd) recargar(nd); });
  $("#hist-hoy", back).addEventListener("click", () => recargar(hoyISO()));
  $("#hist-print-dia", back).addEventListener("click", () => imprimirHistorialDiaFlujo(data));

  const filasBox = $("#hist-filas", back);
  const buscar = $("#hist-buscar", back);
  const detalle = $("#hist-detalle", back);
  let seleccion = null;
  let lineaSel = null;

  async function recargar(nd) {
    dia = nd; diaInp.value = nd;
    data = await window.api.db.ventasDelDia(nd);
    seleccion = null; lineaSel = null;
    detalle.innerHTML = '<div class="empty-state"><span>🧾</span><p>Selecciona un ticket de la izquierda para ver su detalle.</p></div>';
    const r = $(".hist2__resumen", back);
    if (r) r.innerHTML = `Ventas <b>${data.numVentas}</b> · Total <b>${fmt(data.totalVentasCents)}</b> · Devoluciones <b class="neg">-${fmt(data.totalDevolucionesCents)}</b>`;
    pintarLista();
  }

  function pintarLista() {
    const q = buscar.value || "";
    const ventas = (data.ventas || []).filter((v) =>
      coincideFolioOTotal(q, [v.folio, v.basculaFolio], v.totalCents, [v.cliente]));
    const devs = (data.devoluciones || []).filter((d) =>
      coincideFolioOTotal(q, [d.folio, d.ventaFolio], d.totalCents, [d.motivo]));
    const filasV = ventas.map((v) => `
      <tr class="hist2__row ${v.cancelada ? "row-cancel" : ""} ${seleccion && seleccion.tipo === "venta" && seleccion.folio === v.folio ? "is-sel" : ""}" data-tipo="venta" data-fol="${v.folio}">
        <td>#${v.folio}${v.basculaFolio != null ? ` <span class="tag tag--bascula">⚖️${escapeHtml(String(v.basculaFolio))}</span>` : ""}${v.cancelada ? ' <span class="tag tag--cancel">CANC</span>' : ""}${v.apartado ? ' <span class="tag">APART</span>' : ""}</td>
        <td class="num">${v.numItems != null ? v.numItems : ""}</td>
        <td>${v.hora}</td>
        <td class="num">${fmt(v.totalCents)}</td>
      </tr>`);
    const filasD = devs.map((d) => `
      <tr class="hist2__row ${seleccion && seleccion.tipo === "dev" && seleccion.folio === d.folio ? "is-sel" : ""}" data-tipo="dev" data-fol="${d.folio}">
        <td>#${d.folio} <span class="tag">DEV</span>${d.ventaFolio ? ` <small class="muted">(venta #${escapeHtml(String(d.ventaFolio))})</small>` : ""}</td>
        <td class="num">${d.numItems != null ? d.numItems : ""}</td>
        <td>${d.hora}</td>
        <td class="num neg">- ${fmt(d.totalCents)}</td>
      </tr>`);
    const all = filasV.concat(filasD);
    filasBox.innerHTML = all.length ? all.join("") : `<tr><td colspan="4" class="muted">${String(q).trim() ? "Sin resultados." : "Sin ventas ni devoluciones este día."}</td></tr>`;
    $$(".hist2__row", filasBox).forEach((r) => r.addEventListener("click", () => seleccionar(r.dataset.tipo, +r.dataset.fol)));
  }

  async function seleccionar(tipo, folio) {
    seleccion = { tipo: tipo || "venta", folio }; lineaSel = null;
    $$(".hist2__row", filasBox).forEach((r) => r.classList.toggle("is-sel", r.dataset.tipo === seleccion.tipo && +r.dataset.fol === folio));
    if (seleccion.tipo === "dev") {
      const d = (data.devoluciones || []).find((x) => x.folio === folio);
      if (!d) { detalle.innerHTML = '<div class="empty-state"><span>⚠️</span><p>No se pudo cargar la devolución.</p></div>'; return; }
      pintarDetalleDev(d);
      return;
    }
    const v = await window.api.db.getVentaPorFolio(folio);
    if (!v) { detalle.innerHTML = '<div class="empty-state"><span>⚠️</span><p>No se pudo cargar el ticket.</p></div>'; return; }
    pintarDetalle(v);
  }

  function pintarDetalle(v) {
    const cli = (v.cliente && typeof v.cliente === "object") ? (v.cliente.nombre || "Público en general") : (v.cliente || "Público en general");
    const fechaTxt = v.fecha ? new Date(v.fecha).toLocaleString("es-MX") : "";
    const items = v.items || [];
    const filas = items.map((it, i) => `
      <tr class="hist2__iitem ${lineaSel === i ? "is-sel" : ""}" data-idx="${i}">
        <td class="num">${fmtCant(it.cant, it.unidad)}</td>
        <td>${escapeHtml(it.nombre)}${it.tipo === "paquete" ? ' <span class="tag">PAQUETE</span>' : ""}</td>
        <td class="num">${fmt(it.importeCents)}</td>
      </tr>`).join("") || `<tr><td colspan="3" class="muted">Ticket sin artículos.</td></tr>`;
    detalle.innerHTML = `
      <div class="hist2__d-head">
        <h4>Ticket · Folio ${escapeHtml(String(v.folio))}</h4>
        ${v.cancelada ? '<span class="tag tag--cancel">CANCELADA</span>' : ""}
      </div>
      <div class="hist2__d-meta">
        <div><span>Cajero:</span> <b>${escapeHtml(v.usuario || "—")}</b></div>
        <div><span>Cliente:</span> <b>${escapeHtml(cli)}</b></div>
        <div><span>Fecha:</span> <b>${escapeHtml(fechaTxt)}</b></div>
        ${v.origenBascula ? `<div class="hist2__bascula"><span>⚖️ Ticket báscula:</span> <b>Folio ${escapeHtml(String(v.origenBascula.folio))}${v.origenBascula.nserie ? " · serie " + escapeHtml(String(v.origenBascula.nserie)) : ""}</b></div>` : ""}
      </div>
      <div class="mv-table-wrap hist2__d-items hist-scroll">
        <table class="mv-table">
          <thead><tr><th class="num">Cant.</th><th>Descripción</th><th class="num">Importe</th></tr></thead>
          <tbody id="hist-items">${filas}</tbody>
        </table>
      </div>
      <div class="hist2__d-tot">
        <div><span>Pago:</span> <b>${pagoEmoji(v.pago)} ${escapeHtml(pagoLabel(v.pago))}</b></div>
        <div class="hist2__d-total"><span>Total</span> <b>${fmt(v.totalCents)}</b></div>
      </div>
      <div class="hist2__d-acts">
        <button class="btn btn--sec" id="hist-devart" ${v.cancelada ? "disabled" : ""}>↩️ Devolver artículo seleccionado</button>
        <button class="btn btn--sec" id="hist-reimp">🖨️ Imprimir copia</button>
        <button class="btn btn--danger" id="hist-cancel" ${v.cancelada ? "disabled" : ""}>✕ Cancelar venta</button>
      </div>`;

    $$("#hist-items .hist2__iitem", detalle).forEach((r) => r.addEventListener("click", () => {
      lineaSel = +r.dataset.idx;
      $$("#hist-items .hist2__iitem", detalle).forEach((x) => x.classList.toggle("is-sel", +x.dataset.idx === lineaSel));
    }));

    $("#hist-reimp", detalle).addEventListener("click", () => reimprimirTicketFlujo(v.folio));

    const bCancel = $("#hist-cancel", detalle);
    if (bCancel && !v.cancelada) bCancel.addEventListener("click", () => {
      pedirTexto({ titulo: "Cancelar venta #" + v.folio, label: "Motivo (opcional)", placeholder: "Ej. error de captura" }, async (motivo) => {
        if (!confirm(`¿Cancelar (anular) la venta #${v.folio}?\nLos productos con inventario regresarán a existencias y la venta se excluirá del corte.`)) return;
        const r = await window.api.db.cancelarVenta(v.folio, usuarioActual ? usuarioActual.nombre : null, motivo);
        if (r && r.error) return alert(r.error);
        await refreshCajaStatus();
        await recargar(dia);
      });
    });

    const bDev = $("#hist-devart", detalle);
    if (bDev && !v.cancelada) bDev.addEventListener("click", () => {
      if (lineaSel == null) return alert("Selecciona primero el artículo que deseas devolver (haz clic sobre su renglón).");
      const it = items[lineaSel];
      if (!it) return;
      pedirTexto({ titulo: "Devolver: " + it.nombre, label: "Motivo (opcional)", placeholder: "Ej. producto en mal estado" }, async (motivo) => {
        if (!confirm(`¿Devolver ${fmtCant(it.cant, it.unidad)} ${it.unidad || ""} de "${it.nombre}" por ${fmt(it.importeCents)}?`)) return;
        const dev = {
          usuario: usuarioActual ? usuarioActual.nombre : null,
          pago: v.pago || "efectivo",
          motivo: motivo || "",
          ventaFolio: v.folio,
          items: [{
            tipo: it.tipo, productoId: it.productoId, nombre: it.nombre,
            cant: it.cant, unidad: it.unidad, precioCents: it.precioCents, importeCents: it.importeCents
          }],
          totalCents: it.importeCents
        };
        const r = await window.api.db.registrarDevolucion(dev);
        if (r && r.error) return alert(r.error);
        await refreshCajaStatus();
        alert(`↩️ Devolución registrada (folio ${r.folio}).`);
        await recargar(dia);
      });
    });
  }

  function pintarDetalleDev(d) {
    detalle.innerHTML = `
      <div class="hist2__d-head">
        <h4>Devolución · Folio ${escapeHtml(String(d.folio))}</h4>
        <span class="tag">DEV</span>
      </div>
      <div class="hist2__d-meta">
        <div><span>Venta:</span> <b>${d.ventaFolio != null ? "#" + escapeHtml(String(d.ventaFolio)) : "—"}</b></div>
        <div><span>Hora:</span> <b>${escapeHtml(d.hora || "")}</b></div>
        <div><span>Pago:</span> <b>${pagoEmoji(d.pago)} ${escapeHtml(pagoLabel(d.pago))}</b></div>
        <div><span>Motivo:</span> <b>${escapeHtml(d.motivo || "—")}</b></div>
      </div>
      <div class="hist2__d-tot">
        <div class="hist2__d-total"><span>Total devuelto</span> <b class="neg">- ${fmt(d.totalCents)}</b></div>
      </div>`;
  }

  buscar.addEventListener("input", pintarLista);
  pintarLista();
  setTimeout(() => buscar.focus(), 40);
}

// Crédito a clientes (fiado). Ventana emergente estilo ELEVENTA, adaptada:
// los clientes se toman de la ventana de Clientes (solo buscador aquí), sin
// fechas ni plazos: cargos (fiado), abonos, liquidación o cancelación del
// adeudo, e impresión de estado de cuenta / liquidación.
async function abrirCreditos() {
  await cargarClientes();
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--historial hist2 creditos">
      <div class="hist2__head">
        <h3>💳 Crédito a clientes</h3>
        <div class="hist2__tools"><button class="iconbtn" data-cerrar="1" title="Cerrar">✕</button></div>
      </div>
      <div class="hist2__body">
        <div class="hist2__list">
          <input type="search" id="cr-buscar" class="mv-search" placeholder="Buscar cliente por nombre…" autocomplete="off" />
          <div class="hist2__list-wrap hist-scroll">
            <table class="mv-table hist2__table">
              <thead><tr><th>Cliente</th><th class="num">Saldo</th></tr></thead>
              <tbody id="cr-filas"></tbody>
            </table>
          </div>
          <div class="hist2__resumen" id="cr-resumen"></div>
        </div>
        <div class="hist2__detail" id="cr-detalle">
          <div class="empty-state"><span>💳</span><p>Busca y elige un cliente para ver su estado de cuenta.</p></div>
        </div>
      </div>
      <div class="modal__foot">
        <span class="qty-hint">Los clientes se administran en la ventana de Clientes. Aquí: cargo (fiado), abono, liquidar o cancelar el adeudo.</span>
        <button class="btn" data-cerrar="1">Cerrar</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar !== undefined) cerrar(); });

  const filasBox = $("#cr-filas", back);
  const buscar = $("#cr-buscar", back);
  const detalle = $("#cr-detalle", back);
  let seleccion = null;
  let movSelIdx = null; // índice en c.movimientos (orden original) del movimiento a cancelar
  const clienteSel = () => (DATA.clientes || []).find((x) => x.id === seleccion);

  function pintarResumen() {
    const deudores = (DATA.clientes || []).filter((c) => (c.saldoCents || 0) > 0);
    const total = deudores.reduce((s, c) => s + (c.saldoCents || 0), 0);
    $("#cr-resumen", back).innerHTML = `Deudores <b>${deudores.length}</b> · Adeudo total <b class="neg">${fmt(total)}</b>`;
  }

  function pintarLista() {
    const q = (buscar.value || "").trim().toLowerCase();
    let lista = (DATA.clientes || []).slice().sort((a, b) => {
      const sa = (a.saldoCents || 0) > 0 ? 0 : 1, sb = (b.saldoCents || 0) > 0 ? 0 : 1;
      if (sa !== sb) return sa - sb; // deudores primero
      return a.nombre.localeCompare(b.nombre);
    });
    if (q) lista = lista.filter((c) => (c.nombre + " " + (c.telefono || "")).toLowerCase().includes(q));
    filasBox.innerHTML = lista.length ? lista.map((c) => `
      <tr class="hist2__row ${seleccion === c.id ? "is-sel" : ""}" data-cli="${c.id}">
        <td>👤 ${escapeHtml(c.nombre)}</td>
        <td class="num ${(c.saldoCents || 0) > 0 ? "neg" : ""}">${(c.saldoCents || 0) > 0 ? fmt(c.saldoCents) : "—"}</td>
      </tr>`).join("") : `<tr><td colspan="2" class="muted">Sin clientes. Créalos en la ventana de Clientes.</td></tr>`;
    $$(".hist2__row", filasBox).forEach((r) => r.addEventListener("click", () => seleccionar(+r.dataset.cli)));
  }

  function seleccionar(id) {
    seleccion = id;
    movSelIdx = null;
    $$(".hist2__row", filasBox).forEach((r) => r.classList.toggle("is-sel", +r.dataset.cli === id));
    pintarDetalle();
  }

  async function pintarDetalle() {
    const c = clienteSel();
    if (!c) { detalle.innerHTML = '<div class="empty-state"><span>💳</span><p>Elige un cliente.</p></div>'; return; }
    const saldo = c.saldoCents || 0;
    const desde = await window.api.db.getHistorialPantallaDesde(c.id);
    const movs = filtrarMovsPantalla((c.movimientos || []).map((m, idx) => ({ ...m, _idx: idx })), desde).slice().reverse();
    const filas = movs.map((m) => `
      <tr class="hist2__iitem ${movSelIdx === m._idx ? "is-sel" : ""}" data-idx="${m._idx}">
        <td class="muted">${new Date(m.fecha).toLocaleString("es-MX")}</td>
        <td>${m.tipo === "abono" ? "⬇ Abono" : m.tipo === "cancelacion" ? "✖ Cancelación" : "⬆ Cargo"}</td>
        <td>${escapeHtml(m.nota || "")}${m.ventaFolio != null ? ` <small class="muted">#${m.ventaFolio}</small>` : ""}</td>
        <td class="num ${m.tipo === "cargo" ? "neg" : ""}">${m.tipo === "cargo" ? "+" : "-"} ${fmt(m.montoCents)}</td>
        <td class="num">${fmt(m.saldoCents)}</td>
      </tr>`).join("") || `<tr><td colspan="5" class="muted">Sin movimientos de crédito.</td></tr>`;
    detalle.innerHTML = `
      <div class="cr-edo">
        <div class="cr-edo__cli">👤 ${escapeHtml(c.nombre)}${c.telefono ? ` · ${escapeHtml(c.telefono)}` : ""}</div>
        <div class="cr-edo__saldo"><span>Saldo actual</span><b class="${saldo > 0 ? "neg" : ""}">${fmt(saldo)}</b></div>
      </div>
      <div class="cr-acts">
        <button class="btn btn--sec" id="cr-cargo">➕ Nuevo cargo (fiado)</button>
        <button class="btn btn--primary" id="cr-abono" ${saldo > 0 ? "" : "disabled"}>⬇ Abonar</button>
        <button class="btn btn--sec" id="cr-liquidar" ${saldo > 0 ? "" : "disabled"}>✅ Liquidar</button>
        <button class="btn btn--sec" id="cr-limpiar-hist" title="Oculta abonos viejos en pantalla; siguen en Supabase">🧹 Limpiar historial</button>
        <button class="btn btn--danger" id="cr-cancelar">✖ Cancelar…</button>
      </div>
      <p class="qty-hint" style="margin:6px 0 0">Elige un movimiento en la tabla y cancélalo. No se cancela toda la cuenta, solo ese renglón.${desde ? " Abonos viejos ocultos en pantalla." : ""}</p>
      <div class="mv-table-wrap hist2__d-items hist-scroll">
        <table class="mv-table">
          <thead><tr><th>Fecha</th><th>Tipo</th><th>Concepto</th><th class="num">Monto</th><th class="num">Saldo</th></tr></thead>
          <tbody id="cr-movs">${filas}</tbody>
        </table>
      </div>
      <div class="cr-print">
        <button class="btn btn--sec" id="cr-ver-edo">👁 Ver estado de cuenta</button>
        <button class="btn btn--sec" id="cr-print-edo">🖨️ Imprimir estado de cuenta</button>
        <button class="btn btn--sec" id="cr-print-liq" ${saldo > 0 ? "" : "disabled"}>🖨️ Imprimir liquidación</button>
      </div>`;
    $("#cr-cargo", detalle).addEventListener("click", () => movCredito(c, "cargo"));
    const bAb = $("#cr-abono", detalle); if (bAb && saldo > 0) bAb.addEventListener("click", async () => {
      const estado = await window.api.db.estadoCuentaCliente(c.id);
      if (!estado || estado.error) return alert((estado && estado.error) || "No se pudo cargar el estado de cuenta.");
      abrirAbonoCredito(estado, null, null, () => refrescar());
    });
    const bLiq = $("#cr-liquidar", detalle); if (bLiq && saldo > 0) bLiq.addEventListener("click", () => liquidar(c));
    $("#cr-limpiar-hist", detalle).addEventListener("click", async () => {
      if (!confirm(`¿Limpiar en pantalla el historial de abonos de "${c.nombre}"?\n\nSolo se ocultan en esta PC. El saldo no cambia y los abonos siguen guardados en Supabase.`)) return;
      const r = await window.api.db.limpiarHistorialPantallaCliente(c.id);
      if (r && r.error) return alert(r.error);
      movSelIdx = null;
      pintarDetalle();
    });
    $("#cr-cancelar", detalle).addEventListener("click", () => cancelarMovimientoSeleccionado(c));
    const abrirEdo = async (soloVer) => {
      const estado = await window.api.db.estadoCuentaCliente(c.id);
      if (!estado || estado.error) return alert((estado && estado.error) || "No se pudo cargar el estado de cuenta.");
      if (soloVer) verEstadoDeCuenta(estado);
      else imprimirEstadoDeCuenta(estado);
    };
    $("#cr-ver-edo", detalle).addEventListener("click", () => abrirEdo(true));
    $("#cr-print-edo", detalle).addEventListener("click", () => abrirEdo(false));
    const bpl = $("#cr-print-liq", detalle); if (bpl && saldo > 0) bpl.addEventListener("click", () => imprimirLiquidacion(c, saldo));
    $$("#cr-movs .hist2__iitem", detalle).forEach((r) => r.addEventListener("click", () => {
      movSelIdx = +r.dataset.idx;
      $$("#cr-movs .hist2__iitem", detalle).forEach((x) => x.classList.toggle("is-sel", +x.dataset.idx === movSelIdx));
    }));
  }

  async function refrescar() {
    await cargarClientes();
    pintarLista(); pintarResumen();
    pintarDetalle();
  }

  // Modal reutilizable para capturar monto + nota (aceptar / cerrar en X).
  function pedirMontoNota(o, cb) {
    const b2 = document.createElement("div");
    b2.className = "modal-back";
    b2.innerHTML = `
      <div class="modal modal--qty">
        <div class="hist2__head" style="margin-bottom:6px"><h3 style="margin:0">${escapeHtml(o.titulo)}</h3>
          <button class="iconbtn" data-cerrar="1" title="Cerrar">✕</button></div>
        ${o.sub ? `<p class="sub">${o.sub}</p>` : ""}
        <div class="qty-field"><label>Monto</label><input type="number" min="0" step="0.01" id="cm-monto" placeholder="0.00" /></div>
        <div class="qty-field"><label>Concepto / nota (opcional)</label><input type="text" id="cm-nota" placeholder="${attr(o.ph || "")}" /></div>
        <p class="qty-hint" id="cm-msg"></p>
        <div class="modal__foot">
          <button class="btn" data-cerrar="1">Cerrar</button>
          <button class="btn btn--primary" id="cm-ok">${escapeHtml(o.okLabel || "Guardar")}</button>
        </div>
      </div>`;
    document.body.appendChild(b2);
    const cerrar2 = () => b2.remove();
    b2.addEventListener("click", (e) => { if (e.target === b2 || e.target.dataset.cerrar !== undefined) cerrar2(); });
    const ok = async () => {
      const monto = Money.toCents(parseFloat(($("#cm-monto", b2).value || "").replace(",", ".")) || 0) || 0;
      if (monto <= 0) { $("#cm-msg", b2).innerHTML = '<span class="tk-warn">Escribe un monto mayor a cero.</span>'; return; }
      await cb(monto, $("#cm-nota", b2).value.trim(), cerrar2);
    };
    $("#cm-ok", b2).addEventListener("click", ok);
    const mi = $("#cm-monto", b2);
    mi.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); ok(); } });
    setTimeout(() => mi.focus(), 30);
  }

  function movCredito(c, tipo) {
    const abono = tipo === "abono";
    pedirMontoNota({
      titulo: abono ? "Registrar abono" : "Nuevo cargo (fiado)",
      sub: `${escapeHtml(c.nombre)} · Saldo actual: <b>${fmt(c.saldoCents || 0)}</b>`,
      ph: abono ? "Ej. abono en efectivo" : "Ej. fiado de la semana",
      okLabel: abono ? "Registrar abono" : "Registrar cargo"
    }, async (monto, nota, cerrar2) => {
      let fp = "efectivo";
      if (abono) {
        fp = await elegirFormaLiquidacion(c.nombre, monto);
        if (!fp) return;
        const sigue = await confirmarDatos("Confirmar abono", [
          { etiqueta: "Cliente", valor: c.nombre },
          { etiqueta: "Saldo actual", valor: fmt(c.saldoCents || 0) },
          { etiqueta: "Abono", valor: fmt(monto) },
          { etiqueta: "Forma de pago", valor: etiquetaFormaPago(fp) },
          { etiqueta: "Nota", valor: nota || "—" },
          { etiqueta: "Saldo que queda", valor: fmt(Math.max(0, (c.saldoCents || 0) - monto)) }
        ]);
        if (!sigue) return;
      }
      const r = await window.api.db.movimientoCredito(c.id, tipo, monto, nota, usuarioActual ? usuarioActual.nombre : null, abono ? fp : undefined);
      if (r && r.error) return alert(r.error);
      cerrar2();
      await refrescar();
    });
  }

  async function liquidar(c) {
    const saldo = c.saldoCents || 0;
    if (saldo <= 0) return;
    const fp = await elegirFormaLiquidacion(c.nombre, saldo);
    if (!fp) return;
    if (fp !== "efectivo_casa") {
      const st = await window.api.db.estadoCaja();
      if (!st || !st.abierta) return alert("Abre la caja. Así la liquidación entra al corte de hoy.");
    }
    const sigue = await confirmarDatos("Confirmar liquidación", [
      { etiqueta: "Cliente", valor: c.nombre },
      { etiqueta: "Se liquida", valor: fmt(saldo) },
      { etiqueta: "Forma de pago", valor: etiquetaFormaPago(fp) },
      { etiqueta: "Saldo que queda", valor: fmt(0) }
    ]);
    if (!sigue) return;
    const r = await window.api.db.abonarCredito(c.id, saldo, {
      destino: "todas", comentario: "Liquidación de adeudo", formaPago: fp,
      usuario: usuarioActual ? usuarioActual.nombre : null
    });
    if (r && r.error) return alert(r.error);
    await refrescar();
    if (confirm("Adeudo liquidado. ¿Imprimir comprobante de liquidación?")) imprimirLiquidacion(c, saldo, fp);
  }

  async function cancelarMovimientoSeleccionado(c) {
    if (movSelIdx == null) return alert("Selecciona primero el movimiento (haz clic en su renglón).");
    const m = (c.movimientos || [])[movSelIdx];
    if (!m) return alert("Movimiento no encontrado.");
    const folio = m.ventaFolio != null ? "#" + m.ventaFolio : "#" + (movSelIdx + 1);
    const alcance = await elegirAlcanceCancelacion({
      titulo: "Cancelar crédito",
      notaLabel: (m.tipo === "cargo" ? "Cargo " : m.tipo === "abono" ? "Abono " : "Mov. ") + folio,
      notaMonto: m.montoCents,
      cuentaLabel: c.nombre,
      cuentaMonto: c.saldoCents || 0
    });
    if (!alcance) return;
    if (alcance === "nota") {
      const et = m.tipo === "cargo" ? "este cargo" : m.tipo === "abono" ? "este abono" : "esta cancelación";
      if (!confirm(`¿Confirmar: cancelar SOLO ${et} ${folio} por ${fmt(m.montoCents)}?`)) return;
      const r = await window.api.db.cancelarMovimientoCredito(c.id, movSelIdx);
      if (r && r.error) return alert(r.error);
    } else {
      const saldo = c.saldoCents || 0;
      if (saldo <= 0) return alert("No hay saldo por cancelar.");
      if (!confirm(`¿Confirmar: cancelar TODA la cuenta de "${c.nombre}" por ${fmt(saldo)}?`)) return;
      const r = await window.api.db.movimientoCredito(c.id, "cancelacion", saldo, "Cancelación de cuenta completa", usuarioActual ? usuarioActual.nombre : null);
      if (r && r.error) return alert(r.error);
    }
    movSelIdx = null;
    await refrescar();
  }

  function imprimirLiquidacion(c, monto, formaPago) {
    const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
    const lr = (a, b) => { const s = cols - a.length - b.length; return s >= 1 ? a + " ".repeat(s) + b : (a + " " + b); };
    const m = monto != null ? monto : (c.saldoCents || 0);
    const fpTxt = formaPago ? etiquetaFormaPago(formaPago) : "";
    const L = [];
    L.push("Cliente: " + (c.nombre || ""));
    L.push("Fecha: " + new Date().toLocaleString("es-MX"));
    if (usuarioActual) L.push("Atiende: " + usuarioActual.nombre);
    L.push("-".repeat(cols));
    if (fpTxt) L.push(lr("Forma de pago", fpTxt));
    L.push(lr("Adeudo liquidado", fmt(m)));
    L.push(lr("Saldo restante", fmt(c.saldoCents || 0)));
    L.push("-".repeat(cols));
    L.push("Gracias por su pago.");
    imprimirListaFlujo("LIQUIDACION DE CREDITO", L);
  }

  buscar.addEventListener("input", pintarLista);
  pintarLista();
  pintarResumen();
  // Preselecciona el cliente del ticket activo si tiene uno asignado.
  if (clienteActual && clienteActual !== CLIENTE_DEFAULT) {
    const match = (DATA.clientes || []).find((x) => x.nombre === clienteActual);
    if (match) seleccionar(match.id);
  }
  setTimeout(() => buscar.focus(), 40);
}

/* ================= Crédito a clientes (módulo dedicado, estilo ELEVENTA) =========
   Pestaña propia del menú superior. Dos vistas: "Estado de Cuenta" (movimientos de
   un cliente con saldo corrido, abonos por venta o repartidos, liquidar, imprimir)
   y "Reporte de Saldos" (todos los clientes con adeudo). La lista de Clientes sigue
   siendo la base de datos de donde se eligen. ============================== */
const _creditoSel = { lado: "clientes", subvista: "estado", clienteId: null, provNombre: null, movSel: null, grupoDia: null, diasAbiertos: {}, periodo: "liquidacion", diaSel: "", rangoDesde: "", rangoHasta: "" };

function credIniciales(nombre) {
  const p = String(nombre || "").trim().split(/\s+/).filter(Boolean);
  return ((p[0] || "").charAt(0) + (p[1] || "").charAt(0)).toUpperCase() || "?";
}

async function renderCreditos(body) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>💳</span><p>Sin base de datos disponible.</p></div>'; return; }
  await cargarClientes();
  const clientes = _creditoSel.lado !== "proveedores";
  body.innerHTML = `
    <div class="cred-wrap">
      <div class="cred-head">
        <h2 class="cred-title">${clientes ? "CRÉDITO A CLIENTES" : "CRÉDITO A PROVEEDORES"}</h2>
        <div class="cred-tabs">
          <button class="cred-tab ${_creditoSel.lado !== "proveedores" ? "is-active" : ""}" data-lado="clientes">👤 Clientes (nos deben)</button>
          <button class="cred-tab ${_creditoSel.lado === "proveedores" ? "is-active" : ""}" data-lado="proveedores">📒 Proveedores (debemos)</button>
        </div>
        <div class="cred-tabs">
          <button class="cred-tab ${_creditoSel.subvista === "estado" ? "is-active" : ""}" data-sub="estado">🧾 Estado de Cuenta</button>
          <button class="cred-tab ${_creditoSel.subvista === "saldos" ? "is-active" : ""}" data-sub="saldos">📊 Reporte de Saldos</button>
        </div>
      </div>
      <div id="cred-body"></div>
    </div>`;
  $$("[data-lado]", body).forEach((b) => b.addEventListener("click", () => { _creditoSel.lado = b.dataset.lado; renderCreditos(body); }));
  $$("[data-sub]", body).forEach((b) => b.addEventListener("click", () => { _creditoSel.subvista = b.dataset.sub; renderCreditos(body); }));
  const cb = $("#cred-body", body);
  if (!clientes) return renderCreditosProveedor(cb, body);
  if (_creditoSel.subvista === "saldos") renderReporteSaldos(cb, body);
  else renderEstadoCuenta(cb, body);
}

// Filtra movimientos (en orden cronológico) según el periodo seleccionado.
function credFiltrarMovs(movs, periodo) {
  if (periodo === "siempre" || !periodo) return movs.slice();
  if (periodo === "liquidacion") {
    let start = 0;
    for (let i = 0; i < movs.length; i++) if ((movs[i].saldoCents || 0) === 0) start = i + 1;
    return movs.slice(start);
  }
  if (periodo === "dia") {
    if (!_creditoSel.diaSel) return movs.slice();
    const d = new Date(_creditoSel.diaSel + "T00:00:00");
    const h = new Date(_creditoSel.diaSel + "T23:59:59");
    return movs.filter((m) => { const f = new Date(m.fecha); return f >= d && f <= h; });
  }
  if (periodo === "rango") {
    const d = _creditoSel.rangoDesde ? new Date(_creditoSel.rangoDesde + "T00:00:00") : null;
    const h = _creditoSel.rangoHasta ? new Date(_creditoSel.rangoHasta + "T23:59:59") : null;
    return movs.filter((m) => { const f = new Date(m.fecha); return (!d || f >= d) && (!h || f <= h); });
  }
  const now = new Date();
  let desde;
  if (periodo === "semana") { const d = new Date(now); const dow = (d.getDay() + 6) % 7; d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - dow); desde = d; }
  else if (periodo === "mes") desde = new Date(now.getFullYear(), now.getMonth(), 1);
  else if (periodo === "90") desde = new Date(now.getTime() - 90 * 86400000);
  else return movs.slice();
  return movs.filter((m) => new Date(m.fecha) >= desde);
}

// Etiqueta legible del periodo/rango para el encabezado impreso.
function credPeriodoLabel() {
  const p = _creditoSel.periodo;
  if (p === "siempre") return "Movimientos: todo el estado de cuenta";
  if (p === "liquidacion") return "Movimientos: desde ultima liquidacion";
  if (p === "semana") return "Movimientos: de esta semana";
  if (p === "mes") return "Movimientos: de este mes";
  if (p === "90") return "Movimientos: ultimos 90 dias";
  if (p === "dia") {
    const d = _creditoSel.diaSel ? new Date(_creditoSel.diaSel + "T00:00:00").toLocaleDateString("es-MX") : "(elige el dia)";
    return "Movimientos: solo del " + d;
  }
  if (p === "rango") {
    const d = _creditoSel.rangoDesde ? new Date(_creditoSel.rangoDesde + "T00:00:00").toLocaleDateString("es-MX") : "inicio";
    const h = _creditoSel.rangoHasta ? new Date(_creditoSel.rangoHasta + "T00:00:00").toLocaleDateString("es-MX") : "hoy";
    return `Movimientos: del ${d} al ${h}`;
  }
  return "";
}

function credBadge(tipo) {
  if (tipo === "abono") return '<span class="cred-badge cred-badge--abono">ABONO</span>';
  if (tipo === "cancelacion") return '<span class="cred-badge cred-badge--cancel">CANCEL.</span>';
  return '<span class="cred-badge cred-badge--venta">VENTA</span>';
}

// Oculta en pantalla abonos anteriores al corte visual (siguen en DB / Supabase).
function filtrarMovsPantalla(movs, desdeIso) {
  if (!desdeIso) return (movs || []).slice();
  const t = new Date(desdeIso).getTime();
  if (!Number.isFinite(t)) return (movs || []).slice();
  return (movs || []).filter((m) => {
    if (m.tipo !== "abono") return true;
    const f = new Date(m.fecha).getTime();
    return Number.isFinite(f) && f >= t;
  });
}

function vistaAbonos(movs, nombre) {
  const abonos = (movs || []).filter((m) => m.tipo === "abono");
  const total = abonos.reduce((s, m) => s + (m.montoCents || 0), 0);
  const filas = abonos.map((m) => {
    const forma = m.formaPago ? etiquetaFormaPago(m.formaPago) : "";
    const nota = m.nota || "Abono";
    return `<li><span><b>${new Date(m.fecha).toLocaleString("es-MX")}</b><small>${escapeHtml(nota)}${forma ? " · " + escapeHtml(forma) : ""}</small></span><b>${fmt(m.montoCents || 0)}</b></li>`;
  }).join("");
  return `<section class="mv-card cred-abonos">
      <h3>Abonos de ${escapeHtml(nombre || "")}</h3>
      <p class="sub">Cada pago, con su fecha. Es un dato aparte: no cambia el saldo.</p>
      ${abonos.length
        ? `<ul class="resumen-lista">${filas}</ul><p class="resumen-aviso"><b>Total de abonos ${fmt(total)}</b> · ${abonos.length} pago${abonos.length === 1 ? "" : "s"}</p>`
        : `<p class="resumen-vacio">Sin abonos en este listado.</p>`}
    </section>`;
}

async function renderEstadoCuenta(el, root) {
  const clientes = DATA.clientes || [];
  const estado = _creditoSel.clienteId != null ? await window.api.db.estadoCuentaCliente(_creditoSel.clienteId) : null;
  const cli = estado && !estado.error ? estado.cliente : null;

  el.innerHTML = `
    <div class="cred-pick">
      <span class="searchbar__icon">🔍</span>
      <input type="search" id="cred-cli-search" placeholder="Buscar cliente por nombre o teléfono…" autocomplete="off" value="${cli ? attr(cli.nombre) : ""}" />
      <div class="cred-pick__list" id="cred-cli-list" hidden></div>
    </div>
    <div id="cred-edo"></div>`;

  const search = $("#cred-cli-search", el);
  const listBox = $("#cred-cli-list", el);
  const pintarDrop = () => {
    const q = (search.value || "").trim().toLowerCase();
    let lista = clientes.slice().sort((a, b) => (b.saldoCents || 0) - (a.saldoCents || 0) || a.nombre.localeCompare(b.nombre));
    if (q) lista = lista.filter((c) => (c.nombre + " " + (c.telefono || "")).toLowerCase().includes(q));
    lista = lista.slice(0, 40);
    listBox.innerHTML = lista.length
      ? lista.map((c) => `<button class="cred-pick__item" data-cli="${c.id}">👤 ${escapeHtml(c.nombre)}${(c.saldoCents || 0) > 0 ? ` · <b class="neg">${fmt(c.saldoCents)}</b>` : ""}</button>`).join("")
      : '<div class="muted" style="padding:8px">Sin coincidencias. Crea el cliente en la pestaña Clientes.</div>';
    listBox.hidden = false;
    $$(".cred-pick__item", listBox).forEach((b) => b.addEventListener("mousedown", (e) => {
      e.preventDefault();
      _creditoSel.clienteId = +b.dataset.cli; _creditoSel.movSel = null;
      renderEstadoCuenta(el, root);
    }));
  };
  search.addEventListener("focus", pintarDrop);
  search.addEventListener("input", pintarDrop);
  search.addEventListener("blur", () => setTimeout(() => { listBox.hidden = true; }, 180));

  const edo = $("#cred-edo", el);
  if (!cli) {
    edo.innerHTML = '<div class="empty-state cred-empty"><span>💳</span><p>Busca y elige un cliente para ver su estado de cuenta.</p></div>';
    setTimeout(() => search.focus(), 30);
    return;
  }

  const saldo = estado.saldoCents || 0;
  const desdePantalla = await window.api.db.getHistorialPantallaDesde(cli.id);
  const movsCrono = filtrarMovsPantalla(estado.movimientos || [], desdePantalla);
  // Pantalla: más reciente → más antiguo. Impresión usa el orden inverso (abajo).
  const movsFiltrados = credFiltrarMovs(movsCrono, _creditoSel.periodo).slice().reverse();
  const periodos = [["dia", "Un día…"], ["liquidacion", "Desde última liquidación"], ["semana", "De esta semana"], ["mes", "De este mes"], ["90", "Últimos 90 días"], ["siempre", "De siempre (todo)"], ["rango", "Rango de fechas…"]];

  const filas = movsFiltrados.map((m) => {
    const folioTxt = m.tipo === "cargo" && m.ventaFolio != null ? "#" + m.ventaFolio : (m.tipo === "abono" || m.tipo === "cancelacion" ? "#" + (m.id + 1) : "—");
    const desc = escapeHtml(m.nota || (m.tipo === "cargo" ? "Venta a crédito" : m.tipo === "abono" ? "Abono" : "Cancelación"))
      + (m.comentario ? ` <small class="muted">· ${escapeHtml(m.comentario)}</small>` : "");
    const cargo = m.tipo === "cargo" ? fmt(m.montoCents) : "";
    const abono = (m.tipo === "abono" || m.tipo === "cancelacion") ? fmt(m.montoCents) : "";
    return `<tr class="cred-row ${_creditoSel.movSel === m.id ? "is-sel" : ""}" data-mov="${m.id}">
        <td class="muted">${new Date(m.fecha).toLocaleString("es-MX")}</td>
        <td>${folioTxt}</td>
        <td>${credBadge(m.tipo)}</td>
        <td>${desc}</td>
        <td class="num neg">${cargo}</td>
        <td class="num">${abono}</td>
        <td class="num"><b>${fmt(m.saldoCents)}</b></td>
        <td class="muted">${escapeHtml(m.usuario || "—")}</td>
      </tr>`;
  }).join("");
  const sumaCli = movsFiltrados.reduce((s, m) => {
    if (m.tipo === "cargo") s.cargos += m.montoCents || 0;
    else s.abonos += m.montoCents || 0;
    return s;
  }, { cargos: 0, abonos: 0 });
  // Al ocultar notas pagadas: fila "Saldo anterior" (lo que traían las notas
  // ocultas) debajo del movimiento más antiguo mostrado, para que el saldo
  // corrido se lea en orden. Se muestra abajo porque la vista es reciente→antiguo.
  const saldoAnteriorRow = (estado.ocultarPagadas && movsFiltrados.length)
    ? (() => {
        const o = movsFiltrados[movsFiltrados.length - 1];
        const ant = o.tipo === "cargo" ? ((o.saldoCents || 0) - (o.montoCents || 0)) : ((o.saldoCents || 0) + (o.montoCents || 0));
        return `<tr class="cred-row"><td colspan="6" class="muted"><i>Saldo anterior (notas pagadas ocultas)</i></td><td class="num"><b>${fmt(ant)}</b></td><td></td></tr>`;
      })()
    : "";
  const pieCli = movsFiltrados.length
    ? `<tr class="mv-total-row"><td colspan="4"><b>Total de ${escapeHtml(cli.nombre)}</b><div class="muted">${movsFiltrados.length} movimiento${movsFiltrados.length === 1 ? "" : "s"} (reciente → antiguo)${desdePantalla ? " · abonos viejos ocultos en pantalla" : ""}${estado.ocultarPagadas && estado.ocultadas ? ` · ${estado.ocultadas} de notas pagadas ocultas` : ""}</div></td><td class="num neg"><b>${fmt(sumaCli.cargos)}</b></td><td class="num"><b>${fmt(sumaCli.abonos)}</b></td><td colspan="2"></td></tr>`
    : (estado.ocultarPagadas
        ? `<tr><td colspan="8" class="muted" style="padding:16px">Este cliente no tiene notas pendientes (todas las pagadas están ocultas). Pulsa “Mostrar notas pagadas” para verlas.</td></tr>`
        : `<tr><td colspan="8" class="muted" style="padding:16px">Sin movimientos en el periodo seleccionado.</td></tr>`);

  edo.innerHTML = `
    <div class="cred-cli-head">
      <div class="cred-cli-id"><span class="cred-avatar">${credIniciales(cli.nombre)}</span>
        <div><b>${escapeHtml(cli.nombre)}</b>${cli.telefono ? `<small class="muted"> · ${escapeHtml(cli.telefono)}</small>` : ""}
          <div class="muted" style="font-size:12px">${cli.clienteCasa ? "🏠 Cliente casa (solo esta PC)" : (cli.creditoActivo ? "Crédito activo" : "Contado")}${cli.limiteCents ? ` · Límite ${fmt(cli.limiteCents)}` : ""}</div>
        </div>
      </div>
      <div class="cred-cli-saldo"><span>Saldo actual</span><b class="${saldo > 0 ? "neg" : "ok"}">${fmt(saldo)}</b></div>
    </div>
    <div class="cred-actions">
      <div class="cred-actions__btns">
        <button class="btn btn--primary" id="cred-abonar" ${saldo > 0 ? "" : "disabled"}>⬇ Abonar a deuda</button>
        <button class="btn btn--sec" id="cred-liquidar" ${saldo > 0 ? "" : "disabled"}>✅ Liquidar</button>
        <button class="btn btn--sec" id="cred-ver">👁 Ver estado de cuenta</button>
        <button class="btn btn--sec" id="cred-print">🖨️ Imprimir Estado de Cuenta</button>
        <button class="btn btn--sec" id="cred-limpiar-hist" title="Oculta abonos viejos en pantalla; siguen en Supabase">🧹 Limpiar historial en pantalla</button>
        <button class="btn btn--sec" id="cred-ocultar-pagadas" title="Oculta de la vista y de la impresión las notas 100% pagadas (solo en esta PC, no borra nada ni afecta Supabase). Reversible.">${estado.ocultarPagadas ? "👁 Mostrar notas pagadas" : "🧹 Ocultar notas pagadas"}</button>
        <button class="btn btn--danger" id="cred-eliminar">🗑 Eliminar cliente</button>
      </div>
      <label class="cred-filtro">Movimientos:
        <select id="cred-periodo">${periodos.map(([v, t]) => `<option value="${v}" ${_creditoSel.periodo === v ? "selected" : ""}>${t}</option>`).join("")}</select>
        ${_creditoSel.periodo === "dia" ? `<span class="cred-rango"><input type="date" id="cred-dia" value="${_creditoSel.diaSel || ""}" max="${hoyISO()}" /></span>` : ""}
        ${_creditoSel.periodo === "rango" ? `<span class="cred-rango"><input type="date" id="cred-desde" value="${_creditoSel.rangoDesde || ""}" max="${hoyISO()}" /><span>a</span><input type="date" id="cred-hasta" value="${_creditoSel.rangoHasta || ""}" max="${hoyISO()}" /></span>` : ""}
      </label>
    </div>
    <div class="cred-edo-grid">
      <div class="mv-table-wrap cred-movs">
        <table class="mv-table">
          <thead><tr><th>Fecha</th><th>Folio</th><th>Movimiento</th><th>Descripción</th><th class="num">Cargo</th><th class="num">Abono</th><th class="num">Saldo</th><th>Cajero</th></tr></thead>
          <tbody>${filas}${saldoAnteriorRow}${pieCli}</tbody>
        </table>
      </div>
      <div class="cred-detail" id="cred-detail"></div>
    </div>
    ${vistaAbonos(movsFiltrados, cli.nombre)}`;

  $("#cred-periodo", edo).addEventListener("change", (e) => { _creditoSel.periodo = e.target.value; renderEstadoCuenta(el, root); });
  const cd = $("#cred-desde", edo); if (cd) cd.addEventListener("change", (e) => { _creditoSel.rangoDesde = e.target.value; renderEstadoCuenta(el, root); });
  const ch = $("#cred-hasta", edo); if (ch) ch.addEventListener("change", (e) => { _creditoSel.rangoHasta = e.target.value; renderEstadoCuenta(el, root); });
  const cdia = $("#cred-dia", edo); if (cdia) cdia.addEventListener("change", (e) => { _creditoSel.diaSel = e.target.value; renderEstadoCuenta(el, root); });
  const ba = $("#cred-abonar", edo); if (ba && saldo > 0) ba.addEventListener("click", () => abrirAbonoCredito(estado, el, root));
  const bl = $("#cred-liquidar", edo); if (bl && saldo > 0) bl.addEventListener("click", () => liquidarCredito(estado, el, root));
  $("#cred-ver", edo).addEventListener("click", () => verEstadoDeCuenta(estado));
  $("#cred-print", edo).addEventListener("click", () => imprimirEstadoDeCuenta(estado));
  $("#cred-limpiar-hist", edo).addEventListener("click", async () => {
    if (!confirm(`¿Limpiar en pantalla el historial de abonos de "${cli.nombre}"?\n\nSolo se ocultan en esta PC. El saldo no cambia y los abonos siguen guardados en Supabase.`)) return;
    const r = await window.api.db.limpiarHistorialPantallaCliente(cli.id);
    if (r && r.error) return alert(r.error);
    _creditoSel.movSel = null;
    renderEstadoCuenta(el, root);
  });
  const bop = $("#cred-ocultar-pagadas", edo);
  if (bop) bop.addEventListener("click", async () => {
    const r = await window.api.db.setOcultarPagadasCliente(cli.id, !estado.ocultarPagadas);
    if (r && r.error) return alert(r.error);
    _creditoSel.movSel = null;
    renderEstadoCuenta(el, root);
  });
  $("#cred-eliminar", edo).addEventListener("click", async () => {
    if (saldo > 0) return alert("Este cliente tiene saldo. Liquídalo antes de eliminarlo.");
    if (!confirm(`¿Eliminar a "${cli.nombre}" de la lista?\nLas ventas ya hechas no se borran.`)) return;
    const r = await window.api.db.eliminarCliente(cli.id);
    if (r && r.error) return alert(r.error);
    DATA.clientes = r.clientes || DATA.clientes;
    _creditoSel.clienteId = null;
    _creditoSel.movSel = null;
    renderCreditos(root);
  });
  $$(".cred-row", edo).forEach((r) => r.addEventListener("click", () => { _creditoSel.movSel = +r.dataset.mov; pintarDetalle(); }));

  function pintarDetalle() {
    const box = $("#cred-detail", edo);
    $$(".cred-row", edo).forEach((r) => r.classList.toggle("is-sel", +r.dataset.mov === _creditoSel.movSel));
    const m = (estado.movimientos || []).find((x) => x.id === _creditoSel.movSel);
    if (!m) { box.innerHTML = '<div class="cred-detail__empty">Selecciona un movimiento para ver el detalle.</div>'; return; }
    box.innerHTML = `
      <div class="cred-detail__head">${credBadge(m.tipo)} <b>${m.tipo === "cargo" ? "Venta a crédito" : m.tipo === "abono" ? "Abono" : "Cancelación"}</b></div>
      <div class="cred-kv"><span>Folio</span><b>${m.tipo === "cargo" && m.ventaFolio != null ? "#" + m.ventaFolio : "#" + (m.id + 1)}</b></div>
      <div class="cred-kv"><span>Fecha</span><b>${new Date(m.fecha).toLocaleString("es-MX")}</b></div>
      <div class="cred-kv"><span>Cajero</span><b>${escapeHtml(m.usuario || "—")}</b></div>
      ${m.folios && m.folios.length ? `<div class="cred-kv"><span>Ventas</span><b>#${m.folios.join(", ")}</b></div>` : ""}
      <div class="cred-kv"><span>Descripción</span><b>${escapeHtml(m.nota || "—")}</b></div>
      ${m.comentario ? `<div class="cred-kv"><span>Comentario</span><b>${escapeHtml(m.comentario)}</b></div>` : ""}
      <div class="cred-kv cred-kv--total"><span>Total</span><b class="${m.tipo === "cargo" ? "neg" : ""}">${m.tipo === "cargo" ? "+" : "-"} ${fmt(m.montoCents)}</b></div>
      <div class="cred-kv"><span>Forma de pago</span><b>${(m.formaPago || "—").toString().toUpperCase()}</b></div>
      <div class="cred-detail__acts">
        <button class="btn btn--sec" id="cred-reimp">🖨️ Re-imprimir</button>
        <button class="btn btn--danger" id="cred-cancel">✖ Cancelar…</button>
      </div>`;
    $("#cred-reimp", box).addEventListener("click", () => imprimirMovimientoCredito(cli, m));
    $("#cred-cancel", box).addEventListener("click", async () => {
      const folio = m.ventaFolio != null ? "#" + m.ventaFolio : "#" + (m.id + 1);
      const alcance = await elegirAlcanceCancelacion({
        titulo: "Cancelar crédito",
        notaLabel: (m.tipo === "cargo" ? "Cargo " : m.tipo === "abono" ? "Abono " : "Mov. ") + folio,
        notaMonto: m.montoCents,
        cuentaLabel: cli.nombre,
        cuentaMonto: estado.saldoCents || 0
      });
      if (!alcance) return;
      if (alcance === "nota") {
        const et = m.tipo === "cargo" ? "esta venta a crédito" : m.tipo === "abono" ? "este abono" : "esta cancelación";
        if (!confirm(`¿Confirmar: cancelar SOLO ${et} ${folio} por ${fmt(m.montoCents)}?\nEl resto de la cuenta se mantiene.`)) return;
        const r = await window.api.db.cancelarMovimientoCredito(cli.id, m.id);
        if (r && r.error) return alert(r.error);
      } else {
        const saldo = estado.saldoCents || 0;
        if (saldo <= 0) return alert("No hay saldo por cancelar en la cuenta.");
        if (!confirm(`¿Confirmar: cancelar TODA la cuenta de "${cli.nombre}" por ${fmt(saldo)}?\nEl saldo quedará en $0.00 (NO es un pago).`)) return;
        const r = await window.api.db.movimientoCredito(cli.id, "cancelacion", saldo, "Cancelación de cuenta completa", usuarioActual ? usuarioActual.nombre : null);
        if (r && r.error) return alert(r.error);
      }
      _creditoSel.movSel = null;
      await cargarClientes();
      renderEstadoCuenta(el, root);
    });
  }
  if (_creditoSel.movSel != null) pintarDetalle(); else $("#cred-detail", edo).innerHTML = '<div class="cred-detail__empty">Selecciona un movimiento para ver el detalle.</div>';
}

function etiquetaFormaPago(fp) {
  const id = String(fp || "").toLowerCase();
  if (id === "tarjeta") return "Tarjeta";
  if (id === "transferencia") return "Transferencia";
  if (id === "efectivo_casa") return "Efectivo casa";
  if (id === "efectivo") return "Efectivo";
  return id ? id : "—";
}

// Pregunta al cancelar crédito: solo esta nota o toda la cuenta.
function elegirAlcanceCancelacion({ titulo, notaLabel, notaMonto, cuentaLabel, cuentaMonto }) {
  return new Promise((resolve) => {
    const back = document.createElement("div");
    back.className = "modal-back";
    back.style.zIndex = "85";
    back.innerHTML = `
      <div class="modal modal--qty" style="max-width:460px">
        <h3>${escapeHtml(titulo || "¿Qué deseas cancelar?")}</h3>
        <p class="qty-hint">Elige con cuidado. Cancelar toda la cuenta no se puede deshacer fácil.</p>
        <div class="modal__foot" style="flex-direction:column;align-items:stretch;gap:8px">
          <button class="btn btn--primary" data-alcance="nota" type="button">
            Solo esta nota${notaLabel ? ": " + escapeHtml(notaLabel) : ""}${notaMonto != null ? " · " + fmt(notaMonto) : ""}
          </button>
          <button class="btn btn--danger" data-alcance="cuenta" type="button">
            Toda la cuenta${cuentaLabel ? " de " + escapeHtml(cuentaLabel) : ""}${cuentaMonto != null ? " · " + fmt(cuentaMonto) : ""}
          </button>
          <button class="btn" data-alcance="" type="button">No cancelar</button>
        </div>
      </div>`;
    document.body.appendChild(back);
    const fin = (v) => { back.remove(); resolve(v || null); };
    back.addEventListener("click", (e) => {
      if (e.target === back) return fin(null);
      if (e.target.dataset && e.target.dataset.alcance !== undefined) {
        const a = e.target.dataset.alcance;
        fin(a === "nota" || a === "cuenta" ? a : null);
      }
    });
  });
}

// Tres columnas fijas para ticket de estado de cuenta (Cargo | Abono | Saldo).
function tresColsTicket(cols, a, b, c) {
  const w1 = Math.floor(cols / 3);
  const w2 = Math.floor(cols / 3);
  const w3 = cols - w1 - w2;
  const cell = (s, w, right) => {
    s = String(s == null ? "" : s).slice(0, w);
    const pad = Math.max(0, w - s.length);
    return right ? (" ".repeat(pad) + s) : (s + " ".repeat(pad));
  };
  return cell(a, w1, false) + cell(b, w2, true) + cell(c, w3, true);
}

// Documento hoja carta (DeskJet / oficina): tipografía grande, tabla ancha, cajero una sola vez.
function cssDocumentoEstadoCuenta() {
  return `
    @page { size: letter; margin: 1.4cm 1.6cm; }
    * { box-sizing: border-box; }
    body { font-family: "Calibri", "Segoe UI", Arial, sans-serif; font-size: 12pt; color: #111; margin: 0; }
    .doc { width: 100%; }
    .brand { text-align: center; font-size: 11pt; letter-spacing: .04em; color: #444; margin: 0 0 2pt; text-transform: uppercase; }
    h1 { text-align: center; font-size: 20pt; margin: 0 0 2pt; font-weight: 700; }
    h2 { text-align: center; font-size: 14pt; margin: 0 0 14pt; font-weight: 600; color: #222; }
    .meta { width: 100%; border-collapse: collapse; margin-bottom: 12pt; font-size: 11.5pt; }
    .meta td { padding: 3pt 0; vertical-align: top; }
    .meta .lab { color: #555; width: 22%; }
    .meta .val { font-weight: 600; }
    .saldo-box { display: flex; justify-content: space-between; gap: 12pt; margin: 10pt 0 14pt; }
    .saldo-box div { flex: 1; border: 1px solid #bbb; padding: 8pt 10pt; }
    .saldo-box span { display: block; font-size: 10pt; color: #555; }
    .saldo-box b { font-size: 14pt; }
    table.movs { width: 100%; border-collapse: collapse; table-layout: fixed; font-size: 11pt; }
    table.movs th { background: #e8e8e8; border-bottom: 2px solid #333; padding: 7pt 5pt; text-align: left; font-size: 10.5pt; }
    table.movs td { border-bottom: 1px solid #ccc; padding: 6pt 5pt; vertical-align: top; }
    table.movs .num { text-align: right; white-space: nowrap; font-variant-numeric: tabular-nums; }
    table.movs .desc { color: #333; font-size: 10.5pt; }
    table.movs col.c-fecha { width: 12%; }
    table.movs col.c-mov { width: 14%; }
    table.movs col.c-folio { width: 10%; }
    table.movs col.c-desc { width: 28%; }
    table.movs col.c-cargo { width: 12%; }
    table.movs col.c-abono { width: 12%; }
    table.movs col.c-saldo { width: 12%; }
    .pie { margin-top: 16pt; font-size: 12pt; }
    .pie .tot { display: flex; justify-content: flex-end; gap: 18pt; border-top: 2px solid #333; padding-top: 8pt; }
    .firma { margin-top: 36pt; text-align: center; }
    .firma .linea { margin: 28pt auto 4pt; width: 55%; border-top: 1px solid #222; }
    .firma .nombre { font-size: 11pt; font-weight: 600; }
    .vacio { padding: 16pt; color: #666; text-align: center; }
  `;
}

function htmlDocumentoEstadoCuenta({ titulo, subtitulo, nombre, metaFilas, saldoAnteriorLabel, saldoAnterior, saldoFinalLabel, saldoFinal, filas, firmaNombre }) {
  const esc = (s) => escapeHtml(String(s == null ? "" : s));
  const metaHtml = (metaFilas || []).map((f) =>
    `<tr><td class="lab">${esc(f.lab)}</td><td class="val">${esc(f.val)}</td></tr>`).join("");
  const bodyRows = (filas || []).length
    ? filas.map((r) => `<tr>
        <td>${esc(r.fecha)}</td>
        <td>${esc(r.mov)}</td>
        <td>${esc(r.folio)}</td>
        <td class="desc">${esc(r.desc || "")}</td>
        <td class="num">${esc(r.cargo || "")}</td>
        <td class="num">${esc(r.abono || "")}</td>
        <td class="num">${esc(r.saldo || "")}</td>
      </tr>`).join("")
    : `<tr><td colspan="7" class="vacio">(sin movimientos en el periodo)</td></tr>`;
  const negocio = (CFG && CFG.negocio && CFG.negocio.nombre) || "Mayoreo de Carne de Res";
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${esc(titulo)}</title>
    <style>${cssDocumentoEstadoCuenta()}</style></head><body><div class="doc">
      <div class="brand">${esc(negocio)}</div>
      <h1>${esc(nombre || "")}</h1>
      <h2>${esc(subtitulo || titulo || "Estado de cuenta")}</h2>
      <table class="meta">${metaHtml}</table>
      <div class="saldo-box">
        <div><span>${esc(saldoAnteriorLabel || "Saldo anterior")}</span><b>${esc(saldoAnterior)}</b></div>
        <div><span>${esc(saldoFinalLabel || "Saldo pendiente")}</span><b>${esc(saldoFinal)}</b></div>
      </div>
      <table class="movs">
        <colgroup>
          <col class="c-fecha"/><col class="c-mov"/><col class="c-folio"/><col class="c-desc"/>
          <col class="c-cargo"/><col class="c-abono"/><col class="c-saldo"/>
        </colgroup>
        <thead><tr>
          <th>Fecha</th><th>Movimiento</th><th>Folio</th><th>Descripción</th>
          <th class="num">Cargo</th><th class="num">Abono</th><th class="num">Saldo</th>
        </tr></thead>
        <tbody>${bodyRows}</tbody>
      </table>
      <div class="pie"><div class="tot">
        <span>${esc(saldoFinalLabel || "Saldo pendiente")}:</span>
        <b>${esc(saldoFinal)}</b>
      </div></div>
      ${firmaNombre ? `<div class="firma"><div class="linea"></div><div class="nombre">${esc(firmaNombre)}</div><div>Firma</div></div>` : ""}
    </div></body></html>`;
}

async function mostrarDocumentoFlujo(titulo, html, opts) {
  opts = opts || {};
  const autoImprimir = !!opts.autoImprimir;
  let impreso = false, errImp = null;
  const modo = CFG && CFG.impresora ? CFG.impresora.modo : "off";
  if (autoImprimir && window.api && window.api.printer && modo !== "off") {
    try {
      const r = await window.api.printer.imprimirHtml(html);
      if (r && r.ok) impreso = true; else errImp = r && r.error;
    } catch (e) { errImp = String(e); }
  }
  let nota;
  if (!autoImprimir) nota = `<span class="tk-info">Vista en pantalla · no se envió a la impresora.</span>`;
  else if (impreso) nota = `<span class="tk-ok">✅ Documento enviado a la impresora</span>`;
  else if (modo === "off") nota = `<span class="tk-info">🖨️ Impresora en modo vista previa. Configúrala en Administración → Configuración.</span>`;
  else if (errImp) nota = `<span class="tk-warn">⚠️ No se pudo imprimir: ${escapeHtml(errImp)}</span>`;
  else nota = `<span class="tk-info">Vista previa del documento.</span>`;

  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--ticket" style="max-width:920px;width:94vw">
      <h3>${escapeHtml(titulo || "Documento")}</h3>
      ${nota}
      <iframe title="vista" style="width:100%;height:62vh;border:1px solid #ccc;background:#fff;border-radius:4px"></iframe>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cerrar</button>
        <button class="btn btn--primary" id="doc-imprimir">🖨️ Imprimir</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const iframe = back.querySelector("iframe");
  try { iframe.srcdoc = html; } catch (e) { /* ignore */ }
  const cerrar = () => back.remove();
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#doc-imprimir", back).addEventListener("click", async () => {
    if (!(window.api && window.api.printer)) return alert("Impresión no disponible.");
    const r = await window.api.printer.imprimirHtml(html);
    if (r && r.ok) {
      const n = back.querySelector("h3") && back.querySelector(".tk-info, .tk-ok, .tk-warn");
      if (n) n.outerHTML = `<span class="tk-ok">✅ Documento enviado a la impresora</span>`;
    } else alert(r && r.error ? r.error : "No se pudo imprimir.");
  });
}
async function imprimirDocumentoFlujo(titulo, html) {
  return mostrarDocumentoFlujo(titulo, html, { autoImprimir: true });
}
async function verDocumentoFlujo(titulo, html) {
  return mostrarDocumentoFlujo(titulo, html, { autoImprimir: false });
}

async function debeImprimirDocumentoHoja() {
  try {
    if (window.api && window.api.printer && window.api.printer.esDocumentoHoja) {
      return !!(await window.api.printer.esDocumentoHoja());
    }
  } catch (e) { /* ignore */ }
  const i = CFG && CFG.impresora;
  if (!i || i.modo !== "windows") return false;
  const envio = String(i.envioWindows || "auto").toLowerCase();
  if (envio === "texto") return true;
  if (envio === "raw") return false;
  const n = String(i.rutaWindows || "").toLowerCase();
  return /deskjet|laserjet|officejet|envy|pixma|brother|lexmark|canon|pdf|onenote|microsoft print|\bhp\b/.test(n);
}

function confirmarDatos(titulo, filas) {
  return new Promise((resolve) => {
    const back = document.createElement("div");
    back.className = "modal-back";
    back.style.zIndex = "80";
    const rows = (filas || []).filter((f) => f && String(f.valor || "").trim() !== "")
      .map((f) => `<div class="mv-kv"><span>${escapeHtml(f.etiqueta)}</span><b>${escapeHtml(String(f.valor))}</b></div>`).join("");
    back.innerHTML = `
      <div class="modal modal--qty" style="max-width:420px">
        <h3>${escapeHtml(titulo)}</h3>
        <p class="qty-hint">Revisa los datos. Si están bien, confirma.</p>
        ${rows}
        <div class="modal__foot">
          <button class="btn" type="button" data-no="1">Cancelar</button>
          <button class="btn btn--primary" type="button" data-si="1">Confirmar</button>
        </div>
      </div>`;
    document.body.appendChild(back);
    const fin = (ok) => { back.remove(); resolve(!!ok); };
    back.addEventListener("click", (e) => {
      if (e.target === back || e.target.dataset.no) fin(false);
      else if (e.target.dataset.si) fin(true);
    });
  });
}

// Diálogo Abonar: cuenta general o un cargo concreto del estado de cuenta.
function abrirAbonoCredito(estado, el, root, onDone) {
  const cli = estado.cliente;
  const saldo = estado.saldoCents || 0;
  const movSel = (estado.movimientos || []).find((x) => x.id === _creditoSel.movSel);
  const ventaSelPref = movSel && movSel.tipo === "cargo" && movSel.ventaFolio != null ? movSel.ventaFolio : null;
  const movSelPref = movSel && movSel.tipo === "cargo" && movSel.ventaFolio == null ? movSel.id : null;
  const ventasPend = (estado.ventas || []).filter((v) => (v.saldoCents || 0) > 0)
    .slice()
    .sort((a, b) => new Date(a.fecha) - new Date(b.fecha));
  const optsCargo = ventasPend.map((v) => {
    const f = v.fecha ? new Date(v.fecha).toLocaleDateString("es-MX") : "";
    const nota = (v.nota || "").toString().trim().slice(0, 36);
    if (v.folio != null) {
      const sel = ventaSelPref != null && Number(v.folio) === Number(ventaSelPref) ? "selected" : "";
      return `<option value="venta:${v.folio}" ${sel}>Cargo #${v.folio}${f ? " · " + f : ""}${nota ? " · " + escapeHtml(nota) : ""} · ${fmt(v.saldoCents)}</option>`;
    }
    const sel = movSelPref != null && Number(v.movIndex) === Number(movSelPref) ? "selected" : "";
    const n = (v.movIndex != null ? Number(v.movIndex) + 1 : "?");
    return `<option value="mov:${v.movIndex}" ${sel}>Cargo #${n}${f ? " · " + f : ""}${nota ? " · " + escapeHtml(nota) : ""} · ${fmt(v.saldoCents)}</option>`;
  }).join("");
  const b2 = document.createElement("div");
  b2.className = "modal-back";
  b2.innerHTML = `
    <div class="modal modal--qty" style="max-width:480px">
      <div class="hist2__head" style="margin-bottom:6px"><h3 style="margin:0">Créditos · Abonar</h3>
        <button class="iconbtn" data-cerrar="1" title="Cerrar">✕</button></div>
      <p class="sub">${escapeHtml(cli.nombre)} · Saldo actual: <b>${fmt(saldo)}</b></p>
      <div class="qty-field"><label>¿A qué se aplica el abono?</label>
        <select id="ab-destino" style="font-size:15px;min-height:40px">
          <option value="todas">Cuenta general</option>
          ${optsCargo || ""}
        </select>
      </div>
      <div class="qty-field"><label>Abonar</label><input type="number" min="0" step="0.01" id="ab-monto" placeholder="0.00" /></div>
      <div class="qty-field"><label>Forma de pago</label>
        <select id="ab-forma">
          <option value="efectivo">Efectivo</option>
          ${copiaEnVivo ? '<option value="efectivo_casa">Efectivo casa</option>' : ""}
          <option value="transferencia">Transferencia</option>
          <option value="tarjeta">Tarjeta</option>
        </select>
      </div>
      <div class="qty-field"><label>Comentarios</label><input type="text" id="ab-coment" placeholder="Opcional" /></div>
      <p class="qty-hint" id="ab-msg"></p>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="ab-ok">Aceptar</button>
      </div>
    </div>`;
  document.body.appendChild(b2);
  const cerrar = () => b2.remove();
  b2.addEventListener("click", (e) => { if (e.target === b2 || e.target.dataset.cerrar !== undefined) cerrar(); });
  const topeDestino = () => {
    const destRaw = ($("#ab-destino", b2).value || "todas");
    if (destRaw.indexOf("venta:") === 0) {
      const folio = Number(destRaw.slice(6));
      const v = ventasPend.find((x) => x.folio != null && Number(x.folio) === folio);
      return v ? (v.saldoCents || 0) : saldo;
    }
    if (destRaw.indexOf("mov:") === 0) {
      const idx = Number(destRaw.slice(4));
      const v = ventasPend.find((x) => x.movIndex != null && Number(x.movIndex) === idx);
      return v ? (v.saldoCents || 0) : saldo;
    }
    return saldo;
  };
  const syncMontoCli = () => {
    const mi = $("#ab-monto", b2);
    if (mi) mi.value = ((topeDestino() || 0) / 100).toFixed(2);
  };
  const selDestCli = $("#ab-destino", b2);
  if (selDestCli) {
    if (ventaSelPref != null && ventasPend.some((v) => v.folio != null && Number(v.folio) === Number(ventaSelPref))) {
      selDestCli.value = "venta:" + ventaSelPref;
    } else if (movSelPref != null && ventasPend.some((v) => v.movIndex != null && Number(v.movIndex) === Number(movSelPref))) {
      selDestCli.value = "mov:" + movSelPref;
    }
    selDestCli.addEventListener("change", syncMontoCli);
    syncMontoCli();
  }
  const ok = async () => {
    const monto = Money.toCents(parseFloat(($("#ab-monto", b2).value || "").replace(",", ".")) || 0) || 0;
    if (monto <= 0) { $("#ab-msg", b2).innerHTML = '<span class="tk-warn">Escribe un monto mayor a cero.</span>'; return; }
    const destRaw = $("#ab-destino", b2).value || "todas";
    const esVenta = destRaw.indexOf("venta:") === 0;
    const esMov = destRaw.indexOf("mov:") === 0;
    const ventaFolio = esVenta ? Number(destRaw.slice(6)) : null;
    const movIndex = esMov ? Number(destRaw.slice(4)) : null;
    const destino = esVenta ? "venta" : (esMov ? "movimiento" : "todas");
    const tope = topeDestino();
    if (monto > tope) { $("#ab-msg", b2).innerHTML = `<span class="tk-warn">El abono no puede ser mayor a ${fmt(tope)}.</span>`; return; }
    const forma = $("#ab-forma", b2).value;
    if (forma !== "efectivo_casa") {
      const stCaja = await window.api.db.estadoCaja();
      if (!stCaja || !stCaja.abierta) { $("#ab-msg", b2).innerHTML = '<span class="tk-warn">Abre la caja para que el abono entre al corte.</span>'; return; }
    }
    const coment = $("#ab-coment", b2).value.trim();
    const etqDest = esVenta ? ("Cargo #" + ventaFolio) : (esMov ? ("Cargo #" + (movIndex + 1)) : "Cuenta general");
    const sigue = await confirmarDatos("Confirmar abono", [
      { etiqueta: "Cliente", valor: cli.nombre },
      { etiqueta: "Saldo actual", valor: fmt(saldo) },
      { etiqueta: "Abono", valor: fmt(monto) },
      { etiqueta: "Destino", valor: etqDest },
      { etiqueta: "Forma de pago", valor: etiquetaFormaPago(forma) },
      { etiqueta: "Comentario", valor: coment || "—" },
      { etiqueta: "Saldo que queda", valor: fmt(Math.max(0, saldo - monto)) }
    ]);
    if (!sigue) return;
    const r = await window.api.db.abonarCredito(cli.id, monto, {
      destino,
      ventaFolio: esVenta ? ventaFolio : null,
      movIndex: esMov ? movIndex : null,
      comentario: coment, formaPago: forma,
      usuario: usuarioActual ? usuarioActual.nombre : null
    });
    if (r && r.error) { $("#ab-msg", b2).innerHTML = `<span class="tk-warn">${escapeHtml(r.error)}</span>`; return; }
    cerrar();
    await cargarClientes();
    if (typeof onDone === "function") onDone();
    else if (el && root) renderEstadoCuenta(el, root);
  };
  $("#ab-ok", b2).addEventListener("click", ok);
  const mi = $("#ab-monto", b2);
  mi.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); ok(); } });
  setTimeout(() => { if (selDestCli) selDestCli.focus(); else mi.focus(); }, 30);
}

function elegirFormaLiquidacion(nombre, saldo) {
  return new Promise((resolve) => {
    const back = document.createElement("div");
    back.className = "modal-back";
    back.innerHTML = `
      <div class="modal modal--qty" style="max-width:440px">
        <h3>Liquidar crédito</h3>
        <p class="qty-hint">¿Con qué se paga el adeudo de <b>${escapeHtml(nombre || "")}</b> por <b>${fmt(saldo)}</b>?</p>
        <div class="modal__foot" style="flex-wrap:wrap">
          <button class="btn" data-cerrar="1">Cancelar</button>
          <button class="btn btn--primary" data-fp="efectivo">Efectivo</button>
          ${copiaEnVivo ? '<button class="btn btn--primary" data-fp="efectivo_casa">Efectivo casa</button>' : ""}
          <button class="btn btn--primary" data-fp="tarjeta">Tarjeta</button>
          <button class="btn btn--primary" data-fp="transferencia">Transferencia</button>
        </div>
      </div>`;
    document.body.appendChild(back);
    const cerrar = (fp) => { back.remove(); resolve(fp || null); };
    back.addEventListener("click", (e) => {
      if (e.target === back || e.target.dataset.cerrar) { cerrar(null); return; }
      if (e.target.dataset.fp) cerrar(e.target.dataset.fp);
    });
  });
}

async function liquidarCredito(estado, el, root) {
  const cli = estado.cliente;
  const saldo = estado.saldoCents || 0;
  if (saldo <= 0) return;
  const fp = await elegirFormaLiquidacion(cli.nombre, saldo);
  if (!fp) return;
  if (fp !== "efectivo_casa") {
    const st = await window.api.db.estadoCaja();
    if (!st || !st.abierta) return alert("Abre la caja. Así la liquidación entra al corte de hoy.");
  }
  const sigue = await confirmarDatos("Confirmar liquidación", [
    { etiqueta: "Cliente", valor: cli.nombre },
    { etiqueta: "Se liquida", valor: fmt(saldo) },
    { etiqueta: "Forma de pago", valor: etiquetaFormaPago(fp) },
    { etiqueta: "Saldo que queda", valor: fmt(0) }
  ]);
  if (!sigue) return;
  const r = await window.api.db.abonarCredito(cli.id, saldo, { destino: "todas", comentario: "Liquidación de adeudo", formaPago: fp, usuario: usuarioActual ? usuarioActual.nombre : null });
  if (r && r.error) return alert(r.error);
  await cargarClientes();
  renderEstadoCuenta(el, root);
  if (confirm("Adeudo liquidado. ¿Imprimir comprobante?")) {
    const nuevo = await window.api.db.estadoCuentaCliente(cli.id);
    if (nuevo && !nuevo.error) imprimirEstadoDeCuenta(nuevo);
  }
}

function armarDatosEstadoCuentaCliente(estado) {
  const cli = estado.cliente;
  const etiqueta = (m) => {
    if (m.tipo === "cargo") return "CARGO";
    if (m.tipo === "cancelacion") return "CANCELA";
    const txt = ((m.comentario || "") + " " + (m.nota || "")).toLowerCase();
    return txt.includes("liquid") ? "LIQUIDACION" : "ABONO";
  };
  const movs = credFiltrarMovs(estado.movimientos || [], _creditoSel.periodo)
    .slice()
    .sort((a, b) => new Date(a.fecha) - new Date(b.fecha));
  let saldoAnterior, saldoPendiente;
  if (movs.length) {
    const first = movs[0];
    saldoAnterior = first.tipo === "cargo" ? (first.saldoCents - first.montoCents) : (first.saldoCents + first.montoCents);
    saldoPendiente = movs[movs.length - 1].saldoCents;
  } else {
    saldoAnterior = estado.saldoCents || 0;
    saldoPendiente = estado.saldoCents || 0;
  }
  const cajeroUnaVez = usuarioActual ? usuarioActual.nombre : "—";
  const filasDoc = movs.map((m) => {
    const folio = m.tipo === "cargo" && m.ventaFolio != null ? "#" + m.ventaFolio : "#" + (m.id + 1);
    return {
      fecha: new Date(m.fecha).toLocaleDateString("es-MX"),
      mov: etiqueta(m),
      folio,
      desc: (m.nota || m.comentario || "").toString().trim(),
      cargo: m.tipo === "cargo" ? fmt(m.montoCents) : "",
      abono: m.tipo !== "cargo" ? fmt(m.montoCents) : "",
      saldo: fmt(m.saldoCents)
    };
  });
  const metaFilas = [
    { lab: "Cajero", val: cajeroUnaVez },
    { lab: "Caja", val: (CFG && CFG.terminal) || "Caja Principal" }
  ];
  if (cli.telefono) metaFilas.push({ lab: "Teléfono", val: cli.telefono });
  metaFilas.push({ lab: "Periodo", val: credPeriodoLabel() });
  metaFilas.push({ lab: "Consultado", val: new Date().toLocaleString("es-MX") });
  const html = htmlDocumentoEstadoCuenta({
    titulo: "Estado de cuenta",
    subtitulo: "Crédito a cliente · Estado de cuenta",
    nombre: (cli.nombre || "").toUpperCase(),
    metaFilas,
    saldoAnteriorLabel: "Saldo anterior",
    saldoAnterior: fmt(saldoAnterior),
    saldoFinalLabel: "Saldo pendiente",
    saldoFinal: fmt(saldoPendiente),
    filas: filasDoc,
    firmaNombre: (cli.nombre || "").toUpperCase()
  });
  return { cli, movs, saldoAnterior, saldoPendiente, cajeroUnaVez, etiqueta, html };
}

async function imprimirEstadoDeCuenta(estado, opts) {
  opts = opts || {};
  const soloVer = !!opts.soloVer;
  const d = armarDatosEstadoCuentaCliente(estado);
  // Ver en pantalla: siempre documento estructurado (sin mandar a impresora).
  if (soloVer) return verDocumentoFlujo("ESTADO DE CUENTA", d.html);
  if (await debeImprimirDocumentoHoja()) return imprimirDocumentoFlujo("ESTADO DE CUENTA", d.html);

  const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
  const lr = (a, b) => { const s = cols - a.length - b.length; return s >= 1 ? a + " ".repeat(s) + b : (a + " " + b); };
  const center = (s) => { s = String(s); const pad = Math.max(0, Math.floor((cols - s.length) / 2)); return " ".repeat(pad) + s; };
  const L = [];
  L.push(center(`* ${(d.cli.nombre || "").toUpperCase()} *`));
  L.push("");
  L.push("CAJERO: " + d.cajeroUnaVez);
  L.push("CAJA: " + ((CFG && CFG.terminal) || "Caja Principal"));
  if (d.cli.telefono) L.push("TEL: " + d.cli.telefono);
  L.push(credPeriodoLabel());
  L.push("-".repeat(cols));
  L.push(lr("SALDO ANTERIOR:", fmt(d.saldoAnterior)));
  L.push("-".repeat(cols));
  L.push(tresColsTicket(cols, "CARGO", "ABONO", "SALDO"));
  L.push("-".repeat(cols));
  if (!d.movs.length) L.push("(sin movimientos en el periodo)");
  d.movs.forEach((m) => {
    const f = new Date(m.fecha).toLocaleDateString("es-MX", { day: "2-digit", month: "2-digit", year: "2-digit" });
    const folio = m.tipo === "cargo" && m.ventaFolio != null ? "#" + m.ventaFolio : "#" + (m.id + 1);
    L.push(`${f} ${d.etiqueta(m)} ${folio}`.slice(0, cols));
    const desc = (m.nota || m.comentario || "").toString().trim();
    if (desc) L.push(("  " + desc).slice(0, cols));
    const cargo = m.tipo === "cargo" ? fmt(m.montoCents) : "";
    const abono = m.tipo !== "cargo" ? fmt(m.montoCents) : "";
    L.push(tresColsTicket(cols, cargo, abono, fmt(m.saldoCents)));
    L.push("-".repeat(cols));
  });
  L.push(lr("SALDO PENDIENTE:", fmt(d.saldoPendiente)));
  L.push("");
  L.push("");
  L.push(center("* CREDITO A CLIENTE *"));
  L.push("FIRMA DEL CLIENTE:");
  L.push("");
  L.push("");
  L.push(center("____________________________"));
  L.push(center((d.cli.nombre || "").toUpperCase()));
  return imprimirListaFlujo("ESTADO DE CUENTA", L);
}

function verEstadoDeCuenta(estado) {
  return imprimirEstadoDeCuenta(estado, { soloVer: true });
}

function imprimirMovimientoCredito(cli, m) {
  const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
  const lr = (a, b) => { const s = cols - a.length - b.length; return s >= 1 ? a + " ".repeat(s) + b : (a + " " + b); };
  const L = [];
  L.push("Cliente: " + (cli.nombre || ""));
  L.push("Fecha: " + new Date(m.fecha).toLocaleString("es-MX"));
  if (m.usuario) L.push("Atiende: " + m.usuario);
  L.push("-".repeat(cols));
  L.push(m.tipo === "cargo" ? "VENTA A CREDITO" : m.tipo === "abono" ? "ABONO A CUENTA" : "CANCELACION");
  if (m.nota) L.push(m.nota);
  if (m.comentario) L.push(m.comentario);
  L.push(lr(m.tipo === "cargo" ? "Cargo" : "Abono", fmt(m.montoCents)));
  L.push(lr("Saldo tras el movimiento", fmt(m.saldoCents)));
  if (m.formaPago) L.push(lr("Forma de pago", etiquetaFormaPago(m.formaPago).toUpperCase()));
  L.push("-".repeat(cols));
  // En ventas a crédito, incluir el apartado de firma del cliente.
  if (m.tipo === "cargo") {
    const center = (s) => { s = String(s); const pad = Math.max(0, Math.floor((cols - s.length) / 2)); return " ".repeat(pad) + s; };
    L.push("");
    L.push(center("* VENTA A CREDITO *"));
    L.push("FIRMA DEL CLIENTE:");
    L.push("");
    L.push("");
    L.push(center("____________________________"));
    L.push(center((cli.nombre || "").toUpperCase()));
  }
  imprimirListaFlujo(m.tipo === "abono" ? "COMPROBANTE DE ABONO" : m.tipo === "cargo" ? "VENTA A CREDITO" : "COMPROBANTE", L);
}

async function renderReporteSaldos(el, root) {
  const lista = await window.api.db.resumenCreditos();
  const conSaldo = (lista || []).filter((c) => (c.saldoCents || 0) > 0);
  const total = conSaldo.reduce((s, c) => s + (c.saldoCents || 0), 0);
  const filas = (lista || []).map((c) => `
    <tr class="cred-saldo-row" data-cli="${c.id}">
      <td>👤 ${escapeHtml(c.nombre)}</td>
      <td class="muted">${escapeHtml(c.telefono || "—")}</td>
      <td>${c.creditoActivo ? `<span class="pill pill--ok">Crédito${c.limiteCents ? " " + fmt(c.limiteCents) : ""}</span>` : `<span class="pill">Contado</span>`}</td>
      <td class="muted">${c.ultimaFecha ? new Date(c.ultimaFecha).toLocaleDateString("es-MX") : "—"}</td>
      <td class="num ${(c.saldoCents || 0) > 0 ? "neg" : ""}"><b>${fmt(c.saldoCents || 0)}</b></td>
    </tr>`).join("") || `<tr><td colspan="5" class="muted" style="padding:16px">Sin clientes registrados.</td></tr>`;

  el.innerHTML = `
    <div class="cred-saldos-top">
      <div class="cred-saldos-tot"><span>Deudores</span><b>${conSaldo.length}</b></div>
      <div class="cred-saldos-tot"><span>Adeudo total</span><b class="neg">${fmt(total)}</b></div>
      <button class="btn btn--sec" id="cred-print-saldos">🖨️ Imprimir reporte</button>
    </div>
    <div class="mv-table-wrap">
      <table class="mv-table">
        <thead><tr><th>Cliente</th><th>Teléfono</th><th>Tipo</th><th>Última actividad</th><th class="num">Saldo</th></tr></thead>
        <tbody>${filas}</tbody>
      </table>
    </div>`;

  $$(".cred-saldo-row", el).forEach((r) => r.addEventListener("click", () => {
    _creditoSel.clienteId = +r.dataset.cli; _creditoSel.subvista = "estado"; _creditoSel.movSel = null;
    renderCreditos(root);
  }));
  $("#cred-print-saldos", el).addEventListener("click", () => {
    const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
    const lr = (a, b) => { const s = cols - a.length - b.length; return s >= 1 ? a + " ".repeat(s) + b : (a + " " + b); };
    const L = ["Fecha: " + new Date().toLocaleString("es-MX"), "-".repeat(cols)];
    conSaldo.forEach((c) => L.push(lr((c.nombre || "").slice(0, cols - 12), fmt(c.saldoCents || 0))));
    L.push("-".repeat(cols));
    L.push(lr("TOTAL POR COBRAR", fmt(total)));
    imprimirListaFlujo("REPORTE DE SALDOS", L);
  });
}

function vistaPreviaLocal(t) {
  const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
  const neg = (CFG && CFG.negocio) || { nombre: "Mayoreo de Carnes de Res" };
  const rep = (c, n) => c.repeat(Math.max(0, n));
  const lr = (a, b) => { const s = cols - a.length - b.length; return s >= 1 ? a + rep(" ", s) + b : (a + " " + b); };
  const center = (s) => rep(" ", Math.max(0, Math.floor((cols - s.length) / 2))) + s;
  const L = [center((neg.nombre || "").toUpperCase()), rep("-", cols)];
  L.push(lr("Folio: " + t.folio, t.fecha || ""));
  if (t.cajero) L.push("Atiende: " + t.cajero);
  L.push(rep("-", cols));
  (t.items || []).forEach((it) => {
    const cant = fmtCant(it.cant, it.unidad) + (it.unidad || "");
    L.push(lr(cant + "  " + it.nombre, fmt(it.importeCents)));
  });
  L.push(rep("-", cols));
  if (t.descuentoCents > 0) {
    L.push(lr("Subtotal", fmt(t.subtotalCents != null ? t.subtotalCents : (t.totalCents + t.descuentoCents))));
    L.push(lr("Descuento", "-" + fmt(t.descuentoCents)));
  }
  L.push(lr("TOTAL", fmt(t.totalCents)));
  L.push(lr("Pago", t.pagoLabel || t.pago));
  if (t.pago === "combinado" && Array.isArray(t.pagos)) {
    t.pagos.forEach((p) => L.push(lr("  " + (p.label || p.metodo), fmt(p.montoCents))));
    if (t.cambioCents > 0) {
      L.push(lr("  Efectivo recibido", fmt(t.efectivoRecibidoCents || t.recibidoCents)));
      L.push(lr("  Cambio", fmt(t.cambioCents)));
    }
  }
  if (t.pago === "efectivo") { L.push(lr("Recibido", fmt(t.recibidoCents))); L.push(lr("Cambio", fmt(t.cambioCents))); }
  if (String(t.pago || "").toLowerCase() === "credito") {
    L.push(rep("-", cols));
    L.push(center("*** VENTA A CREDITO ***"));
    if (t.cliente) L.push(lr("Cliente", t.cliente));
    L.push(lr("Cargo de esta venta", fmt(t.totalCents)));
    if (t.saldoClienteCents != null) L.push(lr("SALDO QUE DEBE", fmt(t.saldoClienteCents)));
    L.push("");
    L.push("FIRMA DEL CLIENTE:");
    L.push("");
    L.push("");
    L.push(center("____________________________"));
    if (t.cliente) L.push(center(String(t.cliente).toUpperCase()));
  }
  return L.join("\n");
}

function escapeHtml(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/* ---------------- Navegación superior ---------------- */
function showVenta() {
  $$(".navbtn").forEach((b) => b.classList.toggle("is-active", b.dataset.view === "venta"));
  $("#view-venta").style.display = "grid";
  $("#module-view").classList.remove("is-active");
  // El buscador de productos queda activo para escribir sin dar clic.
  setTimeout(() => { const s = $("#entry-search"); if (s) s.focus(); }, 30);
}
function moverResumen(delta) {
  const ancla = resumenFiltro.ancla || hoyISO();
  const [y, m, d] = ancla.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  if (resumenFiltro.periodo === "mes") dt.setMonth(dt.getMonth() + delta);
  else if (resumenFiltro.periodo === "trimestre") dt.setMonth(dt.getMonth() + delta * 3);
  else dt.setDate(dt.getDate() + delta);
  const iso = dt.getFullYear() + "-" + String(dt.getMonth() + 1).padStart(2, "0") + "-" + String(dt.getDate()).padStart(2, "0");
  const hoy = hoyISO();
  resumenFiltro.ancla = iso > hoy ? hoy : iso;
}

function cuandoResumen(iso) {
  if (!iso) return "";
  return new Date(iso).toLocaleString("es-MX", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
}

function filasResumen(lista, vacio, pintar) {
  if (!lista || !lista.length) return `<p class="resumen-vacio">${vacio}</p>`;
  return `<ul class="resumen-lista">${lista.map(pintar).join("")}</ul>`;
}

async function renderResumen(body) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>📊</span><p>Sin base de datos disponible.</p></div>'; return; }
  if (!copiaEnVivo && window.api && window.api.getAppInfo) {
    try {
      const info = await window.api.getAppInfo();
      copiaEnVivo = !!(info && info.copiaEnVivo);
    } catch (e) {}
  }
  const tabs = [
    { id: "general", label: "Resumen" },
    { id: "meses", label: "Ingresos por mes" }
  ];
  body.innerHTML = `
    <div class="inv-tabs">
      ${tabs.map((t) => `<button type="button" class="inv-tab ${t.id === resumenTab ? "is-active" : ""}" data-resumen-tab="${t.id}">${t.label}</button>`).join("")}
    </div>
    <div id="resumen-sub"></div>`;
  $$("[data-resumen-tab]", body).forEach((b) => b.addEventListener("click", () => {
    resumenTab = b.dataset.resumenTab;
    renderResumen(body);
  }));
  const sub = $("#resumen-sub", body);
  if (resumenTab === "meses") return renderIngresosMeses(sub);
  return renderResumenGeneral(sub);
}

async function renderResumenGeneral(body) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>📊</span><p>Sin base de datos disponible.</p></div>'; return; }
  if (!resumenFiltro.ancla) resumenFiltro.ancla = hoyISO();
  let r;
  try { r = await window.api.db.resumenAuditoria(resumenFiltro.periodo, resumenFiltro.ancla); }
  catch (e) { body.innerHTML = `<div class="empty-state"><span>📊</span><p>${escapeHtml(e.message || "No se pudo armar el resumen.")}</p></div>`; return; }
  const dif = r.cortes.diferenciaCents || 0;
  const difTxt = dif === 0 ? "Cuadrados" : (dif > 0 ? "Sobrante " : "Faltante ") + fmt(Math.abs(dif));
  const liCorte = (c) => {
    const d = c.diferenciaCents || 0;
    const marca = d === 0 ? "cuadró" : (d > 0 ? "sobrante " : "faltante ") + fmt(Math.abs(d));
    return `<li><span><b>Caja ${c.cajaId}</b> · ${escapeHtml(c.usuario || "—")} · ${cuandoResumen(c.cierre)}<small>${c.numVentas || 0} ventas · ${marca}</small></span><b>${fmt(c.ventasCents)}</b></li>`;
  };
  const liDinero = (x) => `<li><span><b>${escapeHtml(x.quien || x.titulo || "")}</b> · ${cuandoResumen(x.fecha)}<small>${escapeHtml(x.detalle || "")}${x.forma ? " · " + escapeHtml(x.forma) : ""}</small></span><b>${x.montoCents ? fmt(x.montoCents) : ""}</b></li>`;
  const liAlta = (x) => `<li><span><b>${escapeHtml(x.nombre)}</b> · ${cuandoResumen(x.fecha)}<small>${escapeHtml(x.telefono || "Primera vez que aparece en los registros")}</small></span></li>`;
  const liEvento = (x) => `<li><span><b>${escapeHtml(x.titulo || "")}</b> · ${cuandoResumen(x.fecha)}<small>${escapeHtml(x.detalle || "")}</small></span><b>${x.montoCents ? fmt(x.montoCents) : ""}</b></li>`;
  const aviso = (n, mostrados) => n > mostrados ? `<p class="resumen-aviso">Se muestran ${mostrados} de ${n}.</p>` : "";
  body.innerHTML = `
    <div class="resumen-bar">
      <div class="resumen-modos">
        <button type="button" class="navbtn ${r.periodo === "dia" ? "is-active" : ""}" data-periodo="dia">Diario</button>
        <button type="button" class="navbtn ${r.periodo === "mes" ? "is-active" : ""}" data-periodo="mes">Mensual</button>
        <button type="button" class="navbtn ${r.periodo === "trimestre" ? "is-active" : ""}" data-periodo="trimestre">Trimestral</button>
      </div>
      <div class="resumen-nav">
        <button type="button" class="btn btn--sec" id="resumen-antes">←</button>
        <b id="resumen-etiqueta">${escapeHtml(r.etiqueta)}</b>
        <button type="button" class="btn btn--sec" id="resumen-despues">→</button>
        <input type="date" id="resumen-fecha" value="${r.ancla}" max="${hoyISO()}" />
      </div>
    </div>
    <p class="sub">Solo en esta computadora. Sirve para revisar el negocio; no se envía a ningún lado.</p>
    <div class="resumen-grid">
      <article class="resumen-kpi"><small>Cortes</small><b>${r.cortes.cantidad}</b><span>${fmt(r.cortes.ventasCents)} en ventas</span><span>${difTxt}</span></article>
      <article class="resumen-kpi"><small>Créditos nuevos</small><b>${r.creditosNuevos.cantidad}</b><span>${fmt(r.creditosNuevos.montoCents)}</span></article>
      <article class="resumen-kpi"><small>Liquidaciones</small><b>${r.liquidaciones.cantidad}</b><span>${fmt(r.liquidaciones.montoCents)}</span><span>${r.liquidaciones.parciales || 0} abonos parciales</span></article>
      <article class="resumen-kpi"><small>Altas</small><b>${r.altas.clientes + r.altas.proveedores}</b><span>${r.altas.clientes} clientes · ${r.altas.proveedores} proveedores</span></article>
      <article class="resumen-kpi"><small>Otros registros</small><b>${r.eventos.cantidad}</b><span>Cancelaciones, devoluciones, entradas y salidas</span></article>
    </div>
    ${r.cortes.abiertos ? `<p class="resumen-aviso">${r.cortes.abiertos} turno${r.cortes.abiertos === 1 ? "" : "s"} abierto${r.cortes.abiertos === 1 ? "" : "s"} en este periodo: todavía no tiene corte.</p>` : ""}
    <div class="resumen-bloques">
      <section class="mv-card"><h3>Cortes</h3>${filasResumen(r.cortes.lista, "Ningún corte cerrado en este periodo.", liCorte)}${aviso(r.cortes.total, (r.cortes.lista || []).length)}</section>
      <section class="mv-card"><h3>Créditos nuevos</h3>${filasResumen(r.creditosNuevos.lista, "Ningún crédito nuevo.", liDinero)}${aviso(r.creditosNuevos.total, (r.creditosNuevos.lista || []).length)}</section>
      <section class="mv-card"><h3>Liquidaciones</h3>${filasResumen(r.liquidaciones.lista, "Ninguna cuenta liquidada.", liDinero)}${aviso(r.liquidaciones.total, (r.liquidaciones.lista || []).length)}
        ${r.liquidaciones.parciales ? `<h4>Abonos que no liquidaron la cuenta</h4>${filasResumen(r.liquidaciones.listaParciales, "", liDinero)}` : ""}</section>
      <section class="mv-card"><h3>Clientes y proveedores nuevos</h3>
        <p class="sub">Se toma la primera fecha que hay de cada quien. Quien ya tenía movimientos antes no sale como nuevo.</p>
        <h4>Clientes</h4>${filasResumen(r.altas.listaClientes, "Ningún cliente nuevo.", liAlta)}
        <h4>Proveedores</h4>${filasResumen(r.altas.listaProveedores, "Ningún proveedor nuevo.", liAlta)}</section>
      <section class="mv-card resumen-ancho"><h3>Registros importantes</h3>${filasResumen(r.eventos.lista, "Sin cancelaciones, devoluciones ni movimientos de caja en este periodo.", liEvento)}${aviso(r.eventos.total, (r.eventos.lista || []).length)}</section>
    </div>`;
  const volver = () => renderResumen($("#mv-body"));
  $$("[data-periodo]", body).forEach((b) => b.addEventListener("click", () => {
    resumenFiltro.periodo = b.dataset.periodo;
    volver();
  }));
  $("#resumen-antes", body).addEventListener("click", () => { moverResumen(-1); volver(); });
  $("#resumen-despues", body).addEventListener("click", () => { moverResumen(1); volver(); });
  $("#resumen-fecha", body).addEventListener("change", (e) => {
    resumenFiltro.ancla = e.target.value || hoyISO();
    volver();
  });
}

async function showModule(mod) {
  const info = MODULOS[mod] || { icon: "📦", title: mod };
  $("#mv-icon").textContent = info.icon;
  $("#mv-title").textContent = info.title;
  $("#view-venta").style.display = "none";
  $("#module-view").classList.add("is-active");
  $$(".navbtn").forEach((b) => b.classList.toggle("is-active", b.dataset.module === mod));

  const body = $("#mv-body");
  if (mod === "resumen") return renderResumen(body);
  if (mod === "corte") return renderCorte(body);
  if (mod === "movimientos") return renderEntradasSalidas(body, "ingreso");
  if (mod === "entrada") return renderEntradasSalidas(body, "ingreso");
  if (mod === "salida") return renderEntradasSalidas(body, "retiro");
  if (mod === "inventario") return renderInventarioHub(body);
  if (mod === "devoluciones") return renderDevoluciones(body);
  if (mod === "productos") return renderProductos(body);
  if (mod === "categorias") return renderCategorias(body);
  if (mod === "clientes") return renderClientes(body);
  if (mod === "creditos") return renderCreditos(body);
  if (mod === "apartados") return renderApartados(body);
  if (mod === "espera") return renderEspera(body);
  if (mod === "usuarios") return renderBitacora(body);
  if (mod === "facturacion") return renderFacturacion(body);
  if (mod === "config") return renderConfig(body);
  body.innerHTML =
    `<div class="empty-state"><span>${info.icon}</span>` +
    `<h3>${info.title}</h3>` +
    `<p>En construcción — se implementa en la siguiente fase.</p></div>`;
}

/* ---------------- Corte de caja ---------------- */
function tienenDB() { return window.api && window.api.db; }

async function refreshCajaStatus() {
  if (!tienenDB()) return;
  try {
    const st = await window.api.db.estadoCaja();
    cajaAbierta = !!st.abierta;
    cajaFondoActual = st.fondoCents || (st.caja && st.caja.fondoCents) || 0;
    // Caja abierta pero sin actividad => se puede capturar/corregir el fondo inicial.
    cajaVacia = cajaAbierta && (st.numVentas || 0) === 0 &&
      ((st.entradas || []).length + (st.salidas || []).length + (st.abonos || []).length) === 0;
    const btn = $("#btn-abrir-caja");
    const status = $(".caja-status");
    if (btn) btn.textContent = cajaAbierta ? "CERRAR" : "ABRIR";
    if (status) status.innerHTML =
      `<span class="dot ${cajaAbierta ? "" : "dot--closed"}"></span> ${cajaAbierta ? "Caja abierta" : "Caja cerrada"}`;
  } catch (e) { /* offline safe */ }
}

function hoyISO() {
  const d = new Date();
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
}

function lineasDinero(izq, cents) {
  const der = fmt(cents);
  const pad = Math.max(1, 42 - String(izq).length - der.length);
  return String(izq) + " ".repeat(pad) + der;
}

function lineasDesdeVentasBascula(ventas, titulo) {
  const L = [];
  L.push(titulo || "CORTE DE BASCULAS");
  L.push(new Date().toLocaleString("es-MX"));
  L.push("------------------------------------------");
  const porIp = {};
  for (const v of ventas || []) {
    const k = v.ip || v.nserie || "bascula";
    if (!porIp[k]) porIp[k] = [];
    porIp[k].push(v);
  }
  let gran = 0;
  Object.keys(porIp).forEach((ip) => {
    const lista = porIp[ip].slice().sort((a, b) => String(a.folio).localeCompare(String(b.folio), "es", { numeric: true }));
    let tot = 0;
    L.push("");
    L.push("== BASCULA " + ip + " ==");
    lista.forEach((v) => {
      tot += v.totalCents || 0;
      L.push(lineasDinero("Folio " + (v.folio != null ? v.folio : "?"), v.totalCents || 0));
      (v.lineas || []).forEach((ln) => {
        if (!ln || ln.devolucion) return;
        const cant = ln.unidad === "kg" ? Number(ln.cant || 0).toFixed(3) : String(ln.cant || 1);
        L.push("  " + cant + " " + (ln.unidad || "") + " " + (ln.nombre || ""));
        L.push(lineasDinero("    ", ln.importeCents || 0));
      });
    });
    gran += tot;
    L.push(lineasDinero("TOTAL " + ip, tot));
  });
  L.push("------------------------------------------");
  L.push(lineasDinero("TOTAL BASCULAS", gran));
  L.push("(lectura en vivo; no borra el corte de la bascula)");
  return L;
}

async function imprimirCorteBasculasVivo() {
  if (!(window.api && window.api.bascula && window.api.bascula.leerVentasTodas)) {
    return alert("No se puede leer la báscula en esta terminal.");
  }
  try {
    const rv = await window.api.bascula.leerVentasTodas();
    if (!rv || (!rv.ok && !(rv.ventas || []).length)) {
      return alert(rv && rv.error ? rv.error : "No se pudo leer el corte de las básculas.");
    }
    const ventas = rv.ventas || [];
    if (!ventas.length) return alert("Las básculas no tienen ventas acumuladas para imprimir.");
    const err = (rv.basculas || []).filter((b) => !b.ok);
    const lineas = lineasDesdeVentasBascula(ventas, "CORTE DE BASCULAS");
    if (err.length) lineas.push("AVISO: " + err.map((b) => (b.ip || "") + " " + (b.error || "")).join("; "));
    return imprimirListaFlujo("CORTE DE BASCULAS", lineas);
  } catch (e) {
    return alert(e && e.message ? e.message : String(e));
  }
}

async function imprimirCorteBasculasDia(fecha) {
  if (!(window.api && window.api.db && window.api.db.detalleCorteBasculaDia)) {
    return alert("Esta versión no trae el corte de báscula por día.");
  }
  const dia = fecha || hoyISO();
  const r = await window.api.db.detalleCorteBasculaDia(dia);
  if (!r) return alert("Sin datos.");
  const L = [];
  L.push("CORTE BASCULA vs SISTEMA");
  L.push("Dia " + dia);
  L.push("------------------------------------------");
  L.push("Tickets de bascula cobrados en el POS:");
  (r.tickets || []).forEach((t) => {
    L.push(lineasDinero("#" + t.posFolio + " " + (t.etiqueta || ""), t.cents));
  });
  L.push(lineasDinero("TOTAL TICKETS BASCULA", r.ticketsCents || 0));
  if ((r.comunes || []).length) {
    L.push("");
    L.push("Producto comun (NO es ticket de bascula):");
    r.comunes.forEach((c) => L.push(lineasDinero("POS #" + c.posFolio, c.cents)));
    L.push(lineasDinero("TOTAL PRODUCTO COMUN", r.comunCents || 0));
  }
  L.push("");
  L.push(lineasDinero("Carnes bascula (sistema)", r.carnesBasculaCents || 0));
  L.push(lineasDinero("Categorias mostrador", r.categoriasCents || 0));
  L.push(lineasDinero("Ventas cobradas", r.cobradoCents || 0));
  if (r.basculaManualCents != null) {
    L.push(lineasDinero("Bascula capturada al cierre", r.basculaManualCents));
    if (r.paquetesManualCents != null) L.push(lineasDinero("Paquetes capturados al cierre", r.paquetesManualCents));
    L.push(lineasDinero("Categ + bascula + paquetes", (r.categoriasCents || 0) + r.basculaManualCents + (r.paquetesManualCents || 0)));
    L.push(lineasDinero("DIFERENCIA", r.diferenciaCents || 0));
    L.push("(categ + bascula + paquetes - cobrado)");
  }
  if (r.diferidoCents) L.push(lineasDinero("Diferido (canc/dev)", r.diferidoCents));
  (r.cancelaciones || []).forEach((c) => {
    L.push("  CANC #" + c.folio + (c.basculaFolio != null ? " B" + c.basculaFolio : "") + " " + fmt(c.montoCents));
  });
  L.push("------------------------------------------");
  L.push("La bascula fisica solo se lee en vivo.");
  L.push("Este ticket usa lo cobrado en el sistema.");
  return imprimirListaFlujo("CORTE BASCULA " + dia, L);
}

async function renderCorte(body) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>🧾</span><p>Sin base de datos disponible.</p></div>'; return; }
  body.innerHTML = `<div id="corte-live"></div><div id="corte-dia" class="mv-topgap"></div>`;
  await renderCajaLive($("#corte-live", body), body);
  await renderCorteDia($("#corte-dia", body), hoyISO());
}

let ingresosMesesOk = false;
const MES_NOMBRE = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
function etiquetaMes(ym) {
  const p = String(ym || "").split("-");
  const i = Number(p[1]) - 1;
  return (MES_NOMBRE[i] || ym) + " " + (p[0] || "");
}

function imprimirIngresosMeses(filas, titulo) {
  const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
  const lr = (a, b) => { a = String(a); b = String(b); const s = cols - a.length - b.length; return s >= 1 ? a + " ".repeat(s) + b : (a + " " + b); };
  const center = (s) => { s = String(s); const pad = Math.max(0, Math.floor((cols - s.length) / 2)); return " ".repeat(pad) + s; };
  const L = [];
  L.push(center("INGRESOS POR MES"));
  L.push(center(titulo || ""));
  L.push("Fecha: " + new Date().toLocaleString("es-MX"));
  L.push("(ventas menos devoluciones, mas abonos)");
  const suma = {};
  let gran = 0;
  const fechaCorta = (iso) => {
    const p = String(iso || "").split("-");
    return p.length === 3 ? (p[2] + "/" + p[1] + "/" + p[0]) : iso;
  };
  (filas || []).forEach((f) => {
    L.push("-".repeat(cols));
    L.push(etiquetaMes(f.mes).toUpperCase() + (f.numVentas ? "  " + f.numVentas + " ventas" : ""));
    (f.dias || []).forEach((d) => {
      L.push("");
      L.push(fechaCorta(d.dia) + (d.numVentas ? "  " + d.numVentas + " ventas" : ""));
      Object.keys(d.metodos || {}).sort().forEach((k) => {
        const c = d.metodos[k] || 0;
        if (!c) return;
        L.push(lr("  " + pagoLabel(k), fmt(c)));
      });
      L.push(lr("  TOTAL DEL DIA", fmt(d.totalCents || 0)));
    });
    L.push("");
    Object.keys(f.metodos || {}).sort().forEach((k) => {
      const c = f.metodos[k] || 0;
      if (!c) return;
      suma[k] = (suma[k] || 0) + c;
      L.push(lr(pagoLabel(k), fmt(c)));
    });
    L.push(lr("TOTAL DEL MES", fmt(f.totalCents || 0)));
    gran += f.totalCents || 0;
  });
  L.push("=".repeat(cols));
  Object.keys(suma).sort().forEach((k) => L.push(lr(pagoLabel(k), fmt(suma[k]))));
  L.push(lr("TOTAL DEL PERIODO", fmt(gran)));
  imprimirListaFlujo("INGRESOS POR MES", L);
}

async function renderIngresosMeses(el) {
  if (!el) return;
  if (!copiaEnVivo && window.api && window.api.getAppInfo) {
    try {
      const info = await window.api.getAppInfo();
      copiaEnVivo = !!(info && info.copiaEnVivo);
    } catch (e) {}
  }
  if (copiaEnVivo) ingresosMesesOk = true;
  const pintarBloqueo = () => {
    el.innerHTML = `
      <div class="mv-card gan-box">
        <div class="mv-card__head"><h3>Ingresos por mes</h3></div>
        <div class="gan-body is-locked">
          <p class="sub">Efectivo, tarjeta, transferencia y el resto de formas de pago, por mes.</p>
          <div class="gan-fake"><span>Enero</span><span>Efectivo</span><span>Tarjeta</span><span>Total</span></div>
          <div class="gan-fake"><span>Febrero</span><span>Efectivo</span><span>Tarjeta</span><span>Total</span></div>
        </div>
        <div class="gan-veil">
          <p>Este apartado está bloqueado.</p>
          <button class="btn btn--primary" id="gan-abrir">Ingresar clave de administrador</button>
        </div>
      </div>`;
    $("#gan-abrir", el).addEventListener("click", async () => {
      const ok = await pedirPinAdmin("Solo un administrador puede ver los ingresos por mes.");
      if (!ok) return;
      ingresosMesesOk = true;
      renderIngresosMeses(el);
    });
  };
  if (!ingresosMesesOk) return pintarBloqueo();
  let data = { meses: [] };
  try { data = await window.api.db.resumenIngresosMeses() || data; } catch (e) { data = { meses: [] }; }
  const meses = data.meses || [];
  const opts = meses.map((m) => `<option value="${attr(m.mes)}">${escapeHtml(etiquetaMes(m.mes))}</option>`).join("");
  el.innerHTML = `
    <div class="mv-card">
      <div class="mv-card__head">
        <h3>Ingresos por mes</h3>
        <div class="mv-actions">
          ${copiaEnVivo ? "" : `<button class="btn btn--sec" id="gan-cerrar">🔒 Cerrar sesión</button>`}
          <button class="btn btn--sec" id="gan-print" disabled>🖨️ Imprimir</button>
        </div>
      </div>
      <p class="sub" style="margin:0 0 8px">Ventas menos devoluciones, más abonos. El crédito es lo fiado de ese mes.</p>
      <div class="gan-filtros">
        <label><input type="radio" name="gan-modo" value="todos" checked /> Todos los meses</label>
        <label><input type="radio" name="gan-modo" value="mes" /> Un mes</label>
        <select id="gan-mes" ${opts ? "" : "disabled"}>${opts || `<option value="">Sin meses</option>`}</select>
        <label><input type="radio" name="gan-modo" value="rango" /> Rango</label>
        <select id="gan-desde" ${opts ? "" : "disabled"}>${opts}</select>
        <span>a</span>
        <select id="gan-hasta" ${opts ? "" : "disabled"}>${opts}</select>
      </div>
      <div id="gan-tabla" style="margin-top:10px"></div>
    </div>`;
  const modo = () => { const r = el.querySelector('input[name="gan-modo"]:checked'); return r ? r.value : "todos"; };
  const elegidos = () => {
    const m = modo();
    if (m === "mes") {
      const v = $("#gan-mes", el).value;
      return meses.filter((x) => x.mes === v);
    }
    if (m === "rango") {
      let a = $("#gan-desde", el).value;
      let b = $("#gan-hasta", el).value;
      if (a > b) { const t = a; a = b; b = t; }
      return meses.filter((x) => x.mes >= a && x.mes <= b);
    }
    return meses.slice();
  };
  const pintar = () => {
    const filas = elegidos();
    const box = $("#gan-tabla", el);
    const btn = $("#gan-print", el);
    if (btn) btn.disabled = !filas.length;
    if (!filas.length) { box.innerHTML = '<p class="muted">No hay ventas en ese periodo.</p>'; return; }
    const keys = [];
    const visto = new Set();
    const orden = ["efectivo", "dolares", "tarjeta", "transferencia", "vales", "credito"];
    filas.forEach((f) => Object.keys(f.metodos || {}).forEach((k) => { if ((f.metodos[k] || 0) !== 0 && !visto.has(k)) { visto.add(k); keys.push(k); } }));
    keys.sort((a, b) => {
      const ia = orden.indexOf(a); const ib = orden.indexOf(b);
      return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib) || a.localeCompare(b);
    });
    const suma = {};
    let gran = 0;
    const filaCeldas = (metodos, acumular) => keys.map((k) => {
      const c = (metodos && metodos[k]) || 0;
      if (acumular) suma[k] = (suma[k] || 0) + c;
      return `<td class="num">${c ? fmt(c) : "—"}</td>`;
    }).join("");
    const bodyRows = filas.map((f) => {
      gran += f.totalCents || 0;
      const dias = (f.dias || []).map((d) => {
        const p = String(d.dia || "").split("-");
        const etq = p.length === 3 ? (p[2] + "/" + p[1]) : d.dia;
        return `<tr><td style="padding-left:16px">${escapeHtml(etq)}<div class="muted">${d.numVentas || 0} ventas</div></td>${filaCeldas(d.metodos, false)}<td class="num">${fmt(d.totalCents || 0)}</td></tr>`;
      }).join("");
      return `<tr class="mv-total-row"><td>${escapeHtml(etiquetaMes(f.mes))}<div class="muted">${f.numVentas || 0} ventas</div></td>${filaCeldas(f.metodos, true)}<td class="num"><b>${fmt(f.totalCents || 0)}</b></td></tr>` + dias;
    }).join("");
    const pie = keys.map((k) => `<td class="num"><b>${fmt(suma[k] || 0)}</b></td>`).join("");
    box.innerHTML = `<div class="mv-table-wrap"><table class="mv-table"><thead><tr><th>Mes</th>${keys.map((k) => `<th class="num">${escapeHtml(pagoLabel(k))}</th>`).join("")}<th class="num">Total del mes</th></tr></thead><tbody>${bodyRows}<tr class="mv-total-row"><td>Total del periodo</td>${pie}<td class="num"><b>${fmt(gran)}</b></td></tr></tbody></table></div>`;
    if (btn) btn.onclick = () => {
      const m = modo();
      const tit = m === "mes" ? etiquetaMes(filas[0].mes) : (m === "rango" ? (etiquetaMes(filas[0].mes) + " a " + etiquetaMes(filas[filas.length - 1].mes)) : "Todos los meses");
      imprimirIngresosMeses(filas, tit);
    };
  };
  const btnCerrar = $("#gan-cerrar", el);
  if (btnCerrar) btnCerrar.addEventListener("click", () => {
    ingresosMesesOk = false;
    renderIngresosMeses(el);
  });
  $$('input[name="gan-modo"]', el).forEach((r) => r.addEventListener("change", pintar));
  ["gan-mes", "gan-desde", "gan-hasta"].forEach((id) => { const s = $("#" + id, el); if (s) s.addEventListener("change", () => { const radio = el.querySelector('input[name="gan-modo"][value="' + (id === "gan-mes" ? "mes" : "rango") + '"]'); if (radio) radio.checked = true; pintar(); }); });
  pintar();
}

// Cuadre del corte de la báscula contra el sistema. Lee lo que cada báscula
// tiene acumulado y lo empareja (por clave de venta) con lo que realmente se
// cobró en el POS, mostrando y justificando cada diferencia (artículo quitado,
// venta cancelada, devolución) para que el corte cuadre al centavo.
async function renderCorteBascula(el) {
  if (!el) return;
  const dir = CFG && CFG.bascula && CFG.bascula.modoDirecto;
  el.innerHTML = `
    <div class="mv-card">
      <div class="mv-card__head">
        <h3>⚖️ Corte de báscula (cuadre con el sistema)</h3>
        <button class="btn btn--sec" id="cb-comparar">🔄 Comparar con básculas</button>
        <button class="btn btn--sec" id="cb-imprimir">🖨️ Imprimir corte de básculas</button>
      </div>
      <p class="sub" style="margin:0">Compara lo que la báscula tiene registrado contra lo que realmente cobraste en el sistema (ya con cancelaciones y devoluciones). Cada diferencia queda explicada.</p>
      ${dir ? "" : '<p class="tk-warn" style="margin-top:8px">⚠️ Requiere el modo directo (TCP). Actívalo en ⚙️ Configuración → Básculas.</p>'}
      <div class="bk-estado" id="cb-estado"></div>
      <div id="cb-tabla" style="margin-top:10px"></div>
    </div>`;

  const btn = $("#cb-comparar", el);
  const bImp = $("#cb-imprimir", el);
  const est = $("#cb-estado", el);
  const cont = $("#cb-tabla", el);
  if (!dir) { if (btn) btn.disabled = true; if (bImp) bImp.disabled = true; return; }
  if (bImp) bImp.addEventListener("click", () => imprimirCorteBasculasVivo());

  btn.addEventListener("click", async () => {
    est.innerHTML = "Leyendo básculas y cuadrando con el sistema…";
    cont.innerHTML = "";
    let rv, mapa;
    try {
      [rv, mapa] = await Promise.all([
        window.api.bascula.leerVentasTodas(),
        window.api.db.resumenBasculaCorte()
      ]);
    } catch (e) { est.innerHTML = `<span class="tk-warn">⚠️ ${escapeHtml(e.message)}</span>`; return; }
    if (!rv || (!rv.ok && !rv.ventas)) {
      est.innerHTML = `<span class="tk-warn">⚠️ ${escapeHtml(rv && rv.error ? rv.error : "No se pudo leer la báscula.")}</span>`;
      return;
    }
    mapa = mapa || {};
    const ventas = (rv.ventas || []).slice().sort((a, b) =>
      String(a.folio).localeCompare(String(b.folio), "es", { numeric: true }));

    let sumBascula = 0, sumSistema = 0, sumDif = 0, pendientes = 0;
    const filas = ventas.map((v) => {
      const bTot = v.totalCents || 0;
      sumBascula += bTot;
      const pos = mapa[v.key];
      let sisTxt, difTot, motivo, cls = "";
      if (!pos) {
        sisTxt = "—";
        difTot = 0;                 // aún no cobrada en el sistema (no es descuadre)
        motivo = "Pendiente (no cobrada en el sistema)";
        cls = "cb-row--pend";
        pendientes++;
      } else {
        const neto = pos.netoCents || 0;
        sumSistema += neto;
        difTot = bTot - neto;
        sumDif += difTot;
        sisTxt = fmt(neto);
        if (pos.cancelada) { motivo = "Venta cancelada"; cls = "cb-row--dif"; }
        else if (pos.devueltoCents) { motivo = "Devolución " + fmt(pos.devueltoCents); cls = "cb-row--dif"; }
        else if (difTot !== 0) { motivo = "Modificada (paquete/artículos)"; cls = "cb-row--dif"; }
        else { motivo = "✓ Cuadra"; }
      }
      const serie = v.nserie ? ` <span class="sub">·${escapeHtml(String(v.nserie))}</span>` : "";
      return `<tr class="${cls}">
        <td>${escapeHtml(String(v.folio))}${serie}</td>
        <td class="num">${fmt(bTot)}</td>
        <td class="num">${sisTxt}</td>
        <td class="num">${difTot ? fmt(difTot) : "—"}</td>
        <td>${motivo}</td>
      </tr>`;
    }).join("");

    if (!ventas.length) {
      est.innerHTML = '<span class="tk-info">La(s) báscula(s) no tienen ventas acumuladas.</span>';
      return;
    }

    const errBas = (rv.basculas || []).filter((b) => !b.ok);
    est.innerHTML = `<span class="tk-ok">✅ ${ventas.length} venta(s) en báscula comparadas.</span>` +
      (pendientes ? ` <span class="tk-info">${pendientes} pendiente(s) de cobro.</span>` : "") +
      (errBas.length ? `<br/><span class="tk-warn">⚠️ ${errBas.map((b) => `${escapeHtml(b.ip)}: ${escapeHtml(b.error || "sin respuesta")}`).join("; ")}</span>` : "");

    cont.innerHTML = `
      <table class="mv-table">
        <thead><tr><th>Folio báscula</th><th class="num">Báscula</th><th class="num">Sistema (cobrado)</th><th class="num">Diferencia</th><th>Motivo</th></tr></thead>
        <tbody>${filas}</tbody>
        <tfoot>
          <tr class="mv-total-row">
            <td>Totales</td>
            <td class="num">${fmt(sumBascula)}</td>
            <td class="num">${fmt(sumSistema)}</td>
            <td class="num">${fmt(sumDif)}</td>
            <td>${sumDif ? "Diferencia justificada" : "Cuadra"}</td>
          </tr>
        </tfoot>
      </table>
      <p class="sub" style="margin-top:8px"><b>Báscula</b>: lo que la báscula registró. <b>Sistema</b>: lo que realmente cobraste (con modificaciones, cancelaciones y devoluciones). El corte oficial es el del <b>sistema</b>; la columna Diferencia explica cada descuadre contra el ticket de la báscula.</p>`;
  });
}

// Modal de apertura de caja: pregunta el dinero inicial (fondo) del turno.
// Se muestra al iniciar sesión y, si hiciera falta, para reabrir un turno.
function pedirAperturaCaja(onDone) {
  if (!tienenDB()) { if (onDone) onDone(false); return; }
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>${cajaAbierta ? "Fondo inicial de la caja" : "Apertura de caja"}</h3>
      <div class="qty-hint">¿Cuánto dinero hay <b>ahora</b> en la caja para iniciar el turno? <b>(fondo inicial)</b></div>
      <input type="number" id="ap-fondo" class="qty-field" min="0" step="0.01" value="${cajaAbierta ? (cajaFondoActual / 100).toFixed(2) : "0"}" />
      <div class="qty-hint">Cuenta lo que hay físicamente (puede diferir del “queda en caja” del cierre si se sacó dinero fuera de turno).</div>
      <div class="qty-hint" style="margin-top:12px">💵 <b>Tipo de cambio del dólar</b> (pesos por dólar). Se usa para cobros en dólares durante el turno.</div>
      <div style="display:flex;gap:8px;align-items:center">
        <input type="number" id="ap-dolar" class="qty-field" min="0" step="0.01" value="" placeholder="Cargando del día…" style="flex:1" />
        <button class="btn btn--sec" id="ap-dolar-hoy" title="Actualizar del día">🔄 Hoy</button>
      </div>
      <div class="qty-hint" id="ap-dolar-hint">Se llena automáticamente con el tipo de cambio del día (editable).</div>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Ahora no</button>
        <button class="btn btn--primary" id="ap-ok">${cajaAbierta ? "Guardar fondo" : "Abrir caja"}</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = (ok) => { back.remove(); if (onDone) onDone(!!ok); };
  // Autollenado del tipo de cambio del día (de internet), editable.
  const cargarTC = async (force) => {
    const inp = $("#ap-dolar", back); const hint = $("#ap-dolar-hint", back);
    if (!inp || !window.api || !window.api.fx) return;
    if (hint) hint.textContent = "Consultando tipo de cambio…";
    try {
      const r = await window.api.fx.usdMxn(!!force);
      if (r && r.rate) {
        if (!inp.value || force) inp.value = r.rate.toFixed(2);
        if (hint) hint.textContent = r.offline
          ? `Sin internet: último conocido $${r.rate.toFixed(2)} (editable)`
          : `Tipo de cambio de hoy: $${r.rate.toFixed(2)} · ${r.fuente || "internet"} (editable)`;
      } else if (hint) { hint.textContent = "No se pudo obtener de internet; escríbelo a mano."; }
    } catch (e) { if (hint) hint.textContent = "No se pudo obtener de internet; escríbelo a mano."; }
  };
  cargarTC(false);
  const bHoy = $("#ap-dolar-hoy", back); if (bHoy) bHoy.addEventListener("click", () => cargarTC(true));
  const abrir = async () => {
    const fondo = Money.toCents(parseFloat($("#ap-fondo", back).value.replace(",", ".")) || 0) || 0;
    const tipoCambio = parseFloat(String($("#ap-dolar", back).value).replace(",", ".")) || 0;
    // Si la caja YA está abierta (recién, sin actividad) corrige su fondo inicial;
    // si está cerrada, abre una nueva con ese fondo.
    const r = cajaAbierta
      ? await window.api.db.setFondoInicialCaja(fondo, tipoCambio, usuarioActual ? usuarioActual.nombre : null)
      : await window.api.db.abrirCaja(fondo, usuarioActual ? usuarioActual.nombre : null, tipoCambio);
    if (r && r.error) return alert(r.error);
    await refreshCajaStatus();
    cerrar(true);
  };
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(false); });
  $("#ap-ok", back).addEventListener("click", abrir);
  const inp = $("#ap-fondo", back);
  inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); abrir(); } });
  setTimeout(() => { inp.focus(); inp.select(); }, 30);
}

/* ---------------- Configuración inicial (primera instalación) ---------------- */
// Se muestra solo la primera vez. Permite elegir entre trabajar con datos de
// ejemplo o importar la información desde un respaldo o desde ELEVENTA.
function pedirSetupInicial(onDone) {
  if (!tienenDB()) { if (onDone) onDone(); return; }
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--setup">
      <h3>Configuración inicial</h3>
      <p class="cobro-desc">¿Cómo quieres empezar a trabajar? Puedes cambiar esto después.</p>
      <div class="setup-opts">
        <button class="setup-opt" id="su-demo">
          <span class="setup-opt__ico">🧪</span>
          <span class="setup-opt__t">Usar datos de ejemplo</span>
          <span class="setup-opt__d">Productos, precios y existencias de prueba para empezar de inmediato.</span>
        </button>
        <button class="setup-opt" id="su-respaldo">
          <span class="setup-opt__ico">📦</span>
          <span class="setup-opt__t">Importar un respaldo</span>
          <span class="setup-opt__d">Cargar un archivo de respaldo (.json) generado por este sistema.</span>
        </button>
        <button class="setup-opt" id="su-eleventa">
          <span class="setup-opt__ico">🗄️</span>
          <span class="setup-opt__t">Importar desde ELEVENTA</span>
          <span class="setup-opt__d">Traer productos, existencias y clientes desde la base de datos de ELEVENTA.</span>
        </button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => { back.remove(); if (onDone) onDone(); };
  $("#su-demo", back).addEventListener("click", async () => {
    await window.api.db.marcarConfigurado();
    CFG = await window.api.db.getConfig();
    cerrar();
  });
  $("#su-respaldo", back).addEventListener("click", async () => {
    const r = await window.api.db.importar();
    if (r && r.cancelado) return;
    if (r && r.error) return alert(r.error);
    await window.api.db.marcarConfigurado();
    await recargarDatos();
    alert("Respaldo importado correctamente.");
    cerrar();
  });
  $("#su-eleventa", back).addEventListener("click", () => {
    back.remove();
    pedirImportarEleventa(onDone, () => pedirSetupInicial(onDone));
  });
}

// Asistente de conexión e importación desde ELEVENTA (Firebird / PDVDATA.FDB).
function pedirImportarEleventa(onDone, onVolver) {
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--setup">
      <h3>Importar desde ELEVENTA</h3>
      <p class="cobro-desc">Conéctate a la base de datos de ELEVENTA (PDVDATA.FDB) para traer productos, existencias y clientes.</p>
      <div class="ev-form">
        <label class="mv-field"><span>Archivo de base de datos (PDVDATA.FDB)</span>
          <div class="ev-file">
            <input type="text" id="ev-archivo" placeholder="C:\\Program Files (x86)\\AbarrotesMultiCaja\\db\\PDVDATA.FDB" />
            <button class="btn btn--sec" id="ev-elegir">Elegir…</button>
          </div>
        </label>
        <div class="cf-2col">
          <label class="mv-field"><span>Servidor</span><input type="text" id="ev-host" value="localhost" /></label>
          <label class="mv-field"><span>Puerto</span><input type="number" id="ev-port" value="3050" /></label>
        </div>
        <div class="cf-2col">
          <label class="mv-field"><span>Usuario</span><input type="text" id="ev-user" value="SYSDBA" /></label>
          <label class="mv-field"><span>Contraseña</span><input type="text" id="ev-pass" value="masterkey" /></label>
        </div>
      </div>
      <div class="ev-estado" id="ev-estado"></div>
      <div class="modal__foot ev-foot">
        <button class="btn" id="ev-volver">Volver</button>
        <button class="btn btn--sec" id="ev-probar">Probar conexión</button>
        <button class="btn btn--sec" id="ev-analizar">Analizar</button>
        <button class="btn btn--primary" id="ev-importar">Importar</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const est = $("#ev-estado", back);
  const cfg = () => ({
    database: $("#ev-archivo", back).value.trim(),
    host: $("#ev-host", back).value.trim() || "localhost",
    port: parseInt($("#ev-port", back).value, 10) || 3050,
    user: $("#ev-user", back).value.trim() || "SYSDBA",
    password: $("#ev-pass", back).value
  });
  const msg = (txt, tipo) => { est.className = "ev-estado ev-estado--" + (tipo || "info"); est.textContent = txt; };
  const validarArchivo = () => {
    if (!$("#ev-archivo", back).value.trim()) { msg("Primero selecciona el archivo PDVDATA.FDB.", "warn"); return false; }
    return true;
  };

  $("#ev-elegir", back).addEventListener("click", async () => {
    const r = await window.api.eleventa.elegirArchivo();
    if (r && r.ok) { $("#ev-archivo", back).value = r.archivo; msg("Archivo seleccionado.", "ok"); }
  });
  $("#ev-probar", back).addEventListener("click", async () => {
    if (!validarArchivo()) return;
    msg("Probando conexión…", "info");
    const r = await window.api.eleventa.probar(cfg());
    if (r && r.ok) msg("✓ Conexión exitosa con ELEVENTA.", "ok");
    else msg("✕ " + ((r && r.error) || "No se pudo conectar."), "err");
  });
  $("#ev-analizar", back).addEventListener("click", async () => {
    if (!validarArchivo()) return;
    msg("Analizando base de datos…", "info");
    const r = await window.api.eleventa.analizar(cfg());
    if (r && r.ok) {
      msg(`Encontrado — Productos: ${r.productos ?? "?"} · Departamentos: ${r.departamentos ?? "?"} · Clientes: ${r.clientes ?? "?"} · Ventas: ${r.ventas ?? "?"}`, "ok");
    } else msg("✕ " + ((r && r.error) || "No se pudo analizar."), "err");
  });
  $("#ev-importar", back).addEventListener("click", async () => {
    if (!validarArchivo()) return;
    if (!confirm("Se reemplazarán los productos, existencias, categorías y clientes actuales con los datos de ELEVENTA. ¿Continuar?")) return;
    msg("Importando datos… puede tardar unos segundos.", "info");
    const r = await window.api.eleventa.importar(cfg());
    if (r && r.ok) {
      await window.api.db.marcarConfigurado();
      await recargarDatos();
      alert(`Importación completada.\nProductos: ${r.resumen.productos}\nCategorías: ${r.resumen.categorias}\nClientes: ${r.resumen.clientes}`);
      back.remove();
      if (onDone) onDone();
    } else msg("✕ " + ((r && r.error) || "No se pudo importar."), "err");
  });
  $("#ev-volver", back).addEventListener("click", () => { back.remove(); if (onVolver) onVolver(); });
  setTimeout(() => { const a = $("#ev-archivo", back); if (a) a.focus(); }, 30);
}

async function renderCajaLive(el, body) {
  const st = await window.api.db.estadoCaja();

  if (!st.abierta) {
    el.innerHTML = `
      <div class="mv-card mv-card--center">
        <h3>Caja cerrada</h3>
        <p class="sub">La caja se abre al iniciar sesión. Si la cerraste para hacer el corte, puedes abrir un nuevo turno aquí.</p>
        <button class="btn btn--primary" id="corte-abrir">Abrir caja</button>
      </div>`;
    $("#corte-abrir", el).addEventListener("click", () => pedirAperturaCaja(() => renderCorte(body)));
    return;
  }

  const c = st.caja;
  const movs = (c.movimientos || []).map((m) =>
    `<tr><td>${m.tipo === "ingreso" ? "⬆ Ingreso" : "⬇ Retiro"}</td><td>${m.motivo || ""}</td><td class="num">${fmt(m.montoCents)}</td></tr>`
  ).join("") || `<tr><td colspan="3" class="muted">Sin movimientos de efectivo.</td></tr>`;

  el.innerHTML = `
    <div class="mv-grid2">
      <div class="mv-card">
        <div class="mv-card__head"><h3>Estado de caja (turno actual)</h3><span class="pill pill--ok">Abierta</span></div>
        <div class="mv-kv"><span>Cajero</span><b>${c.usuario || "—"}</b></div>
        <div class="mv-kv"><span>Apertura</span><b>${new Date(c.aperturaFecha).toLocaleString("es-MX")}</b></div>
        <div class="mv-kv"><span>Fondo inicial</span><b>${fmt(c.fondoCents)}</b></div>
        <div class="mv-kv"><span>Ventas cobradas (${st.numVentas})</span><b>${fmt(st.ventasCobradas != null ? st.ventasCobradas : st.totalVentas)}</b></div>
        ${st.apartadosCents ? `<div class="mv-kv"><span>🏷️ de las cuales, apartados (abonos)</span><b>${fmt(st.apartadosCents)}</b></div>` : ""}
        <div class="mv-kv"><span>Devoluciones de contado</span><b class="neg">- ${fmt(st.devCobradas != null ? st.devCobradas : st.totalDevoluciones)}</b></div>
        <div class="mv-kv mv-kv--total"><span>Venta neta cobrada</span><b>${fmt(st.ventasNetas)}</b></div>
        ${st.creditoVentas ? `<div class="mv-kv"><span>📒 A crédito (no cobrado)</span><b>${fmt(st.creditoVentas)}</b></div>` : ""}
        ${st.totalDevoluciones ? `<p class="nota-dev">↩️ Las devoluciones no son pérdida: el dinero regresó al cliente y la mercancía volvió al inventario. Solo se descuenta del efectivo lo reembolsado en efectivo.</p>` : ""}
        <hr/>
        <h4>Por forma de pago <span class="muted">(ventas + abonos)</span></h4>
        ${Object.keys(st.porMetodo || {}).filter((id) => st.porMetodo[id] && id !== "credito").map((id) =>
          `<div class="mv-kv"><span>${pagoLabel(id)}</span><b>${fmt(st.porMetodo[id])}</b></div>`
        ).join("") || `<div class="mv-kv"><span class="muted">Sin cobros</span><b>${fmt(0)}</b></div>`}
        <hr/>
        <h4>Cálculo de efectivo</h4>
        <div class="mv-kv"><span>Fondo inicial</span><b>${fmt(c.fondoCents)}</b></div>
        <div class="mv-kv"><span>Efectivo de ventas</span><b>${fmt(st.efectivoVentas)}</b></div>
        <div class="mv-kv"><span>Devoluciones en efectivo</span><b class="neg">- ${fmt(st.efectivoDevoluciones)}</b></div>
        <div class="mv-kv"><span>Ingresos de efectivo</span><b>${fmt(st.ingresos)}</b></div>
        ${st.totalAbonosCents ? `<div class="mv-kv"><span>💳 Abonos a crédito (efectivo)</span><b>${fmt(st.totalAbonosCents)}</b></div>` : ""}
        ${st.totalAbonosOtrosCents ? `<div class="mv-kv"><span>💳 Abonos a crédito (tarjeta/transf.)</span><b>${fmt(st.totalAbonosOtrosCents)}</b></div>` : ""}
        <div class="mv-kv"><span>Retiros de efectivo</span><b class="neg">- ${fmt(st.retiros)}</b></div>
        <div class="mv-kv mv-kv--total"><span>Efectivo esperado en caja</span><b>${fmt(st.efectivoEsperado)}</b></div>
        ${(() => {
          const otras = deptosCorte(st.ventasPorDepto);
          const cb = datoCarnesBascula(st);
          if (!cb.montoCents && !otras.length) return "";
          const fila = (d) => {
            const prods = (d.productos || []).map((p) => `<div class="mv-kv" style="padding-left:14px"><span>${escapeHtml(p.nombre)}${p.cant != null ? ` <span class="muted">× ${Number(p.cant).toLocaleString("es-MX")}</span>` : ""}</span><b>${fmt(p.montoCents)}</b></div>`).join("");
            return `<div class="mv-kv"><span><b>${escapeHtml(d.depto)}</b></span><b>${fmt(d.montoCents)}</b></div>${prods}`;
          };
          const sumaCatLive = otras.reduce((s, d) => s + (d.montoCents || 0), 0);
          return `
        <hr/>
        <h4>Ventas por categoría <span class="muted">(sin créditos no pagados; báscula sin desglose)</span></h4>
        ${otras.map(fila).join("")}
        <div class="mv-kv mv-kv--total"><span>Total categorías</span><b>${fmt(sumaCatLive)}</b></div>
        <div class="mv-kv"><span>Total báscula (manual)</span><b>${st.basculaTotalManualCents != null ? fmt(st.basculaTotalManualCents) : "(al cierre)"}</b></div>
        <div class="mv-kv"><span>Total paquetes (manual)</span><b>${st.paquetesTotalManualCents != null ? fmt(st.paquetesTotalManualCents) : "(al cierre)"}</b></div>
        <div class="mv-kv mv-kv--total"><span>Total categorías + báscula + paquetes</span><b>${fmt(sumaCatLive + (st.basculaTotalManualCents || 0) + (st.paquetesTotalManualCents || 0))}</b></div>
        <h4>Carnes báscula <span class="muted">(dato; no suma)</span></h4>
        <div class="mv-kv"><span>Total carnes báscula${cb.cant ? ` <span class="muted">× ${Number(cb.cant).toLocaleString("es-MX")}</span>` : ""}</span><b>${fmt(cb.montoCents)}</b></div>`;
        })()}
      </div>

      <div class="mv-card">
        <div class="mv-card__head"><h3>Movimientos de efectivo</h3></div>
        <p class="sub">Las entradas y salidas de efectivo se registran en los botones <b>⬆️ Entrada</b> y <b>⬇️ Salida</b> del menú superior.</p>
        <div class="mv-actions">
          <button class="btn btn--sec" id="corte-mov-print">🖨️ Imprimir movimientos</button>
        </div>
        <table class="mv-table"><thead><tr><th>Tipo</th><th>Motivo</th><th class="num">Monto</th></tr></thead>
          <tbody>${movs}</tbody></table>
        <hr/>
        <div class="mv-actions">
          <button class="btn btn--sec" id="corte-imprimir">🖨️ Imprimir corte</button>
        </div>
        <button class="btn btn--primary btn--block" id="corte-cerrar">Cerrar caja / Hacer corte</button>
      </div>
    </div>`;
    // Nota: los apartados "Abonos a crédito" y "Diferido con báscula" se muestran
    // UNA sola vez, en la vista de "Corte por día" de abajo (evita duplicado).

  $("#corte-imprimir", el).addEventListener("click", () => imprimirCorteFlujo(corteDesdeEstado(st)));
  // El corte de otro día se reimprime abajo, eligiendo la fecha (sin folio).
  $("#corte-mov-print", el).addEventListener("click", () => {
    const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
    const lista = (c.movimientos || []);
    const lineas = lista.map((m) => {
      const hora = m.fecha ? new Date(m.fecha).toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" }) : "";
      const signo = m.tipo === "ingreso" ? "+" : "-";
      const izq = `${hora} ${m.tipo === "ingreso" ? "INGRESO" : "RETIRO"} ${m.motivo || ""}`.trim();
      const der = signo + fmt(m.montoCents);
      const esp = cols - izq.length - der.length;
      return izq + (esp >= 1 ? " ".repeat(esp) : " ") + der;
    });
    lineas.push("-".repeat(cols));
    lineas.push(`Ingresos: ${fmt(st.ingresos)}  Retiros: ${fmt(st.retiros)}`);
    lineas.push(`Efectivo esperado: ${fmt(st.efectivoEsperado)}`);
    imprimirListaFlujo("MOVIMIENTOS DE EFECTIVO", lineas.length ? lineas : ["(sin movimientos)"]);
  });
  $("#corte-cerrar", el).addEventListener("click", () => cerrarCajaFlujo(st, body));
}

/* Corte por día (calendario) con métodos de pago agrupados y desglose */
async function renderCorteDia(el, fecha) {
  const d = await window.api.db.detalleDia(fecha);
  const activos = [];
  PAGOS.forEach((p) => {
    const m = d.metodos[p.id];
    if (m && (m.ventasCents || m.devolucionesCents || m.abonosCents)) activos.push({ id: p.id, emoji: p.emoji, label: p.label });
  });
  // El crédito no va en estas tarjetas: tiene su propio apartado y no suma al neto.
  Object.keys(d.metodos).forEach((id) => {
    if (id === "credito" || PAGOS.some((p) => p.id === id)) return;
    const m = d.metodos[id];
    if (m && (m.ventasCents || m.devolucionesCents || m.abonosCents)) activos.push({ id, emoji: pagoEmoji(id), label: pagoLabel(id) });
  });

  const tarjetas = activos.length
    ? activos.map((p) => {
        const m = d.metodos[p.id];
        return `<button class="pay-card" data-metodo="${p.id}">
            <span class="pay-card__emoji">${p.emoji}</span>
            <span class="pay-card__label">${p.label}</span>
            <span class="pay-card__amt">${fmt(m.netoCents)}</span>
            <span class="pay-card__sub">${m.numVentas} venta(s)${m.devolucionesCents ? " · dev. " + fmt(m.devolucionesCents) : ""}${m.abonosCents ? " · incl. abonos " + fmt(m.abonosCents) : ""}</span>
          </button>`;
      }).join("")
    : `<div class="muted" style="padding:14px">Sin ventas registradas en esta fecha.</div>`;

  el.innerHTML = `
    <div class="mv-card">
      <div class="mv-card__head">
        <h3>Corte por día</h3>
        <div class="mv-head-actions">
          <input type="date" id="corte-fecha" class="mv-search" value="${d.dia}" max="${hoyISO()}" />
          <button class="btn btn--sec" id="dia-imprimir-corte">🖨️ Imprimir corte de este día</button>
          <button class="btn btn--sec" id="dia-imprimir-bascula">🖨️ Corte de básculas de este día</button>
        </div>
      </div>
      <div class="dia-tot">
        <div class="dia-tot__item"><span>Ventas cobradas</span><b>${fmt(d.ventasCobradasCents != null ? d.ventasCobradasCents : d.totalVentasCents)}</b></div>
        <div class="dia-tot__item"><span>Devoluciones de contado</span><b class="neg">- ${fmt(d.devCobradasCents != null ? d.devCobradasCents : d.totalDevolucionesCents)}</b></div>
        ${d.apartadosCents ? `<div class="dia-tot__item"><span>🏷️ Apartados (abonos)</span><b>${fmt(d.apartadosCents)}</b></div>` : ""}
        <div class="dia-tot__item dia-tot__item--net"><span>Neto cobrado</span><b>${fmt(d.totalNetoCents)}</b></div>
        ${d.creditoVentasCents ? `<div class="dia-tot__item"><span>📒 Crédito (no cobrado)</span><b>${fmt(d.creditoVentasCents)}</b></div>` : ""}
      </div>
      <p class="qty-hint">Elige el día y pulsa imprimir. No hace falta el folio.</p>
      <h4>Formas de pago (clic para ver el detalle)</h4>
      <div class="pay-cards">${tarjetas}</div>
      <div id="metodo-detalle" class="metodo-detalle"></div>
    </div>
    ${creditosCorteHTML(d)}
    ${abonosCorteHTML(d)}
    ${diferidoBasculaHTML(d)}`;

  $("#corte-fecha", el).addEventListener("change", (e) => renderCorteDia(el, e.target.value));
  $("#dia-imprimir-corte", el).addEventListener("click", () => imprimirCorteDelDia(d.dia));
  const bb = $("#dia-imprimir-bascula", el);
  if (bb) bb.addEventListener("click", () => imprimirCorteBasculasDia(d.dia));
  $$("[data-metodo]", el).forEach((b) =>
    b.addEventListener("click", () => {
      $$(".pay-card", el).forEach((x) => x.classList.remove("is-active"));
      b.classList.add("is-active");
      renderMetodoDetalle($("#metodo-detalle", el), d.metodos[b.dataset.metodo], b.dataset.metodo);
    }));
}

function creditosCorteHTML(d) {
  const lista = d.creditos || [];
  if (!lista.length && !(d.creditoVentasCents || d.creditoDevCents)) return "";
  const filas = lista.map((x) => `
    <tr>
      <td class="muted">${escapeHtml(String(x.hora || ""))}</td>
      <td>${escapeHtml(x.cliente || "Sin nombre")}</td>
      <td class="num">${fmt(x.montoCents)}</td>
    </tr>`).join("");
  const dev = d.creditoDevCents
    ? `<tr class="mv-total-row"><td colspan="2">Devoluciones a crédito</td><td class="num neg">- ${fmt(d.creditoDevCents)}</td></tr>`
    : "";
  const total = Math.max(0, (d.creditoVentasCents || 0) - (d.creditoDevCents || 0));
  return `
    <div class="mv-card mv-topgap">
      <div class="mv-card__head"><h3>📒 Créditos del día</h3></div>
      <p class="sub" style="margin:0 0 8px">Fiado del día. <b>No entra</b> al neto cobrado. El abono, cuando se pague, sí entra en el corte de ese día.</p>
      <table class="mv-table">
        <thead><tr><th>Hora</th><th>A quién se vendió</th><th class="num">Monto</th></tr></thead>
        <tbody>${filas || `<tr><td colspan="3" class="muted">Total de crédito sin nombres.</td></tr>`}</tbody>
        <tfoot>
          ${dev}
          <tr class="mv-total-row"><td colspan="2">Total créditos</td><td class="num">${fmt(total)}</td></tr>
        </tfoot>
      </table>
    </div>`;
}

// Apartado "Diferido con báscula": cancelaciones + devoluciones. La báscula las
// cuenta como venta (no respeta cancelado/devuelto), así que aquí se describen
// para poder cuadrar el corte del sistema contra el ticket de corte de la báscula.
function diferidoBasculaHTML(d) {
  const cancel = d.cancelaciones || [];
  const devs = d.devolucionesLista || [];
  if (!cancel.length && !devs.length) return "";
  const total = d.diferidoBasculaCents != null ? d.diferidoBasculaCents : (d.diferidoBascula || 0);
  const filaCancel = cancel.map((c) => `
    <tr class="dif-row dif-row--cancel">
      <td><span class="tag tag--cancel">CANCELADA</span></td>
      <td>#${escapeHtml(String(c.folio))}${c.basculaFolio != null ? ` <span class="tag tag--bascula">⚖️${escapeHtml(String(c.basculaFolio))}</span>` : ""}</td>
      <td>${c.motivo ? escapeHtml(c.motivo) : "<i>Sin motivo</i>"}</td>
      <td class="num neg">- ${fmt(c.montoCents)}</td>
    </tr>`).join("");
  const filaDev = devs.map((x) => `
    <tr class="dif-row dif-row--dev">
      <td><span class="tag">DEVOLUCIÓN</span></td>
      <td>#${escapeHtml(String(x.folio))}${x.ventaFolio ? ` <small class="muted">(venta #${escapeHtml(String(x.ventaFolio))})</small>` : ""}</td>
      <td>${x.motivo ? escapeHtml(x.motivo) : "Devolución"}</td>
      <td class="num neg">- ${fmt(x.montoCents)}</td>
    </tr>`).join("");
  return `
    <div class="mv-card mv-topgap">
      <div class="mv-card__head"><h3>⚖️ Diferido con báscula</h3></div>
      <p class="sub" style="margin:0 0 8px">La báscula cuenta estas operaciones como <b>venta</b> (no sabe que se cancelaron o devolvieron). Este es el monto que <b>sobra</b> en el corte de la báscula respecto al del sistema.</p>
      <table class="mv-table">
        <thead><tr><th>Tipo</th><th>Folio</th><th>Motivo</th><th class="num">Monto</th></tr></thead>
        <tbody>${filaCancel}${filaDev}</tbody>
        <tfoot>
          <tr class="mv-total-row"><td colspan="3">Total diferido con báscula</td><td class="num neg">- ${fmt(total)}</td></tr>
        </tfoot>
      </table>
      <p class="sub" style="margin-top:8px">Corte báscula (bruto) − <b>${fmt(total)}</b> = corte del sistema (neto real cobrado).</p>
    </div>`;
}

// Apartado "Abonos a crédito": pagos de fiado cobrados en el turno/día. Entran
// físicamente al cajón (suman al efectivo esperado) pero se muestran aparte para
// distinguir el dinero de ventas del dinero de cobranza de crédito.
function abonosCorteHTML(d) {
  // Efectivo casa no se lista ni se imprime en el corte (solo estado de cuenta).
  const abonos = (d.abonos || []).filter((a) => {
    const fp = String(a.formaPago || "efectivo").toLowerCase();
    return fp !== "efectivo_casa" && fp !== "ajuste";
  });
  if (!abonos.length) return "";
  const esEfvo = (fp) => { fp = (fp || "efectivo").toLowerCase(); return fp === "efectivo" || fp === "dolares"; };
  const totalEfvo = abonos.filter((a) => esEfvo(a.formaPago)).reduce((s, a) => s + (a.montoCents || 0), 0);
  const totalOtros = abonos.filter((a) => !esEfvo(a.formaPago)).reduce((s, a) => s + (a.montoCents || 0), 0);
  const total = totalEfvo + totalOtros;
  const filas = abonos.map((a) => {
    const hora = a.hora ? (typeof a.hora === "string" && a.hora.includes("T") ? new Date(a.hora).toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" }) : a.hora) : "";
    const fp = (a.formaPago || "efectivo").toUpperCase();
    const tag = esEfvo(a.formaPago) ? `<span class="tag">${escapeHtml(fp)}</span>` : `<span class="tag tag--cancel">${escapeHtml(fp)}</span>`;
    return `<tr class="dif-row">
      <td class="muted">${escapeHtml(String(hora))}</td>
      <td>${escapeHtml(a.cliente || "")}</td>
      <td>${tag}</td>
      <td class="num">${fmt(a.montoCents)}</td>
    </tr>`;
  }).join("");
  const totOtrosRow = totalOtros ? `<tr class="mv-total-row"><td colspan="3">Abonos con tarjeta/transferencia (NO en cajón)</td><td class="num">${fmt(totalOtros)}</td></tr>` : "";
  return `
    <div class="mv-card mv-topgap">
      <div class="mv-card__head"><h3>💳 Abonos a crédito</h3></div>
      <p class="sub" style="margin:0 0 8px">Cobranza de fiado del turno/día. Los abonos en <b>efectivo</b> están en el cajón (incluidos en el efectivo esperado). Los de <b>tarjeta/transferencia</b> NO entran al cajón: se listan aquí para cuadrar contra la terminal/banco.</p>
      <table class="mv-table">
        <thead><tr><th>Hora</th><th>Cliente</th><th>Forma de pago</th><th class="num">Monto</th></tr></thead>
        <tbody>${filas}</tbody>
        <tfoot>
          <tr class="mv-total-row"><td colspan="3">Abonos en efectivo (en cajón)</td><td class="num">${fmt(totalEfvo)}</td></tr>
          ${totOtrosRow}
          <tr class="mv-total-row"><td colspan="3">Total abonos a crédito</td><td class="num">${fmt(total)}</td></tr>
        </tfoot>
      </table>
    </div>`;
}

function renderMetodoDetalle(el, m, metodoId) {
  if (!m) { el.innerHTML = ""; return; }
  const label = pagoLabel(metodoId);

  // Cada venta (ticket) es una sola fila; al hacer clic se despliegan sus
  // productos. Así no se repite el folio por cada artículo.
  const itemsTabla = (items, neg) => `<table class="det-items"><tbody>${
    (items || []).map((it) => `<tr>
        <td>${escapeHtml(it.nombre)}${it.tipo === "paquete" ? ' <span class="tag">paq</span>' : ""}</td>
        <td class="num">${fmtCant(it.cant, it.unidad)} ${it.unidad || ""}</td>
        <td class="num${neg ? " neg" : ""}">${neg ? "- " : ""}${fmt(it.importeCents)}</td>
      </tr>`).join("") || '<tr><td class="muted">Sin productos.</td></tr>'
  }</tbody></table>`;

  const filas = (m.ventas || []).map((v) => {
    const combo = v.combinado
      ? `<div class="combo-mini">Pago combinado: ${(v.comboDesglose || []).map((x) => `${pagoEmoji(x.metodo)} ${pagoLabel(x.metodo)} ${fmt(x.montoCents)}`).join(" · ")}</div>`
      : "";
    const dev = v.devuelta;
    return `
      <tbody class="det-venta ${dev ? "det-venta--devuelta" : ""}">
        <tr class="det-venta__row">
          <td class="muted">${v.hora}</td>
          <td>#${v.folio}${v.combinado ? ' <span class="tag">comb</span>' : ""}${v.apartado ? ' <span class="tag">apart</span>' : ""}${dev ? ' <span class="tag tag--cancel">DEVUELTA</span>' : ""}</td>
          <td>${escapeHtml(v.cliente || "")}</td>
          <td class="num">${(v.items || []).length} art.</td>
          <td class="num">${dev ? `<span class="dif-strike">${fmt(v.montoCents)}</span> <b>$0.00</b>` : fmt(v.montoCents)}</td>
          <td class="det-caret">▸</td>
        </tr>
        <tr class="det-venta__body" hidden><td colspan="6">${combo}${itemsTabla(v.items, false)}</td></tr>
      </tbody>`;
  }).join("") || `<tbody><tr><td colspan="6" class="muted">Sin ventas con ${label}.</td></tr></tbody>`;

  const filasDev = (m.devoluciones || []).map((d) => `
      <tbody class="det-venta det-venta--dev">
        <tr class="det-venta__row">
          <td class="muted">${d.hora}</td>
          <td>#${d.folio}${d.ventaFolio ? ` <small class="muted">(venta #${d.ventaFolio})</small>` : ""}</td>
          <td>${d.motivo ? `<i>${escapeHtml(d.motivo)}</i>` : "Devolución"}</td>
          <td class="num">${(d.items || []).length} art.</td>
          <td class="num neg">- ${fmt(d.montoCents)}</td>
          <td class="det-caret">▸</td>
        </tr>
        <tr class="det-venta__body" hidden><td colspan="6">${itemsTabla(d.items, true)}</td></tr>
      </tbody>`).join("");

  const filasAbonos = (m.abonos || []).map((a) => `
      <tbody class="det-venta">
        <tr class="det-venta__row">
          <td class="muted">${a.hora || ""}</td>
          <td><span class="tag">ABONO</span></td>
          <td>${escapeHtml(a.cliente || "")}</td>
          <td class="num">—</td>
          <td class="num">${fmt(a.montoCents)}</td>
          <td></td>
        </tr>
      </tbody>`).join("");

  const totAbonos = (m.abonos || []).reduce((s, a) => s + (a.montoCents || 0), 0);
  el.innerHTML = `
    <div class="detalle-head">${pagoEmoji(metodoId)} Detalle — ${label} · Neto ${fmt(m.netoCents)} · ${m.numVentas} venta(s)${totAbonos ? " · abonos " + fmt(totAbonos) : ""}</div>
    <p class="muted det-hint">Clic en una venta para ver sus productos.</p>
    <table class="mv-table det-table">
      <thead><tr><th>Hora</th><th>Folio</th><th>Cliente / motivo</th><th class="num">Artículos</th><th class="num">Importe</th><th></th></tr></thead>
      ${filas}
      ${filasDev ? `<tbody><tr><td colspan="6" class="subhead">Devoluciones</td></tr></tbody>${filasDev}` : ""}
      ${filasAbonos ? `<tbody><tr><td colspan="6" class="subhead">Abonos a crédito (${label})</td></tr></tbody>${filasAbonos}` : ""}
    </table>`;

  $$(".det-venta__row", el).forEach((row) => row.addEventListener("click", () => {
    const body = row.parentElement.querySelector(".det-venta__body");
    if (!body) return;
    const abierto = !body.hidden;
    body.hidden = abierto;
    row.classList.toggle("is-open", !abierto);
    const caret = row.querySelector(".det-caret");
    if (caret) caret.textContent = abierto ? "▸" : "▾";
  }));
}

function pagoEmoji(id) { return (PAGOS.find((p) => p.id === id) || METODO_EXTRA[id] || { emoji: "•" }).emoji; }

function htmlMovimientosDia() {
  return `
    <h4>Imprimir un día</h4>
    <p class="qty-hint">Elige la fecha. No pide folio.</p>
    <div class="mv-actions" style="flex-wrap:wrap">
      <input type="date" id="es-dia" class="mv-search" value="${hoyISO()}" max="${hoyISO()}" />
      <button class="btn btn--sec" id="es-print-dia">🖨️ Imprimir ese día</button>
    </div>
    <div id="es-dia-vista" style="margin-top:8px"></div>`;
}

function bindMovimientosDia(root) {
  const lineasMovimientos = (lista, totales) => {
    const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
    const lineas = (lista || []).map((m) => {
      const hora = m.fecha ? new Date(m.fecha).toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" }) : "";
      const signo = m.tipo === "ingreso" ? "+" : "-";
      const fp = String(m.formaPago || "efectivo").toUpperCase();
      const etq = m.categoria === "compra" ? "COMPRA" : (m.tipo === "ingreso" ? "ENTRADA" : "SALIDA");
      const izq = `${hora} ${etq} ${fp} ${m.motivo || ""}${m.proveedor ? (" [" + m.proveedor + "]") : ""}`.trim();
      const der = signo + fmt(m.montoCents);
      const esp = cols - izq.length - der.length;
      return izq + (esp >= 1 ? " ".repeat(esp) : " ") + der;
    });
    lineas.push("-".repeat(cols));
    lineas.push(`Efectivo  entradas: ${fmt(totales.entradas)}  salidas: ${fmt(totales.salidas)}`);
    return lineas.length ? lineas : ["(sin movimientos)"];
  };
  const pintarDiaMov = async () => {
    const vista = $("#es-dia-vista", root);
    const fecha = ($("#es-dia", root) && $("#es-dia", root).value) || hoyISO();
    const info = await window.api.db.movimientosEfectivoDia(fecha);
    const lista = (info && info.movimientos) || [];
    if (!vista) return;
    if (!lista.length) { vista.innerHTML = `<p class="muted">Sin entradas ni salidas el ${escapeHtml(fecha)}.</p>`; return; }
    vista.innerHTML = `<table class="mv-table"><thead><tr><th>Hora</th><th>Tipo</th><th>Concepto</th><th class="num">Monto</th></tr></thead><tbody>${
      lista.map((m) => {
        const hora = m.fecha ? new Date(m.fecha).toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" }) : "";
        const esIn = m.tipo === "ingreso";
        const etiqueta = m.categoria === "compra" ? "Compra" : (esIn ? "Entrada" : "Salida");
        const fp = m.formaPago === "tarjeta" ? "Tarjeta" : m.formaPago === "transferencia" ? "Transferencia" : m.formaPago === "credito" ? "Crédito" : "Efectivo";
        return `<tr><td>${hora}</td><td>${etiqueta}<br/><small class="muted">${fp}</small></td><td>${escapeHtml(m.motivo || "")}${m.proveedor ? ` <small class="muted">· ${escapeHtml(m.proveedor)}</small>` : ""}</td><td class="num ${esIn ? "" : "neg"}">${esIn ? "" : "- "}${fmt(m.montoCents)}</td></tr>`;
      }).join("")
    }</tbody></table>
    <p class="qty-hint">Efectivo del día: entradas ${fmt(info.entradas)} · salidas ${fmt(info.salidas)}. Tarjeta y transferencia se listan arriba y no restan del cajón.</p>`;
  };
  const diaInp = $("#es-dia", root);
  const btn = $("#es-print-dia", root);
  if (diaInp) diaInp.addEventListener("change", pintarDiaMov);
  if (btn) btn.addEventListener("click", async () => {
    const fecha = (diaInp && diaInp.value) || hoyISO();
    const info = await window.api.db.movimientosEfectivoDia(fecha);
    imprimirListaFlujo("MOVIMIENTOS " + fecha, lineasMovimientos((info && info.movimientos) || [], { entradas: info ? info.entradas : 0, salidas: info ? info.salidas : 0 }));
  });
  if (diaInp) pintarDiaMov();
}

function lineasReciboAdeudo(proveedor, items) {
  const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
  const fit = (izq, der) => {
    izq = String(izq);
    const max = Math.max(8, cols - der.length - 1);
    if (izq.length > max) izq = izq.slice(0, max);
    const esp = cols - izq.length - der.length;
    return izq + (esp >= 1 ? " ".repeat(esp) : " ") + der;
  };
  const lineas = [
    "Mercancia recibida, aun sin pagar",
    "Proveedor: " + (proveedor || "Sin proveedor"),
    "-".repeat(cols)
  ];
  items.forEach((p) => {
    const cant = p.cantidad != null && p.cantidad !== "" && !isNaN(Number(p.cantidad)) ? (String(p.cantidad) + " ") : "";
    lineas.push(fit(cant + (p.motivo || ""), fmt(p.montoCents)));
  });
  const tot = items.reduce((s, p) => s + (p.montoCents || 0), 0);
  lineas.push("-".repeat(cols));
  lineas.push(fit("TOTAL ADEUDO", fmt(tot)));
  lineas.push("No sale del cajon hasta liberarla.");
  return lineas;
}

function pedirPagoPendiente(id, body, modo) {
  const ids = Array.isArray(id) ? id : [id];
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty" style="max-width:420px">
      <h3>Pagar compra a crédito</h3>
      <p class="qty-hint">${ids.length > 1 ? ids.length + " renglones del mismo proveedor. " : ""}Al pagarla entra al corte de <b>hoy</b>. El efectivo sí sale del cajón. Tarjeta y transferencia no descuentan efectivo, pero quedan en el corte de ese método.${copiaEnVivo ? " Con «Efectivo casa» se paga con dinero de la casa: no sale del cajón ni entra al corte." : ""}</p>
      <div class="modal__foot" style="flex-wrap:wrap">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" data-fp="efectivo">Efectivo</button>
        <button class="btn btn--primary" data-fp="tarjeta">Tarjeta</button>
        <button class="btn btn--primary" data-fp="transferencia">Transferencia</button>
        ${copiaEnVivo ? '<button class="btn btn--primary" data-fp="efectivo_casa">Efectivo casa</button>' : ""}
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  back.addEventListener("click", async (e) => {
    if (e.target === back || e.target.dataset.cerrar) { cerrar(); return; }
    const fp = e.target.dataset.fp;
    if (!fp) return;
    e.target.disabled = true;
    for (const uno of ids) {
      const r = await window.api.db.liberarMovimientoPendiente(uno, fp, usuarioActual ? usuarioActual.nombre : null);
      if (r && r.error) { e.target.disabled = false; return alert(r.error); }
    }
    cerrar();
    renderEntradasSalidas(body, modo);
  });
}

function lineasAbonoProveedor(r) {
  const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
  const fit = (izq, der) => {
    izq = String(izq);
    const max = Math.max(8, cols - der.length - 1);
    if (izq.length > max) izq = izq.slice(0, max);
    const esp = cols - izq.length - der.length;
    return izq + (esp >= 1 ? " ".repeat(esp) : " ") + der;
  };
  const esCasa = r.formaPago === "efectivo_casa";
  const fp = r.formaPago === "tarjeta" ? "TARJETA" : r.formaPago === "transferencia" ? "TRANSFERENCIA" : esCasa ? "EFECTIVO CASA" : "EFECTIVO";
  const lineas = [
    "Abono a proveedor",
    "Proveedor: " + (r.proveedor || "Sin proveedor"),
    "Metodo: " + fp,
    "-".repeat(cols)
  ];
  (r.lineas || []).forEach((p) => {
    const cant = p.cantidad != null && p.cantidad !== "" && !isNaN(Number(p.cantidad)) ? (String(p.cantidad) + " ") : "";
    lineas.push(fit(cant + (p.motivo || ""), fmt(p.montoCents)));
  });
  lineas.push("-".repeat(cols));
  lineas.push(fit("ABONO", fmt(r.aplicadoCents || 0)));
  lineas.push(fit("SALDO PENDIENTE", fmt(r.saldoCents || 0)));
  lineas.push(esCasa ? "Pago de la casa. No toca el cajon ni el corte." : (fp === "EFECTIVO" ? "Salio del cajon y entra al corte de hoy." : "No toca el cajon. Entra al corte de " + fp.toLowerCase() + "."));
  return lineas;
}

async function pedirAbonoProveedor(proveedor, saldoCents, onDone, pagarTodo, destino, estadoProv) {
  destino = destino || null; // { pendienteId } | { conjunto, pendienteIds, etiqueta }
  // Misma fuente que clientes: si no vino el estado, lo carga para listar cargos pendientes.
  if (!estadoProv || !Array.isArray(estadoProv.movimientos)) {
    try {
      const st = await window.api.db.estadoCuentaProveedor(proveedor);
      if (st && !st.error) estadoProv = st;
    } catch (e) { /* ignore */ }
  }
  const cargosPend = ((estadoProv && estadoProv.movimientos) || [])
    .filter((m) => m && m.tipo === "cargo" && (m.restanteCents != null ? m.restanteCents : m.montoCents) > 0)
    .slice()
    .sort((a, b) => new Date(a.fecha) - new Date(b.fecha));
  const prefId = destino && destino.pendienteId != null ? Number(destino.pendienteId) : null;
  const optsCargo = cargosPend.map((m) => {
    const rest = m.restanteCents != null ? m.restanteCents : m.montoCents;
    const sel = prefId != null && Number(m.id) === prefId ? "selected" : "";
    const f = m.fecha ? new Date(m.fecha).toLocaleDateString("es-MX") : "";
    const nota = m.nota ? " · " + escapeHtml(String(m.nota).slice(0, 40)) : "";
    return `<option value="cargo:${m.id}" data-rest="${rest}" ${sel}>Cargo #${m.id}${f ? " · " + f : ""}${nota} · ${fmt(rest)}</option>`;
  }).join("");
  const fijoConjunto = !!(destino && destino.conjunto);
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty" style="max-width:480px">
      <h3>${pagarTodo ? "Pagar crédito de proveedor" : "Abonar a proveedor"}</h3>
      <p class="qty-hint">${escapeHtml(proveedor)} · Debemos en total <b>${fmt(saldoCents)}</b></p>
      <div class="qty-field"><label>¿A qué se aplica el abono?</label>
        ${fijoConjunto
          ? `<div class="bk-estado" style="margin:0">${escapeHtml(destino.etiqueta || "Conjunto del día")} · saldo <b>${fmt(destino.restanteCents != null ? destino.restanteCents : saldoCents)}</b></div>`
          : `<select id="abp-destino" style="font-size:15px;min-height:40px" ${pagarTodo ? "disabled" : ""}>
              <option value="general">Cuenta general</option>
              ${optsCargo}
            </select>`}
      </div>
      <div class="qty-field"><label>Cuánto se paga</label>
        <input type="number" min="0" step="0.01" id="abp-monto" value="${(saldoCents / 100).toFixed(2)}" ${pagarTodo ? "readonly" : ""} />
      </div>
      <p class="qty-hint" id="abp-msg"></p>
      <div class="modal__foot" style="flex-wrap:wrap">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" data-fp="efectivo">Efectivo</button>
        <button class="btn btn--primary" data-fp="tarjeta">Tarjeta</button>
        <button class="btn btn--primary" data-fp="transferencia">Transferencia</button>
        ${copiaEnVivo ? '<button class="btn btn--primary" data-fp="efectivo_casa">Efectivo casa</button>' : ""}
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  const leerDestino = () => {
    if (fijoConjunto) return { modo: "conjunto", tope: destino.restanteCents != null ? destino.restanteCents : saldoCents, etq: destino.etiqueta || "Conjunto del día" };
    if (pagarTodo) return { modo: "general", tope: saldoCents, etq: "Cuenta general" };
    const sel = $("#abp-destino", back);
    const v = sel ? sel.value : "general";
    if (v.indexOf("cargo:") === 0) {
      const id = Number(v.slice(6));
      const opt = sel && sel.selectedOptions && sel.selectedOptions[0];
      const rest = opt && opt.dataset.rest != null ? Number(opt.dataset.rest) : saldoCents;
      const m = cargosPend.find((x) => Number(x.id) === id);
      return {
        modo: "cargo", pendienteId: id, tope: rest,
        etq: `Cargo #${id}` + (m && m.nota ? " · " + m.nota : "")
      };
    }
    return { modo: "general", tope: saldoCents, etq: "Cuenta general" };
  };
  const syncMonto = () => {
    if (pagarTodo || fijoConjunto) return;
    const d = leerDestino();
    const inp = $("#abp-monto", back);
    if (inp) inp.value = ((d.tope || 0) / 100).toFixed(2);
  };
  const selDest = $("#abp-destino", back);
  if (selDest) {
    if (prefId != null && cargosPend.some((m) => Number(m.id) === prefId)) selDest.value = "cargo:" + prefId;
    selDest.addEventListener("change", syncMonto);
    syncMonto();
  } else if (fijoConjunto) {
    const inp = $("#abp-monto", back);
    if (inp) inp.value = (((destino.restanteCents != null ? destino.restanteCents : saldoCents) / 100)).toFixed(2);
  }
  back.addEventListener("click", async (e) => {
    if (e.target === back || e.target.dataset.cerrar) { cerrar(); return; }
    const fp = e.target.dataset.fp;
    if (!fp) return;
    const d = leerDestino();
    const monto = Money.toCents(parseFloat(($("#abp-monto", back).value || "").replace(",", ".")) || 0) || 0;
    const tope = d.tope;
    if (monto <= 0) { $("#abp-msg", back).innerHTML = '<span class="tk-warn">Escribe un monto mayor a cero.</span>'; return; }
    if (monto > tope) { $("#abp-msg", back).innerHTML = `<span class="tk-warn">El abono no puede ser mayor a ${fmt(tope)}.</span>`; return; }
    const sigue = await confirmarDatos(pagarTodo ? "Confirmar pago" : "Confirmar abono", [
      { etiqueta: "Proveedor", valor: proveedor },
      { etiqueta: "Destino", valor: d.etq },
      { etiqueta: "Debemos (total)", valor: fmt(saldoCents) },
      { etiqueta: "Se paga", valor: fmt(monto) },
      { etiqueta: "Forma de pago", valor: etiquetaFormaPago(fp) },
      { etiqueta: "Saldo total que queda", valor: fmt(Math.max(0, saldoCents - monto)) }
    ]);
    if (!sigue) return;
    e.target.disabled = true;
    const opts = d.modo === "conjunto" && destino && Array.isArray(destino.pendienteIds)
      ? { pendienteIds: destino.pendienteIds, conjunto: true }
      : d.modo === "cargo"
      ? { pendienteId: d.pendienteId }
      : {};
    const r = await window.api.db.abonarCreditoProveedor(proveedor, monto, fp, usuarioActual ? usuarioActual.nombre : null, opts);
    if (r && r.error) { e.target.disabled = false; $("#abp-msg", back).innerHTML = `<span class="tk-warn">${escapeHtml(r.error)}</span>`; return; }
    cerrar();
    if (d.modo === "conjunto") {
      imprimirAbonoConjunto({
        fecha: d.etq || "",
        totalConjunto: tope,
        abono: r.aplicadoCents || monto,
        saldoConjunto: Math.max(0, tope - (r.aplicadoCents || monto)),
        formaPago: fp
      });
    } else {
      imprimirListaFlujo("ABONO " + (r.proveedor || proveedor), lineasAbonoProveedor(r));
    }
    if (onDone) onDone();
  });
}

// Créditos de PROVEEDORES: misma estructura que Clientes (Estado de Cuenta +
// Reporte de Saldos). Datos intactos: solo LEE de movimientosPendientes y usa
// las mismas funciones de registro/abono que ya existían.
async function renderCreditosProveedor(el, root) {
  if (_creditoSel.subvista === "saldos") return renderReporteSaldosProveedor(el, root);
  return renderEstadoCuentaProveedor(el, root);
}

function credBadgeProv(tipo) {
  if (tipo === "abono") return '<span class="cred-badge cred-badge--abono">ABONO</span>';
  return '<span class="cred-badge cred-badge--venta">COMPRA</span>';
}

// Resumen de saldos por proveedor a partir de los pendientes (mismo criterio que
// el backend: suma lo NO pagado por proveedor). Evita depender de IPC extra.
function resumenProveedoresLocal(pendientes) {
  const map = new Map();
  (pendientes || []).filter((p) => p.estado !== "pagado").forEach((p) => {
    const nombre = String(p.proveedor || "Sin proveedor").trim() || "Sin proveedor";
    const k = nombre.toLowerCase();
    if (!map.has(k)) map.set(k, { proveedor: nombre, montoCents: 0 });
    map.get(k).montoCents += p.montoCents || 0;
  });
  const lista = Array.from(map.values()).sort((a, b) => b.montoCents - a.montoCents || a.proveedor.localeCompare(b.proveedor, "es"));
  return { lista, totalCents: lista.reduce((s, x) => s + x.montoCents, 0) };
}

async function renderEstadoCuentaProveedor(el, root) {
  const pendientes = (await window.api.db.getMovimientosPendientes()) || [];
  const resumen = resumenProveedoresLocal(pendientes);
  const saldoDe = new Map((resumen.lista || []).map((x) => [String(x.proveedor).toLowerCase(), x.montoCents]));
  let nombres = [];
  try { nombres = (await window.api.db.getProveedores()) || []; } catch (e) { nombres = []; }
  const setN = new Map();
  nombres.forEach((n) => setN.set(String(n).toLowerCase(), n));
  (resumen.lista || []).forEach((x) => { const k = String(x.proveedor).toLowerCase(); if (!setN.has(k)) setN.set(k, x.proveedor); });
  const listaProv = Array.from(setN.values())
    .sort((a, b) => (saldoDe.get(b.toLowerCase()) || 0) - (saldoDe.get(a.toLowerCase()) || 0) || a.localeCompare(b, "es"));

  const sel = _creditoSel.provNombre;
  const estado = sel ? await window.api.db.estadoCuentaProveedor(sel) : null;

  el.innerHTML = `
    <div class="cred-pick">
      <span class="searchbar__icon">🔍</span>
      <input type="search" id="credp-search" placeholder="Buscar proveedor por nombre…" autocomplete="off" value="${sel ? attr(sel) : ""}" />
      <button class="btn btn--sec" id="credp-nuevo-prov" style="margin-left:8px;white-space:nowrap">＋ Nuevo proveedor</button>
      <button class="btn btn--sec" id="credp-nueva" style="margin-left:6px;white-space:nowrap">＋ Nueva compra a crédito</button>
      <div class="cred-pick__list" id="credp-list" hidden></div>
    </div>
    <div id="credp-edo"></div>`;

  const search = $("#credp-search", el);
  const listBox = $("#credp-list", el);
  const pintarDrop = () => {
    const q = (search.value || "").trim().toLowerCase();
    let lista = listaProv.slice();
    if (q) lista = lista.filter((n) => n.toLowerCase().includes(q));
    lista = lista.slice(0, 40);
    listBox.innerHTML = lista.length
      ? lista.map((n) => { const s = saldoDe.get(n.toLowerCase()) || 0; return `<button class="cred-pick__item" data-prov="${attr(n)}">📒 ${escapeHtml(n)}${s > 0 ? ` · <b class="neg">${fmt(s)}</b>` : ""}</button>`; }).join("")
      : '<div class="muted" style="padding:8px">Sin coincidencias. Usa “＋ Nuevo proveedor” o “＋ Nueva compra a crédito”.</div>';
    listBox.hidden = false;
    $$(".cred-pick__item", listBox).forEach((b) => b.addEventListener("mousedown", (e) => {
      e.preventDefault();
      _creditoSel.provNombre = b.dataset.prov; _creditoSel.movSel = null;
      renderEstadoCuentaProveedor(el, root);
    }));
  };
  search.addEventListener("focus", pintarDrop);
  search.addEventListener("input", pintarDrop);
  search.addEventListener("blur", () => setTimeout(() => { listBox.hidden = true; }, 180));
  $("#credp-nuevo-prov", el).addEventListener("click", () => abrirNuevoProveedor(() => renderCreditos(root)));
  $("#credp-nueva", el).addEventListener("click", () => abrirNuevaCompraProveedor(() => renderCreditos(root)));

  const edo = $("#credp-edo", el);
  if (!sel || !estado || estado.error) {
    edo.innerHTML = '<div class="empty-state cred-empty"><span>📒</span><p>Busca y elige un proveedor, agrega uno nuevo, o registra una compra a crédito.</p></div>';
    setTimeout(() => search.focus(), 30);
    return;
  }

  const saldo = estado.saldoCents || 0;
  const movsCrono = estado.movimientos || [];
  const movsFiltrados = credFiltrarMovs(movsCrono, _creditoSel.periodo).slice().reverse(); // recientes primero
  const periodos = [["dia", "Un día…"], ["liquidacion", "Desde última liquidación"], ["semana", "De esta semana"], ["mes", "De este mes"], ["90", "Últimos 90 días"], ["siempre", "De siempre (todo)"], ["rango", "Rango de fechas…"]];
  if (!_creditoSel.diasAbiertos) _creditoSel.diasAbiertos = {};

  const diaDe = (iso) => {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    const off = d.getTimezoneOffset();
    return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
  };
  const fmtDia = (iso) => {
    const p = String(iso || "").split("-");
    return p.length === 3 ? `${p[2]}/${p[1]}/${p[0]}` : iso;
  };
  const grupos = [];
  const porDia = new Map();
  movsFiltrados.forEach((m) => {
    const k = diaDe(m.fecha) || "sin-fecha";
    if (!porDia.has(k)) {
      const g = { dia: k, movs: [] };
      porDia.set(k, g);
      grupos.push(g);
    }
    porDia.get(k).movs.push(m);
  });

  const filaProducto = (m) => {
    const folioTxt = "#" + m.id;
    const fpTxt = m.tipo === "abono" && m.formaPago ? ` <small class="muted">· ${escapeHtml(etiquetaFormaPago(m.formaPago))}</small>` : "";
    const desc = escapeHtml(m.nota || (m.tipo === "cargo" ? "Compra a crédito" : "Abono")) + fpTxt
      + (m.tipo === "cargo" && m.restanteCents != null && m.restanteCents !== m.montoCents ? ` <small class="muted">(orig. ${fmt(m.montoCents)})</small>` : "");
    const montoVista = m.tipo === "cargo" && m.restanteCents != null ? m.restanteCents : m.montoCents;
    const cargo = m.tipo === "cargo" ? fmt(montoVista) : "";
    const abono = m.tipo !== "cargo" ? fmt(m.montoCents) : "";
    return `<tr class="cred-row cred-dia-hijo ${_creditoSel.movSel === m.uid ? "is-sel" : ""}" data-mov="${m.uid}">
        <td class="muted">${new Date(m.fecha).toLocaleString("es-MX")}</td>
        <td>${folioTxt}</td>
        <td>${credBadgeProv(m.tipo)}</td>
        <td>${desc}</td>
        <td class="num neg">${cargo}</td>
        <td class="num">${abono}</td>
        <td class="num"><b>${fmt(m.saldoCents)}</b></td>
        <td class="muted">${escapeHtml(m.usuario || "—")}</td>
      </tr>`;
  };

  edo.innerHTML = `
    <div class="cred-cli-head">
      <div class="cred-cli-id"><span class="cred-avatar">${credIniciales(estado.proveedor)}</span>
        <div><b>${escapeHtml(estado.proveedor)}</b>
          <div class="muted" style="font-size:12px">Proveedor · lo que le debemos</div>
        </div>
      </div>
      <div class="cred-cli-saldo"><span>Debemos</span><b class="${saldo > 0 ? "neg" : "ok"}">${fmt(saldo)}</b></div>
    </div>
    <div class="cred-actions">
      <div class="cred-actions__btns">
        <button class="btn btn--primary" id="credp-abonar" ${saldo > 0 ? "" : "disabled"}>⬇ Abonar a deuda</button>
        <button class="btn btn--sec" id="credp-pagar" ${saldo > 0 ? "" : "disabled"}>✅ Pagar todo</button>
        <button class="btn btn--sec" id="credp-ver">👁 Ver estado de cuenta</button>
        <button class="btn btn--sec" id="credp-print">🖨️ Imprimir Estado de Cuenta</button>
        <button class="btn btn--danger" id="credp-eliminar">🗑 Eliminar proveedor</button>
      </div>
      <label class="cred-filtro">Movimientos:
        <select id="cred-periodo">${periodos.map(([v, t]) => `<option value="${v}" ${_creditoSel.periodo === v ? "selected" : ""}>${t}</option>`).join("")}</select>
        ${_creditoSel.periodo === "dia" ? `<span class="cred-rango"><input type="date" id="cred-dia" value="${_creditoSel.diaSel || ""}" max="${hoyISO()}" /></span>` : ""}
        ${_creditoSel.periodo === "rango" ? `<span class="cred-rango"><input type="date" id="cred-desde" value="${_creditoSel.rangoDesde || ""}" max="${hoyISO()}" /><span>a</span><input type="date" id="cred-hasta" value="${_creditoSel.rangoHasta || ""}" max="${hoyISO()}" /></span>` : ""}
      </label>
    </div>
    <div class="cred-edo-grid">
      <div class="mv-table-wrap cred-movs">
        <table class="mv-table">
          <thead><tr><th>Fecha</th><th>Folio</th><th>Movimiento</th><th>Descripción</th><th class="num">Cargo</th><th class="num">Abono</th><th class="num">Saldo</th><th>Cajero</th></tr></thead>
          <tbody id="credp-filas"></tbody>
        </table>
      </div>
      <div class="cred-detail" id="credp-detail"></div>
    </div>
    <div id="credp-abonos"></div>`;

  const refrescar = () => renderCreditos(root);
  $("#cred-periodo", edo).addEventListener("change", (e) => { _creditoSel.periodo = e.target.value; renderEstadoCuentaProveedor(el, root); });
  const cd = $("#cred-desde", edo); if (cd) cd.addEventListener("change", (e) => { _creditoSel.rangoDesde = e.target.value; renderEstadoCuentaProveedor(el, root); });
  const ch = $("#cred-hasta", edo); if (ch) ch.addEventListener("change", (e) => { _creditoSel.rangoHasta = e.target.value; renderEstadoCuentaProveedor(el, root); });
  const cdia = $("#cred-dia", edo); if (cdia) cdia.addEventListener("change", (e) => { _creditoSel.diaSel = e.target.value; renderEstadoCuentaProveedor(el, root); });
  const ba = $("#credp-abonar", edo); if (ba && saldo > 0) ba.addEventListener("click", () => {
    const movSel = (estado.movimientos || []).find((x) => x.uid === _creditoSel.movSel);
    const destino = (movSel && movSel.tipo === "cargo" && (movSel.restanteCents || 0) > 0)
      ? { pendienteId: movSel.id, motivo: movSel.nota || "", cantidad: movSel.cantidad, restanteCents: movSel.restanteCents }
      : null;
    pedirAbonoProveedor(estado.proveedor, saldo, refrescar, false, destino, estado);
  });
  const bp = $("#credp-pagar", edo); if (bp && saldo > 0) bp.addEventListener("click", () => pedirAbonoProveedor(estado.proveedor, saldo, refrescar, true, null, estado));
  $("#credp-ver", edo).addEventListener("click", () => verEstadoDeCuentaProveedor(estado));
  $("#credp-print", edo).addEventListener("click", () => imprimirEstadoDeCuentaProveedor(estado));
  $("#credp-eliminar", edo).addEventListener("click", async () => {
    if (saldo > 0) return alert("A este proveedor todavía le debemos. Paga o cancela la cuenta antes de eliminarlo.");
    if (!confirm(`¿Eliminar a "${estado.proveedor}" de la lista?\nLas compras y los cortes ya registrados no se borran.`)) return;
    const r = await window.api.db.eliminarProveedor(estado.proveedor, usuarioActual ? usuarioActual.nombre : null);
    if (r && r.error) return alert(r.error);
    _creditoSel.provNombre = null;
    _creditoSel.movSel = null;
    renderCreditos(root);
  });

  const filasBox = $("#credp-filas", edo);
  function pintarListaDias() {
    let gran = 0;
    const htmlDias = grupos.map((g) => {
      const abierto = !!_creditoSel.diasAbiertos[g.dia];
      const cargos = g.movs.filter((m) => m.tipo === "cargo");
      const abonos = g.movs.filter((m) => m.tipo !== "cargo");
      const totalDia = cargos.reduce((s, m) => s + (m.montoCents || 0), 0) - abonos.reduce((s, m) => s + (m.montoCents || 0), 0);
      gran += totalDia;
      const saldoDia = g.movs.length ? (g.movs[0].saldoCents || 0) : 0;
      const selDia = _creditoSel.grupoDia === g.dia && _creditoSel.movSel == null;
      const cabeza = `<tr class="cred-dia ${selDia ? "is-sel" : ""}" data-dia="${attr(g.dia)}">
        <td colspan="3"><span class="cred-dia__caret">${abierto ? "▾" : "▸"}</span> ${escapeHtml(fmtDia(g.dia))}</td>
        <td>${cargos.length} producto(s)${abonos.length ? ` · ${abonos.length} abono(s)` : ""}</td>
        <td class="num neg">${cargos.length ? fmt(cargos.reduce((s, m) => s + (m.montoCents || 0), 0)) : ""}</td>
        <td class="num">${abonos.length ? fmt(abonos.reduce((s, m) => s + (m.montoCents || 0), 0)) : ""}</td>
        <td class="num"><b>${fmt(saldoDia)}</b></td>
        <td></td>
      </tr>`;
      return cabeza + (abierto ? g.movs.map(filaProducto).join("") : "");
    }).join("");
    const pieProv = grupos.length
      ? `<tr class="mv-total-row"><td colspan="4"><b>Total de ${escapeHtml(estado.proveedor)}</b><div class="muted">${grupos.length} fecha${grupos.length === 1 ? "" : "s"} (reciente → antiguo)</div></td><td class="num neg"><b>${fmt(grupos.reduce((s, g) => s + g.movs.filter((m) => m.tipo === "cargo").reduce((a, m) => a + (m.montoCents || 0), 0), 0))}</b></td><td class="num"><b>${fmt(grupos.reduce((s, g) => s + g.movs.filter((m) => m.tipo !== "cargo").reduce((a, m) => a + (m.montoCents || 0), 0), 0))}</b></td><td colspan="2"></td></tr>`
      : "";
    const html = htmlDias
      ? htmlDias + pieProv
      : `<tr><td colspan="8" class="muted" style="padding:16px">Sin movimientos en el periodo seleccionado.</td></tr>`;
    filasBox.innerHTML = html;
    const cajaAbonos = $("#credp-abonos", edo);
    if (cajaAbonos) cajaAbonos.innerHTML = vistaAbonos(movsFiltrados, estado.proveedor);
    $$(".cred-dia", filasBox).forEach((r) => r.addEventListener("click", () => {
      const dia = r.dataset.dia;
      _creditoSel.diasAbiertos[dia] = !_creditoSel.diasAbiertos[dia];
      _creditoSel.grupoDia = dia;
      _creditoSel.movSel = null;
      pintarListaDias();
      pintarDetalleProv();
    }));
    $$(".cred-row", filasBox).forEach((r) => r.addEventListener("click", (e) => {
      e.stopPropagation();
      _creditoSel.movSel = +r.dataset.mov;
      pintarListaDias();
      pintarDetalleProv();
    }));
  }

  function pintarDetalleDia(g) {
    const box = $("#credp-detail", edo);
    const cargos = g.movs.filter((m) => m.tipo === "cargo").slice().reverse();
    const total = cargos.reduce((s, m) => s + (m.montoCents || 0), 0);
    const pendienteDia = cargos.reduce((s, m) => s + (m.restanteCents != null ? m.restanteCents : (m.montoCents || 0)), 0);
    const idsDia = cargos.filter((m) => (m.restanteCents != null ? m.restanteCents : (m.montoCents || 0)) > 0).map((m) => m.id);
    const saldoDia = g.movs.length ? (g.movs[0].saldoCents || 0) : 0;
    box.innerHTML = `
      <div class="cred-detail__head"><b>Día ${escapeHtml(fmtDia(g.dia))}</b></div>
      <div class="cred-kv"><span>Productos</span><b>${cargos.length}</b></div>
      <div class="cred-kv cred-kv--total"><span>Total del día</span><b class="neg">${fmt(total)}</b></div>
      <div class="cred-kv"><span>Pendiente del conjunto</span><b class="neg">${fmt(pendienteDia)}</b></div>
      <div class="cred-kv"><span>Saldo al cierre</span><b>${fmt(saldoDia)}</b></div>
      <p class="qty-hint">El abono del día baja el total del conjunto. El de un producto sigue al abrirlo.</p>
      <div class="cred-detail__acts">
        ${pendienteDia > 0 ? `<button class="btn btn--primary" id="credp-abonar-dia">⬇ Abonar este día</button>` : ""}
        <button class="btn btn--sec" id="credp-print-dia">🖨️ Imprimir venta al contado</button>
      </div>`;
    const bAbDia = $("#credp-abonar-dia", box);
    if (bAbDia) bAbDia.addEventListener("click", () => {
      pedirAbonoProveedor(estado.proveedor, saldo, refrescar, false, {
        conjunto: true,
        etiqueta: "Conjunto del " + fmtDia(g.dia),
        restanteCents: pendienteDia,
        pendienteIds: idsDia
      }, estado);
    });
    $("#credp-print-dia", box).addEventListener("click", () => imprimirNotaDiaContado(g));
  }

  function pintarDetalleProv() {
    const box = $("#credp-detail", edo);
    if (_creditoSel.movSel == null && _creditoSel.grupoDia) {
      const g = grupos.find((x) => x.dia === _creditoSel.grupoDia);
      if (g) { pintarDetalleDia(g); return; }
    }
    const m = (estado.movimientos || []).find((x) => x.uid === _creditoSel.movSel);
    if (!m) { box.innerHTML = '<div class="cred-detail__empty">Selecciona un día o un producto.</div>'; return; }
    const titulo = m.tipo === "cargo" ? "Compra a crédito" : "Abono / pago";
    const puedeAbonar = m.tipo === "cargo" && (m.restanteCents || 0) > 0;
    box.innerHTML = `
      <div class="cred-detail__head">${credBadgeProv(m.tipo)} <b>${titulo}</b></div>
      <div class="cred-kv"><span>Folio</span><b>#${m.id}</b></div>
      <div class="cred-kv"><span>Fecha</span><b>${new Date(m.fecha).toLocaleString("es-MX")}</b></div>
      <div class="cred-kv"><span>Usuario</span><b>${escapeHtml(m.usuario || "—")}</b></div>
      <div class="cred-kv"><span>Descripción</span><b>${escapeHtml(m.nota || "—")}</b></div>
      ${m.cantidad != null ? `<div class="cred-kv"><span>Cantidad</span><b>${escapeHtml(String(m.cantidad))}</b></div>` : ""}
      <div class="cred-kv cred-kv--total"><span>${m.tipo === "cargo" ? "Saldo de esta nota" : "Total"}</span><b class="${m.tipo === "cargo" ? "neg" : ""}">${m.tipo === "cargo" ? "+" : "-"} ${fmt(m.tipo === "cargo" && m.restanteCents != null ? m.restanteCents : m.montoCents)}</b></div>
      ${m.tipo === "cargo" && m.restanteCents != null && m.restanteCents !== m.montoCents ? `<div class="cred-kv"><span>Monto original</span><b>${fmt(m.montoCents)}</b></div>` : ""}
      <div class="cred-kv"><span>Saldo corrido</span><b>${fmt(m.saldoCents)}</b></div>
      <div class="cred-kv"><span>Forma de pago</span><b>${m.formaPago ? etiquetaFormaPago(m.formaPago) : (m.tipo === "cargo" ? "CRÉDITO" : "—")}</b></div>
      <div class="cred-detail__acts">
        ${puedeAbonar ? `<button class="btn btn--primary" id="credp-abonar-esta">⬇ Abonar esta compra</button>` : ""}
        <button class="btn btn--sec" id="credp-reimp">🖨️ Re-imprimir</button>
        <button class="btn btn--danger" id="credp-cancel">✖ Cancelar…</button>
      </div>`;
    const bEsta = $("#credp-abonar-esta", box);
    if (bEsta) bEsta.addEventListener("click", () => {
      pedirAbonoProveedor(estado.proveedor, saldo, refrescar, false, {
        pendienteId: m.id, motivo: m.nota || "", cantidad: m.cantidad, restanteCents: m.restanteCents || 0
      }, estado);
    });
    $("#credp-reimp", box).addEventListener("click", () => imprimirMovimientoProveedor(estado.proveedor, m, estado.saldoCents));
    $("#credp-cancel", box).addEventListener("click", async () => {
      const alcance = await elegirAlcanceCancelacion({
        titulo: "Cancelar crédito proveedor",
        notaLabel: `Compra #${m.id}` + (m.nota ? " · " + m.nota : ""),
        notaMonto: m.tipo === "cargo" ? (m.restanteCents != null ? m.restanteCents : m.montoCents) : m.montoCents,
        cuentaLabel: estado.proveedor,
        cuentaMonto: saldo
      });
      if (!alcance) return;
      if (alcance === "nota") {
        if (m.tipo !== "cargo" || !m.cancelable) return alert("Solo se puede cancelar una compra pendiente. Los abonos ya registrados se revierten desde el turno de caja si aún está abierto.");
        if (!confirm(`¿Confirmar: cancelar SOLO la compra #${m.id}?\nSe quita esa nota del adeudo.`)) return;
        const r = await window.api.db.cancelarMovimientoPendiente(m.id, usuarioActual ? usuarioActual.nombre : null);
        if (r && r.error) return alert(r.error);
      } else {
        if (saldo <= 0) return alert("No hay compras pendientes en esta cuenta.");
        if (!confirm(`¿Confirmar: cancelar TODA la cuenta de "${estado.proveedor}" por ${fmt(saldo)}?\nSe borran todas las compras pendientes.`)) return;
        const r = await window.api.db.cancelarCuentaProveedor(estado.proveedor, usuarioActual ? usuarioActual.nombre : null, "Cancelación de cuenta completa");
        if (r && r.error) return alert(r.error);
      }
      _creditoSel.movSel = null;
      renderEstadoCuentaProveedor(el, root);
    });
  }
  pintarListaDias();
  pintarDetalleProv();
}

async function renderReporteSaldosProveedor(el, root) {
  const pendientes = (await window.api.db.getMovimientosPendientes()) || [];
  const resumen = resumenProveedoresLocal(pendientes);
  const conSaldo = (resumen.lista || []).filter((c) => (c.montoCents || 0) > 0);
  const total = resumen.totalCents || conSaldo.reduce((s, c) => s + (c.montoCents || 0), 0);
  const filas = conSaldo.map((c) => `
    <tr class="cred-saldo-row" data-prov="${attr(c.proveedor)}">
      <td>📒 ${escapeHtml(c.proveedor)}</td>
      <td class="num neg"><b>${fmt(c.montoCents || 0)}</b></td>
    </tr>`).join("") || `<tr><td colspan="2" class="muted" style="padding:16px">Sin adeudo a proveedores.</td></tr>`;

  el.innerHTML = `
    <div class="cred-saldos-top">
      <div class="cred-saldos-tot"><span>Proveedores</span><b>${conSaldo.length}</b></div>
      <div class="cred-saldos-tot"><span>Total por pagar</span><b class="neg">${fmt(total)}</b></div>
      <button class="btn btn--sec" id="credp-print-saldos">🖨️ Imprimir reporte</button>
    </div>
    <div class="mv-table-wrap">
      <table class="mv-table">
        <thead><tr><th>Proveedor</th><th class="num">Debemos</th></tr></thead>
        <tbody>${filas}</tbody>
      </table>
    </div>`;

  $$(".cred-saldo-row", el).forEach((r) => r.addEventListener("click", () => {
    _creditoSel.provNombre = r.dataset.prov; _creditoSel.subvista = "estado"; _creditoSel.movSel = null;
    renderCreditos(root);
  }));
  $("#credp-print-saldos", el).addEventListener("click", async () => {
    const todos = (await window.api.db.getMovimientosPendientes()) || [];
    const solo = todos.filter((x) => x.estado !== "pagado");
    if (!solo.length) return alert("No hay adeudo pendiente.");
    const map = new Map();
    solo.forEach((p) => {
      const nombre = (p.proveedor || "Sin proveedor").trim() || "Sin proveedor";
      if (!map.has(nombre.toLowerCase())) map.set(nombre.toLowerCase(), { nombre, items: [] });
      map.get(nombre.toLowerCase()).items.push(p);
    });
    const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
    const todas = [];
    Array.from(map.values()).forEach((g, i) => {
      if (i) todas.push("");
      todas.push(...lineasReciboAdeudo(g.nombre, g.items));
      todas.push("-".repeat(cols));
    });
    todas.push("TOTAL GENERAL  " + fmt(solo.reduce((s, p) => s + (p.montoCents || 0), 0)));
    imprimirListaFlujo("ADEUDOS POR PROVEEDOR", todas);
  });
}

// Alta de proveedor (lista), sin registrar deuda todavía.
function abrirNuevoProveedor(onDone) {
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty" style="max-width:420px">
      <h3>Nuevo proveedor</h3>
      <p class="qty-hint">Queda en la lista para buscarlo y usarlo en compras a crédito. No registra deuda todavía.</p>
      <div class="qty-field"><label>Nombre del proveedor</label>
        <input type="text" id="np-nombre" autocomplete="off" spellcheck="false" placeholder="Ej. CESAR, TONY…" />
      </div>
      <p class="qty-hint" id="np-msg"></p>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="np-ok">Guardar proveedor</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  const inp = $("#np-nombre", back);
  const guardar = async () => {
    const nombre = (inp.value || "").trim();
    if (!nombre) { $("#np-msg", back).innerHTML = '<span class="tk-warn">Escribe el nombre.</span>'; inp.focus(); return; }
    const r = await window.api.db.guardarProveedor(nombre);
    if (r && r.error) { $("#np-msg", back).innerHTML = `<span class="tk-warn">${escapeHtml(r.error)}</span>`; return; }
    _creditoSel.provNombre = r.proveedor || nombre;
    _creditoSel.movSel = null;
    cerrar();
    if (r && r.existe) alert(`El proveedor "${r.proveedor}" ya existía. Quedó seleccionado.`);
    if (onDone) onDone();
  };
  $("#np-ok", back).addEventListener("click", guardar);
  inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); guardar(); } });
  setTimeout(() => inp.focus(), 40);
}

// Registrar compra a crédito (ventana). Usa la MISMA función movimientoEfectivo
// que antes: no cambia cómo se guardan los datos.
function abrirNuevaCompraProveedor(onDone) {
  borradorCredito = [];
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal" style="max-width:640px">
      <h3>Registrar compra a crédito</h3>
      <p class="qty-hint">Escribe una letra y elige del inventario, o anota un producto que no esté. La cantidad por el precio da el total de cada renglón. No sale del cajón hasta el abono.</p>
      <div class="es-form">
        <label>Proveedor</label>
        <input type="text" id="cp-prov" list="cp-prov-list" autocomplete="off" spellcheck="false" placeholder="Escribe o elige el proveedor" />
        <datalist id="cp-prov-list"></datalist>
        <label>Producto</label>
        <input type="text" id="cp-motivo" autocomplete="off" spellcheck="false" placeholder="Escribe A, salsa, requesón…" />
        <div class="pk-results" id="cp-lista"></div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
          <div>
            <label>Cantidad</label>
            <input type="text" id="cp-cant" inputmode="decimal" autocomplete="off" placeholder="Ej. 5, 16" />
          </div>
          <div>
            <label>Precio de compra</label>
            <div class="es-monto"><span>$</span><input type="text" id="cp-precio" inputmode="decimal" placeholder="0.00" autocomplete="off" /></div>
          </div>
          <div>
            <label>Total de este</label>
            <div class="es-monto"><span>$</span><input type="text" id="cp-linea" readonly tabindex="-1" placeholder="0.00" /></div>
          </div>
        </div>
        <p class="qty-hint" id="cp-msg"></p>
        <button type="button" class="btn btn--sec btn--block" id="cp-agregar">＋ Agregar renglón</button>
        <div id="cp-borrador"></div>
      </div>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="cp-guardar">Guardar nota a crédito</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => { borradorCredito = []; back.remove(); };
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });

  window.api.db.getProveedores().then((ns) => {
    const dl = $("#cp-prov-list", back);
    if (dl) dl.innerHTML = (ns || []).map((n) => `<option value="${attr(n)}"></option>`).join("");
  }).catch(() => {});

  const motivoInp = $("#cp-motivo", back);
  const cantInp = $("#cp-cant", back);
  const precioInp = $("#cp-precio", back);
  const lineaInp = $("#cp-linea", back);
  let hi = 0;
  let opciones = [];
  let enviando = false;

  const num = (el) => {
    const n = parseFloat(String(el.value || "").replace(",", "."));
    return isNaN(n) ? 0 : n;
  };
  const totalLineaCents = () => {
    const cant = num(cantInp);
    const precio = Money.toCents(num(precioInp)) || 0;
    if (cant <= 0 || precio <= 0) return 0;
    return Money.multiplicar(precio, cant);
  };
  const pintarLinea = () => {
    const c = totalLineaCents();
    lineaInp.value = c > 0 ? (c / 100).toFixed(2) : "";
  };
  const elegirProducto = (p) => {
    motivoInp.value = p && p.nombre ? p.nombre : String(p || "");
    $("#cp-lista", back).innerHTML = "";
    opciones = [];
    pintarLinea();
    cantInp.focus();
    cantInp.select();
  };
  const pintarBusqueda = () => {
    const q = (motivoInp.value || "").trim().toLowerCase();
    const box = $("#cp-lista", back);
    if (!q) { box.innerHTML = ""; opciones = []; return; }
    const prods = ((DATA && DATA.productos) || [])
      .filter((p) => (p.nombre || "").toLowerCase().includes(q))
      .slice(0, 12);
    const exacto = prods.some((p) => (p.nombre || "").trim().toLowerCase() === q);
    opciones = prods.map((p) => ({ tipo: "inv", p }));
    if (!exacto) opciones.push({ tipo: "nuevo", nombre: motivoInp.value.trim() });
    if (hi >= opciones.length) hi = 0;
    box.innerHTML = opciones.map((o, i) => {
      if (o.tipo === "nuevo") {
        return `<button type="button" class="pk-res ${i === hi ? "is-on" : ""}" data-cpopt="${i}"><span>Añadir «${escapeHtml(o.nombre)}» <span class="muted">(no está en el inventario)</span></span></button>`;
      }
      const precio = o.p.precioCents != null ? fmt(o.p.precioCents) : "sin precio";
      return `<button type="button" class="pk-res ${i === hi ? "is-on" : ""}" data-cpopt="${i}"><span>${escapeHtml(o.p.nombre)}</span><b>${precio}${o.p.unidad ? "/" + escapeHtml(o.p.unidad) : ""}</b></button>`;
    }).join("");
    $$("[data-cpopt]", box).forEach((b) => b.addEventListener("mousedown", (e) => {
      e.preventDefault();
      const o = opciones[+b.dataset.cpopt];
      if (!o) return;
      if (o.tipo === "nuevo") { motivoInp.value = o.nombre; box.innerHTML = ""; opciones = []; cantInp.focus(); }
      else elegirProducto(o.p);
    }));
  };
  const leer = () => {
    const cantidad = num(cantInp);
    const cents = totalLineaCents();
    const motivo = (motivoInp.value || "").trim();
    const proveedor = ($("#cp-prov", back).value || "").trim();
    return { cents, motivo, proveedor, cantidad };
  };
  const pintarBorrador = () => {
    const box = $("#cp-borrador", back);
    if (!borradorCredito.length) { box.innerHTML = `<p class="qty-hint">Agrega los productos. El proveedor va en todos los renglones.</p>`; return; }
    const tot = borradorCredito.reduce((s, x) => s + (x.cents || 0), 0);
    box.innerHTML = `<table class="mv-table" style="margin-top:8px"><thead><tr><th>Producto</th><th class="num">Cant.</th><th class="num">Precio</th><th class="num">Total</th><th></th></tr></thead><tbody>${borradorCredito.map((x, i) =>
      `<tr><td>${escapeHtml(x.motivo)}</td><td class="num">${escapeHtml(String(x.cantidad))}</td><td class="num">${fmt(x.precioCents || 0)}</td><td class="num"><b>${fmt(x.cents)}</b></td><td><button type="button" class="chip chip--out" data-qborra="${i}">✕</button></td></tr>`
    ).join("")}</tbody></table>
      <div class="cred-kv cred-kv--total" style="margin-top:8px"><span>Suma total</span><b class="neg">${fmt(tot)}</b></div>`;
    $$("[data-qborra]", box).forEach((b) => b.addEventListener("click", () => { borradorCredito.splice(+b.dataset.qborra, 1); pintarBorrador(); }));
  };
  const agregar = () => {
    const cap = leer();
    if (!cap.proveedor) { $("#cp-msg", back).innerHTML = '<span class="tk-warn">Escribe el proveedor una vez.</span>'; $("#cp-prov", back).focus(); return false; }
    if (!cap.motivo) { $("#cp-msg", back).innerHTML = '<span class="tk-warn">Escribe o elige el producto.</span>'; motivoInp.focus(); return false; }
    if (!(cap.cantidad > 0)) { $("#cp-msg", back).innerHTML = '<span class="tk-warn">Escribe la cantidad.</span>'; cantInp.focus(); return false; }
    if (cap.cents <= 0) { $("#cp-msg", back).innerHTML = '<span class="tk-warn">Escribe el precio.</span>'; precioInp.focus(); return false; }
    borradorCredito.push({
      motivo: cap.motivo,
      cents: cap.cents,
      precioCents: Money.toCents(num(precioInp)) || 0,
      cantidad: cap.cantidad,
      proveedor: cap.proveedor
    });
    motivoInp.value = ""; cantInp.value = ""; precioInp.value = ""; lineaInp.value = "";
    $("#cp-lista", back).innerHTML = ""; opciones = [];
    $("#cp-msg", back).innerHTML = "";
    pintarBorrador();
    motivoInp.focus();
    return true;
  };
  motivoInp.addEventListener("input", () => { hi = 0; pintarBusqueda(); });
  motivoInp.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown" && opciones.length) { e.preventDefault(); hi = (hi + 1) % opciones.length; pintarBusqueda(); return; }
    if (e.key === "ArrowUp" && opciones.length) { e.preventDefault(); hi = (hi - 1 + opciones.length) % opciones.length; pintarBusqueda(); return; }
    if (e.key === "Escape") { $("#cp-lista", back).innerHTML = ""; opciones = []; return; }
    if (e.key === "Enter") {
      e.preventDefault();
      if (opciones.length) {
        const o = opciones[hi] || opciones[0];
        if (o.tipo === "nuevo") { motivoInp.value = o.nombre; $("#cp-lista", back).innerHTML = ""; opciones = []; cantInp.focus(); }
        else elegirProducto(o.p);
        return;
      }
      cantInp.focus();
    }
  });
  cantInp.addEventListener("input", pintarLinea);
  precioInp.addEventListener("input", pintarLinea);
  cantInp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); precioInp.focus(); precioInp.select(); } });
  precioInp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); agregar(); } });
  $("#cp-agregar", back).addEventListener("click", (e) => { e.preventDefault(); agregar(); });
  $("#cp-guardar", back).addEventListener("click", async (e) => {
    e.preventDefault();
    if (enviando) return;
    const cap = leer();
    if (cap.motivo || num(cantInp) || num(precioInp)) {
      if (!agregar()) return;
    }
    if (!borradorCredito.length) return;
    const prov = ($("#cp-prov", back).value || "").trim() || borradorCredito[0].proveedor;
    if (!prov) { $("#cp-msg", back).innerHTML = '<span class="tk-warn">Escribe el proveedor.</span>'; return; }
    enviando = true;
    $("#cp-guardar", back).disabled = true;
    const lineas = borradorCredito.slice();
    for (const ln of lineas) {
      const r = await window.api.db.movimientoEfectivo("retiro", ln.cents, ln.motivo, usuarioActual ? usuarioActual.nombre : null, prov, "compra", "credito", ln.cantidad);
      if (r && r.error) { enviando = false; $("#cp-guardar", back).disabled = false; return alert(r.error); }
    }
    borradorCredito = [];
    _creditoSel.provNombre = prov;
    back.remove();
    if (onDone) onDone();
  });
  pintarBorrador();
  setTimeout(() => { const c = $("#cp-prov", back); if (c) c.focus(); }, 40);
}

function armarDatosEstadoCuentaProveedor(estado) {
  const todos = estado.movimientos || [];
  const movs = credFiltrarMovs(todos, _creditoSel.periodo)
    .slice()
    .sort((a, b) => new Date(a.fecha) - new Date(b.fecha));
  let saldoAnterior, saldoFinal;
  if (movs.length) {
    const first = movs[0];
    saldoAnterior = first.tipo === "cargo" ? (first.saldoCents - first.montoCents) : (first.saldoCents + first.montoCents);
    saldoFinal = movs[movs.length - 1].saldoCents;
  } else {
    saldoAnterior = estado.saldoCents || 0;
    saldoFinal = estado.saldoCents || 0;
  }
  const cajeroUnaVez = usuarioActual ? usuarioActual.nombre : "—";
  const filasDoc = movs.map((m) => {
    const fp = m.tipo === "abono" && m.formaPago ? etiquetaFormaPago(m.formaPago) : "";
    const desc = [m.nota || "", fp].filter(Boolean).join(" · ").trim();
    return {
      fecha: new Date(m.fecha).toLocaleDateString("es-MX"),
      mov: m.tipo === "cargo" ? "CARGO" : "ABONO",
      folio: "#" + m.id,
      desc,
      cargo: m.tipo === "cargo" ? fmt(m.montoCents) : "",
      abono: m.tipo !== "cargo" ? fmt(m.montoCents) : "",
      saldo: fmt(m.saldoCents)
    };
  });
  const html = htmlDocumentoEstadoCuenta({
    titulo: "Estado de cuenta proveedor",
    subtitulo: "Estado de cuenta · Proveedor",
    nombre: (estado.proveedor || "").toUpperCase(),
    metaFilas: [
      { lab: "Cajero", val: cajeroUnaVez },
      { lab: "Caja", val: (CFG && CFG.terminal) || "Caja Principal" },
      { lab: "Periodo", val: credPeriodoLabel() },
      { lab: "Consultado", val: new Date().toLocaleString("es-MX") }
    ],
    saldoAnteriorLabel: "Saldo anterior",
    saldoAnterior: fmt(saldoAnterior),
    saldoFinalLabel: "Saldo actual",
    saldoFinal: fmt(saldoFinal),
    filas: filasDoc,
    firmaNombre: null
  });
  return { estado, movs, saldoAnterior, saldoFinal, cajeroUnaVez, html };
}

async function imprimirEstadoDeCuentaProveedor(estado, opts) {
  opts = opts || {};
  const soloVer = !!opts.soloVer;
  const d = armarDatosEstadoCuentaProveedor(estado);
  if (soloVer) return verDocumentoFlujo("ESTADO DE CUENTA PROVEEDOR", d.html);
  if (await debeImprimirDocumentoHoja()) return imprimirDocumentoFlujo("ESTADO DE CUENTA PROVEEDOR", d.html);

  const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
  const lr = (a, b) => { a = String(a); b = String(b); const s = cols - a.length - b.length; return s >= 1 ? a + " ".repeat(s) + b : (a + " " + b); };
  const center = (s) => { s = String(s); const pad = Math.max(0, Math.floor((cols - s.length) / 2)); return " ".repeat(pad) + s; };
  const L = [];
  L.push(center(`* ${(estado.proveedor || "").toUpperCase()} *`));
  L.push(center("ESTADO DE CUENTA - PROVEEDOR"));
  L.push("");
  L.push("CAJERO: " + d.cajeroUnaVez);
  L.push("CAJA: " + ((CFG && CFG.terminal) || "Caja Principal"));
  L.push(credPeriodoLabel());
  L.push("-".repeat(cols));
  L.push(lr("SALDO ANTERIOR:", fmt(d.saldoAnterior)));
  L.push("-".repeat(cols));
  L.push(tresColsTicket(cols, "CARGO", "ABONO", "SALDO"));
  L.push("-".repeat(cols));
  if (!d.movs.length) L.push("(sin movimientos en el periodo)");
  d.movs.forEach((m) => {
    const fecha = new Date(m.fecha).toLocaleDateString("es-MX");
    const tipo = m.tipo === "cargo" ? "CARGO" : "ABONO";
    L.push(`${fecha} ${tipo} #${m.id}`.slice(0, cols));
    const fp = m.tipo === "abono" && m.formaPago ? etiquetaFormaPago(m.formaPago) : "";
    const desc = [m.nota || "", fp].filter(Boolean).join(" · ").trim();
    if (desc) L.push(("  " + desc).slice(0, cols));
    const cargo = m.tipo === "cargo" ? fmt(m.montoCents) : "";
    const abono = m.tipo !== "cargo" ? fmt(m.montoCents) : "";
    L.push(tresColsTicket(cols, cargo, abono, fmt(m.saldoCents)));
    L.push("-".repeat(cols));
  });
  L.push(lr("SALDO ACTUAL:", fmt(d.saldoFinal)));
  return imprimirListaFlujo("ESTADO DE CUENTA PROVEEDOR", L);
}

function verEstadoDeCuentaProveedor(estado) {
  return imprimirEstadoDeCuentaProveedor(estado, { soloVer: true });
}

function imprimirAbonoConjunto(info) {
  const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
  const lr = (a, b) => { a = String(a); b = String(b); const s = cols - a.length - b.length; return s >= 1 ? a + " ".repeat(s) + b : (a + " " + b); };
  const center = (s) => { s = String(s); const pad = Math.max(0, Math.floor((cols - s.length) / 2)); return " ".repeat(pad) + s; };
  const esCasa = info.formaPago === "efectivo_casa";
  const fp = info.formaPago === "tarjeta" ? "TARJETA" : info.formaPago === "transferencia" ? "TRANSFERENCIA" : esCasa ? "EFECTIVO CASA" : "EFECTIVO";
  const L = [];
  L.push(center("VENTA AL CONTADO"));
  L.push(center("COMPROBANTE DE ABONO"));
  L.push(info.fecha || "");
  L.push("Proveedor: CONTADO");
  L.push("Forma de pago: " + fp);
  L.push("-".repeat(cols));
  L.push(lr("TOTAL DEL CONJUNTO", fmt(info.totalConjunto || 0)));
  L.push(lr("ABONO", "-" + fmt(info.abono || 0)));
  L.push("-".repeat(cols));
  L.push(lr("SALDO DEL CONJUNTO", fmt(info.saldoConjunto || 0)));
  L.push(esCasa ? "Pago de la casa. No toca el cajon ni el corte." : (fp === "EFECTIVO" ? "Salio del cajon y entra al corte de hoy." : "No toca el cajon. Entra al corte de " + fp.toLowerCase() + "."));
  imprimirListaFlujo("ABONO AL CONTADO", L);
}

function imprimirNotaDiaContado(grupo) {
  const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
  const lr = (a, b) => { a = String(a); b = String(b); const s = cols - a.length - b.length; return s >= 1 ? a + " ".repeat(s) + b : (a + " " + b); };
  const center = (s) => { s = String(s); const pad = Math.max(0, Math.floor((cols - s.length) / 2)); return " ".repeat(pad) + s; };
  const cargos = (grupo.movs || []).filter((m) => m.tipo === "cargo").slice().reverse();
  const L = [];
  L.push(center("VENTA AL CONTADO"));
  L.push(center("NOTA DE COMPRA"));
  L.push("Fecha: " + (grupo.dia ? new Date(grupo.dia + "T12:00:00").toLocaleDateString("es-MX") : ""));
  L.push("Proveedor: CONTADO");
  L.push("-".repeat(cols));
  L.push(lr("CANT  DESCRIPCION", "IMPORTE"));
  let total = 0;
  cargos.forEach((m) => {
    const cant = m.cantidad != null && m.cantidad !== "" ? String(m.cantidad) + " " : "";
    const nombre = cant + (m.nota || "Producto");
    const monto = m.montoCents || 0;
    total += monto;
    L.push(lr(nombre.slice(0, Math.max(1, cols - 12)), fmt(monto)));
  });
  if (!cargos.length) L.push("(sin productos este día)");
  L.push("-".repeat(cols));
  L.push(lr("TOTAL", fmt(total)));
  imprimirListaFlujo("VENTA AL CONTADO", L);
}

function imprimirMovimientoProveedor(proveedor, m, saldoActualCents) {
  const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
  const lr = (a, b) => { const s = cols - a.length - b.length; return s >= 1 ? a + " ".repeat(s) + b : (a + " " + b); };
  const center = (s) => { s = String(s); const pad = Math.max(0, Math.floor((cols - s.length) / 2)); return " ".repeat(pad) + s; };
  const L = [];
  L.push("Proveedor: " + (proveedor || ""));
  L.push("Fecha: " + new Date(m.fecha).toLocaleString("es-MX"));
  if (m.usuario) L.push("Atiende: " + m.usuario);
  L.push("-".repeat(cols));
  L.push(m.tipo === "cargo" ? "COMPRA A CREDITO" : "ABONO A PROVEEDOR");
  L.push("Folio: #" + m.id);
  if (m.nota) L.push(m.nota);
  if (m.cantidad != null) L.push("Cantidad: " + m.cantidad);
  L.push(lr(m.tipo === "cargo" ? "Cargo" : "Abono", fmt(m.montoCents)));
  L.push(lr("Saldo tras el movimiento", fmt(m.saldoCents)));
  if (m.formaPago) L.push(lr("Forma de pago", etiquetaFormaPago(m.formaPago).toUpperCase()));
  if (saldoActualCents != null) L.push(lr("SALDO ACTUAL (DEBEMOS)", fmt(saldoActualCents)));
  L.push("-".repeat(cols));
  if (m.tipo === "cargo") {
    L.push("");
    L.push(center("* CREDITO PROVEEDOR *"));
    L.push("FIRMA / RECIBI:");
    L.push("");
    L.push("");
    L.push(center("____________________________"));
    L.push(center((proveedor || "").toUpperCase()));
  }
  imprimirListaFlujo(m.tipo === "abono" ? "ABONO PROVEEDOR" : "COMPRA A CREDITO", L);
}

/* ---------------- Entradas / Salidas de efectivo ---------------- */
// Módulo dedicado (estilo ELEVENTA): registra movimientos de efectivo que no
// vienen de ventas (entradas de cambio, pagos a proveedor, retiros parciales),
// muestra el historial del turno y permite cancelar un movimiento erróneo.
async function renderEntradasSalidas(body, accion) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>💵</span><p>Sin base de datos disponible.</p></div>'; return; }
  const modo = accion === "retiro" ? "retiro" : accion === "compra" ? "compra" : "ingreso";
  const dbTipo = modo === "ingreso" ? "ingreso" : "retiro";
  const esCompra = modo === "compra";

  const tabsHtml = `
    <div class="es-tabs">
      <button class="es-tab ${modo === "ingreso" ? "is-active" : ""}" data-esmode="ingreso">⬆ Entrada</button>
      <button class="es-tab ${modo === "retiro" ? "is-active" : ""}" data-esmode="retiro">⬇ Salida</button>
      <button class="es-tab ${modo === "compra" ? "is-active" : ""}" data-esmode="compra">🧾 Compras</button>
    </div>`;
  const bindTabs = () => $$(".es-tab", body).forEach((b) => b.addEventListener("click", () => {
    if (b.dataset.esmode !== modo) renderEntradasSalidas(body, b.dataset.esmode);
  }));

  const st = await window.api.db.estadoCaja();

  if (!st.abierta) {
    body.innerHTML = `
      <div class="mv-card">
        <div class="mv-card__head"><h3>Movimientos</h3></div>
        ${tabsHtml}
        <div class="mv-card mv-card--center">
          <h3>Caja cerrada</h3>
          <p class="sub">Abre la caja para registrar efectivo, tarjeta o transferencia. Lo que debemos a proveedores se anota en Créditos → Proveedores.</p>
          <button class="btn btn--primary" id="es-abrir">Abrir caja</button>
          <div style="margin-top:16px;text-align:left">${htmlMovimientosDia()}</div>
        </div>
      </div>`;
    bindTabs();
    $("#es-abrir", body).addEventListener("click", () => pedirAperturaCaja(() => renderEntradasSalidas(body, modo)));
    bindMovimientosDia(body);
    return;
  }

  const c = st.caja || { movimientos: [] };
  const esCajon = (m) => {
    const fp = String(m.formaPago || "efectivo").toLowerCase();
    return fp === "efectivo" || fp === "dolares";
  };
  const compras = (c.movimientos || []).filter((m) => m.categoria === "compra" && esCajon(m)).reduce((s, m) => s + (m.montoCents || 0), 0);
  const movs = (c.movimientos || []).filter((m) => m.categoria !== "abono").slice().reverse();
  let proveedores = [];
  try { proveedores = (await window.api.db.getProveedores()) || []; } catch (e) { proveedores = []; }
  const datalistProv = proveedores.map((n) => `<option value="${attr(n)}"></option>`).join("");
  const filas = movs.length ? movs.map((m) => {
    const hora = m.fecha ? new Date(m.fecha).toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" }) : "";
    const esIn = m.tipo === "ingreso";
    const etiqueta = m.categoria === "compra" ? "🧾 Compra" : (esIn ? "⬆ Entrada" : "⬇ Salida");
    const fp = String(m.formaPago || "efectivo").toLowerCase();
    const fpTxt = fp === "tarjeta" ? "Tarjeta" : fp === "transferencia" ? "Transferencia" : fp === "credito" ? "Crédito" : "Efectivo";
    return `<tr>
      <td>${hora}</td>
      <td>${etiqueta}<br/><small class="muted">${fpTxt}</small></td>
      <td>${escapeHtml(m.motivo || "")}${m.proveedor ? ` <small class="muted">· ${escapeHtml(m.proveedor)}</small>` : ""}</td>
      <td class="num ${esIn ? "" : "neg"}">${esIn ? "" : "- "}${fmt(m.montoCents)}</td>
      <td class="acts"><button class="chip chip--out" data-esdel="${m.id}">Cancelar</button></td>
    </tr>`;
  }).join("") : `<tr><td colspan="5" class="muted">Sin movimientos en este turno.</td></tr>`;

  const labelProv = esCompra ? "Proveedor" : (modo === "ingreso" ? "Proveedor / origen (opcional)" : "Proveedor (opcional)");
  const phProv = esCompra ? "Elige o escribe el proveedor…" : "Elige de la lista o escribe uno nuevo…";

  body.innerHTML = `
    <div class="mv-grid2">
      <div class="mv-card">
        <div class="mv-card__head"><h3>Registrar movimientos</h3></div>
        ${tabsHtml}
        <p class="sub">${
          modo === "credito" ? "Compra a crédito: se queda pendiente. No resta del cajón ni sale en el corte hasta que la pagues." :
          modo === "ingreso" ? "Entrada al turno. Elige si entra en efectivo, tarjeta o transferencia." :
          modo === "compra" ? "Compra de insumos. En efectivo sale del cajón hoy. En tarjeta o transferencia no toca el efectivo, pero sí el corte de ese método." :
          "Salida del turno. En efectivo sale del cajón. En tarjeta o transferencia se anota en el corte sin descontar efectivo."
        }</p>
        <div class="es-form">
          <label>Monto</label>
          <div class="es-monto"><span>$</span><input type="text" id="es-monto" inputmode="decimal" placeholder="0.00" /></div>
          ${modo === "credito" ? `<label>Cantidad</label><input type="text" id="es-cant" inputmode="decimal" autocomplete="off" placeholder="Ej. 5, 16, 112" />` : ""}
          <label>Concepto</label>
          <input type="text" id="es-motivo" placeholder="${
            esCompra ? "Ej. bolsas, carbón, refacción, servicio…" :
            modo === "ingreso" ? "Ej. cambio para caja, aporte…" :
            "Ej. comida del personal, gasto, retiro…"
          }" />
          <div id="es-prov-wrap">
            <label>${labelProv}</label>
            <input type="text" id="es-prov" list="es-prov-list" autocomplete="off" spellcheck="false" placeholder="${phProv}" />
            <datalist id="es-prov-list">${datalistProv}</datalist>
            <p class="qty-hint" style="margin-top:4px">Escribe el proveedor o elige uno ya usado.</p>
          </div>
          ${modo === "credito" ? "" : `
          <label>Método de pago</label>
          <select id="es-fp" class="qty-field">
            <option value="efectivo">Efectivo (entra o sale del cajón y del corte)</option>
            <option value="tarjeta">Tarjeta (no toca el cajón; sí el corte)</option>
            <option value="transferencia">Transferencia (no toca el cajón; sí el corte)</option>
          </select>`}
          <p class="qty-hint" id="es-msg"></p>
          ${modo === "credito"
            ? `<button type="button" class="btn btn--sec btn--block" id="es-agregar">＋ Agregar renglón</button><div id="es-borrador"></div><button type="button" class="btn btn--primary btn--block" id="es-guardar">Guardar nota a crédito</button>`
            : `<button type="button" class="btn btn--primary btn--block" id="es-guardar">${esCompra ? "Registrar compra" : "Guardar movimiento"}</button>`}
        </div>
      </div>

      <div class="mv-card">
        <div class="mv-card__head"><h3>${modo === "credito" ? "Compras a crédito" : "Movimientos del turno"}</h3></div>
        ${modo === "credito" ? `<p class="sub">Pendientes: aún no salen del cajón ni del corte. Al pagarlas, eligen efectivo, tarjeta o transferencia y entran al corte de ese día.</p><div id="es-pend"></div>` : `
        <div class="mv-kv"><span>Entradas de efectivo</span><b>${fmt(st.ingresos || 0)}</b></div>
        <div class="mv-kv"><span>Salidas de efectivo</span><b class="neg">- ${fmt(st.retiros || 0)}</b></div>
        <div class="mv-kv"><span>· compras en efectivo (ya descontadas)</span><b class="neg">- ${fmt(compras)}</b></div>
        <div class="mv-kv mv-kv--total"><span>Efectivo esperado en caja</span><b>${fmt(st.efectivoEsperado || 0)}</b></div>`}
        ${modo === "credito" ? `<div class="mv-actions" style="margin-top:10px"><button class="btn btn--sec" id="es-print-pend">🖨️ Imprimir pendientes</button></div>` : `
        <div class="mv-table-wrap hist-scroll" style="margin-top:10px">
          <table class="mv-table">
            <thead><tr><th>Hora</th><th>Tipo</th><th>Concepto</th><th class="num">Monto</th><th></th></tr></thead>
            <tbody>${filas}</tbody>
          </table>
        </div>
        <div class="mv-actions" style="margin-top:10px;flex-wrap:wrap">
          <button class="btn btn--sec" id="es-print">🖨️ Imprimir este turno</button>
        </div>
        <hr/>
        ${htmlMovimientosDia()}`}
      </div>
    </div>`;

  bindTabs();

  const monto = $("#es-monto", body);
  let enviando = false;
  const leerCaptura = () => {
    const cents = Money.toCents(parseFloat((monto.value || "").replace(",", ".")) || 0) || 0;
    const motivo = ($("#es-motivo", body).value || "").trim();
    const proveedor = $("#es-prov", body) ? $("#es-prov", body).value.trim() : "";
    const fpSel = $("#es-fp", body);
    const formaPago = modo === "credito" ? "credito" : (fpSel ? fpSel.value : "efectivo");
    const cantRaw = $("#es-cant", body) ? $("#es-cant", body).value.trim().replace(",", ".") : "";
    const cantidad = cantRaw === "" ? null : Number(cantRaw);
    return { cents, motivo, proveedor, formaPago, cantidad };
  };
  const pintarBorrador = () => {
    const box = $("#es-borrador", body);
    if (!box) return;
    if (!borradorCredito.length) { box.innerHTML = `<p class="qty-hint">Agrega los productos. El proveedor se escribe una sola vez.</p>`; return; }
    const tot = borradorCredito.reduce((s, x) => s + (x.cents || 0), 0);
    box.innerHTML = `<table class="mv-table" style="margin-top:8px"><tbody>${borradorCredito.map((x, i) =>
      `<tr><td>${x.cantidad != null && !isNaN(x.cantidad) ? escapeHtml(String(x.cantidad)) + " " : ""}${escapeHtml(x.motivo)}</td><td class="num">${fmt(x.cents)}</td><td><button type="button" class="chip chip--out" data-qborra="${i}">✕</button></td></tr>`
    ).join("")}</tbody></table><p class="qty-hint">En la nota: ${fmt(tot)}</p>`;
    $$("[data-qborra]", box).forEach((b) => b.addEventListener("click", () => {
      borradorCredito.splice(+b.dataset.qborra, 1);
      pintarBorrador();
    }));
  };
  const agregarRenglon = () => {
    const cap = leerCaptura();
    if (cap.cents <= 0) { $("#es-msg", body).innerHTML = '<span class="tk-warn">Captura un monto mayor a cero.</span>'; monto.focus(); return; }
    if (!cap.motivo) { $("#es-msg", body).innerHTML = '<span class="tk-warn">Escribe el concepto.</span>'; $("#es-motivo", body).focus(); return; }
    if (!cap.proveedor) { $("#es-msg", body).innerHTML = '<span class="tk-warn">Escribe el proveedor una vez. Se usa en toda la nota.</span>'; $("#es-prov", body).focus(); return; }
    borradorCredito.push({ motivo: cap.motivo, cents: cap.cents, cantidad: cap.cantidad != null && !isNaN(cap.cantidad) ? cap.cantidad : null, proveedor: cap.proveedor });
    monto.value = "";
    $("#es-motivo", body).value = "";
    const cant = $("#es-cant", body); if (cant) cant.value = "";
    $("#es-msg", body).innerHTML = "";
    pintarBorrador();
    if (cant) cant.focus(); else $("#es-motivo", body).focus();
  };
  const guardar = async () => {
    if (enviando) return;
    const btn = $("#es-guardar", body);
    if (modo === "credito") {
      const cap = leerCaptura();
      if (cap.motivo || cap.cents) agregarRenglon();
      if (!borradorCredito.length) return;
      const prov = ($("#es-prov", body) && $("#es-prov", body).value.trim()) || borradorCredito[0].proveedor;
      if (!prov) { $("#es-msg", body).innerHTML = '<span class="tk-warn">Escribe el proveedor.</span>'; return; }
      enviando = true;
      if (btn) btn.disabled = true;
      const lineas = borradorCredito.slice();
      for (const ln of lineas) {
        const r = await window.api.db.movimientoEfectivo("retiro", ln.cents, ln.motivo, usuarioActual ? usuarioActual.nombre : null, prov, "compra", "credito", ln.cantidad);
        if (r && r.error) { enviando = false; if (btn) btn.disabled = false; return alert(r.error); }
      }
      borradorCredito = [];
      renderEntradasSalidas(body, modo);
      return;
    }
    const cap = leerCaptura();
    if (cap.cents <= 0) { $("#es-msg", body).innerHTML = '<span class="tk-warn">Captura un monto mayor a cero.</span>'; monto.focus(); return; }
    if (!cap.motivo) { $("#es-msg", body).innerHTML = '<span class="tk-warn">Escribe el concepto.</span>'; return; }
    if (esCompra && !cap.proveedor) { $("#es-msg", body).innerHTML = '<span class="tk-warn">Escribe el proveedor.</span>'; return; }
    enviando = true;
    if (btn) btn.disabled = true;
    const categoria = modo === "compra" || cap.formaPago === "credito" ? "compra" : "";
    const tipo = cap.formaPago === "credito" && modo === "ingreso" ? "ingreso" : dbTipo;
    const r = await window.api.db.movimientoEfectivo(tipo, cap.cents, cap.motivo, usuarioActual ? usuarioActual.nombre : null, cap.proveedor, categoria, cap.formaPago, null);
    if (r && r.error) { enviando = false; if (btn) btn.disabled = false; return alert(r.error); }
    renderEntradasSalidas(body, modo);
  };
  const btnGuardar = $("#es-guardar", body);
  if (btnGuardar) btnGuardar.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); guardar(); });
  const btnAgregar = $("#es-agregar", body);
  if (btnAgregar) btnAgregar.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); agregarRenglon(); });
  monto.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); (modo === "credito" && $("#es-cant", body) ? $("#es-cant", body) : $("#es-motivo", body)).focus(); } });
  const cantInp = $("#es-cant", body);
  if (cantInp) cantInp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); $("#es-motivo", body).focus(); } });
  $("#es-motivo", body).addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); $("#es-prov", body).focus(); } });
  $("#es-prov", body).addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); if (modo === "credito") agregarRenglon(); } });
  if (modo === "credito") pintarBorrador();

  $$("[data-esdel]", body).forEach((b) => b.addEventListener("click", async () => {
    if (!confirm("¿Cancelar este movimiento de efectivo?")) return;
    const r = await window.api.db.cancelarMovimientoEfectivo(+b.dataset.esdel, usuarioActual ? usuarioActual.nombre : null);
    if (r && r.error) return alert(r.error);
    renderEntradasSalidas(body, modo);
  }));

  const btnPrint = $("#es-print", body);
  if (btnPrint) btnPrint.addEventListener("click", () => {
    const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
    const lista = (c.movimientos || []).filter((m) => m.categoria !== "abono");
    const lineas = lista.map((m) => {
      const hora = m.fecha ? new Date(m.fecha).toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" }) : "";
      const signo = m.tipo === "ingreso" ? "+" : "-";
      const fp = String(m.formaPago || "efectivo").toUpperCase();
      const etq = m.categoria === "compra" ? "COMPRA" : (m.tipo === "ingreso" ? "ENTRADA" : "SALIDA");
      const izq = `${hora} ${etq} ${fp} ${m.motivo || ""}${m.proveedor ? (" [" + m.proveedor + "]") : ""}`.trim();
      const der = signo + fmt(m.montoCents);
      const esp = cols - izq.length - der.length;
      return izq + (esp >= 1 ? " ".repeat(esp) : " ") + der;
    });
    lineas.push("-".repeat(cols));
    lineas.push(`Entradas efectivo: ${fmt(st.ingresos || 0)}  Salidas efectivo: ${fmt(st.retiros || 0)}`);
    imprimirListaFlujo("ENTRADAS Y SALIDAS", lineas.length ? lineas : ["(sin movimientos)"]);
  });
  if (modo !== "credito") bindMovimientosDia(body);

  const pintarPend = async () => {
    const box = $("#es-pend", body);
    if (!box) return;
    const lista = (await window.api.db.getMovimientosPendientes()) || [];
    const pend = lista.filter((x) => x.estado !== "pagado");
    const pags = lista.filter((x) => x.estado === "pagado").slice(0, 40);
    const grupos = new Map();
    pend.forEach((p) => {
      const nombre = (p.proveedor || "Sin proveedor").trim() || "Sin proveedor";
      const k = nombre.toLowerCase();
      if (!grupos.has(k)) grupos.set(k, { nombre, items: [] });
      grupos.get(k).items.push(p);
    });
    const bloques = Array.from(grupos.values()).map((g) => {
      const tot = g.items.reduce((s, p) => s + (p.montoCents || 0), 0);
      const filas = g.items.map((p) => {
        const cant = p.cantidad != null && p.cantidad !== "" ? `${escapeHtml(String(p.cantidad))} ` : "";
        return `<tr>
          <td>${cant}${escapeHtml(p.motivo || "")}</td>
          <td class="num">${fmt(p.montoCents)}</td>
          <td class="acts"><button type="button" class="chip chip--out" data-pendel="${p.id}">Quitar</button></td>
        </tr>`;
      }).join("");
      const ids = g.items.map((p) => p.id).join(",");
      return `<div class="mv-card" style="margin-top:10px;padding:10px">
        <div class="mv-kv mv-kv--total"><span>${escapeHtml(g.nombre)}</span><b>${fmt(tot)}</b></div>
        <table class="mv-table"><tbody>${filas}</tbody></table>
        <div class="mv-actions" style="margin-top:8px;flex-wrap:wrap">
          <button type="button" class="btn btn--sec" data-recibo="${attr(g.nombre)}">🖨️ Recibo de adeudo</button>
          <button type="button" class="btn btn--primary" data-pagar-grupo="${ids}">Pagar todo</button>
        </div>
      </div>`;
    }).join("");
    const filaG = (p) => {
      const fecha = p.pagoFecha ? new Date(p.pagoFecha).toLocaleDateString("es-MX") : "";
      const fp = p.pagoForma === "tarjeta" ? "Tarjeta" : p.pagoForma === "transferencia" ? "Transferencia" : "Efectivo";
      const cant = p.cantidad != null && p.cantidad !== "" ? `${escapeHtml(String(p.cantidad))} ` : "";
      return `<tr><td>${fecha}</td><td>${escapeHtml(p.proveedor || "")}</td><td>${cant}${escapeHtml(p.motivo || "")}</td><td>${fp}</td><td class="num">${fmt(p.montoCents)}</td></tr>`;
    };
    const granTotal = pend.reduce((s, p) => s + (p.montoCents || 0), 0);
    box.innerHTML = `
      <h4>Adeudos pendientes</h4>
      <p class="qty-hint">Agrupado por proveedor. El nombre sale una vez. Total pendiente: <b>${fmt(granTotal)}</b></p>
      ${bloques || `<p class="muted">Sin compras a crédito pendientes.</p>`}
      <h4 style="margin-top:14px">Ya pagadas</h4>
      <table class="mv-table"><thead><tr><th>Pagada</th><th>Proveedor</th><th>Concepto</th><th>Método</th><th class="num">Monto</th></tr></thead>
      <tbody>${pags.length ? pags.map(filaG).join("") : `<tr><td colspan="5" class="muted">Aún no hay compras liberadas.</td></tr>`}</tbody></table>`;
    $$("[data-pagar-grupo]", box).forEach((b) => b.addEventListener("click", () => {
      const ids = String(b.dataset.pagarGrupo || "").split(",").map((n) => +n).filter((n) => n);
      if (ids.length) pedirPagoPendiente(ids, body, modo);
    }));
    $$("[data-recibo]", box).forEach((b) => b.addEventListener("click", () => {
      const nombre = b.dataset.recibo || "";
      const g = Array.from(grupos.values()).find((x) => x.nombre === nombre);
      if (!g) return;
      imprimirListaFlujo("ADEUDO " + g.nombre, lineasReciboAdeudo(g.nombre, g.items));
    }));
    $$("[data-pendel]", box).forEach((b) => b.addEventListener("click", async () => {
      if (!confirm("¿Quitar este renglón? Todavía no ha salido del cajón.")) return;
      const r = await window.api.db.cancelarMovimientoPendiente(+b.dataset.pendel, usuarioActual ? usuarioActual.nombre : null);
      if (r && r.error) return alert(r.error);
      renderEntradasSalidas(body, modo);
    }));
    const btnPend = $("#es-print-pend", body);
    if (btnPend && !btnPend.dataset.listo) {
      btnPend.dataset.listo = "1";
      btnPend.addEventListener("click", async () => {
        const todos = (await window.api.db.getMovimientosPendientes()) || [];
        const solo = todos.filter((x) => x.estado !== "pagado");
        if (!solo.length) return alert("No hay adeudo pendiente.");
        const map = new Map();
        solo.forEach((p) => {
          const nombre = (p.proveedor || "Sin proveedor").trim() || "Sin proveedor";
          if (!map.has(nombre.toLowerCase())) map.set(nombre.toLowerCase(), { nombre, items: [] });
          map.get(nombre.toLowerCase()).items.push(p);
        });
        const gruposImp = Array.from(map.values());
        const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
        const todas = [];
        gruposImp.forEach((g, i) => {
          if (i) todas.push("");
          todas.push(...lineasReciboAdeudo(g.nombre, g.items));
          todas.push("-".repeat(cols));
        });
        const gran = solo.reduce((s, p) => s + (p.montoCents || 0), 0);
        todas.push("TOTAL GENERAL  " + fmt(gran));
        imprimirListaFlujo("ADEUDOS POR PROVEEDOR", todas);
      });
    }
  };
  if (modo === "credito") pintarPend();

  setTimeout(() => monto.focus(), 40);
}

async function pedirCierreCajaModal(st) {
  return new Promise((resolve) => {
    const esperado = fmt(st.efectivoEsperado);
    const back = document.createElement("div");
    back.className = "modal-back";
    back.innerHTML = `
      <div class="modal modal--qty" style="max-width:420px">
        <h3>Cerrar caja / Corte del día</h3>
        <p class="qty-hint">Efectivo esperado por el sistema: <b>${esperado}</b></p>

        <div class="qty-field"><label>1) Total báscula (captura manual)</label>
          <input type="number" min="0" step="0.01" inputmode="decimal" id="ci-bascula" placeholder="Suma del ticket de corte de báscula(s)" /></div>
        <p class="qty-hint">Anota el total de la(s) báscula(s). No se desglosa por corte.</p>

        <div class="qty-field"><label>2) Total categoría paquetes (captura manual)</label>
          <input type="number" min="0" step="0.01" inputmode="decimal" id="ci-paquetes" placeholder="Total de paquetes del turno" /></div>
        <p class="qty-hint">Aparte de las entradas de efectivo. Entra al total de categorías + báscula + paquetes.</p>

        <div class="qty-field"><label>3) Efectivo contado (arqueo)</label>
          <input type="number" min="0" step="0.01" inputmode="decimal" id="ci-conteo" placeholder="Lo que cuentas ahora" /></div>
        <p class="qty-hint">Se compara contra el esperado (${esperado}).</p>

        <div class="qty-field"><label>4) Dinero que queda en caja al cierre</label>
          <input type="number" min="0" step="0.01" inputmode="decimal" id="ci-queda" placeholder="Cuánto dejas en el cajón" /></div>
        <p class="qty-hint">Referencia del cierre. <b>No</b> tiene que coincidir con el fondo de mañana (si sacan dinero fuera de turno, al abrir capturan lo real).</p>

        <div class="qty-field"><label>5) Cuánto se entregó</label>
          <input type="number" min="0" step="0.01" inputmode="decimal" id="ci-entrego" placeholder="Dinero que entregas al cierre" /></div>
        <p class="qty-hint">Lo anotado sale en el ticket, debajo de lo que queda en caja.</p>

        <p class="qty-hint" id="ci-msg"></p>
        <div class="modal__foot">
          <button class="btn" data-cerrar="1">Cancelar</button>
          <button class="btn btn--primary" id="ci-ok">Cerrar caja</button>
        </div>
      </div>`;
    document.body.appendChild(back);
    const cerrar = (val) => { back.remove(); resolve(val); };
    const toCents = (el) => {
      const raw = String((el && el.value) || "").trim().replace(",", ".");
      if (raw === "") return null;
      return Money.toCents(parseFloat(raw) || 0) || 0;
    };
    const ok = () => {
      const bascula = toCents($("#ci-bascula", back));
      const paquetes = toCents($("#ci-paquetes", back));
      const conteo = toCents($("#ci-conteo", back));
      const queda = toCents($("#ci-queda", back));
      const entrego = toCents($("#ci-entrego", back));
      if (conteo == null) { $("#ci-msg", back).innerHTML = '<span class="tk-warn">Captura el efectivo contado.</span>'; return; }
      if (bascula == null) { $("#ci-msg", back).innerHTML = '<span class="tk-warn">Captura el total de báscula (aunque sea 0).</span>'; return; }
      if (paquetes == null) { $("#ci-msg", back).innerHTML = '<span class="tk-warn">Captura el total de paquetes (aunque sea 0).</span>'; return; }
      if (queda == null) { $("#ci-msg", back).innerHTML = '<span class="tk-warn">Captura cuánto dinero queda en caja.</span>'; return; }
      if (entrego == null) { $("#ci-msg", back).innerHTML = '<span class="tk-warn">Captura cuánto se entregó (aunque sea 0).</span>'; return; }
      cerrar({
        conteoCents: conteo,
        basculaTotalManualCents: bascula,
        paquetesTotalManualCents: paquetes,
        dineroEnCajaCierreCents: queda,
        entregadoCents: entrego
      });
    };
    $("#ci-ok", back).addEventListener("click", ok);
    back.addEventListener("keydown", (e) => {
      if (e.key === "Escape") { e.preventDefault(); cerrar(null); }
      if (e.key === "Enter") { e.preventDefault(); ok(); }
    });
    back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(null); });
    setTimeout(() => { const i = $("#ci-bascula", back); if (i) { i.focus(); i.select && i.select(); } }, 30);
  });
}

async function cerrarCajaFlujo(st, body) {
  const datos = await pedirCierreCajaModal(st);
  if (!datos) return;
  const r = await window.api.db.cerrarCaja(datos.conteoCents, usuarioActual ? usuarioActual.nombre : null, {
    basculaTotalManualCents: datos.basculaTotalManualCents,
    paquetesTotalManualCents: datos.paquetesTotalManualCents,
    dineroEnCajaCierreCents: datos.dineroEnCajaCierreCents,
    entregadoCents: datos.entregadoCents
  });
  if (r.error) return alert(r.error);
  await refreshCajaStatus();

  const co = r.corte;
  const dif = co.diferenciaCents;
  const difTxt = dif === 0 ? "Cuadró exacto ✅" : (dif > 0 ? `Sobrante +${fmt(dif)}` : `Faltante ${fmt(dif)}`);
  const filasMetodo = PAGOS.map((p) => {
    const v = co.porMetodo[p.id] || 0;
    return v ? `<tr><td>${p.emoji} ${p.label}</td><td class="num">${fmt(v)}</td></tr>` : "";
  }).join("");
  const otrasCat = deptosCorte(co.ventasPorDepto);
  const cbCierre = datoCarnesBascula(co);
  const sumaCat = otrasCat.reduce((s, d) => s + (d.montoCents || 0), 0);
  const cobradoCierre = co.ventasCobradas != null ? co.ventasCobradas : co.totalVentas;
  const categMasBascula = sumaCat + (co.basculaTotalManualCents || 0) + (co.paquetesTotalManualCents || 0);
  const difCatCob = categMasBascula - cobradoCierre;
  const filaCat = (d) => {
    const prods = (d.productos || []).map((p) => {
      const cant = p.cant != null ? ` <span class="muted">× ${Number(p.cant).toLocaleString("es-MX")}</span>` : "";
      return `<tr><td style="padding-left:18px">${escapeHtml(p.nombre)}${cant}</td><td class="num">${fmt(p.montoCents)}</td></tr>`;
    }).join("");
    return `<tr><td colspan="2" class="subhead">${escapeHtml(d.depto)}</td></tr>${prods}<tr><td>Total ${escapeHtml(d.depto)}</td><td class="num">${fmt(d.montoCents)}</td></tr>`;
  };
  const filasCat = ((cbCierre.montoCents || otrasCat.length || co.basculaTotalManualCents != null || co.paquetesTotalManualCents != null) ? (
    `<tr><td colspan="2" class="subhead">Ventas por categoría (sin créditos no pagados; báscula sin desglose)</td></tr>` +
    otrasCat.map(filaCat).join("") +
    `<tr class="mv-total-row"><td>Total categorías</td><td class="num">${fmt(sumaCat)}</td></tr>` +
    `<tr><td>Total báscula (manual)</td><td class="num">${co.basculaTotalManualCents != null ? fmt(co.basculaTotalManualCents) : "(sin capturar)"}</td></tr>` +
    `<tr><td>Total paquetes (manual)</td><td class="num">${co.paquetesTotalManualCents != null ? fmt(co.paquetesTotalManualCents) : "(sin capturar)"}</td></tr>` +
    `<tr class="mv-total-row"><td>Total categorías + báscula + paquetes</td><td class="num">${fmt(categMasBascula)}</td></tr>` +
    `<tr><td>Ventas cobradas</td><td class="num">${fmt(cobradoCierre)}</td></tr>` +
    `<tr class="mv-total-row"><td>Diferencia (categ+báscula+paquetes − cobrado)</td><td class="num">${difCatCob > 0 ? "+" : ""}${fmt(difCatCob)}</td></tr>` +
    `<tr><td colspan="2" class="subhead">Carnes báscula (dato; no suma)</td></tr>` +
    `<tr><td>Total carnes báscula${cbCierre.cant ? ` <span class="muted">× ${Number(cbCierre.cant).toLocaleString("es-MX")}</span>` : ""}</td><td class="num">${fmt(cbCierre.montoCents)}</td></tr>`
  ) : "");
  body.innerHTML = `
    <div class="mv-card mv-card--center">
      <h3>Corte realizado</h3>
      <span class="pill ${dif === 0 ? "pill--ok" : "pill--warn"}">${difTxt}</span>
      <table class="mv-table" style="margin-top:14px">
        <tbody>
          <tr><td>Fondo inicial</td><td class="num">${fmt(co.fondoCents)}</td></tr>
          <tr><td>Ventas cobradas (${co.numVentas})</td><td class="num">${fmt(co.ventasCobradas != null ? co.ventasCobradas : co.totalVentas)}</td></tr>
          ${co.apartadosCents ? `<tr><td>🏷️ de las cuales, apartados (abonos)</td><td class="num">${fmt(co.apartadosCents)}</td></tr>` : ""}
          <tr><td>Devoluciones de contado</td><td class="num neg">- ${fmt(co.devCobradas != null ? co.devCobradas : co.totalDevoluciones)}</td></tr>
          <tr class="mv-total-row"><td>Venta neta cobrada</td><td class="num">${fmt(co.ventasNetas)}</td></tr>
          ${(co.creditosLista || []).length ? `<tr><td colspan="2" class="subhead">Crédito clientes (no entra al neto)</td></tr>` + (co.creditosLista || []).map((x) => `<tr><td>${escapeHtml(x.cliente || "Sin nombre")}</td><td class="num">${fmt(x.montoCents)}</td></tr>`).join("") + `<tr class="mv-total-row"><td>Total crédito clientes</td><td class="num">${fmt(co.creditoVentas || 0)}</td></tr>` : (co.creditoVentas ? `<tr><td>📒 Crédito clientes (no cobrado)</td><td class="num">${fmt(co.creditoVentas)}</td></tr>` : "")}
          ${(co.creditosProveedor || []).length ? `<tr><td colspan="2" class="subhead">Crédito proveedor (lo que debemos; no sale del cajón)</td></tr>` + (co.creditosProveedor || []).map((x) => `<tr><td>${escapeHtml(x.proveedor || "Sin proveedor")}</td><td class="num">${fmt(x.montoCents)}</td></tr>`).join("") + `<tr class="mv-total-row"><td>Total por pagar</td><td class="num">${fmt(co.creditosProveedorCents || 0)}</td></tr>` : `<tr><td>Crédito proveedor</td><td class="num">${fmt(0)}</td></tr>`}
          ${co.totalDevoluciones ? `<tr><td colspan="2" class="nota-dev">↩️ Las devoluciones no son pérdida: la mercancía regresó al inventario. En el efectivo solo se refleja lo reembolsado en efectivo.</td></tr>` : ""}
          <tr><td colspan="2" class="subhead">Neto por método de pago</td></tr>
          ${filasMetodo}
          ${filasCat || ""}
          <tr><td colspan="2" class="subhead">Ingresos / cancelaciones</td></tr>
          <tr><td>Ingresos (entradas)</td><td class="num">${fmt(co.ingresos)}</td></tr>
          <tr><td>Cancelaciones</td><td class="num neg">- ${fmt(co.totalCancelaciones || 0)}</td></tr>
          <tr><td colspan="2" class="subhead">Efectivo</td></tr>
          <tr><td>Efectivo de ventas</td><td class="num">${fmt(co.efectivoVentas)}</td></tr>
          <tr><td>Devoluciones en efectivo</td><td class="num neg">- ${fmt(co.efectivoDevoluciones || 0)}</td></tr>
          <tr><td>Ingresos efectivo</td><td class="num">${fmt(co.ingresos)}</td></tr>
          ${co.totalAbonosCents ? `<tr><td>💳 Abonos a crédito (efectivo)</td><td class="num">${fmt(co.totalAbonosCents)}</td></tr>` : ""}
          ${co.totalAbonosOtrosCents ? `<tr><td>💳 Abonos a crédito (tarjeta/transf.)</td><td class="num">${fmt(co.totalAbonosOtrosCents)}</td></tr>` : ""}
          <tr><td>Retiros efectivo</td><td class="num neg">- ${fmt(co.retiros)}</td></tr>
          <tr class="mv-total-row"><td>Efectivo esperado</td><td class="num">${fmt(co.efectivoEsperado)}</td></tr>
          <tr><td>Efectivo contado</td><td class="num">${fmt(co.conteoCents)}</td></tr>
          <tr class="mv-total-row"><td>Diferencia</td><td class="num">${fmt(dif)}</td></tr>
          <tr><td>Dinero que queda en caja</td><td class="num">${fmt(co.dineroEnCajaCierreCents != null ? co.dineroEnCajaCierreCents : co.conteoCents)}</td></tr>
          <tr><td>Se entregó</td><td class="num">${co.entregadoCents != null ? fmt(co.entregadoCents) : "—"}</td></tr>
        </tbody>
      </table>
      <div class="mv-actions" style="margin-top:14px;justify-content:center">
        <button class="btn btn--sec" id="corte-imprimir-cierre">🖨️ Imprimir corte</button>
        <button class="btn btn--primary" id="corte-nuevo">Abrir nueva caja</button>
      </div>
    </div>`;
  const corteImp = {
    titulo: "CORTE DE TURNO",
    abrirCajon: true,
    turno: co.turno,
    terminal: co.terminal || "",
    fecha: new Date().toLocaleString("es-MX"),
    cajero: usuarioActual ? usuarioActual.nombre : "",
    aperturaFecha: co.aperturaFecha ? new Date(co.aperturaFecha).toLocaleString("es-MX") : "",
    fondoCents: co.fondoCents,
    numVentas: co.numVentas,
    metodos: Object.keys(co.porMetodo || {}).filter((id) => co.porMetodo[id]).map((id) => ({ label: pagoLabel(id), montoCents: co.porMetodo[id] })),
    porMetodo: co.porMetodo || {},
    porMetodoCobrado: co.porMetodoCobrado || null,
    entradas: co.entradas || [],
    salidas: co.salidas || [],
    movimientosOtros: co.movimientosOtros || [],
    abonos: co.abonos || [],
    totalAbonosCents: co.totalAbonosCents || 0,
    totalAbonosOtrosCents: co.totalAbonosOtrosCents || 0,
    ventasPorDepto: deptosCorte(co.ventasPorDepto),
    carnesBascula: datoCarnesBascula(co),
    totalVentasCents: co.totalVentas,
    ventasCobradasCents: co.ventasCobradas != null ? co.ventasCobradas : co.totalVentas,
    apartadosCents: co.apartadosCents || 0,
    totalDevolucionesCents: co.totalDevoluciones,
    devCobradasCents: co.devCobradas != null ? co.devCobradas : co.totalDevoluciones,
    ventasNetasCents: co.ventasNetas,
    creditoVentasCents: co.creditoVentas || 0,
    creditoDevCents: co.creditoDev || 0,
    creditosLista: co.creditosLista || [],
    creditosProveedor: co.creditosProveedor || [],
    creditosProveedorCents: co.creditosProveedorCents || 0,
    ingresosCents: co.ingresos,
    retirosCents: co.retiros,
    efectivoVentasCents: co.efectivoVentas || 0,
    efectivoDevolucionesCents: co.efectivoDevoluciones || 0,
    efectivoEsperadoCents: co.efectivoEsperado,
    efectivoContadoCents: co.conteoCents,
    diferenciaCents: co.diferenciaCents,
    dineroEnCajaCierreCents: co.dineroEnCajaCierreCents != null ? co.dineroEnCajaCierreCents : co.conteoCents,
    entregadoCents: co.entregadoCents != null ? co.entregadoCents : null,
    basculaTotalManualCents: co.basculaTotalManualCents,
    paquetesTotalManualCents: co.paquetesTotalManualCents,
    cancelaciones: co.cancelaciones || [],
    totalCancelacionesCents: co.totalCancelaciones || 0,
    devolucionesLista: co.devolucionesLista || [],
    diferidoBasculaCents: co.diferidoBascula || 0
  };
  $("#corte-imprimir-cierre", body).addEventListener("click", () => imprimirCorteFlujo(corteImp));
  $("#corte-nuevo", body).addEventListener("click", () => renderCorte(body));
}

/* ---------------- Inventario y catálogo (pestañas) ---------------- */
// Un solo módulo agrupa: Productos + existencias, Paquetes y Categorías.
// Clientes queda como botón independiente en la barra superior.
let invTabActual = "productos";
async function renderInventarioHub(body, tab) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>📦</span><p>Sin base de datos disponible.</p></div>'; return; }
  invTabActual = tab || invTabActual || "productos";
  if (invTabActual === "paquetes") invTabActual = "productos";
  const tabs = [
    { id: "productos", label: "🥩 Productos y existencias" },
    { id: "categorias", label: "🗂️ Categorías" },
    { id: "imagenes", label: "🖼️ Imágenes" },
    { id: "bascula", label: "⚖️ Precios báscula" }
  ];
  body.innerHTML = `
    <div class="inv-tabs">
      ${tabs.map((t) => `<button class="inv-tab ${t.id === invTabActual ? "is-active" : ""}" data-invtab="${t.id}">${t.label}</button>`).join("")}
    </div>
    <div id="inv-sub"></div>`;
  const sub = $("#inv-sub", body);
  $$("[data-invtab]", body).forEach((b) => b.addEventListener("click", () => renderInventarioHub(body, b.dataset.invtab)));
  if (invTabActual === "categorias") return renderCategorias(sub);
  if (invTabActual === "imagenes") return renderImagenesProducto(sub);
  if (invTabActual === "bascula") return renderPreciosBascula(sub);
  return renderProductos(sub);
}

/* ---------------- Precios de la báscula (leer / modificar / enviar) ---------------- */
// Estado en memoria del catálogo leído desde cada báscula, para poder editar y
// enviar sólo lo que cambió. { [ip]: { ip, nombre, productos: [{id, plu, nombre, precio, _orig}] } }
let basculasCatalogo = null;

async function renderPreciosBascula(body) {
  const dir = CFG && CFG.bascula && CFG.bascula.modoDirecto;
  body.innerHTML = `
    <div class="mv-card">
      <div class="mv-card__head">
        <h3>⚖️ Precios de la báscula</h3>
        <div class="mv-actions">
          <button class="btn btn--sec" id="pb-leer">📥 Leer básculas</button>
          <button class="btn btn--primary" id="pb-enviar" disabled>📤 Enviar cambios</button>
        </div>
      </div>
      <p class="sub" style="margin:0 0 8px">Lee todos los productos y precios directamente de la(s) báscula(s), modifica los precios que necesites y envía la actualización. Se envían <b>solo los precios que cambies</b>.</p>
      ${dir ? "" : '<p class="tk-warn">⚠️ Esta función requiere el <b>modo directo (TCP)</b>. Actívalo en ⚙️ Configuración → Básculas.</p>'}
      <div class="bk-estado" id="pb-estado"></div>
      <div id="pb-tablas" style="margin-top:12px"></div>
    </div>`;

  const est = $("#pb-estado", body);
  const cont = $("#pb-tablas", body);
  const btnEnviar = $("#pb-enviar", body);

  const pintar = () => {
    if (!basculasCatalogo || !basculasCatalogo.length) { cont.innerHTML = ""; return; }
    cont.innerHTML = basculasCatalogo.map((b, bi) => {
      const filas = (b.productos || []).map((p, pi) => {
        const cambiado = Number(p.precio) !== Number(p._orig);
        return `<tr class="${cambiado ? "pb-row--dirty" : ""}">
          <td>${escapeHtml(String(p.plu || p.id || "?"))}</td>
          <td>${escapeHtml(p.nombre || "")}</td>
          <td class="num"><input type="number" min="0" step="0.01" class="pb-precio" data-bi="${bi}" data-pi="${pi}" value="${(Number(p.precio) || 0).toFixed(2)}" style="width:110px;text-align:right"/></td>
        </tr>`;
      }).join("") || `<tr><td colspan="3" class="muted">Sin productos.</td></tr>`;
      return `<div class="mv-card" style="margin-top:12px">
        <div class="mv-card__head"><h4 style="margin:0">${escapeHtml(b.nombre || ("Báscula " + (bi + 1)))} · ${escapeHtml(b.ip || "")}</h4><span class="sub">${(b.productos || []).length} producto(s)</span></div>
        <table class="mv-table"><thead><tr><th>PLU</th><th>Nombre</th><th class="num">Precio</th></tr></thead>
          <tbody>${filas}</tbody></table>
      </div>`;
    }).join("");

    $$(".pb-precio", cont).forEach((inp) => {
      inp.addEventListener("input", () => {
        const b = basculasCatalogo[+inp.dataset.bi];
        const p = b && b.productos[+inp.dataset.pi];
        if (!p) return;
        p.precio = parseFloat(String(inp.value).replace(",", ".")) || 0;
        const dirty = p.precio !== Number(p._orig);
        inp.closest("tr").classList.toggle("pb-row--dirty", dirty);
        actualizarBotonEnviar();
      });
    });
    actualizarBotonEnviar();
  };

  const contarCambios = () => {
    if (!basculasCatalogo) return 0;
    let n = 0;
    for (const b of basculasCatalogo)
      for (const p of (b.productos || []))
        if (Number(p.precio) !== Number(p._orig)) n++;
    return n;
  };
  const actualizarBotonEnviar = () => {
    const n = contarCambios();
    btnEnviar.disabled = n === 0;
    btnEnviar.textContent = n ? `📤 Enviar ${n} cambio(s)` : "📤 Enviar cambios";
  };

  // Repintar si ya había un catálogo leído en esta sesión.
  pintar();

  $("#pb-leer", body).addEventListener("click", async () => {
    est.innerHTML = "Leyendo básculas… (puede tardar unos segundos)";
    let r; try { r = await window.api.bascula.leerProductos(); } catch (e) { r = { error: e.message }; }
    if (!r || (!r.ok && !r.basculas)) {
      est.innerHTML = `<span class="tk-warn">⚠️ ${escapeHtml(r && r.error ? r.error : "No se pudo leer la báscula.")}</span>`;
      return;
    }
    basculasCatalogo = (r.basculas || []).map((b) => ({
      ip: b.ip, nombre: b.nombre, ok: b.ok, error: b.error,
      productos: (b.productos || []).map((p) => ({
        id: p.id, plu: p.plu, nombre: p.nombre,
        precio: Number(p.precio) || 0, _orig: Number(p.precio) || 0
      }))
    }));
    const oks = basculasCatalogo.filter((b) => b.ok);
    const errs = basculasCatalogo.filter((b) => !b.ok);
    const total = oks.reduce((s, b) => s + (b.productos || []).length, 0);
    est.innerHTML = `<span class="tk-ok">✅ ${total} producto(s) leído(s) de ${oks.length} báscula(s).</span>` +
      (errs.length ? `<br/><span class="tk-warn">⚠️ ${errs.map((b) => `${escapeHtml(b.ip)}: ${escapeHtml(b.error || "sin respuesta")}`).join("; ")}</span>` : "");
    pintar();
  });

  btnEnviar.addEventListener("click", async () => {
    if (!basculasCatalogo) return;
    const n = contarCambios();
    if (!n) return;
    if (!confirm(`Se enviarán ${n} precio(s) modificado(s) a la báscula. ¿Continuar?`)) return;
    est.innerHTML = `Enviando ${n} cambio(s)…`;
    let totalOk = 0; const errores = [];
    for (const b of basculasCatalogo) {
      const items = (b.productos || [])
        .filter((p) => Number(p.precio) !== Number(p._orig))
        .map((p) => ({ id: p.id, precio: Number(p.precio) }));
      if (!items.length) continue;
      let r; try { r = await window.api.bascula.enviarPrecios({ ip: b.ip, items }); } catch (e) { r = { error: e.message }; }
      if (r && r.ok) {
        totalOk += (r.enviados || items.length);
        for (const p of b.productos) p._orig = p.precio;
      } else {
        errores.push(`${b.ip}: ${(r && r.error) || "no se pudo enviar"}`);
      }
    }
    est.innerHTML = (totalOk ? `<span class="tk-ok">✅ ${totalOk} precio(s) actualizados en la báscula.</span>` : "") +
      (errores.length ? `<br/><span class="tk-warn">⚠️ ${errores.map(escapeHtml).join("; ")}</span>` : "");
    pintar();
  });
}

/* ---------------- Imágenes de producto ---------------- */
const IMG_MAX = 200;          // tamaño máx. de la miniatura (px)
const IMG_CALIDAD = 0.72;     // calidad JPEG

// Convierte cualquier imagen (jpg, png, gif, webp, bmp, svg, avif…) a una
// miniatura cuadrada que CONTIENE la imagen completa (sin recortar), centrada y
// con fondo TRANSPARENTE (respeta íconos con transparencia). Así se "ajusta" al
// botón mostrando el ícono completo. Se guarda como PNG.
function imagenAMiniatura(file) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type || !file.type.startsWith("image/")) return reject(new Error("Selecciona un archivo de imagen."));
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("No se pudo leer el archivo."));
    reader.onload = () => {
      const im = new Image();
      im.onerror = () => reject(new Error("Formato de imagen no soportado por el sistema. Prueba JPG, PNG, WEBP o GIF."));
      im.onload = () => {
        const w0 = im.naturalWidth || im.width, h0 = im.naturalHeight || im.height;
        if (!w0 || !h0) return reject(new Error("La imagen no tiene dimensiones válidas."));
        const lado = IMG_MAX;
        const canvas = document.createElement("canvas");
        canvas.width = lado; canvas.height = lado;
        const ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, lado, lado);                 // fondo transparente
        if (ctx.imageSmoothingEnabled !== undefined) { ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = "high"; }
        // AJUSTE "contain": la imagen COMPLETA cabe en el cuadro, centrada (sin recorte).
        const esc = Math.min(lado / w0, lado / h0);
        const w = Math.max(1, Math.round(w0 * esc)), h = Math.max(1, Math.round(h0 * esc));
        const dx = Math.round((lado - w) / 2), dy = Math.round((lado - h) / 2);
        ctx.drawImage(im, 0, 0, w0, h0, dx, dy, w, h);
        try { resolve(canvas.toDataURL("image/png")); }
        catch (e) { reject(new Error("No se pudo procesar la imagen.")); }
      };
      im.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

let imgFiltro = "";
async function renderImagenesProducto(body) {
  // Se puede asignar imagen a CUALQUIER producto del catálogo (no solo los del
  // panel): carnes, carne seca, complementos, lo que sea.
  const lista = (DATA.productos || []).slice().sort((a, b) => String(a.nombre).localeCompare(String(b.nombre)));
  const conImg = lista.filter((p) => IMGS[p.id]).length;
  body.innerHTML = `
    <p class="sub">Agrega una foto a <b>cualquier producto</b> (busca por nombre). Se guarda en miniatura, no afecta el tamaño de los botones. Para que la foto salga como ícono en la pantalla de ventas, el producto debe estar marcado para el panel (Inventario → 🖼️ En panel). ${conImg} con imagen.</p>
    <div class="searchbar searchbar--inv">
      <span class="searchbar__icon">🔎</span>
      <input type="text" id="img-search" placeholder="Buscar producto por nombre…" value="${attr(imgFiltro)}" />
    </div>
    <div class="img-grid" id="img-grid">
      ${lista.map((p) => {
        const src = IMGS[p.id];
        return `<div class="img-card" data-idcard="${p.id}" data-nombre="${attr(p.nombre.toLowerCase())}">
          <div class="img-card__thumb">${src ? `<img src="${attr(src)}" alt="" />` : `<span>${catEmoji(p.cat)}</span>`}</div>
          <div class="img-card__name">${escapeHtml(p.nombre)}</div>
          <div class="img-card__acts">
            <button class="chip" data-imgset="${p.id}">${src ? "Cambiar" : "📷 Agregar"}</button>
            ${src ? `<button class="chip chip--out" data-imgdel="${p.id}">Quitar</button>` : ""}
          </div>
        </div>`;
      }).join("") || '<p class="muted" style="padding:16px">Sin complementos. Agrega productos de reventa (quesos, salsas, abarrotes) en Inventario.</p>'}
    </div>
    <input type="file" id="img-file" accept="image/*" style="display:none" />`;

  const fileInput = $("#img-file", body);
  let idPendiente = null;

  // Filtrado en el lugar (sin reconstruir el DOM) para no perder el foco ni "tragarse" clics.
  const search = $("#img-search", body);
  const aplicarFiltro = () => {
    const q = (search.value || "").trim().toLowerCase();
    imgFiltro = search.value;
    $$(".img-card", body).forEach((card) => {
      const match = !q || (card.dataset.nombre || "").includes(q);
      card.classList.toggle("hidden", !match);
    });
  };
  search.addEventListener("input", aplicarFiltro);
  if (imgFiltro) aplicarFiltro();

  $$("[data-imgset]", body).forEach((b) => b.addEventListener("click", () => {
    idPendiente = +b.dataset.imgset;
    fileInput.value = "";
    fileInput.click();
  }));
  $$("[data-imgdel]", body).forEach((b) => b.addEventListener("click", async () => {
    const id = +b.dataset.imgdel;
    await window.api.db.setImagenProducto(id, null);
    delete IMGS[id];
    renderImagenesProducto(body);
    renderProducts($("#entry-search") ? $("#entry-search").value : "");
  }));
  fileInput.addEventListener("change", async () => {
    const file = fileInput.files && fileInput.files[0];
    if (!file || idPendiente == null) return;
    try {
      const dataURL = await imagenAMiniatura(file);
      await window.api.db.setImagenProducto(idPendiente, dataURL);
      IMGS[idPendiente] = dataURL;
      renderImagenesProducto(body);
      renderProducts($("#entry-search") ? $("#entry-search").value : "");
    } catch (e) {
      alert(e.message || "No se pudo procesar la imagen.");
    }
    idPendiente = null;
  });
}

async function imprimirMovInventarioFlujo() {
  const dia = hoyISO();
  const movs = await window.api.db.getMovimientosInv({ dia });
  const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
  const etq = { entrada: "ENTRADA", salida: "SALIDA", ajuste: "AJUSTE", venta: "VENTA" };
  const lineas = (movs || []).map((m) => {
    const hora = new Date(m.fecha).toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" });
    const signo = m.tipo === "entrada" ? "+" : (m.tipo === "salida" || m.tipo === "venta" ? "-" : "=");
    return `${hora} ${(etq[m.tipo] || m.tipo)} ${m.nombre}\n   ${signo}${fmtCant(Math.abs(m.cant || 0), m.unidad)} ${m.unidad}${m.nota ? " · " + m.nota : ""}`;
  });
  imprimirListaFlujo("MOVIMIENTOS INVENTARIO " + dia, lineas.length ? lineas : ["(sin movimientos hoy)"]);
}

/* ---------------- Productos (catálogo) ---------------- */
const UNIDADES = ["kg", "pza", "paq", "bolsa", "manojo", "litro", "s/pedido"];

/* ---------------- Catálogos SAT (CFDI 4.0) ---------------- */
const REGIMENES_SAT = [
  ["601", "General de Ley Personas Morales"],
  ["603", "Personas Morales con Fines no Lucrativos"],
  ["605", "Sueldos y Salarios e Ingresos Asimilados a Salarios"],
  ["606", "Arrendamiento"],
  ["607", "Régimen de Enajenación o Adquisición de Bienes"],
  ["608", "Demás ingresos"],
  ["610", "Residentes en el Extranjero sin Establecimiento Permanente en México"],
  ["611", "Ingresos por Dividendos (socios y accionistas)"],
  ["612", "Personas Físicas con Actividades Empresariales y Profesionales"],
  ["614", "Ingresos por intereses"],
  ["615", "Régimen de los ingresos por obtención de premios"],
  ["616", "Sin obligaciones fiscales"],
  ["620", "Sociedades Cooperativas de Producción que optan por diferir sus ingresos"],
  ["621", "Incorporación Fiscal"],
  ["622", "Actividades Agrícolas, Ganaderas, Silvícolas y Pesqueras"],
  ["623", "Opcional para Grupos de Sociedades"],
  ["624", "Coordinados"],
  ["625", "Régimen de las Actividades Empresariales con ingresos a través de Plataformas Tecnológicas"],
  ["626", "Régimen Simplificado de Confianza (RESICO)"]
];
const USOS_CFDI = [
  ["G01", "Adquisición de mercancías"],
  ["G02", "Devoluciones, descuentos o bonificaciones"],
  ["G03", "Gastos en general"],
  ["I01", "Construcciones"],
  ["I02", "Mobiliario y equipo de oficina"],
  ["I04", "Equipo de cómputo y accesorios"],
  ["I08", "Otra maquinaria y equipo"],
  ["D01", "Honorarios médicos, dentales y gastos hospitalarios"],
  ["P01", "Por definir"],
  ["S01", "Sin efectos fiscales"],
  ["CP01", "Pagos"]
];
const CLAVE_UNIDAD_SAT = [
  ["KGM", "Kilogramo"],
  ["H87", "Pieza"],
  ["LTR", "Litro"],
  ["XPK", "Paquete"],
  ["E48", "Servicio"]
];
const optsFrom = (lista, sel) => lista.map(([v, t]) =>
  `<option value="${v}" ${v === sel ? "selected" : ""}>${v} — ${escapeHtml(t)}</option>`).join("");

async function recargarCatalogo() {
  if (!tienenDB()) return;
  const d = await window.api.db.bootstrap();
  DATA.productos = d.productos;
  DATA.categorias = d.categorias;
  DATA.paquetes = d.paquetes;
  renderCats();
  renderProducts();
}

async function renderProductos(body, estado) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>📦</span><p>Sin base de datos disponible.</p></div>'; return; }
  const q = ((estado && estado.q) || "").trim().toLowerCase();
  const catF = (estado && estado.cat) || "";
  const editable = puedeEditarInventario();   // precios, bajar stock, editar/borrar
  const puedeSumar = puedeSumarInventario();

  // Solo productos CON inventario. Los de báscula ("siempre disponible") no se listan.
  let lista = DATA.productos.slice().filter(productoConInventario);
  if (catF) lista = lista.filter((p) => p.cat === catF);
  if (q) lista = lista.filter((p) => p.nombre.toLowerCase().includes(q));
  lista.sort((a, b) => a.nombre.localeCompare(b.nombre));

  const catOpc = `<option value="">Todas las categorías</option>` +
    DATA.categorias
      .filter((c) => DATA.productos.some((p) => productoConInventario(p) && p.cat === c.id))
      .map((c) => `<option value="${c.id}" ${c.id === catF ? "selected" : ""}>${c.emoji} ${escapeHtml(c.nombre)}</option>`).join("");

  const filas = lista.map((p) => {
    const cat = DATA.categorias.find((c) => c.id === p.cat);
    const bajo = (p.existencia || 0) <= (p.stockMin || 0);
    const stepEx = p.unidad === "kg" ? "0.001" : "1";
    let existCell;
    if (editable) {
      existCell = `<div class="price-edit"><input type="number" min="0" step="${stepEx}" data-exist="${p.id}" value="${p.existencia || 0}" class="${bajo ? "low" : ""}" title="Existencia total (puedes subir o bajar). Enter para guardar" /></div>`;
    } else {
      // Cajero: ve existencia + botón para SOLO agregar (nunca bajar).
      existCell = `<div class="inv-exist-cajero">
        <b class="${bajo ? "low" : ""}">${fmtCant(p.existencia, p.unidad)}</b>
        ${puedeSumar ? `<button type="button" class="chip chip--in" data-entrada="${p.id}" title="Agregar existencias">＋ Entrada</button>` : ""}
      </div>`;
    }
    return `<tr data-nombre="${attr(p.nombre.toLowerCase())}">
      <td>${escapeHtml(p.nombre)}</td>
      <td class="muted">${cat ? cat.emoji + " " + escapeHtml(cat.nombre) : "—"}</td>
      <td class="num"><div class="price-edit"><span>$</span><input type="number" min="0" step="0.01" data-precio="${p.id}" value="${p.precioCents != null ? (p.precioCents / 100).toFixed(2) : ""}" placeholder="manual" ${editable ? "" : "readonly"} title="${editable ? "Clic y escribe el precio · Enter o salir para guardar" : "Solo administrador puede cambiar precios"}" /></div></td>
      <td class="muted">${p.unidad}</td>
      <td class="num">${existCell}</td>
      <td class="acts">
        ${editable ? `<button class="chip ${mostrarEnPanel(p) ? "" : "chip--out"}" data-panel="${p.id}" title="Mostrar u ocultar en el panel de ventas">${mostrarEnPanel(p) ? "🖼️ En panel" : "🖼️ Fuera"}</button>
        <button class="chip" data-edit="${p.id}">✎ Editar</button>
        <button class="chip chip--out" data-del="${p.id}">🗑</button>`
          : (puedeSumar
            ? '<span class="muted" title="Puedes agregar existencias; precios y bajas solo admin">＋ solo entradas</span>'
            : '<span class="muted">🔒 solo lectura</span>')}
      </td></tr>`;
  }).join("") || `<tr><td colspan="6" class="muted">Sin productos.</td></tr>`;

  body.innerHTML = `
    <div class="mv-card">
      <div class="mv-card__head">
        <h3>Productos <small class="muted">(${lista.length})</small></h3>
        <div class="mv-head-actions">
          <select id="pc-catf" class="mv-search">${catOpc}</select>
          <input type="search" id="pc-search" class="mv-search" placeholder="Buscar producto…" value="${escapeHtml(q)}" />
          <button class="btn btn--sec" id="pc-print">🖨️ Existencias</button>
          <button class="btn btn--sec" id="pc-movs">📄 Movimientos</button>
          ${editable
            ? '<button class="btn btn--primary" id="pc-nuevo">＋ Nuevo producto</button>'
            : '<button class="btn btn--sec" id="pc-desbloq">🔓 Admin (precios / bajas)</button>'}
        </div>
      </div>
      ${!editable ? '<p class="sub">Como cajero puedes <b>agregar existencias</b> (＋ Entrada). No puedes bajar stock ni cambiar precios sin clave de administrador.</p>' : ""}
      <div class="mv-table-wrap">
        <table class="mv-table">
          <thead><tr><th>Producto</th><th>Categoría</th><th class="num">Precio</th><th>Unidad</th><th class="num">Existencia</th><th>Acciones</th></tr></thead>
          <tbody>${filas}</tbody>
        </table>
      </div>
    </div>`;

  const cur = () => ({ q: $("#pc-search", body).value, cat: $("#pc-catf", body).value });
  // Búsqueda EN EL LUGAR: filtra filas sin reconstruir el DOM, así el cuadro de
  // texto no pierde el foco ni el cursor y se puede escribir rápido.
  const inpSearch = $("#pc-search", body);
  const contador = $(".mv-card__head h3 small", body);
  const aplicarBusqueda = () => {
    const qq = (inpSearch.value || "").trim().toLowerCase();
    let visibles = 0;
    $$("tbody tr", body).forEach((tr) => {
      if (tr.dataset.nombre === undefined) return; // fila "Sin productos"
      const match = !qq || tr.dataset.nombre.includes(qq);
      tr.classList.toggle("hidden", !match);
      if (match) visibles++;
    });
    if (contador) contador.textContent = "(" + visibles + ")";
  };
  inpSearch.addEventListener("input", aplicarBusqueda);
  // Los filtros de categoría / inventario sí reconstruyen (son cambios puntuales,
  // no por cada tecla, así que no afectan la escritura).
  $("#pc-catf", body).addEventListener("change", () => renderProductos(body, cur()));
  // Botón de desbloqueo (solo aparece cuando el inventario está en solo lectura).
  const bDesbloq = $("#pc-desbloq", body);
  if (bDesbloq) bDesbloq.addEventListener("click", async () => {
    const ok = await pedirPinAdmin("Ingresa la clave de un administrador para cambiar precios o bajar existencias.");
    if (ok) { invDesbloqueado = true; renderProductos(body, cur()); }
  });
  const bNuevo = $("#pc-nuevo", body);
  if (bNuevo) bNuevo.addEventListener("click", () => editarProducto(null, body, cur()));
  $$("[data-edit]", body).forEach((b) => b.addEventListener("click", () => editarProducto(+b.dataset.edit, body, cur())));
  $$("[data-del]", body).forEach((b) => b.addEventListener("click", () => eliminarProductoFlujo(+b.dataset.del, body, cur())));
  $$("[data-panel]", body).forEach((b) => b.addEventListener("click", async () => {
    const id = +b.dataset.panel;
    const p = DATA.productos.find((x) => x.id === id); if (!p) return;
    const r = await window.api.db.guardarProducto({ id, enPanel: !mostrarEnPanel(p) });
    DATA.productos = r;
    await recargarCatalogo();
    renderProductos(body, cur());
  }));
  // Entrada de inventario (cajeros): solo suma, nunca baja.
  $$("[data-entrada]", body).forEach((b) => b.addEventListener("click", async () => {
    if (!puedeSumarInventario()) return;
    const id = +b.dataset.entrada;
    const p = DATA.productos.find((x) => x.id === id);
    if (!p) return;
    const step = p.unidad === "kg" ? "0.001" : "1";
    const val = await pedirValorModal({
      titulo: "Entrada de inventario",
      hint: `<b>${escapeHtml(p.nombre)}</b><br/>Existencia actual: <b>${fmtCant(p.existencia, p.unidad)} ${p.unidad}</b><br/>Indica cuánto vas a <b>agregar</b> (no se puede restar).`,
      label: `Cantidad a agregar (${p.unidad})`,
      tipo: "number",
      placeholder: step === "1" ? "1" : "0.000",
      okLabel: "Agregar"
    });
    if (val == null) return;
    const cant = parseFloat(String(val).replace(",", ".")) || 0;
    if (cant <= 0) return alert("La cantidad a agregar debe ser mayor a cero.");
    const r = await window.api.db.movimientoInventario(id, "entrada", cant, "entrada cajero", usuarioActual ? usuarioActual.nombre : null);
    if (r && r.error) return alert(r.error);
    p.existencia = r.existencia;
    await recargarCatalogo();
    renderProductos(body, cur());
  }));
  $$("[data-exist]", body).forEach((inp) => {
    const guardar = async () => {
      if (!puedeEditarInventario()) return;   // solo admin: ajuste libre
      const id = +inp.dataset.exist;
      const p = DATA.productos.find((x) => x.id === id);
      if (!p) return;
      const nuevo = parseFloat(inp.value.replace(",", ".")) || 0;
      if (nuevo === (p.existencia || 0)) return;
      const r = await window.api.db.movimientoInventario(id, "ajuste", nuevo, "ajuste manual", usuarioActual ? usuarioActual.nombre : null);
      if (r && r.error) { alert(r.error); return; }
      p.existencia = r.existencia;
      inp.classList.add("saved");
      setTimeout(() => inp.classList.remove("saved"), 700);
    };
    inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); inp.blur(); } });
    inp.addEventListener("blur", guardar);
  });
  $("#pc-print", body).addEventListener("click", () => {
    const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
    const controlados = DATA.productos.filter((p) => p.controlaInventario);
    const lineas = controlados.map((p) => {
      const izq = p.nombre.length > 30 ? p.nombre.slice(0, 30) : p.nombre;
      const der = fmtCant(p.existencia, p.unidad) + " " + p.unidad + ((p.existencia || 0) <= (p.stockMin || 0) ? " *BAJO*" : "");
      const esp = cols - izq.length - der.length;
      return izq + (esp >= 1 ? " ".repeat(esp) : " ") + der;
    });
    imprimirListaFlujo("EXISTENCIAS", lineas.length ? lineas : ["(sin productos con inventario)"]);
  });
  $("#pc-movs", body).addEventListener("click", () => imprimirMovInventarioFlujo());
  $$("[data-precio]", body).forEach((inp) => {
    const guardar = async () => {
      if (!puedeEditarPrecios()) return;
      const id = +inp.dataset.precio;
      const p = DATA.productos.find((x) => x.id === id);
      const raw = inp.value.trim();
      const nuevo = raw === "" ? null : (Money.toCents(parseFloat(raw.replace(",", ".")) || 0) || 0);
      if (p && p.precioCents === nuevo) return;
      const r = await window.api.db.guardarProducto({ id, precioCents: nuevo });
      DATA.productos = r;
      renderCats(); renderProducts();
      inp.classList.add("saved");
      setTimeout(() => inp.classList.remove("saved"), 700);
    };
    inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); inp.blur(); } });
    inp.addEventListener("blur", guardar);
  });
}

function editarProducto(id, body, estado) {
  const p = id ? DATA.productos.find((x) => x.id === id) : null;
  const catOpc = DATA.categorias.map((c) =>
    `<option value="${c.id}" ${p && p.cat === c.id ? "selected" : ""}>${c.emoji} ${escapeHtml(c.nombre)}</option>`).join("");
  const uniOpc = UNIDADES.map((u) => `<option value="${u}" ${p && p.unidad === u ? "selected" : ""}>${u}</option>`).join("");
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>${p ? "Editar producto" : "Nuevo producto"}</h3>
      <div class="qty-field"><label>Nombre</label><input type="text" id="pe-nombre" value="${p ? attr(p.nombre) : ""}" placeholder="Ej. Molida Especial" /></div>
      <div class="qty-field"><label>Categoría</label><select id="pe-cat">${catOpc}</select></div>
      <div class="qty-field"><label>Precio (vacío = manual)</label><input type="number" min="0" step="0.01" id="pe-precio" value="${p && p.precioCents != null ? (p.precioCents / 100).toFixed(2) : ""}" placeholder="0.00" /></div>
      <div class="qty-field"><label>Unidad</label><select id="pe-unidad">${uniOpc}</select></div>
      <details class="cf-fiscal" ${p && (p.claveProdServ || p.ivaTasa) ? "open" : ""}>
        <summary>Claves SAT (para facturar)</summary>
        <div class="qty-field"><label>ClaveProdServ</label><input type="text" id="pe-claveprod" value="${p ? attr(p.claveProdServ) : ""}" placeholder="Ej. 50111500 (carne de res)" /></div>
        <div class="qty-field"><label>ClaveUnidad</label><select id="pe-claveuni">${optsFrom(CLAVE_UNIDAD_SAT, p ? p.claveUnidad : "")}</select></div>
        <div class="qty-field"><label>IVA</label>
          <select id="pe-iva">
            <option value="0" ${p && Number(p.ivaTasa) === 0 ? "selected" : ""}>Tasa 0% (carne/alimentos)</option>
            <option value="0.16" ${p && Number(p.ivaTasa) === 0.16 ? "selected" : ""}>16%</option>
          </select>
        </div>
      </details>
      <label class="cf-check" style="margin:6px 0"><input type="checkbox" id="pe-panel" ${(p ? mostrarEnPanel(p) : true) ? "checked" : ""} /> <span>Mostrar en el <b>panel de ventas</b> (con ícono).</span></label>
      <label class="cf-check" style="margin:6px 0"><input type="checkbox" id="pe-controla" ${(p ? p.controlaInventario : true) ? "checked" : ""} /> <span>Controlar inventario (existencias). Solo marca esto en productos de mostrador (quesos, salsas, abarrotes, carne seca, especialidades).</span></label>
      <div class="qty-field" id="pe-stockmin-wrap"><label>Stock mínimo (alerta)</label><input type="number" min="0" step="0.001" id="pe-stockmin" value="${p ? (p.stockMin || 0) : 0}" /></div>
      <p class="qty-hint" id="pe-msg"></p>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="pe-ok">Guardar</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  const guardar = async () => {
    if (!puedeEditarInventario()) { $("#pe-msg", back).innerHTML = '<span class="tk-warn">Requiere clave de administrador.</span>'; return; }
    const nombre = $("#pe-nombre", back).value.trim();
    if (!nombre) { $("#pe-msg", back).innerHTML = '<span class="tk-warn">Escribe un nombre.</span>'; return; }
    const raw = $("#pe-precio", back).value.trim();
    const precioCents = raw === "" ? null : (Money.toCents(parseFloat(raw.replace(",", ".")) || 0) || 0);
    const controla = $("#pe-controla", back).checked;
    const prod = {
      nombre, cat: $("#pe-cat", back).value, precioCents,
      unidad: $("#pe-unidad", back).value,
      controlaInventario: controla,
      enPanel: $("#pe-panel", back).checked,
      stockMin: controla ? (parseFloat($("#pe-stockmin", back).value.replace(",", ".")) || 0) : 0,
      claveProdServ: $("#pe-claveprod", back).value.trim(),
      claveUnidad: $("#pe-claveuni", back).value,
      ivaTasa: parseFloat($("#pe-iva", back).value) || 0
    };
    if (p) prod.id = p.id;
    const r = await window.api.db.guardarProducto(prod);
    DATA.productos = r;
    cerrar();
    await recargarCatalogo();
    renderProductos(body, estado);
  };
  const toggleStock = () => { $("#pe-stockmin-wrap", back).style.display = $("#pe-controla", back).checked ? "" : "none"; };
  toggleStock();
  $("#pe-controla", back).addEventListener("change", toggleStock);
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#pe-ok", back).addEventListener("click", guardar);
  // Enter guarda solo si NO estás en un campo de texto a medias (evita pérdidas
  // de foco/cursor raras). En inputs de texto, Enter pasa al siguiente campo.
  back.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { e.preventDefault(); cerrar(); return; }
    if (e.key !== "Enter") return;
    const t = e.target;
    if (t && t.tagName === "SELECT") return;
    if (t && t.tagName === "TEXTAREA") return;
    if (t && t.tagName === "INPUT" && (t.type === "text" || t.type === "search" || !t.type)) {
      e.preventDefault();
      const campos = Array.from(back.querySelectorAll('input:not([type="checkbox"]):not([type="hidden"]), select'))
        .filter((el) => el.offsetParent !== null && !el.disabled && !el.readOnly);
      const i = campos.indexOf(t);
      if (i >= 0 && i < campos.length - 1) { campos[i + 1].focus(); campos[i + 1].select && campos[i + 1].select(); }
      else guardar();
      return;
    }
    e.preventDefault();
    guardar();
  });
  setTimeout(() => { const n = $("#pe-nombre", back); if (n) { n.focus(); n.select && n.select(); } }, 30);
}

async function eliminarProductoFlujo(id, body, estado) {
  if (!puedeEditarInventario()) return;   // no-admin: solo lectura
  const p = DATA.productos.find((x) => x.id === id);
  if (!p) return;
  if (!confirm(`¿Eliminar "${p.nombre}" del catálogo?`)) return;
  const r = await window.api.db.eliminarProducto(id);
  if (r.error) return alert(r.error);
  DATA.productos = r.productos;
  await recargarCatalogo();
  renderProductos(body, estado);
}

/* ---------------- Categorías ---------------- */
async function renderCategorias(body) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>🗂️</span><p>Sin base de datos disponible.</p></div>'; return; }
  const cats = DATA.categorias.slice().sort((a, b) => (a.orden || 0) - (b.orden || 0));
  const filas = cats.map((c) => {
    const n = DATA.productos.filter((p) => p.cat === c.id).length;
    return `<tr>
      <td style="font-size:18px">${c.emoji}</td>
      <td>${escapeHtml(c.nombre)}</td>
      <td class="num">${n}</td>
      <td class="acts">
        <button class="chip" data-edit="${c.id}">✎ Editar</button>
        <button class="chip chip--out" data-del="${c.id}" ${n ? "disabled title='Tiene productos'" : ""}>🗑</button>
      </td></tr>`;
  }).join("") || `<tr><td colspan="4" class="muted">Sin categorías.</td></tr>`;

  body.innerHTML = `
    <div class="mv-card">
      <div class="mv-card__head">
        <h3>Categorías <small class="muted">(${cats.length})</small></h3>
        <button class="btn btn--primary" id="ct-nuevo">＋ Nueva categoría</button>
      </div>
      <p class="sub">Solo puedes eliminar categorías sin productos.</p>
      <div class="mv-table-wrap">
        <table class="mv-table">
          <thead><tr><th>Icono</th><th>Nombre</th><th class="num">Productos</th><th>Acciones</th></tr></thead>
          <tbody>${filas}</tbody>
        </table>
      </div>
    </div>`;

  $("#ct-nuevo", body).addEventListener("click", () => editarCategoria(null, body));
  $$("[data-edit]", body).forEach((b) => b.addEventListener("click", () => editarCategoria(b.dataset.edit, body)));
  $$("[data-del]", body).forEach((b) => b.addEventListener("click", () => eliminarCategoriaFlujo(b.dataset.del, body)));
}

function editarCategoria(id, body) {
  const c = id ? DATA.categorias.find((x) => x.id === id) : null;
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>${c ? "Editar categoría" : "Nueva categoría"}</h3>
      <div class="qty-field"><label>Icono (emoji)</label><input type="text" id="ce-emoji" maxlength="4" value="${c ? attr(c.emoji) : "🥩"}" /></div>
      <div class="qty-field"><label>Nombre</label><input type="text" id="ce-nombre" value="${c ? attr(c.nombre) : ""}" placeholder="Ej. Cortes Finos" /></div>
      <p class="qty-hint" id="ce-msg"></p>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="ce-ok">Guardar</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  const guardar = async () => {
    const nombre = $("#ce-nombre", back).value.trim();
    if (!nombre) { $("#ce-msg", back).innerHTML = '<span class="tk-warn">Escribe un nombre.</span>'; return; }
    const cat = { nombre, emoji: $("#ce-emoji", back).value.trim() || "🥩" };
    if (c) cat.id = c.id;
    const r = await window.api.db.guardarCategoria(cat);
    if (r.error) { $("#ce-msg", back).innerHTML = `<span class="tk-warn">${escapeHtml(r.error)}</span>`; return; }
    DATA.categorias = r.categorias;
    cerrar();
    renderCats();
    renderCategorias(body);
  };
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#ce-ok", back).addEventListener("click", guardar);
  back.addEventListener("keydown", (e) => { if (e.key === "Escape") cerrar(); if (e.key === "Enter") { e.preventDefault(); guardar(); } });
  setTimeout(() => $("#ce-nombre", back).focus(), 30);
}

async function eliminarCategoriaFlujo(id, body) {
  const c = DATA.categorias.find((x) => x.id === id);
  if (!c) return;
  if (!confirm(`¿Eliminar la categoría "${c.nombre}"?`)) return;
  const r = await window.api.db.eliminarCategoria(id);
  if (r.error) return alert(r.error);
  DATA.categorias = r.categorias;
  renderCats();
  renderCategorias(body);
}

/* ---------------- Clientes ---------------- */
let _clientesVista = "todos"; // todos | normal | casa

async function cargarClientes() {
  if (!tienenDB()) return DATA.clientes || [];
  DATA.clientes = await window.api.db.getClientes();
  return DATA.clientes;
}

async function renderClientes(body, filtro) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>👥</span><p>Sin base de datos disponible.</p></div>'; return; }
  const clientes = await cargarClientes();
  const q = (filtro || "").trim().toLowerCase();
  let lista = clientes.slice();
  if (_clientesVista === "casa") lista = lista.filter((c) => !!c.clienteCasa);
  else if (_clientesVista === "normal") lista = lista.filter((c) => !c.clienteCasa);
  if (q) lista = lista.filter((c) => (c.nombre + " " + (c.telefono || "") + " " + (c.rfc || "")).toLowerCase().includes(q));
  lista.sort((a, b) => a.nombre.localeCompare(b.nombre));

  const nCasa = clientes.filter((c) => c.clienteCasa).length;
  const nNorm = clientes.length - nCasa;
  const totalDeuda = lista.reduce((s, c) => s + (c.saldoCents || 0), 0);
  const tab = (id, label) => `<button class="cred-tab ${_clientesVista === id ? "is-active" : ""}" data-clvista="${id}">${label}</button>`;

  const filas = lista.map((c) => {
    const debe = (c.saldoCents || 0) > 0;
    const tipo = c.clienteCasa
      ? `<span class="pill" title="Solo esta PC; no se sincroniza">🏠 Casa</span>`
      : (c.creditoActivo ? `<span class="pill pill--ok">Crédito ${c.limiteCents ? fmt(c.limiteCents) : ""}</span>` : `<span class="pill">Contado</span>`);
    return `<tr>
      <td><b>${escapeHtml(c.nombre)}</b>${c.rfc ? `<br><small class="muted">${escapeHtml(c.rfc)}</small>` : ""}${c.clienteCasa ? `<br><small class="muted">No va a la otra PC</small>` : ""}</td>
      <td class="muted">${escapeHtml(c.telefono || "—")}</td>
      <td>${tipo}</td>
      <td class="num ${debe ? "neg" : ""}"><b>${fmt(c.saldoCents || 0)}</b></td>
      <td class="acts">
        <button class="chip chip--in" data-abono="${c.id}" ${debe ? "" : "disabled"}>Abono</button>
        <button class="chip" data-cargo="${c.id}">Cargo</button>
        <button class="chip" data-mov="${c.id}">Historial</button>
        <button class="chip" data-edit="${c.id}">✎</button>
        <button class="chip chip--out" data-del="${c.id}">🗑</button>
      </td></tr>`;
  }).join("") || `<tr><td colspan="5" class="muted">${_clientesVista === "casa" ? "Sin clientes casa." : "Sin clientes."}</td></tr>`;

  body.innerHTML = `
    <div class="mv-card">
      <div class="mv-card__head">
        <h3>Clientes <small class="muted">(${lista.length})</small></h3>
        <div class="mv-head-actions">
          <input type="search" id="cl-search" class="mv-search" placeholder="Buscar nombre, teléfono o RFC…" value="${escapeHtml(q)}" />
          <button class="btn btn--sec" id="cl-cobranza" title="Ir a Créditos">💳 Créditos</button>
          <button class="btn btn--primary" id="cl-nuevo">＋ Nuevo cliente</button>
        </div>
      </div>
      <div class="cred-tabs" style="margin:0 0 10px">
        ${tab("todos", "Todos (" + clientes.length + ")")}
        ${tab("normal", "Sincronizados (" + nNorm + ")")}
        ${copiaEnVivo ? tab("casa", "🏠 Clientes casa (" + nCasa + ")") : ""}
      </div>
      ${copiaEnVivo ? '<p class="sub"><b>Clientes casa</b> quedan solo en esta PC (abonos y saldo no van a la otra terminal). El resto sí se sincroniza.</p>' : ""}
      ${totalDeuda > 0 ? `<p class="sub">Saldo del listado: <b class="neg">${fmt(totalDeuda)}</b></p>` : ""}
      <div class="mv-table-wrap">
        <table class="mv-table">
          <thead><tr><th>Cliente</th><th>Teléfono</th><th>Tipo</th><th class="num">Saldo</th><th>Acciones</th></tr></thead>
          <tbody>${filas}</tbody>
        </table>
      </div>
    </div>`;

  const cur = () => $("#cl-search", body).value;
  $("#cl-search", body).addEventListener("input", () => renderClientes(body, cur()));
  $$("[data-clvista]", body).forEach((b) => b.addEventListener("click", () => {
    _clientesVista = b.dataset.clvista || "todos";
    renderClientes(body, cur());
  }));
  const bCob = $("#cl-cobranza", body); if (bCob) bCob.addEventListener("click", () => showModule("creditos"));
  $("#cl-nuevo", body).addEventListener("click", () => editarCliente(null, body, cur()));
  $$("[data-edit]", body).forEach((b) => b.addEventListener("click", () => editarCliente(+b.dataset.edit, body, cur())));
  $$("[data-del]", body).forEach((b) => b.addEventListener("click", () => eliminarClienteFlujo(+b.dataset.del, body, cur())));
  $$("[data-abono]", body).forEach((b) => b.addEventListener("click", () => movimientoCreditoFlujo(+b.dataset.abono, "abono", body, cur())));
  $$("[data-cargo]", body).forEach((b) => b.addEventListener("click", () => movimientoCreditoFlujo(+b.dataset.cargo, "cargo", body, cur())));
  $$("[data-mov]", body).forEach((b) => b.addEventListener("click", () => verHistorialCliente(+b.dataset.mov)));
}

function editarCliente(id, body, q) {
  const c = id ? (DATA.clientes || []).find((x) => x.id === id) : null;
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>${c ? "Editar cliente" : "Nuevo cliente"}</h3>
      <div class="qty-field"><label>Nombre</label><input type="text" id="cle-nombre" value="${c ? attr(c.nombre) : ""}" placeholder="Nombre o negocio" /></div>
      <div class="qty-field"><label>Teléfono</label><input type="text" id="cle-tel" value="${c ? attr(c.telefono) : ""}" placeholder="Opcional" /></div>
      <div class="qty-field"><label>RFC</label><input type="text" id="cle-rfc" value="${c ? attr(c.rfc) : ""}" placeholder="Opcional (para factura)" /></div>
      <details class="cf-fiscal" ${c && (c.email || c.codigoPostal || c.regimenFiscal || c.usoCfdi) ? "open" : ""}>
        <summary>Datos fiscales (para facturar)</summary>
        <div class="qty-field"><label>Correo (para enviar la factura)</label><input type="email" id="cle-email" value="${c ? attr(c.email) : ""}" placeholder="cliente@correo.com" /></div>
        <div class="qty-field"><label>Código postal fiscal</label><input type="text" id="cle-cp" value="${c ? attr(c.codigoPostal) : ""}" placeholder="Ej. 31000" /></div>
        <div class="qty-field"><label>Régimen fiscal</label><select id="cle-regimen"><option value="">— Selecciona —</option>${optsFrom(REGIMENES_SAT, c ? c.regimenFiscal : "")}</select></div>
        <div class="qty-field"><label>Uso de CFDI</label><select id="cle-uso">${optsFrom(USOS_CFDI, (c && c.usoCfdi) ? c.usoCfdi : "G03")}</select></div>
      </details>
      <div class="qty-field"><label>Dirección</label><input type="text" id="cle-dir" value="${c ? attr(c.direccion) : ""}" placeholder="Opcional" /></div>
      <div class="qty-field"><label>Notas</label><input type="text" id="cle-notas" value="${c ? attr(c.notas) : ""}" placeholder="Opcional" /></div>
      <label class="cf-check"><input type="checkbox" id="cle-credito" ${c && c.creditoActivo ? "checked" : ""}/> Permite compras a crédito</label>
      <div class="qty-field"><label>Límite de crédito (0 = sin límite)</label><input type="number" min="0" step="0.01" id="cle-limite" value="${c && c.limiteCents ? (c.limiteCents / 100).toFixed(2) : "0.00"}" /></div>
      ${copiaEnVivo ? `<label class="cf-check"><input type="checkbox" id="cle-casa" ${c && c.clienteCasa ? "checked" : ""}/> 🏠 Cliente casa (solo esta PC; no se sincroniza a la otra terminal)</label>
      <p class="qty-hint">Los clientes casa y sus abonos quedan locales. Usuarios, ventas y clientes normales sí van a la otra PC.</p>` : ""}
      <p class="qty-hint" id="cle-msg"></p>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="cle-ok">Guardar</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  const guardar = async () => {
    const nombre = $("#cle-nombre", back).value.trim();
    if (!nombre) { $("#cle-msg", back).innerHTML = '<span class="tk-warn">Escribe un nombre.</span>'; return; }
    const cli = {
      nombre, telefono: $("#cle-tel", back).value.trim(), rfc: $("#cle-rfc", back).value.trim().toUpperCase(),
      direccion: $("#cle-dir", back).value.trim(), notas: $("#cle-notas", back).value.trim(),
      email: $("#cle-email", back).value.trim(),
      codigoPostal: $("#cle-cp", back).value.trim(),
      regimenFiscal: $("#cle-regimen", back).value,
      usoCfdi: $("#cle-uso", back).value,
      creditoActivo: $("#cle-credito", back).checked,
      limiteCents: Money.toCents(parseFloat($("#cle-limite", back).value.replace(",", ".")) || 0) || 0,
      clienteCasa: $("#cle-casa", back) ? $("#cle-casa", back).checked : false
    };
    if (c) cli.id = c.id;
    const r = await window.api.db.guardarCliente(cli);
    if (r.error) { $("#cle-msg", back).innerHTML = `<span class="tk-warn">${escapeHtml(r.error)}</span>`; return; }
    DATA.clientes = r.clientes;
    cerrar();
    renderClientes(body, q);
  };
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#cle-ok", back).addEventListener("click", guardar);
  back.addEventListener("keydown", (e) => { if (e.key === "Escape") cerrar(); });
  setTimeout(() => $("#cle-nombre", back).focus(), 30);
}

async function eliminarClienteFlujo(id, body, q) {
  const c = (DATA.clientes || []).find((x) => x.id === id);
  if (!c) return;
  if (!confirm(`¿Eliminar al cliente "${c.nombre}"?`)) return;
  const r = await window.api.db.eliminarCliente(id);
  if (r.error) return alert(r.error);
  DATA.clientes = r.clientes;
  renderClientes(body, q);
}

function movimientoCreditoFlujo(id, tipo, body, q) {
  const c = (DATA.clientes || []).find((x) => x.id === id);
  if (!c) return;
  const titulo = tipo === "abono" ? "Registrar abono (pago del cliente)" : "Registrar cargo (aumenta la deuda)";
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>${titulo}</h3>
      <p class="sub">${escapeHtml(c.nombre)} · Saldo actual: <b>${fmt(c.saldoCents || 0)}</b></p>
      <div class="qty-field"><label>Monto</label><input type="number" min="0" step="0.01" id="mc-monto" placeholder="0.00" /></div>
      ${tipo === "abono" ? `<div class="qty-field"><label>Forma de pago</label>
        <select id="mc-forma">
          <option value="efectivo">Efectivo (entra al cajón)</option>
          ${copiaEnVivo ? '<option value="efectivo_casa">Efectivo casa</option>' : ""}
          <option value="tarjeta">Tarjeta</option>
          <option value="transferencia">Transferencia</option>
        </select></div>` : ""}
      <div class="qty-field"><label>Nota (opcional)</label><input type="text" id="mc-nota" placeholder="Ej. abono en efectivo" /></div>
      <p class="qty-hint" id="mc-msg">${tipo === "abono" ? "El abono baja la deuda en cuanto se registra." : ""}</p>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="mc-ok">Registrar</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  const guardar = async () => {
    const monto = Money.toCents(parseFloat($("#mc-monto", back).value.replace(",", ".")) || 0) || 0;
    if (!monto) { $("#mc-msg", back).innerHTML = '<span class="tk-warn">Escribe un monto válido.</span>'; return; }
    const forma = tipo === "abono" && $("#mc-forma", back) ? $("#mc-forma", back).value : undefined;
    if (tipo === "abono" && forma && forma !== "efectivo_casa") {
      const stCaja = await window.api.db.estadoCaja();
      if (!stCaja || !stCaja.abierta) {
        $("#mc-msg", back).innerHTML = '<span class="tk-warn">Abre la caja para que el abono entre al corte.</span>';
        return;
      }
    }
    const r = await window.api.db.movimientoCredito(id, tipo, monto, $("#mc-nota", back).value.trim(), usuarioActual ? usuarioActual.nombre : null, forma);
    if (r.error) { $("#mc-msg", back).innerHTML = `<span class="tk-warn">${escapeHtml(r.error)}</span>`; return; }
    DATA.clientes = r.clientes;
    cerrar();
    renderClientes(body, q);
  };
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#mc-ok", back).addEventListener("click", guardar);
  back.addEventListener("keydown", (e) => { if (e.key === "Escape") cerrar(); if (e.key === "Enter") { e.preventDefault(); guardar(); } });
  setTimeout(() => $("#mc-monto", back).focus(), 30);
}

async function verHistorialCliente(id) {
  const c = (DATA.clientes || []).find((x) => x.id === id);
  if (!c) return;
  const pintar = async () => {
    const desde = await window.api.db.getHistorialPantallaDesde(c.id);
    const movs = filtrarMovsPantalla(c.movimientos || [], desde).slice().reverse();
    const suma = movs.reduce((s, m) => {
      if (m.tipo === "cargo") s.cargos += m.montoCents || 0;
      else if (m.tipo === "abono") s.abonos += m.montoCents || 0;
      return s;
    }, { cargos: 0, abonos: 0 });
    const neto = suma.cargos - suma.abonos;
    const filas = movs.map((m) => `<tr>
        <td class="muted">${new Date(m.fecha).toLocaleString("es-MX")}</td>
        <td>${m.tipo === "abono" ? "⬇ Abono" : m.tipo === "cancelacion" ? "✖ Cancelación" : "⬆ Cargo"}</td>
        <td>${escapeHtml(m.nota || "")}</td>
        <td class="num ${m.tipo === "cargo" ? "neg" : ""}">${m.tipo === "cargo" ? "+" : "-"} ${fmt(m.montoCents)}</td>
        <td class="num">${fmt(m.saldoCents)}</td>
      </tr>`).join("");
    const pie = movs.length ? `<tr class="mv-total-row"><td colspan="3"><b>Total de ${escapeHtml(c.nombre)}</b><div class="muted">${movs.length} movimiento${movs.length === 1 ? "" : "s"}${suma.abonos ? ` · cargos ${fmt(suma.cargos)} · abonos ${fmt(suma.abonos)}` : ""}${desde ? " · abonos viejos ocultos en pantalla" : ""}</div></td><td class="num ${neto >= 0 ? "neg" : ""}"><b>${neto >= 0 ? "+" : "-"} ${fmt(Math.abs(neto))}</b></td><td></td></tr>` : `<tr><td colspan="5" class="muted">Sin movimientos.</td></tr>`;
    back.querySelector(".modal").innerHTML = `
        <h3>Historial de crédito — ${escapeHtml(c.nombre)}</h3>
        <p class="sub">Saldo actual: <b>${fmt(c.saldoCents || 0)}</b>${desde ? ` · <span class="muted">Abonos anteriores al ${new Date(desde).toLocaleString("es-MX")} ocultos en pantalla</span>` : ""}</p>
        <div class="mv-table-wrap" style="max-height:340px;overflow:auto">
          <table class="mv-table"><thead><tr><th>Fecha</th><th>Tipo</th><th>Nota</th><th class="num">Monto</th><th class="num">Saldo</th></tr></thead>
          <tbody>${filas}${pie}</tbody></table>
        </div>
        ${vistaAbonos(movs, c.nombre)}
        <div class="modal__foot" style="flex-wrap:wrap;gap:8px">
          <button class="btn btn--sec" id="hist-limpiar">🧹 Limpiar historial en pantalla</button>
          <button class="btn btn--primary" data-cerrar="1">Cerrar</button>
        </div>`;
    const btn = $("#hist-limpiar", back);
    if (btn) btn.addEventListener("click", async () => {
      if (!confirm(`¿Limpiar en pantalla el historial de abonos de "${c.nombre}"?\n\nSolo se ocultan en esta PC. El saldo no cambia y los abonos siguen guardados en Supabase.`)) return;
      const r = await window.api.db.limpiarHistorialPantallaCliente(c.id);
      if (r && r.error) return alert(r.error);
      await pintar();
    });
  };
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `<div class="modal modal--ticket"></div>`;
  document.body.appendChild(back);
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) back.remove(); });
  await pintar();
}

/* Selector de cliente para el ticket activo (F2) */
async function abrirSelectorCliente() {
  const clientes = await cargarClientes();
  const back = document.createElement("div");
  back.className = "modal-back";
  const opciones = clientes.slice().sort((a, b) => a.nombre.localeCompare(b.nombre))
    .map((c) => `<button class="cliente-opt" data-cli="${escapeHtml(c.nombre)}">
        <span>👤 ${escapeHtml(c.nombre)}</span>
        ${(c.saldoCents || 0) > 0 ? `<small class="neg">Debe ${fmt(c.saldoCents)}</small>` : (c.creditoActivo ? `<small class="muted">Crédito</small>` : "")}
      </button>`).join("");
  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>Asignar cliente al ticket</h3>
      <input type="search" id="sc-search" class="mv-search" placeholder="Buscar cliente…" style="width:100%;margin-bottom:10px" />
      <div class="cliente-list" id="sc-list">
        <button class="cliente-opt" data-cli="${escapeHtml(CLIENTE_DEFAULT)}"><span>🧾 ${escapeHtml(CLIENTE_DEFAULT)}</span></button>
        ${opciones || ""}
      </div>
      <p class="qty-hint">¿No está en la lista? Créalo en Catálogos → Clientes.</p>
      <div class="modal__foot"><button class="btn" data-cerrar="1">Cancelar</button></div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  const elegir = (nombre) => {
    clienteActual = nombre;
    const activo = ticketActual();
    if (activo) activo.cliente = nombre;
    const cn = $("#cliente-actual"); if (cn) cn.textContent = nombre;
    cerrar();
  };
  $$("[data-cli]", back).forEach((b) => b.addEventListener("click", () => elegir(b.dataset.cli)));
  const s = $("#sc-search", back);
  s.addEventListener("input", () => {
    const q = s.value.trim().toLowerCase();
    $$(".cliente-opt", back).forEach((b) => {
      const match = b.dataset.cli.toLowerCase().includes(q);
      b.style.display = match ? "" : "none";
    });
  });
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  setTimeout(() => s.focus(), 30);
}

/* ---------------- Utilidad: modal de texto ---------------- */
function pedirTexto(opts, cb) {
  const o = Object.assign({ titulo: "Nota", label: "Texto", valor: "", placeholder: "", requerido: false, sub: "" }, opts);
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--qty">
      <h3>${escapeHtml(o.titulo)}</h3>
      ${o.sub ? `<p class="sub">${escapeHtml(o.sub)}</p>` : ""}
      <div class="qty-field"><label>${escapeHtml(o.label)}</label>
        <input type="text" id="pt-val" value="${attr(o.valor)}" placeholder="${attr(o.placeholder)}" /></div>
      <p class="qty-hint" id="pt-msg"></p>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn btn--primary" id="pt-ok">Aceptar</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const inp = $("#pt-val", back);
  const cerrar = () => back.remove();
  const ok = () => {
    const v = inp.value.trim();
    if (o.requerido && !v) { $("#pt-msg", back).innerHTML = '<span class="tk-warn">Este campo es obligatorio.</span>'; return; }
    cerrar(); cb(v);
  };
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) cerrar(); });
  $("#pt-ok", back).addEventListener("click", ok);
  back.addEventListener("keydown", (e) => { if (e.key === "Escape") cerrar(); if (e.key === "Enter") { e.preventDefault(); ok(); } });
  setTimeout(() => inp.focus(), 30);
}

function limpiarTicketTrasAccion() {
  const activo = ticketActual();
  if (activo) { activo.cart.length = 0; activo.cliente = CLIENTE_DEFAULT; activo.descuentoCents = 0; }
  if (tickets.length > 1 && activo) { cerrarTicket(activo.id); }
  else {
    clienteActual = CLIENTE_DEFAULT;
    const cn = $("#cliente-actual"); if (cn) cn.textContent = CLIENTE_DEFAULT;
    renderCart();
  }
}

/* ---------------- Órdenes en espera ---------------- */
function guardarEsperaFlujo() {
  if (!cart.length) { alert("El carrito está vacío."); return; }
  if (!tienenDB()) { alert("No disponible sin base de datos."); return; }
  pedirTexto({
    titulo: "Guardar orden en espera", label: "Nombre o nota para identificarla",
    valor: ticketActual() ? ticketActual().nombre : "", placeholder: "Ej. Cliente de la camioneta"
  }, async (nota) => {
    const orden = {
      nota: nota || "", cliente: clienteActual,
      items: JSON.parse(JSON.stringify(cart)),
      totalCents: Money.sumar(cart.map((it) => it.importeCents)),
      usuario: usuarioActual ? usuarioActual.nombre : null
    };
    const r = await window.api.db.guardarEspera(orden);
    if (r.error) return alert(r.error);
    limpiarTicketTrasAccion();
    alert("Orden guardada en espera. La recuperas en Operaciones → Órdenes en espera.");
  });
}

async function renderEspera(body) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>⏸️</span><p>Sin base de datos disponible.</p></div>'; return; }
  const lista = await window.api.db.getEsperas();
  lista.sort((a, b) => (a.fecha < b.fecha ? 1 : -1));
  const filas = lista.map((o) => `<tr>
      <td class="muted">${new Date(o.fecha).toLocaleString("es-MX")}</td>
      <td><b>${escapeHtml(o.nota || "(sin nombre)")}</b></td>
      <td>${escapeHtml(o.cliente || "")}</td>
      <td class="num">${(o.items || []).length}</td>
      <td class="num">${fmt(o.totalCents)}</td>
      <td class="acts">
        <button class="chip chip--in" data-rec="${o.id}">Recuperar</button>
        <button class="chip chip--out" data-del="${o.id}">🗑</button>
      </td></tr>`).join("") || `<tr><td colspan="6" class="muted">No hay órdenes en espera.</td></tr>`;
  body.innerHTML = `
    <div class="mv-card">
      <div class="mv-card__head"><h3>Órdenes en espera <small class="muted">(${lista.length})</small></h3></div>
      <p class="sub">Guarda una venta a medias y recupérala después. Se conservan aunque cierres sesión o se apague el equipo.</p>
      <div class="mv-table-wrap">
        <table class="mv-table">
          <thead><tr><th>Fecha</th><th>Nombre</th><th>Cliente</th><th class="num">Art.</th><th class="num">Total</th><th>Acciones</th></tr></thead>
          <tbody>${filas}</tbody>
        </table>
      </div>
    </div>`;
  $$("[data-rec]", body).forEach((b) => b.addEventListener("click", () => recuperarEspera(+b.dataset.rec, lista)));
  $$("[data-del]", body).forEach((b) => b.addEventListener("click", async () => {
    if (!confirm("¿Eliminar esta orden en espera?")) return;
    const r = await window.api.db.eliminarEspera(+b.dataset.del);
    if (r.error) return alert(r.error);
    renderEspera(body);
  }));
}

async function recuperarEspera(id, lista) {
  const o = (lista || []).find((x) => x.id === id);
  if (!o) return;
  const t = nuevoTicket(false);
  t.nombre = o.nota || t.nombre;
  t.cliente = o.cliente || CLIENTE_DEFAULT;
  t.cart = JSON.parse(JSON.stringify(o.items || []));
  await window.api.db.eliminarEspera(id);
  activarTicket(t.id);
  showVenta();
}

/* ---------------- Apartados ---------------- */
function apartarFlujo() {
  if (!cart.length) { alert("El carrito está vacío."); return; }
  if (!tienenDB()) { alert("No disponible sin base de datos."); return; }
  const total = subtotalCart() - descuentoTicket();
  const itemsSnap = JSON.parse(JSON.stringify(cart));
  const clientePrefill = (clienteActual && clienteActual !== CLIENTE_DEFAULT) ? clienteActual : "";

  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--apartar">
      <div class="hist2__head" style="margin-bottom:6px">
        <h3 style="margin:0">🏷️ Registrar apartado</h3>
        <button class="iconbtn" data-cerrar="1" title="Cerrar">✕</button>
      </div>
      <div class="cobro-total">Total a apartar <b>${fmt(total)}</b></div>
      <div class="ap-form">
        <div class="qty-field"><label>Nombre del cliente *</label><input type="text" id="ap-nombre" value="${attr(clientePrefill)}" placeholder="Nombre y apellido" /></div>
        <div class="qty-field"><label>Teléfono</label><input type="tel" id="ap-tel" placeholder="Ej. 668 123 4567" /></div>
        <div class="qty-field"><label>Fecha de recolección</label><input type="date" id="ap-fecha" /></div>
        <div class="qty-field"><label>Abono (lo que deja hoy)</label><input type="number" min="0" step="0.01" id="ap-abono" placeholder="0.00" /></div>
        <div class="qty-field"><label>Forma de pago del abono</label>
          <select id="ap-metodo">
            <option value="efectivo">💵 Efectivo</option>
            <option value="transferencia">🏦 Transferencia</option>
            <option value="tarjeta">💳 Tarjeta</option>
            <option value="vales">🎟️ Vales</option>
          </select>
        </div>
        <div class="ap-falta">Etiqueta faltante: <b id="ap-faltante">${fmt(total)}</b></div>
      </div>
      <p class="qty-hint" id="ap-msg">Solo el abono (o el pago completo) entra a la caja y al corte, etiquetado como <b>apartado</b>.</p>
      <div class="modal__foot ap-foot">
        <button class="btn" data-cerrar="1">Cancelar</button>
        <button class="btn" id="ap-guardar">🏷️ Guardar apartado</button>
        <button class="btn btn--primary" id="ap-liquidar">✅ Liquidar (pagar todo)</button>
      </div>
    </div>`;
  document.body.appendChild(back);
  const cerrar = () => back.remove();
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar !== undefined) cerrar(); });

  const abonoInp = $("#ap-abono", back);
  const faltEl = $("#ap-faltante", back);
  const leerAbono = () => Math.min(total, Math.max(0, Money.toCents(parseFloat((abonoInp.value || "").replace(",", ".")) || 0) || 0));
  const pintarFalta = () => { faltEl.textContent = fmt(Math.max(0, total - leerAbono())); };
  abonoInp.addEventListener("input", pintarFalta);

  async function registrar(liquidar) {
    const nombre = $("#ap-nombre", back).value.trim();
    if (!nombre) { $("#ap-msg", back).innerHTML = '<span class="tk-warn">Escribe el nombre del cliente.</span>'; return; }
    const abonoCents = liquidar ? total : leerAbono();
    const data = {
      nombre,
      telefono: $("#ap-tel", back).value.trim(),
      fechaRecoleccion: $("#ap-fecha", back).value || null,
      items: itemsSnap, totalCents: total,
      abonoCents, metodo: $("#ap-metodo", back).value,
      usuario: usuarioActual ? usuarioActual.nombre : null
    };
    const r = await window.api.db.crearApartado(data);
    if (r && r.error) { $("#ap-msg", back).innerHTML = `<span class="tk-warn">${escapeHtml(r.error)}</span>`; return; }
    cerrar();
    limpiarTicketTrasAccion();
    const ap = r.apartado;
    if (confirm(`Apartado #${ap.folio} registrado.\nAbono: ${fmt(ap.abonadoCents)} · Faltante: ${fmt(ap.faltanteCents)}\n\n¿Imprimir comprobante del apartado?`)) {
      imprimirComprobanteApartado(ap);
    }
  }
  $("#ap-guardar", back).addEventListener("click", () => registrar(false));
  $("#ap-liquidar", back).addEventListener("click", () => registrar(true));
  setTimeout(() => $("#ap-nombre", back).focus(), 30);
}

function imprimirComprobanteApartado(ap) {
  const L = [];
  L.push("COMPROBANTE DE APARTADO");
  L.push("Folio apartado: #" + ap.folio);
  L.push("Cliente: " + (ap.nombre || ""));
  if (ap.telefono) L.push("Tel: " + ap.telefono);
  if (ap.fechaRecoleccion) L.push("Recolección: " + fechaLegible(ap.fechaRecoleccion));
  L.push("--------------------------------");
  (ap.items || []).forEach((it) => { L.push(`${fmtCant(it.cant, it.unidad)} ${it.nombre}`); });
  L.push("--------------------------------");
  L.push("Total:    " + fmt(ap.totalCents));
  L.push("Abonado:  " + fmt(ap.abonadoCents));
  L.push("FALTANTE: " + fmt(ap.faltanteCents));
  imprimirListaFlujo("Apartado #" + ap.folio, L);
}

// Muestra YYYY-MM-DD como dd/mm/aaaa sin desfase por zona horaria.
function fechaLegible(s) {
  if (!s) return "";
  const p = String(s).slice(0, 10).split("-");
  return (p.length === 3) ? `${p[2]}/${p[1]}/${p[0]}` : s;
}

// Pide monto + forma de pago (para abonos/liquidación de apartados).
function pedirAbonoApartado(o, cb) {
  const b = document.createElement("div");
  b.className = "modal-back";
  b.innerHTML = `
    <div class="modal modal--qty">
      <div class="hist2__head" style="margin-bottom:6px"><h3 style="margin:0">${escapeHtml(o.titulo)}</h3>
        <button class="iconbtn" data-cerrar="1" title="Cerrar">✕</button></div>
      ${o.sub ? `<p class="sub">${o.sub}</p>` : ""}
      <div class="qty-field"><label>Monto</label><input type="number" min="0" step="0.01" id="ab-monto" value="${o.valor != null ? (o.valor / 100).toFixed(2) : ""}" placeholder="0.00" ${o.montoFijo ? "readonly" : ""} /></div>
      <div class="qty-field"><label>Forma de pago</label>
        <select id="ab-metodo">
          <option value="efectivo">💵 Efectivo</option>
          <option value="transferencia">🏦 Transferencia</option>
          <option value="tarjeta">💳 Tarjeta</option>
          <option value="vales">🎟️ Vales</option>
        </select>
      </div>
      <p class="qty-hint" id="ab-msg"></p>
      <div class="modal__foot">
        <button class="btn" data-cerrar="1">Cerrar</button>
        <button class="btn btn--primary" id="ab-ok">${escapeHtml(o.okLabel || "Registrar")}</button>
      </div>
    </div>`;
  document.body.appendChild(b);
  const cerrar = () => b.remove();
  b.addEventListener("click", (e) => { if (e.target === b || e.target.dataset.cerrar !== undefined) cerrar(); });
  const ok = async () => {
    const monto = Money.toCents(parseFloat(($("#ab-monto", b).value || "").replace(",", ".")) || 0) || 0;
    if (monto <= 0) { $("#ab-msg", b).innerHTML = '<span class="tk-warn">Escribe un monto mayor a cero.</span>'; return; }
    await cb(monto, $("#ab-metodo", b).value, cerrar, (m) => { $("#ab-msg", b).innerHTML = `<span class="tk-warn">${escapeHtml(m)}</span>`; });
  };
  $("#ab-ok", b).addEventListener("click", ok);
  const mi = $("#ab-monto", b);
  mi.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); ok(); } });
  setTimeout(() => mi.focus(), 30);
}

async function renderApartados(body, verEntregados) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>🏷️</span><p>Sin base de datos disponible.</p></div>'; return; }
  const todos = await window.api.db.getApartados();
  const lista = todos.filter((a) => verEntregados ? true : !a.entregado);
  lista.sort((a, b) => (a.fecha < b.fecha ? 1 : -1));
  const recargar = () => renderApartados(body, verEntregados);

  const estadoPill = (a) => a.entregado
    ? '<span class="pill pill--ok">Entregado</span>'
    : (a.faltanteCents <= 0 ? '<span class="pill pill--ok">Liquidado</span>' : '<span class="pill pill--warn">Pendiente</span>');

  const totPend = lista.filter((a) => !a.entregado && a.faltanteCents > 0).reduce((s, a) => s + a.faltanteCents, 0);

  const filas = lista.map((a) => `<tr class="${!a.entregado && a.faltanteCents > 0 ? "row-low" : ""}">
      <td>#${a.folio}</td>
      <td><b>${escapeHtml(a.nombre || "")}</b>${a.telefono ? `<br><small class="muted">📞 ${escapeHtml(a.telefono)}</small>` : ""}</td>
      <td>${a.fechaRecoleccion ? `📅 ${escapeHtml(fechaLegible(a.fechaRecoleccion))}` : '<span class="muted">—</span>'}</td>
      <td class="num">${fmt(a.totalCents)}</td>
      <td class="num">${fmt(a.abonadoCents)}</td>
      <td class="num"><b class="${a.faltanteCents > 0 ? "tk-warn" : ""}">${fmt(a.faltanteCents)}</b></td>
      <td>${estadoPill(a)}</td>
      <td class="acts">
        ${a.faltanteCents > 0 ? `<button class="chip chip--in" data-abonar="${a.id}">⬇ Abonar</button><button class="chip" data-liquidar="${a.id}">✅ Liquidar</button>` : ""}
        ${a.entregado ? `<button class="chip" data-rev="${a.id}">↩ Revertir</button>` : `<button class="chip" data-ent="${a.id}">📦 Entregado</button>`}
        <button class="chip" data-print="${a.id}">🧾</button>
        ${a.abonadoCents <= 0 ? `<button class="chip chip--danger" data-del="${a.id}">🗑</button>` : ""}
      </td></tr>`).join("") || `<tr><td colspan="8" class="muted">No hay apartados ${verEntregados ? "" : "pendientes"}.</td></tr>`;

  body.innerHTML = `
    <div class="mv-card">
      <div class="mv-card__head">
        <h3>Apartados <small class="muted">(${lista.length})</small></h3>
        <label class="cf-check"><input type="checkbox" id="ap-ver" ${verEntregados ? "checked" : ""}/> Mostrar entregados</label>
      </div>
      <p class="sub">Reserva de mercancía con abonos. Solo el dinero recibido entra al corte (etiquetado <b>apartado</b>). El faltante queda pendiente hasta abonar o liquidar.${totPend > 0 ? ` · <b>Por cobrar: ${fmt(totPend)}</b>` : ""}</p>
      <div class="mv-table-wrap">
        <table class="mv-table">
          <thead><tr><th>Folio</th><th>Cliente</th><th>Recolección</th><th class="num">Total</th><th class="num">Abonado</th><th class="num">Faltante</th><th>Estado</th><th>Acciones</th></tr></thead>
          <tbody>${filas}</tbody>
        </table>
      </div>
    </div>`;

  const getAp = (id) => lista.find((x) => x.id === id);

  $("#ap-ver", body).addEventListener("change", (e) => renderApartados(body, e.target.checked));

  $$("[data-abonar]", body).forEach((b) => b.addEventListener("click", () => {
    const ap = getAp(+b.dataset.abonar); if (!ap) return;
    pedirAbonoApartado({
      titulo: `Abonar · Apartado #${ap.folio}`,
      sub: `${escapeHtml(ap.nombre)} · Faltante: <b>${fmt(ap.faltanteCents)}</b>`,
      valor: ap.faltanteCents, okLabel: "Registrar abono"
    }, async (monto, metodo, cerrar2, err) => {
      const r = await window.api.db.abonarApartado(ap.id, monto, metodo, usuarioActual ? usuarioActual.nombre : null);
      if (r && r.error) return err(r.error);
      cerrar2(); recargar();
    });
  }));

  $$("[data-liquidar]", body).forEach((b) => b.addEventListener("click", () => {
    const ap = getAp(+b.dataset.liquidar); if (!ap) return;
    pedirAbonoApartado({
      titulo: `Liquidar · Apartado #${ap.folio}`,
      sub: `${escapeHtml(ap.nombre)} · Se cobra el faltante completo`,
      valor: ap.faltanteCents, montoFijo: true, okLabel: "Liquidar apartado"
    }, async (_monto, metodo, cerrar2, err) => {
      const r = await window.api.db.liquidarApartado(ap.id, metodo, usuarioActual ? usuarioActual.nombre : null);
      if (r && r.error) return err(r.error);
      cerrar2();
      const ap2 = r.apartado || ap;
      if (confirm("Apartado liquidado. ¿Imprimir comprobante?")) imprimirComprobanteApartado(ap2);
      recargar();
    });
  }));

  $$("[data-ent]", body).forEach((b) => b.addEventListener("click", async () => {
    const ap = getAp(+b.dataset.ent); if (!ap) return;
    if (ap.faltanteCents > 0 && !confirm(`Este apartado aún debe ${fmt(ap.faltanteCents)}. ¿Marcar como entregado de todos modos?`)) return;
    const r = await window.api.db.entregarApartado(ap.id, true);
    if (r && r.error) return alert(r.error);
    recargar();
  }));

  $$("[data-rev]", body).forEach((b) => b.addEventListener("click", async () => {
    const r = await window.api.db.entregarApartado(+b.dataset.rev, false);
    if (r && r.error) return alert(r.error);
    recargar();
  }));

  $$("[data-print]", body).forEach((b) => b.addEventListener("click", () => {
    const ap = getAp(+b.dataset.print); if (ap) imprimirComprobanteApartado(ap);
  }));

  $$("[data-del]", body).forEach((b) => b.addEventListener("click", async () => {
    const ap = getAp(+b.dataset.del); if (!ap) return;
    if (!confirm(`¿Eliminar el apartado #${ap.folio} de ${ap.nombre}? (no tiene pagos registrados)`)) return;
    const r = await window.api.db.eliminarApartado(ap.id);
    if (r && r.error) return alert(r.error);
    recargar();
  }));
}

/* ---------------- Paquetes (catálogo) ---------------- */
async function renderPaquetes(body) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>🎁</span><p>Sin base de datos disponible.</p></div>'; return; }
  const editable = puedeEditarInventario();
  const lista = (DATA.paquetes || []).slice();
  const filas = lista.map((p) => `<tr>
      <td style="font-size:18px">${p.emoji || "🎁"}</td>
      <td><b>${escapeHtml(p.nombre)}</b>${p.porConfirmar ? ' <span class="tag">por armar</span>' : ""}</td>
      <td class="num"><div class="price-edit"><span>$</span><input type="number" min="0" step="0.01" data-precio="${p.id}" value="${(p.precioCents / 100).toFixed(2)}" ${editable ? "" : "readonly"} title="${editable ? "Editar precio" : "Solo admin puede cambiar precios"}" /></div></td>
      <td class="num">${(p.componentes || []).length}</td>
      <td class="acts">
        ${editable
          ? `<button class="chip" data-edit="${p.id}">✎ Editar</button>
        <button class="chip chip--out" data-del="${p.id}">🗑</button>`
          : '<span class="muted">🔒 solo admin</span>'}
      </td></tr>`).join("") || `<tr><td colspan="5" class="muted">Sin paquetes.</td></tr>`;
  body.innerHTML = `
    <div class="mv-card">
      <div class="mv-card__head">
        <h3>Paquetes <small class="muted">(${lista.length})</small></h3>
        ${editable ? '<button class="btn btn--primary" id="pk-nuevo">＋ Nuevo paquete</button>' : ""}
      </div>
      <p class="sub">${editable ? "Edita el precio directo en la tabla (Enter para guardar). Usa Editar para cambiar el contenido." : "Consulta de paquetes. Precio y contenido solo los cambia un administrador."}</p>
      <div class="mv-table-wrap">
        <table class="mv-table">
          <thead><tr><th>Icono</th><th>Nombre</th><th class="num">Precio</th><th class="num">Componentes</th><th>Acciones</th></tr></thead>
          <tbody>${filas}</tbody>
        </table>
      </div>
    </div>`;
  const bNuevo = $("#pk-nuevo", body);
  if (bNuevo) bNuevo.addEventListener("click", () => editarPaquete(null, body));
  $$("[data-edit]", body).forEach((b) => b.addEventListener("click", () => editarPaquete(b.dataset.edit, body)));
  $$("[data-del]", body).forEach((b) => b.addEventListener("click", () => eliminarPaqueteFlujo(b.dataset.del, body)));
  $$("[data-precio]", body).forEach((inp) => {
    const guardar = async () => {
      if (!puedeEditarPrecios()) return;
      const p = DATA.paquetes.find((x) => x.id === inp.dataset.precio);
      const nuevo = Money.toCents(parseFloat(inp.value.replace(",", ".")) || 0) || 0;
      if (p && p.precioCents === nuevo) return;
      const r = await window.api.db.guardarPaquete({ id: inp.dataset.precio, precioCents: nuevo });
      if (r.error) return alert(r.error);
      DATA.paquetes = r.paquetes;
      renderProducts();
      inp.classList.add("saved"); setTimeout(() => inp.classList.remove("saved"), 700);
    };
    inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); inp.blur(); } });
    inp.addEventListener("blur", guardar);
  });
}

function editarPaquete(id, body) {
  const p = id ? DATA.paquetes.find((x) => x.id === id) : null;
  // Cada componente lleva su precio individual; si no lo tiene, se toma del catálogo.
  const comps = p ? (p.componentes || []).map((c) => ({
    nombre: c.nombre, cant: c.cant, unidad: c.unidad,
    precioCents: c.precioCents != null ? c.precioCents : precioComponente(c)
  })) : [];
  let busq = "";
  let liveNombre = p ? (p.nombre || "") : "";
  let liveEmoji = p ? (p.emoji || "🎁") : "🎁";
  let livePrecio = p ? ((p.precioCents || 0) / 100).toFixed(2) : "0.00";
  const back = document.createElement("div");
  back.className = "modal-back";
  const sumaComps = () => Money.sumar(comps.map((c) => Money.multiplicar(c.precioCents || 0, c.cant || 0)));
  const syncLive = () => {
    const n = $("#pk-nombre", back); if (n) liveNombre = n.value;
    const e = $("#pk-emoji", back); if (e) liveEmoji = e.value;
    const pr = $("#pk-precio", back); if (pr) livePrecio = pr.value;
  };
  const pintarResultados = () => {
    const box = $("#pk-results", back);
    if (!box) return;
    const q = busq.trim().toLowerCase();
    if (!q) { box.innerHTML = ""; return; }
    const resultados = DATA.productos.filter((x) => productoConInventario(x) && x.precioCents != null && x.nombre.toLowerCase().includes(q)).slice(0, 8);
    box.innerHTML = resultados.length
      ? resultados.map((x) => `<button type="button" class="pk-res" data-add="${x.id}">${escapeHtml(x.nombre)} <b>${fmt(x.precioCents)}/${x.unidad}</b></button>`).join("")
      : '<div class="pk-empty">Sin coincidencias.</div>';
    $$("[data-add]", box).forEach((b) => b.addEventListener("click", () => {
      const x = DATA.productos.find((y) => y.id === +b.dataset.add);
      if (!x) return;
      pedirCantidadComp(x, (cant) => {
        comps.push({ nombre: x.nombre, cant, unidad: x.unidad, precioCents: x.precioCents });
        busq = "";
        const s = $("#pk-search", back); if (s) s.value = "";
        syncLive(); render();
      });
    }));
  };
  const render = () => {
    syncLive();
    back.innerHTML = `
      <div class="modal modal--ticket">
        <h3>${p ? "Editar paquete" : "Nuevo paquete"}</h3>
        <div class="cf-2col">
          <div class="qty-field"><label>Icono</label><input type="text" id="pk-emoji" maxlength="4" value="${attr(liveEmoji)}" /></div>
          <div class="qty-field"><label>Precio del paquete</label><input type="number" min="0" step="0.01" id="pk-precio" value="${attr(livePrecio)}" /></div>
        </div>
        <div class="qty-field"><label>Nombre</label><input type="text" id="pk-nombre" value="${attr(liveNombre)}" placeholder="Ej. Paquete Familiar" /></div>

        <h4 style="margin:10px 0 6px">Contenido del paquete <small class="muted">(precio individual de cada uno)</small></h4>
        <div id="pk-comps">
          ${comps.length ? comps.map((c, i) => `
            <div class="combo-row">
              <input type="text" data-cnom="${i}" value="${attr(c.nombre)}" placeholder="Producto" style="flex:2" />
              <input type="number" min="0" step="0.001" data-ccant="${i}" value="${c.cant}" placeholder="Cant" style="width:64px" title="Cantidad" />
              <input type="text" data-cuni="${i}" value="${attr(c.unidad || "kg")}" placeholder="Unidad" style="width:60px" title="Unidad" />
              <input type="number" min="0" step="0.01" data-cprc="${i}" value="${c.precioCents != null ? (c.precioCents / 100).toFixed(2) : ""}" placeholder="$/u" style="width:74px" title="Precio individual por unidad" />
              <button class="combo-del" data-cdel="${i}">✕</button>
            </div>`).join("") : '<div class="pk-empty">Aún sin componentes. Búscalos abajo o agrégalos a mano.</div>'}
        </div>

        <div class="pk-add" style="margin-top:8px">
          <input type="text" id="pk-search" placeholder="Buscar producto para agregar…" value="${attr(busq)}" style="flex:2" />
          <button class="btn btn--sec" id="pk-addcomp">＋ A mano</button>
        </div>
        <div class="pk-results" id="pk-results"></div>

        <div class="combo-sum" style="margin-top:10px">
          <span>Suma de individuales <b>${fmt(sumaComps())}</b></span>
          <button class="btn btn--ghost" id="pk-usar-suma" type="button">Usar como precio</button>
        </div>
        <p class="qty-hint" id="pk-msg"></p>
        <div class="modal__foot">
          <button class="btn" data-cerrar="1">Cancelar</button>
          <button class="btn btn--primary" id="pk-ok">Guardar</button>
        </div>
      </div>`;
    bind();
    pintarResultados();
  };
  const cerrar = () => back.remove();
  const bind = () => {
    $$("[data-cnom]", back).forEach((el) => el.addEventListener("input", () => comps[+el.dataset.cnom].nombre = el.value));
    $$("[data-ccant]", back).forEach((el) => el.addEventListener("input", () => { comps[+el.dataset.ccant].cant = parseFloat(el.value.replace(",", ".")) || 0; actSuma(); }));
    $$("[data-cuni]", back).forEach((el) => el.addEventListener("input", () => comps[+el.dataset.cuni].unidad = el.value));
    $$("[data-cprc]", back).forEach((el) => el.addEventListener("input", () => { comps[+el.dataset.cprc].precioCents = el.value === "" ? null : Money.toCents(parseFloat(el.value.replace(",", ".")) || 0); actSuma(); }));
    $$("[data-cdel]", back).forEach((el) => el.addEventListener("click", () => { syncLive(); comps.splice(+el.dataset.cdel, 1); render(); }));
    $("#pk-addcomp", back).addEventListener("click", () => { syncLive(); comps.push({ nombre: "", cant: 1, unidad: "kg", precioCents: null }); render(); });
    // Búsqueda SIN reconstruir el modal (así no se pierde el cursor).
    $("#pk-search", back).addEventListener("input", (e) => { busq = e.target.value; pintarResultados(); });
    $("#pk-usar-suma", back).addEventListener("click", () => {
      const s = sumaComps();
      const inp = $("#pk-precio", back); if (inp) inp.value = (s / 100).toFixed(2);
    });
    $("#pk-ok", back).addEventListener("click", guardar);
    back.querySelectorAll("[data-cerrar]").forEach((b) => b.addEventListener("click", cerrar));
  };
  const actSuma = () => { const el = $(".combo-sum b", back); if (el) el.textContent = fmt(sumaComps()); };
  const guardar = async () => {
    const nombre = $("#pk-nombre", back).value.trim();
    if (!nombre) { $("#pk-msg", back).innerHTML = '<span class="tk-warn">Escribe un nombre.</span>'; return; }
    const pq = {
      nombre, emoji: $("#pk-emoji", back).value.trim() || "🎁",
      precioCents: Money.toCents(parseFloat($("#pk-precio", back).value.replace(",", ".")) || 0) || 0,
      componentes: comps.filter((c) => (c.nombre || "").trim()).map((c) => ({
        nombre: c.nombre.trim(), cant: c.cant || 0, unidad: c.unidad || "kg",
        precioCents: c.precioCents != null ? c.precioCents : undefined
      }))
    };
    if (p) pq.id = p.id;
    const r = await window.api.db.guardarPaquete(pq);
    if (r.error) { $("#pk-msg", back).innerHTML = `<span class="tk-warn">${escapeHtml(r.error)}</span>`; return; }
    DATA.paquetes = r.paquetes;
    cerrar();
    renderProducts();
    renderPaquetes(body);
  };
  document.body.appendChild(back);
  back.addEventListener("click", (e) => { if (e.target === back) cerrar(); });
  render();
  setTimeout(() => { const n = $("#pk-nombre", back); if (n) { n.focus(); n.select && n.select(); } }, 30);
}

async function eliminarPaqueteFlujo(id, body) {
  const p = DATA.paquetes.find((x) => x.id === id);
  if (!p) return;
  if (!confirm(`¿Eliminar el paquete "${p.nombre}"?`)) return;
  const r = await window.api.db.eliminarPaquete(id);
  if (r.error) return alert(r.error);
  DATA.paquetes = r.paquetes;
  renderProducts();
  renderPaquetes(body);
}

/* ---------------- Usuarios y movimientos (bitácora) ---------------- */
const MOV_TIPOS = {
  venta: { emoji: "🛒", label: "Ventas" },
  efectivo: { emoji: "💵", label: "Efectivo (ingresos/retiros)" },
  inventario: { emoji: "📦", label: "Inventario" },
  credito: { emoji: "🏦", label: "Crédito de clientes" },
  caja: { emoji: "🧾", label: "Caja (apertura/cierre)" }
};

async function renderBitacora(body, estado) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>🔐</span><p>Sin base de datos disponible.</p></div>'; return; }
  const st = Object.assign({ tipo: "", dia: hoyISO() }, estado || {});
  const movs = await window.api.db.getMovimientos({ tipo: st.tipo || undefined, dia: st.dia || undefined });
  movs.sort((a, b) => (a.fecha < b.fecha ? 1 : -1));

  const tipoOpc = `<option value="">Todos los tipos</option>` +
    Object.keys(MOV_TIPOS).map((k) => `<option value="${k}" ${st.tipo === k ? "selected" : ""}>${MOV_TIPOS[k].emoji} ${MOV_TIPOS[k].label}</option>`).join("");

  const filas = movs.map((m) => {
    const t = MOV_TIPOS[m.tipo] || { emoji: "•", label: m.tipo };
    return `<tr>
      <td class="muted">${new Date(m.fecha).toLocaleString("es-MX")}</td>
      <td>${t.emoji} ${escapeHtml(t.label)}</td>
      <td>${escapeHtml(m.usuario || "—")}</td>
      <td>${escapeHtml(m.detalle || "")}</td>
    </tr>`;
  }).join("") || `<tr><td colspan="4" class="muted">Sin movimientos para el filtro elegido.</td></tr>`;

  body.innerHTML = `
    <div class="mv-card">
      <div class="mv-card__head">
        <h3>Movimientos / Bitácora <small class="muted">(${movs.length})</small></h3>
        <div class="mv-head-actions">
          <select id="bit-tipo" class="mv-search">${tipoOpc}</select>
          <input type="date" id="bit-dia" class="mv-search" value="${st.dia}" max="${hoyISO()}" />
          <button class="btn btn--sec" id="bit-todos" title="Ver todo el historial">Todo</button>
          <button class="btn btn--sec" id="bit-imprimir">🖨️ Imprimir</button>
        </div>
      </div>
      <p class="sub">Registro de la actividad del sistema. Los usuarios se crean y administran desde la pantalla de inicio (crear, renombrar, contraseña, eliminar).</p>
      <div class="mv-table-wrap">
        <table class="mv-table">
          <thead><tr><th>Fecha</th><th>Tipo</th><th>Usuario</th><th>Detalle</th></tr></thead>
          <tbody>${filas}</tbody>
        </table>
      </div>
    </div>`;

  const cur = () => ({ tipo: $("#bit-tipo", body).value, dia: $("#bit-dia", body).value });
  $("#bit-tipo", body).addEventListener("change", () => renderBitacora(body, cur()));
  $("#bit-dia", body).addEventListener("change", () => renderBitacora(body, cur()));
  $("#bit-todos", body).addEventListener("click", () => renderBitacora(body, { tipo: $("#bit-tipo", body).value, dia: "" }));
  $("#bit-imprimir", body).addEventListener("click", () => {
    const cols = (CFG && CFG.impresora && CFG.impresora.anchoCols) || 48;
    const lineas = movs.map((m) => {
      const t = MOV_TIPOS[m.tipo] || { label: m.tipo };
      const hora = new Date(m.fecha).toLocaleString("es-MX");
      return `${hora}  [${t.label}] ${m.usuario || "-"}\n  ${m.detalle || ""}`;
    });
    imprimirListaFlujo("BITACORA " + (st.dia || "completa"), lineas.length ? lineas : ["(sin movimientos)"]);
  });
}

/* ---------------- Devoluciones ---------------- */
async function renderDevoluciones(body, fecha) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>↩️</span><p>Sin base de datos disponible.</p></div>'; return; }
  const dia = fecha || hoyISO();
  const detalle = await window.api.db.detalleDia(dia);

  const opciones = DATA.productos
    .filter((p) => productoConInventario(p) && p.precioCents != null)
    .map((p) => `<option value="${p.id}">${p.nombre} (${fmt(p.precioCents)}/${p.unidad})</option>`).join("");
  const metodosOpc = PAGOS.map((p) => `<option value="${p.id}">${p.label}</option>`).join("");

  // Lista de devoluciones del día (de todos los métodos)
  const devs = [];
  Object.keys(detalle.metodos).forEach((mid) =>
    detalle.metodos[mid].devoluciones.forEach((x) => devs.push({ ...x, metodo: mid })));
  devs.sort((a, b) => (a.hora < b.hora ? 1 : -1));

  body.innerHTML = `
    <div class="mv-grid2">
      <div class="mv-card">
        <div class="mv-card__head"><h3>Registrar devolución</h3></div>
        <p class="sub">El producto regresa al inventario y el reembolso se registra aparte en el corte (no es pérdida). Requiere caja abierta.</p>
        <div class="mv-field"><label>Producto</label><select id="dv-prod">${opciones}</select></div>
        <div class="mv-field"><label>Cantidad</label><input type="number" min="0" step="0.001" id="dv-cant" value="1" /></div>
        <div class="mv-field"><label>Importe a devolver</label><input type="number" min="0" step="0.01" id="dv-importe" value="0.00" /></div>
        <div class="mv-field"><label>Método de reembolso</label><select id="dv-metodo">${metodosOpc}</select></div>
        <div class="mv-field"><label>Folio de venta (opcional)</label><input type="number" min="0" id="dv-folio" placeholder="—" /></div>
        <div class="mv-field"><label>Motivo (opcional)</label><input type="text" id="dv-motivo" placeholder="Ej. producto en mal estado" /></div>
        <button class="btn btn--primary btn--block" id="dv-registrar">Registrar devolución</button>
      </div>

      <div class="mv-card">
        <div class="mv-card__head">
          <h3>Devoluciones del día</h3>
          <input type="date" id="dv-fecha" class="mv-search" value="${detalle.dia}" max="${hoyISO()}" />
        </div>
        <input type="search" id="dv-buscar" class="mv-search" placeholder="Buscar por folio o total…" autocomplete="off" style="margin:0 0 10px" />
        <div class="mv-table-wrap">
          <table class="mv-table">
            <thead><tr><th>Hora</th><th>Folio</th><th>Producto</th><th>Método</th><th class="num">Cant.</th><th class="num">Importe</th></tr></thead>
            <tbody id="dv-filas"></tbody>
          </table>
        </div>
      </div>
    </div>`;

  const filasDevBox = $("#dv-filas", body);
  const buscarDev = $("#dv-buscar", body);
  const pintarDevs = () => {
    const q = buscarDev ? buscarDev.value : "";
    const lista = devs.filter((x) => coincideFolioOTotal(
      q, [x.folio, x.ventaFolio], x.montoCents,
      [x.motivo].concat((x.items || []).map((it) => it.nombre))
    ));
    filasDevBox.innerHTML = lista.length ? lista.map((x) => {
      const nombres = (x.items || []).map((it) => it.nombre).filter(Boolean).join(", ") || "Devolución";
      const cantTxt = (x.items || []).map((it) => `${fmtCant(it.cant, it.unidad)} ${it.unidad || ""}`.trim()).join(", ");
      return `<tr>
       <td class="muted">${x.hora}</td>
       <td>#${x.folio}${x.ventaFolio ? ` <small class="muted">(venta #${x.ventaFolio})</small>` : ""}</td>
       <td>${escapeHtml(nombres)}${x.motivo ? ` — <i>${escapeHtml(x.motivo)}</i>` : ""}</td>
       <td>${pagoLabel(x.metodo)}</td>
       <td class="num">${escapeHtml(cantTxt)}</td>
       <td class="num neg">- ${fmt(x.montoCents)}</td>
     </tr>`;
    }).join("") : `<tr><td colspan="6" class="muted">${String(q).trim() ? "Sin resultados." : "Sin devoluciones en esta fecha."}</td></tr>`;
  };
  pintarDevs();
  if (buscarDev) buscarDev.addEventListener("input", pintarDevs);

  const prodSel = $("#dv-prod", body);
  const cantInp = $("#dv-cant", body);
  const impInp = $("#dv-importe", body);
  const recalcImporte = () => {
    const p = DATA.productos.find((x) => x.id === +prodSel.value);
    if (!p || p.precioCents == null) return;
    const cant = parseFloat(cantInp.value.replace(",", ".")) || 0;
    impInp.value = (Money.multiplicar(p.precioCents, cant) / 100).toFixed(2);
  };
  recalcImporte();
  prodSel.addEventListener("change", recalcImporte);
  cantInp.addEventListener("input", recalcImporte);
  $("#dv-fecha", body).addEventListener("change", (e) => renderDevoluciones(body, e.target.value));

  $("#dv-registrar", body).addEventListener("click", async () => {
    const p = DATA.productos.find((x) => x.id === +prodSel.value);
    if (!p) return alert("Selecciona un producto.");
    const cant = parseFloat(cantInp.value.replace(",", ".")) || 0;
    if (cant <= 0) return alert("La cantidad debe ser mayor a 0.");
    const importe = Money.toCents(parseFloat(impInp.value.replace(",", ".")) || 0) || 0;
    if (importe <= 0) return alert("El importe debe ser mayor a 0.");
    const folioTxt = $("#dv-folio", body).value.trim();
    const dev = {
      usuario: usuarioActual ? usuarioActual.nombre : null,
      pago: $("#dv-metodo", body).value,
      motivo: $("#dv-motivo", body).value.trim(),
      ventaFolio: folioTxt ? +folioTxt : null,
      items: [{ tipo: "producto", productoId: p.id, nombre: p.nombre, cant, unidad: p.unidad, precioCents: p.precioCents, importeCents: importe }],
      totalCents: importe
    };
    const r = await window.api.db.registrarDevolucion(dev);
    if (r.error) return alert(r.error);
    alert(`↩️ Devolución registrada (folio ${r.folio}).\n${fmtCant(cant, p.unidad)} ${p.unidad} de ${p.nombre} regresaron al inventario.`);
    renderDevoluciones(body, dia);
  });
}

/* ---------------- Configuración (negocio / impresora / ticket / respaldo) ---------------- */
/* ---------------- Facturación electrónica (CFDI 4.0) ---------------- */
function facturaEstadoBadge(f) {
  if (f.estado === "timbrado") return `<span class="pill pill--ok">✓ Timbrada${f.simulado ? " (sim)" : ""}</span>`;
  if (f.estado === "error") return `<span class="pill pill--warn" title="${attr(f.ultimoError || "")}">⚠ Error</span>`;
  return `<span class="pill pill--warn">⏳ Pendiente</span>`;
}

async function cargarListaFacturas(body) {
  const cont = $("#fx-lista", body);
  if (!cont) return;
  let facturas = [];
  try { facturas = await window.api.factura.listar(); } catch (e) { facturas = []; }
  if (!facturas.length) {
    cont.innerHTML = `<p class="sub">Aún no se ha generado ninguna factura.</p>`;
    return;
  }
  const filas = facturas.map((f) => {
    const uuidCorto = f.uuid ? f.uuid.slice(0, 8) + "…" : "—";
    const acciones = [];
    if (f.estado === "timbrado") {
      acciones.push(`<button class="chip" data-pdf="${f.id}">📄 PDF</button>`);
      acciones.push(`<button class="chip" data-correo="${f.id}"${f.enviadoCorreo ? ' title="Ya enviado"' : ""}>${f.enviadoCorreo ? "📧 ✓" : "📧 Correo"}</button>`);
      acciones.push(`<button class="chip" data-whats="${f.id}"${f.enviadoWhats ? ' title="Ya abierto"' : ""}>${f.enviadoWhats ? "🟢 ✓" : "🟢 WhatsApp"}</button>`);
    } else {
      acciones.push(`<button class="chip" data-timbrar="${f.id}">↻ Timbrar</button>`);
    }
    return `<tr>
      <td><b>${escapeHtml(f.serie)}${f.folioFactura}</b></td>
      <td class="muted">#${f.folioVenta}</td>
      <td>${escapeHtml(f.receptor.rfc)}<br/><small class="muted">${escapeHtml(f.receptor.nombre || "")}</small></td>
      <td class="num">${fmt(f.totalCents)}</td>
      <td>${facturaEstadoBadge(f)}</td>
      <td class="muted" title="${attr(f.uuid || "")}">${uuidCorto}</td>
      <td class="acts">${acciones.join(" ")}</td>
    </tr>`;
  }).join("");
  cont.innerHTML = `
    <div class="mv-table-wrap">
      <table class="mv-table">
        <thead><tr><th>Factura</th><th>Venta</th><th>Receptor</th><th class="num">Total</th><th>Estado</th><th>UUID</th><th>Acciones</th></tr></thead>
        <tbody>${filas}</tbody>
      </table>
    </div>`;

  const refrescar = () => cargarListaFacturas(body);
  $$("[data-pdf]", cont).forEach((b) => b.addEventListener("click", async () => {
    const r = await window.api.factura.verPdf(+b.dataset.pdf);
    if (r && r.error) alert(r.error);
  }));
  $$("[data-correo]", cont).forEach((b) => b.addEventListener("click", async () => {
    b.disabled = true; b.textContent = "Enviando…";
    const r = await window.api.factura.enviarCorreo(+b.dataset.correo);
    if (r && r.error) alert(r.error); else alert("Correo enviado.");
    refrescar();
  }));
  $$("[data-whats]", cont).forEach((b) => b.addEventListener("click", async () => {
    const r = await window.api.factura.enviarWhatsApp(+b.dataset.whats);
    if (r && r.error) alert(r.error);
    refrescar();
  }));
  $$("[data-timbrar]", cont).forEach((b) => b.addEventListener("click", async () => {
    b.disabled = true; b.textContent = "Timbrando…";
    const r = await window.api.factura.timbrar(+b.dataset.timbrar);
    if (r && r.error) alert(r.error);
    refrescar();
  }));
}

async function renderFacturacion(body) {
  if (!tienenDB() || !window.api.factura) { body.innerHTML = '<div class="empty-state"><span>🧮</span><p>Facturación no disponible.</p></div>'; return; }
  try { CFG = await window.api.db.getConfig(); } catch (e) {}
  const fa = (CFG && CFG.factura) || {};
  const clientesFact = (DATA.clientes || []).filter((c) => c.rfc);
  const cliOpc = `<option value="">— Autocompletar desde cliente —</option>` +
    clientesFact.map((c) => `<option value="${c.id}">${escapeHtml(c.nombre)} · ${escapeHtml(c.rfc)}</option>`).join("");

  const avisoModo = fa.modo === "produccion"
    ? `<span class="tk-ok">● Producción (timbra ante el SAT)</span>`
    : `<span class="tk-warn">● Simulación (facturas de prueba, no válidas ante el SAT). Cámbialo en Configuración → Facturación.</span>`;
  const avisoDatos = (!fa.activa)
    ? `<p class="sub"><span class="tk-warn">El módulo de facturación está desactivado.</span> Actívalo en Configuración → Facturación.</p>` : "";

  body.innerHTML = `
    <div class="mv-grid2">
      <div class="mv-card">
        <div class="mv-card__head"><h3>Nueva factura (individual)</h3></div>
        <p class="sub">${avisoModo}</p>
        ${avisoDatos}
        <div class="cf-2col">
          <div class="mv-field"><label>Folio de la venta</label><input id="fx-folio" type="number" min="1" placeholder="Ej. 1024" /></div>
          <div class="mv-field" style="align-self:end"><button class="btn btn--sec" id="fx-buscar">🔎 Buscar venta</button></div>
        </div>
        <div id="fx-venta-info" class="bk-estado"></div>
        <div id="fx-form" style="display:none">
          <h4 style="margin-top:12px">Datos del receptor</h4>
          <div class="mv-field"><label>Autocompletar</label><select id="fx-cliente">${cliOpc}</select></div>
          <div class="cf-2col">
            <div class="mv-field"><label>RFC</label><input id="fx-rfc" placeholder="XAXX010101000" /></div>
            <div class="mv-field"><label>Código postal</label><input id="fx-cp" placeholder="31000" /></div>
          </div>
          <div class="mv-field"><label>Razón social / Nombre</label><input id="fx-nombre" placeholder="Nombre fiscal del cliente" /></div>
          <div class="mv-field"><label>Régimen fiscal</label><select id="fx-regimen"><option value="">— Selecciona —</option>${optsFrom(REGIMENES_SAT, "")}</select></div>
          <div class="mv-field"><label>Uso de CFDI</label><select id="fx-uso">${optsFrom(USOS_CFDI, "G03")}</select></div>
          <div class="cf-2col">
            <div class="mv-field"><label>Correo (para enviar)</label><input id="fx-email" type="email" placeholder="cliente@correo.com" /></div>
            <div class="mv-field"><label>Teléfono (WhatsApp)</label><input id="fx-tel" placeholder="10 dígitos" /></div>
          </div>
          <p class="qty-hint" id="fx-msg"></p>
          <div class="mv-actions" style="margin-top:8px">
            <button class="btn btn--primary" id="fx-timbrar">🧾 Generar y timbrar</button>
          </div>
        </div>
      </div>
      <div class="mv-card mv-card--muted">
        <div class="mv-card__head"><h3>Cómo funciona</h3></div>
        <p class="sub">1. Escribe el <b>folio</b> de la venta y da <b>Buscar</b>. 2. Captura (o autocompleta) los <b>datos fiscales</b> del cliente. 3. <b>Genera y timbra</b>: la factura se guarda y, si hay internet, se timbra con el PAC.</p>
        <p class="sub">Luego puedes ver el <b>PDF</b>, enviarla por <b>correo</b> (adjunta XML+PDF) o por <b>WhatsApp</b> (abre el chat con el mensaje listo; el cajero solo pica Enviar).</p>
        <p class="sub">Si no hay internet, la factura queda <b>pendiente</b> y se timbra sola cuando vuelve la conexión.</p>
      </div>
    </div>

    <div class="mv-card" style="margin-top:16px">
      <div class="mv-card__head">
        <h3>Facturas emitidas</h3>
        <button class="btn btn--sec" id="fx-refrescar">↻ Actualizar</button>
      </div>
      <div id="fx-lista"></div>
    </div>`;

  let ventaOK = false;
  const msg = (html) => { $("#fx-msg", body).innerHTML = html; };

  $("#fx-buscar", body).addEventListener("click", async () => {
    const folio = parseInt($("#fx-folio", body).value, 10);
    const info = $("#fx-venta-info", body);
    if (!folio) { info.innerHTML = '<span class="tk-warn">Escribe el folio de la venta.</span>'; return; }
    const r = await window.api.factura.previewVenta(folio);
    if (r && r.error) { info.innerHTML = `<span class="tk-warn">${escapeHtml(r.error)}</span>`; $("#fx-form", body).style.display = "none"; ventaOK = false; return; }
    const lineas = (r.conceptos || []).map((c) =>
      `<tr><td>${escapeHtml(c.descripcion)}</td><td class="num">${fmtCant(c.cantidad, c.unidad)} ${escapeHtml(c.unidad)}</td><td class="num">${fmt(c.totalLineaCents)}</td></tr>`).join("");
    info.innerHTML = `
      <table class="mv-table" style="margin:6px 0">
        <thead><tr><th>Concepto</th><th class="num">Cant.</th><th class="num">Importe</th></tr></thead>
        <tbody>${lineas}</tbody>
        <tfoot>
          <tr><td colspan="2" class="num">Subtotal</td><td class="num">${fmt(r.subtotalCents)}</td></tr>
          <tr><td colspan="2" class="num">IVA</td><td class="num">${fmt(r.ivaCents)}</td></tr>
          <tr><td colspan="2" class="num"><b>Total</b></td><td class="num"><b>${fmt(r.totalCents)}</b></td></tr>
        </tfoot>
      </table>`;
    $("#fx-form", body).style.display = "";
    ventaOK = true;
  });

  $("#fx-cliente", body).addEventListener("change", () => {
    const id = +$("#fx-cliente", body).value;
    const c = clientesFact.find((x) => x.id === id);
    if (!c) return;
    $("#fx-rfc", body).value = c.rfc || "";
    $("#fx-nombre", body).value = c.nombre || "";
    $("#fx-cp", body).value = c.codigoPostal || "";
    $("#fx-email", body).value = c.email || "";
    $("#fx-tel", body).value = c.telefono || "";
    if (c.regimenFiscal) $("#fx-regimen", body).value = c.regimenFiscal;
    if (c.usoCfdi) $("#fx-uso", body).value = c.usoCfdi;
  });

  $("#fx-timbrar", body).addEventListener("click", async () => {
    if (!ventaOK) { msg('<span class="tk-warn">Busca primero una venta válida.</span>'); return; }
    const folio = parseInt($("#fx-folio", body).value, 10);
    const receptor = {
      rfc: $("#fx-rfc", body).value.trim().toUpperCase(),
      nombre: $("#fx-nombre", body).value.trim(),
      regimenFiscal: $("#fx-regimen", body).value,
      usoCfdi: $("#fx-uso", body).value,
      codigoPostal: $("#fx-cp", body).value.trim(),
      email: $("#fx-email", body).value.trim(),
      telefono: $("#fx-tel", body).value.trim()
    };
    if (!receptor.rfc) { msg('<span class="tk-warn">Captura el RFC del receptor.</span>'); return; }
    if (!receptor.codigoPostal) { msg('<span class="tk-warn">Captura el código postal del receptor.</span>'); return; }
    if (!receptor.regimenFiscal) { msg('<span class="tk-warn">Selecciona el régimen fiscal del receptor.</span>'); return; }
    const btn = $("#fx-timbrar", body); btn.disabled = true; btn.textContent = "Procesando…";
    const r = await window.api.factura.crear({ folioVenta: folio, receptor, usuario: usuarioActual ? usuarioActual.nombre : null });
    btn.disabled = false; btn.textContent = "🧾 Generar y timbrar";
    if (r && r.error) { msg(`<span class="tk-warn">${escapeHtml(r.error)}</span>`); return; }
    const t = r.timbrado || {};
    if (t.error) msg(`<span class="tk-warn">Factura creada, pero el timbrado falló: ${escapeHtml(t.error)}. Quedó pendiente y se reintentará.</span>`);
    else msg('<span class="tk-ok">✓ Factura generada y timbrada.</span>');
    $("#fx-folio", body).value = ""; $("#fx-venta-info", body).innerHTML = ""; $("#fx-form", body).style.display = "none"; ventaOK = false;
    await cargarListaFacturas(body);
  });

  $("#fx-refrescar", body).addEventListener("click", () => cargarListaFacturas(body));
  await cargarListaFacturas(body);
}

async function renderConfig(body) {
  if (!tienenDB()) { body.innerHTML = '<div class="empty-state"><span>⚙️</span><p>Sin base de datos disponible.</p></div>'; return; }
  CFG = await window.api.db.getConfig();
  const n = CFG.negocio || {};
  const i = CFG.impresora || {};
  const t = CFG.ticket || {};
  const rb = CFG.respaldo || {};
  const sb = CFG.supabase || {};
  const ac = CFG.actualizaciones || {};
  const ba = CFG.bascula || {};
  const bc = ba.codigoBarras || {};
  const fa = CFG.factura || {};
  const fws = fa.ws || {};
  const fco = fa.correo || {};
  const fwa = fa.whatsapp || {};
  const pm = CFG.permisos || {};
  const sel = (v, opt) => (v === opt ? "selected" : "");
  const ck = (v) => (v ? "checked" : "");
  const chk = (id, label, val) => `<label class="cf-check"><input type="checkbox" id="${id}" ${ck(val)}/> ${label}</label>`;

  body.innerHTML = `
    <div class="mv-grid2">
      <div class="mv-card">
        <div class="mv-card__head"><h3>Datos del negocio (encabezado del ticket)</h3></div>
        <div class="mv-field"><label>Nombre</label><input id="cf-nombre" value="${attr(n.nombre)}" /></div>
        <div class="mv-field"><label>Sucursal (opcional)</label><input id="cf-sucursal" value="${attr(n.sucursal)}" /></div>
        <div class="mv-field"><label>Dirección</label><input id="cf-direccion" value="${attr(n.direccion)}" /></div>
        <div class="mv-field"><label>Teléfono</label><input id="cf-telefono" value="${attr(n.telefono)}" /></div>
        <div class="mv-field"><label>RFC (para facturar)</label><input id="cf-rfc" value="${attr(n.rfc)}" placeholder="Ej. XAXX010101000" /></div>
        <div class="cf-2col">
          <div class="mv-field"><label>Razón social</label><input id="cf-razon" value="${attr(n.razonSocial)}" placeholder="Nombre fiscal del negocio" /></div>
          <div class="mv-field"><label>Código postal fiscal</label><input id="cf-cp" value="${attr(n.codigoPostal)}" placeholder="Ej. 31000" /></div>
        </div>
        <div class="mv-field"><label>Régimen fiscal</label><select id="cf-regimen"><option value="">— Selecciona —</option>${optsFrom(REGIMENES_SAT, n.regimenFiscal)}</select></div>
        <div class="mv-field"><label>Pie de ticket</label><input id="cf-pie" value="${attr(n.pie)}" /></div>
        <div class="mv-field"><label>Pie secundario (opcional)</label><input id="cf-pie2" value="${attr(n.pie2)}" /></div>
        <div class="mv-field"><label>Nombre de esta terminal / caja</label><input id="cf-terminal" value="${attr(CFG.terminal || "Caja Principal")}" placeholder="Caja Principal" /></div>
      </div>

      <div class="mv-card">
        <div class="mv-card__head"><h3>Impresora de tickets y cajón</h3></div>
        <div class="mv-field">
          <label>Conexión</label>
          <select id="cf-modo">
            <option value="off" ${sel(i.modo, "off")}>Desactivada (solo vista previa)</option>
            <option value="red" ${sel(i.modo, "red")}>Por red (Ethernet / Wi-Fi)</option>
            <option value="windows" ${sel(i.modo, "windows")}>Impresora USB / Windows (por nombre) — recomendado</option>
          </select>
        </div>
        <div class="mv-field cf-red"><label>IP de la impresora</label><input id="cf-ip" value="${attr(i.ip)}" placeholder="192.168.1.100" /></div>
        <div class="mv-field cf-red"><label>Puerto</label><input id="cf-puerto" type="number" value="${attr(i.puerto || 9100)}" /></div>
        <div class="mv-field cf-win"><label>Impresora de Windows</label>
          <select id="cf-ruta-sel"><option value="">— Elige una impresora instalada —</option></select>
          <input id="cf-ruta" value="${attr(i.rutaWindows)}" placeholder="HP DeskJet 2300 series" style="margin-top:6px" />
          <small class="muted">Elige el <b>nombre exacto</b> de Windows (no copies el ejemplo de térmica). Para compartida en red: \\\\PC\\Nombre.</small>
        </div>
        <div class="mv-field cf-win"><label>Tipo de envío (Windows)</label>
          <select id="cf-envio">
            <option value="auto" ${sel(i.envioWindows || "auto", "auto")}>Automático (HP DeskJet / oficina = texto; térmica = RAW)</option>
            <option value="texto" ${sel(i.envioWindows, "texto")}>Texto / driver Windows (HP DeskJet, láser, PDF)</option>
            <option value="raw" ${sel(i.envioWindows, "raw")}>RAW ESC/POS (solo térmica de tickets)</option>
          </select>
        </div>
        <div class="mv-field"><label>Ancho del papel</label>
          <select id="cf-ancho">
            <option value="48" ${sel(String(i.anchoCols), "48")}>80 mm / hoja carta angosta (48 columnas)</option>
            <option value="32" ${sel(String(i.anchoCols), "32")}>58 mm (32 columnas)</option>
          </select>
        </div>
        <h4>Cajón de dinero</h4>
        ${chk("cf-cajon", "Abrir cajón automáticamente al cobrar en efectivo/dólares (y al hacer corte)", i.abrirCajonEfectivo)}
        <div class="mv-field"><label>Pulso del cajón</label>
          <select id="cf-pulso">
            <option value="0" ${sel(String(i.pulsoCajon || 0), "0")}>Pin estándar (2)</option>
            <option value="1" ${sel(String(i.pulsoCajon || 0), "1")}>Pin alterno (5)</option>
          </select>
          <small class="muted">Si el cajón no abre, prueba el otro pin.</small>
        </div>
        <div class="mv-actions" style="margin-top:8px">
          <button class="btn btn--sec" id="cf-abrir-cajon">Abrir cajón (prueba)</button>
        </div>
        <h4 style="margin-top:12px">Impresión</h4>
        <p class="sub">Al cobrar, el ticket <b>siempre</b> pide clic en Imprimir (todas las formas de pago). El cajón se abre solo si hay efectivo/dólares.</p>
        ${chk("cf-logo", "Imprimir logo del negocio en el ticket", i.imprimirLogo !== false)}
        <div class="mv-actions" style="margin-top:8px">
          <button class="btn btn--sec" id="cf-probar">🖨️ Probar impresión</button>
        </div>
        <p class="sub" id="cf-estado"></p>
      </div>
    </div>

    <div class="mv-grid2" style="margin-top:16px">
      <div class="mv-card">
        <div class="mv-card__head"><h3>Estructura del ticket</h3></div>
        <p class="sub">Elige qué campos aparecen y sus textos. Usa "Ver ejemplo" para previsualizar.</p>
        <h4>Encabezado</h4>
        ${chk("tk-logo", "Mostrar logo", t.mostrarLogo)}
        ${chk("tk-nombre", "Mostrar nombre del negocio", t.mostrarNombre)}
        ${chk("tk-sucursal", "Mostrar sucursal", t.mostrarSucursal)}
        ${chk("tk-direccion", "Mostrar dirección", t.mostrarDireccion)}
        ${chk("tk-telefono", "Mostrar teléfono", t.mostrarTelefono)}
        ${chk("tk-rfc", "Mostrar RFC", t.mostrarRFC)}
        <div class="mv-field"><label>Líneas extra en el encabezado (una por renglón)</label>
          <textarea id="tk-enc" rows="2" placeholder="Ej. Horario: 8am - 8pm">${escapeHtml((t.lineasEncabezado || []).join("\n"))}</textarea></div>
        <h4>Datos de la venta</h4>
        ${chk("tk-folio", "Mostrar folio", t.mostrarFolio)}
        ${chk("tk-fecha", "Mostrar fecha y hora", t.mostrarFecha)}
        ${chk("tk-cajero", "Mostrar quién atiende", t.mostrarCajero)}
        ${chk("tk-cliente", "Mostrar cliente", t.mostrarCliente)}
        <div class="cf-2col">
          <div class="mv-field"><label>Etiqueta de "atiende"</label><input id="tk-etq-cajero" value="${attr(t.etiquetaCajero || "Atiende")}" /></div>
          <div class="mv-field"><label>Etiqueta de "cliente"</label><input id="tk-etq-cliente" value="${attr(t.etiquetaCliente || "Cliente")}" /></div>
        </div>
        <h4>Detalle y pago</h4>
        ${chk("tk-preciou", "Mostrar precio unitario por renglón", t.mostrarPrecioUnitario)}
        ${chk("tk-pago", "Mostrar forma de pago", t.mostrarFormaPago)}
        <div class="mv-field"><label>Líneas extra al final (una por renglón)</label>
          <textarea id="tk-pie" rows="2" placeholder="Ej. Cambios con ticket dentro de 24h">${escapeHtml((t.lineasPie || []).join("\n"))}</textarea></div>
        <div class="mv-actions" style="margin-top:10px">
          <button class="btn btn--sec" id="cf-ticket-preview">👁️ Ver ejemplo de ticket</button>
        </div>
      </div>

      <div class="mv-card">
        <div class="mv-card__head"><h3>Respaldo en la nube (Cloudflare)</h3></div>
        <p class="sub">Espejo en tiempo real de ventas, inventario y cortes. Si no hay internet, se reintenta solo; los datos nunca se pierden porque también se guardan en esta PC.</p>
        ${chk("bk-activo", "Activar respaldo automático en la nube", rb.activo)}
        <div class="mv-field"><label>Dirección del servicio (endpoint del Worker)</label><input id="bk-endpoint" value="${attr(rb.endpoint)}" placeholder="https://pos-respaldo.tucuenta.workers.dev" /></div>
        <div class="mv-field"><label>Token secreto</label><input id="bk-token" type="password" value="${attr(rb.token)}" placeholder="clave privada del Worker" /></div>
        <div class="cf-2col">
          <div class="mv-field"><label>Intervalo (segundos)</label><input id="bk-intervalo" type="number" min="15" value="${attr(rb.intervaloSeg || 60)}" /></div>
          <label class="cf-check" style="align-self:end"><input type="checkbox" id="bk-comprimir" ${ck(rb.comprimir !== false)}/> Comprimir (gzip)</label>
        </div>
        <div class="mv-actions" style="margin-top:10px">
          <button class="btn btn--primary" id="bk-vincular">🔗 Vincular</button>
          <button class="btn btn--ghost" id="bk-desvincular">Desvincular</button>
        </div>
        <div class="mv-actions" style="margin-top:8px">
          <button class="btn btn--sec" id="bk-probar">🔌 Probar conexión</button>
          <button class="btn btn--sec" id="bk-sync">☁️ Respaldar ahora</button>
        </div>
        <div class="bk-estado" id="bk-estado"></div>
      </div>

      <div class="mv-card">
        <div class="mv-card__head"><h3>Base de datos en la nube (Supabase)</h3></div>
        <p class="sub">Sube <b>desglosado</b> a PostgreSQL. El POS sigue offline. <b>Clientes y créditos se conservan siempre</b>. El historial de <b>ventas</b> (y cortes/cajas) en la nube se mantiene solo en una <b>ventana móvil de los últimos 2 años</b>: conforme pasan los meses, lo más viejo se limpia solo al sincronizar.</p>
        <ol class="sub" style="margin:8px 0 10px;padding-left:18px;line-height:1.45">
          <li>Crea un proyecto en <b>supabase.com</b>.</li>
          <li>En el SQL Editor pega y ejecuta el schema y también <code>Mayoreo-Supabase-limpieza-2anos.sql</code>.</li>
          <li>En <b>Settings → API</b> copia la <b>Project URL</b> y la clave <b>service_role</b> (secreta).</li>
          <li>Pégalas aquí, guarda, prueba y sincroniza.</li>
        </ol>
        ${chk("sb-activo", "Activar sincronización con Supabase", sb.activo)}
        <div class="mv-field"><label>Project URL</label><input id="sb-url" value="${attr(sb.url)}" placeholder="https://xxxx.supabase.co" /></div>
        <div class="mv-field"><label>API key (service_role)</label><input id="sb-key" type="password" value="${attr(sb.key)}" placeholder="eyJhbGciOi…" autocomplete="off" /></div>
        <p class="qty-hint">⬆️ <b>Subir es inmediato y casi no gasta cuota:</b> cada venta/abono/corte sube al instante (así siempre hay respaldo en la nube). ⬇️ <b>Bajar</b> los cambios de la otra PC es lo que consume datos, por eso se hace <b>cada cierto tiempo</b> (juntando todo) para no agotar la cuota gratis. El botón <b>“Sincronizar todo ahora”</b> reenvía TODO; <b>“Traer cambios ahora”</b> baja al instante cuando lo necesites.</p>
        <div class="cf-2col">
          <div class="mv-field"><label>Traer cambios de la otra PC cada (minutos)</label><input id="sb-bajarcada" type="number" min="1" max="1440" value="${attr(sb.bajarCadaMin != null ? sb.bajarCadaMin : 120)}" /></div>
          <div class="mv-field"><label>Años de historial de ventas en la nube (ventana móvil)</label><input id="sb-retener" type="number" min="1" max="10" value="${attr(sb.retenerAnos != null ? sb.retenerAnos : 2)}" /></div>
        </div>
        <div class="mv-actions" style="margin-top:10px">
          <button class="btn btn--ghost" id="sb-schema">📄 Copiar schema.sql al Escritorio</button>
        </div>
        <div class="mv-actions" style="margin-top:8px">
          <button class="btn btn--sec" id="sb-probar">🔌 Probar conexión</button>
          <button class="btn btn--sec" id="sb-bajar">⬇️ Traer cambios ahora</button>
          <button class="btn btn--primary" id="sb-sync">☁️ Sincronizar todo ahora</button>
        </div>
        <div class="bk-estado" id="sb-estado"></div>
      </div>
    </div>

    <div class="mv-grid2" style="margin-top:16px">
      <div class="mv-card">
        <div class="mv-card__head"><h3>🔄 Actualizaciones del sistema</h3></div>
        <p class="sub">Recibe correcciones enviadas desde la PC de <b>sistemas</b> por un canal de GitHub. <b>No usa Supabase</b> ni toca tus datos: solo actualiza el <b>programa</b>. Cada PC tiene su propio canal (oficina / carnicería) y solo descarga lo de su canal.</p>
        ${chk("ac-activo", "Revisar actualizaciones automáticamente", ac.activo !== false)}
        <div class="cf-2col">
          <div class="mv-field"><label>Usuario GitHub (owner)</label><input id="ac-owner" value="${attr(ac.owner)}" placeholder="mi-usuario-github" /></div>
          <div class="mv-field"><label>Repositorio</label><input id="ac-repo" value="${attr(ac.repo)}" placeholder="mayoreo-updates" /></div>
        </div>
        <div class="cf-2col">
          <div class="mv-field"><label>Rama</label><input id="ac-rama" value="${attr(ac.rama || "main")}" placeholder="main" /></div>
          <div class="mv-field"><label>Canal de ESTA PC</label>
            <select id="ac-canal">
              <option value="oficina" ${sel(ac.canal || "oficina", "oficina")}>Oficina</option>
              <option value="carniceria" ${sel(ac.canal || "oficina", "carniceria")}>Carnicería</option>
            </select>
          </div>
        </div>
        <div class="mv-actions" style="margin-top:10px">
          <button class="btn btn--sec" id="ac-buscar">🔎 Buscar actualización</button>
          <button class="btn btn--primary" id="ac-instalar" disabled title="Se habilita cuando sistemas publique una actualización para esta PC">⬇️ Actualizar sistema</button>
        </div>
        <div class="bk-estado" id="ac-estado"></div>
      </div>
      <div class="mv-card mv-card--muted">
        <div class="mv-card__head"><h3>Cómo funciona</h3></div>
        <p class="sub">Versión instalada: <b id="ac-version-local">—</b></p>
        <p class="sub">Cuando sistemas publique una actualización para <b>esta PC</b>, aquí se avisará y se habilitará el botón <b>“Actualizar sistema”</b>. El encargado da clic, <b>confirma</b>, y el programa se respalda, instala y reinicia solo.</p>
        <p class="sub">El botón permanece <b>deshabilitado</b> mientras no haya nada nuevo que instalar.</p>
      </div>
    </div>

    <div class="mv-grid2" style="margin-top:16px">
      <div class="mv-card">
        <div class="mv-card__head"><h3>Respaldo local (archivo)</h3></div>
        <p class="sub">Guarda una copia completa (productos, ventas, inventario, cortes, clientes y configuración) en un archivo de esta PC o una USB. Úsalo como respaldo manual o para pasar los datos a otra terminal.</p>
        <div class="mv-actions" style="margin-top:8px">
          <button class="btn btn--sec" id="cf-exportar">💾 Exportar respaldo…</button>
          <button class="btn btn--ghost" id="cf-importar">📂 Importar respaldo…</button>
          <button class="btn btn--ghost" id="cf-eleventa">🗄️ Importar desde ELEVENTA…</button>
        </div>
        <div class="bk-estado" id="cf-local-estado"></div>
      </div>
      <div class="mv-card mv-card--muted">
        <div class="mv-card__head"><h3>⚠️ Importar reemplaza todo</h3></div>
        <p class="sub">Al importar un respaldo se sustituye <b>toda</b> la información actual de esta terminal por la del archivo. Se recomienda exportar un respaldo antes de importar.</p>
      </div>
    </div>

    <div class="mv-grid2" style="margin-top:16px">
      <div class="mv-card">
        <div class="mv-card__head"><h3>⚖️ Báscula TORREY W-LABEL</h3></div>
        <p class="sub">Trae automáticamente las ventas pesadas (folios, productos, pesos y precios) para armar el ticket en el POS.</p>
        ${chk("ba-activa", "Activar lectura automática de la báscula", ba.activa)}
        <div class="mv-field"><label>Modo de conexión</label>
          <select id="ba-modo">
            <option value="directo" ${sel(ba.modoDirecto ? "directo" : "scalelink", "directo")}>Directo por red (recomendado, sin Scale Link)</option>
            <option value="scalelink" ${sel(ba.modoDirecto ? "directo" : "scalelink", "scalelink")}>Vía Scale Link (base Access)</option>
          </select>
        </div>
        <div id="ba-directo-box">
          <div class="cf-2col">
            <div class="mv-field"><label>IP de la báscula #1</label><input id="ba-ip" value="${attr(ba.ip || "192.168.100.28")}" placeholder="192.168.100.28" /></div>
            <div class="mv-field"><label>Puerto</label><input id="ba-puerto" type="number" min="1" max="65535" value="${attr(ba.puertoDirecto || 50036)}" /></div>
          </div>
          <div class="mv-field"><label>IP de la báscula #2 (opcional)</label><input id="ba-ip2" value="${attr(ba.ip2 || "")}" placeholder="ej. 192.168.100.29 (déjalo vacío si solo hay una)" /></div>
          <div class="mv-actions" style="margin-top:6px">
            <button class="btn btn--sec" id="ba-buscar">🔍 Buscar básculas en la red</button>
            <span class="qty-hint" id="ba-buscar-msg">Si cambiaron de IP (WiFi/DHCP), esto las encuentra y llena las IP.</span>
          </div>
        </div>
        <div class="mv-field" id="ba-ruta-box"><label>Ruta de la base de Scale Link (BaseDeDatos.mdb)</label><input id="ba-ruta" value="${attr(ba.ruta || "")}" placeholder="C:\\Torrey\\Scale Link\\BaseDeDatos.mdb" /></div>
        <div class="cf-2col">
          <div class="mv-field"><label>Frecuencia de lectura (segundos)</label><input id="ba-intervalo" type="number" min="1" max="60" value="${attr(ba.intervaloSeg || 3)}" /></div>
          <label class="cf-check" style="align-self:end"><input type="checkbox" id="ba-sonido" ${ck(ba.avisoSonoro)}/> Aviso sonoro al llegar venta</label>
        </div>
        ${chk("ba-auto", "Crear el ticket automáticamente al llegar la venta", ba.autoTicket !== false)}
        ${chk("ba-escaneo", "Modo escaneo: abrir el ticket al escanear la etiqueta (no automático)", !!ba.modoEscaneo)}
        <div class="mv-actions" style="margin-top:10px">
          <button class="btn btn--sec" id="ba-probar">🔌 Probar conexión</button>
          <button class="btn btn--ghost" id="ba-reiniciar" title="Vuelve a considerar 'nuevas' las ventas ya vistas">↺ Reiniciar histórico</button>
        </div>
        <div class="bk-estado" id="ba-estado"></div>
        <p class="sub" style="margin:12px 0 0;border-top:1px solid var(--line);padding-top:12px">📤 Para <b>modificar los precios de las básculas</b> ve a <b>📦 Inventario → ⚖️ Precios báscula</b>.</p>
      </div>
      <div class="mv-card mv-card--muted">
        <div class="mv-card__head"><h3>Cómo funciona</h3></div>
        <p class="sub"><b>Modo directo (recomendado):</b> el POS se conecta por red a la(s) báscula(s) (puerto 50036) y descarga las ventas (folios, productos, pesos y precios) sin necesidad de Scale Link. Solo indica la IP de cada báscula. La lectura es <b>silenciosa</b>: no bloquea la báscula ni la hace pitar, el operador puede seguir pesando con normalidad.</p>
        <p class="sub">El operador pesa en la báscula como siempre. En cuanto la venta se registra, el POS abre un ticket con las líneas ya pesadas; en mostrador agregas extras (tortillas, etc.) y das <b>Registrar cobro</b>. Cada venta de báscula genera un ticket aparte.</p>
        <p class="sub"><b>Modo escaneo:</b> la báscula imprime en su etiqueta un código de barras con el <b>folio</b>. El cajero lo escanea con un lector USB y el POS abre el ticket completo (con todos sus productos) que Scale Link ya descargó por WiFi. Ideal para saber "qué venta es cuál".</p>
      </div>
    </div>

    <div class="mv-grid2" style="margin-top:16px">
      <div class="mv-card">
        <div class="mv-card__head"><h3>🔖 Formato del código de barras de la báscula</h3></div>
        <p class="sub">Define cómo el POS lee el código de barras de la etiqueta para extraer el <b>folio</b>. Debe coincidir con el formato configurado en la báscula (menú <i>Código de barras</i>). El último dígito es el verificador (no se cuenta).</p>
        <div class="cf-2col">
          <div class="mv-field"><label>Simbología</label>
            <select id="bc-simbologia">
              <option value="EAN13" ${sel(bc.simbologia || "EAN13", "EAN13")}>EAN-13 (13 dígitos)</option>
              <option value="UPC12" ${sel(bc.simbologia, "UPC12")}>UPC-A (12 dígitos)</option>
            </select>
          </div>
          <div class="mv-field"><label>Prefijos válidos (coma)</label><input id="bc-prefijos" value="${attr(bc.prefijos != null ? bc.prefijos : "2")}" placeholder="2" /></div>
        </div>
        <div class="cf-2col">
          <div class="mv-field"><label>Folio: posición inicial (0 = primer dígito)</label><input id="bc-folioini" type="number" min="0" max="12" value="${attr(bc.folioInicio != null ? bc.folioInicio : 3)}" /></div>
          <div class="mv-field"><label>Folio: cantidad de dígitos</label><input id="bc-foliolen" type="number" min="1" max="12" value="${attr(bc.folioLargo != null ? bc.folioLargo : 6)}" /></div>
        </div>
        <div class="cf-2col">
          <div class="mv-field"><label>Báscula/Depto: posición inicial</label><input id="bc-basini" type="number" min="0" max="12" value="${attr(bc.basculaInicio != null ? bc.basculaInicio : 1)}" /></div>
          <div class="mv-field"><label>Báscula/Depto: dígitos (0 = no usar)</label><input id="bc-baslen" type="number" min="0" max="6" value="${attr(bc.basculaLargo != null ? bc.basculaLargo : 2)}" /></div>
        </div>
        <p class="sub" style="margin:10px 0 4px;border-top:1px solid var(--line);padding-top:10px">🛟 <b>Respaldo sin conexión:</b> si la etiqueta lleva el <b>importe</b> (y opcionalmente el <b>peso</b> y el <b>código/PLU</b>) dentro del código de barras, al escanear se arma la venta aunque falle la red con la báscula. Deja el <b>importe en 0 dígitos</b> para no usar este modo.</p>
        <div class="cf-2col">
          <div class="mv-field"><label>Importe: posición inicial</label><input id="bc-impini" type="number" min="0" max="12" value="${attr(bc.importeInicio != null ? bc.importeInicio : 0)}" /></div>
          <div class="mv-field"><label>Importe: dígitos (incluye 2 decimales; 0 = no usar)</label><input id="bc-implen" type="number" min="0" max="8" value="${attr(bc.importeLargo != null ? bc.importeLargo : 0)}" /></div>
        </div>
        <div class="cf-2col">
          <div class="mv-field"><label>Peso: posición inicial</label><input id="bc-pesoini" type="number" min="0" max="12" value="${attr(bc.pesoInicio != null ? bc.pesoInicio : 0)}" /></div>
          <div class="mv-field"><label>Peso: dígitos (kg con 3 decimales; 0 = no usar)</label><input id="bc-pesolen" type="number" min="0" max="8" value="${attr(bc.pesoLargo != null ? bc.pesoLargo : 0)}" /></div>
        </div>
        <div class="cf-2col">
          <div class="mv-field"><label>Código/PLU producto: posición inicial</label><input id="bc-codini" type="number" min="0" max="12" value="${attr(bc.codInicio != null ? bc.codInicio : 0)}" /></div>
          <div class="mv-field"><label>Código/PLU producto: dígitos (0 = no usar)</label><input id="bc-codlen" type="number" min="0" max="8" value="${attr(bc.codLargo != null ? bc.codLargo : 0)}" /></div>
        </div>
      </div>
      <div class="mv-card mv-card--muted">
        <div class="mv-card__head"><h3>Ejemplo de formato</h3></div>
        <p class="sub">Formato TORREY sugerido (CUSTOM) en la báscula, con <b>P</b>=prefijo, <b>D</b>=depto/báscula, <b>F</b>=folio, <b>V</b>=verificador:</p>
        <p class="sub" style="font-family:monospace;font-size:15px">P D D F F F F F F 0 0 V</p>
        <p class="sub">Con este ejemplo: prefijo <b>2</b>, báscula en posición <b>1</b> (2 dígitos), folio en posición <b>3</b> (6 dígitos). Ajusta los campos de la izquierda si configuras la báscula distinto.</p>
      </div>
    </div>

    <div class="mv-grid2" style="margin-top:16px">
      <div class="mv-card">
        <div class="mv-card__head"><h3>🧮 Facturación electrónica (CFDI 4.0)</h3></div>
        <p class="sub">Timbrado con el PAC <b>Copynorte</b>. En <b>Simulación</b> se generan facturas de prueba (sin timbrar ante el SAT) para probar el flujo. Cambia a <b>Producción</b> cuando tengas el web service de Copynorte configurado.</p>
        ${chk("fa-activa", "Activar módulo de facturación", fa.activa)}
        <div class="cf-2col">
          <div class="mv-field"><label>Modo</label>
            <select id="fa-modo">
              <option value="simulacion" ${sel(fa.modo || "simulacion", "simulacion")}>Simulación (pruebas)</option>
              <option value="produccion" ${sel(fa.modo, "produccion")}>Producción (timbra real)</option>
            </select>
          </div>
          <div class="mv-field"><label>Serie</label><input id="fa-serie" value="${attr(fa.serie || "A")}" placeholder="A" /></div>
        </div>
        <div class="mv-field"><label>Próximo folio de factura</label><input id="fa-folio" type="number" min="1" value="${attr(fa.folio || 1)}" /></div>
        <h4>Web service de Copynorte</h4>
        <div class="mv-field"><label>URL del web service</label><input id="fa-wsurl" value="${attr(fws.url)}" placeholder="https://…/timbrar (te lo da Copynorte)" /></div>
        <div class="cf-2col">
          <div class="mv-field"><label>Usuario WS</label><input id="fa-wsuser" value="${attr(fws.usuario)}" /></div>
          <div class="mv-field"><label>Contraseña WS</label><input id="fa-wspass" type="password" value="${attr(fws.password)}" /></div>
        </div>
        <p class="sub">Pídele a Copynorte el "kit de integración / Timbrado WS": URL, usuario y contraseña.</p>
      </div>

      <div class="mv-card">
        <div class="mv-card__head"><h3>📧 Envío de facturas</h3></div>
        <h4>Correo (SMTP)</h4>
        ${chk("fco-activo", "Enviar la factura por correo automáticamente al timbrar", fco.activo)}
        <div class="cf-2col">
          <div class="mv-field"><label>Servidor SMTP</label><input id="fco-host" value="${attr(fco.host)}" placeholder="smtp.gmail.com" /></div>
          <div class="mv-field"><label>Puerto</label><input id="fco-puerto" type="number" value="${attr(fco.puerto || 587)}" /></div>
        </div>
        <label class="cf-check"><input type="checkbox" id="fco-seguro" ${ck(fco.seguro)}/> Conexión segura (SSL/TLS, puerto 465)</label>
        <div class="cf-2col">
          <div class="mv-field"><label>Usuario / correo</label><input id="fco-user" value="${attr(fco.usuario)}" placeholder="negocio@correo.com" /></div>
          <div class="mv-field"><label>Contraseña</label><input id="fco-pass" type="password" value="${attr(fco.password)}" placeholder="contraseña de aplicación" /></div>
        </div>
        <div class="mv-field"><label>Remitente (opcional)</label><input id="fco-remitente" value="${attr(fco.remitente)}" placeholder="Mayoreo de Carne de Res <negocio@correo.com>" /></div>
        <h4 style="margin-top:12px">WhatsApp</h4>
        <p class="sub">Abre WhatsApp con el mensaje listo (el cajero solo pica <b>Enviar</b>). Usa {cliente}, {folio}, {total} y {liga}.</p>
        <div class="mv-field"><label>Mensaje</label><textarea id="fwa-plantilla" rows="2">${escapeHtml(fwa.plantilla || "")}</textarea></div>
        <div class="mv-field"><label>Liga base de descarga (opcional)</label><input id="fa-ligabase" value="${attr(fa.ligaBase)}" placeholder="https://…/facturas (donde se publican los PDF)" /></div>
      </div>
    </div>

    <div class="mv-card">
      <div class="mv-card__head"><h3>🔒 Permisos y roles</h3></div>
      <p class="sub">Los <b>Administradores</b> pueden todo. Los usuarios <b>Cajero/Despacho</b> (como Yakary) <b>sí pueden agregar existencias</b> (＋ Entrada), pero <b>no pueden bajar stock ni cambiar precios</b> sin la clave de un administrador. Para asignar roles: inicio de sesión → Administrar usuarios.</p>
      <label class="cf-check"><input type="checkbox" id="pm-invadmin" ${pm.inventarioSoloAdmin === false ? "" : "checked"} /> <span>Proteger precios y bajas de inventario: solo administradores (los cajeros sí pueden sumar existencias).</span></label>
    </div>

    <div style="max-width:1100px;margin:16px auto 0;text-align:right">
      <button class="btn btn--primary" id="cf-guardar">Guardar configuración</button>
    </div>`;

  const toggleModo = () => {
    const modo = $("#cf-modo", body).value;
    $$(".cf-red", body).forEach((el) => el.style.display = modo === "red" ? "" : "none");
    $$(".cf-win", body).forEach((el) => el.style.display = modo === "windows" ? "" : "none");
  };
  toggleModo();
  $("#cf-modo", body).addEventListener("change", toggleModo);

  // Llena el combo con impresoras reales de Windows (evita copiar el placeholder).
  (async () => {
    const selRuta = $("#cf-ruta-sel", body);
    const inpRuta = $("#cf-ruta", body);
    if (!selRuta || !window.api.printer || !window.api.printer.listarImpresoras) return;
    try {
      const r = await window.api.printer.listarImpresoras();
      const lista = (r && r.impresoras) || [];
      const actual = (inpRuta && inpRuta.value || "").trim();
      selRuta.innerHTML = `<option value="">— Elige una impresora instalada —</option>` +
        lista.map((n) => `<option value="${attr(n)}" ${n === actual ? "selected" : ""}>${escapeHtml(n)}</option>`).join("");
      if (actual && !lista.includes(actual)) {
        const o = document.createElement("option");
        o.value = actual; o.textContent = actual + " (no detectada)"; o.selected = true;
        selRuta.appendChild(o);
      }
      selRuta.addEventListener("change", () => {
        if (selRuta.value && inpRuta) inpRuta.value = selRuta.value;
      });
    } catch (e) {}
  })();

  const lineas = (id) => $(`#${id}`, body).value.split("\n").map((s) => s.trim()).filter(Boolean);

  const recolectar = () => ({
    terminal: $("#cf-terminal", body).value.trim() || "Caja Principal",
    negocio: {
      nombre: $("#cf-nombre", body).value.trim(),
      sucursal: $("#cf-sucursal", body).value.trim(),
      direccion: $("#cf-direccion", body).value.trim(),
      telefono: $("#cf-telefono", body).value.trim(),
      rfc: $("#cf-rfc", body).value.trim().toUpperCase(),
      razonSocial: $("#cf-razon", body).value.trim(),
      regimenFiscal: $("#cf-regimen", body).value,
      codigoPostal: $("#cf-cp", body).value.trim(),
      pie: $("#cf-pie", body).value.trim(),
      pie2: $("#cf-pie2", body).value.trim()
    },
    impresora: {
      modo: $("#cf-modo", body).value,
      ip: $("#cf-ip", body).value.trim(),
      puerto: parseInt($("#cf-puerto", body).value, 10) || 9100,
      rutaWindows: $("#cf-ruta", body).value.trim(),
      envioWindows: ($("#cf-envio", body) && $("#cf-envio", body).value) || "auto",
      anchoCols: parseInt($("#cf-ancho", body).value, 10) || 48,
      autoImprimir: false,
      abrirCajonEfectivo: $("#cf-cajon", body).checked,
      imprimirLogo: $("#cf-logo", body).checked,
      pulsoCajon: parseInt($("#cf-pulso", body).value, 10) || 0
    },
    ticket: {
      mostrarLogo: $("#tk-logo", body).checked,
      mostrarNombre: $("#tk-nombre", body).checked,
      mostrarSucursal: $("#tk-sucursal", body).checked,
      mostrarDireccion: $("#tk-direccion", body).checked,
      mostrarTelefono: $("#tk-telefono", body).checked,
      mostrarRFC: $("#tk-rfc", body).checked,
      lineasEncabezado: lineas("tk-enc"),
      mostrarFolio: $("#tk-folio", body).checked,
      mostrarFecha: $("#tk-fecha", body).checked,
      mostrarCajero: $("#tk-cajero", body).checked,
      mostrarCliente: $("#tk-cliente", body).checked,
      etiquetaCajero: $("#tk-etq-cajero", body).value.trim() || "Atiende",
      etiquetaCliente: $("#tk-etq-cliente", body).value.trim() || "Cliente",
      mostrarPrecioUnitario: $("#tk-preciou", body).checked,
      mostrarFormaPago: $("#tk-pago", body).checked,
      lineasPie: lineas("tk-pie")
    },
    respaldo: {
      activo: $("#bk-activo", body).checked,
      endpoint: $("#bk-endpoint", body).value.trim(),
      token: $("#bk-token", body).value.trim(),
      intervaloSeg: Math.max(15, parseInt($("#bk-intervalo", body).value, 10) || 60),
      comprimir: $("#bk-comprimir", body).checked
    },
    supabase: {
      activo: $("#sb-activo", body).checked,
      url: $("#sb-url", body).value.trim(),
      key: $("#sb-key", body).value.trim(),
      intervaloMin: 0, // subir: en cada cambio (barato). Bajar: según bajarCadaMin.
      bajarCadaMin: Math.max(1, Math.min(1440, parseInt($("#sb-bajarcada", body).value, 10) || 120)),
      retenerAnos: Math.max(1, Math.min(10, parseInt($("#sb-retener", body).value, 10) || 2))
    },
    actualizaciones: {
      activo: $("#ac-activo", body).checked,
      owner: $("#ac-owner", body).value.trim(),
      repo: $("#ac-repo", body).value.trim(),
      rama: $("#ac-rama", body).value.trim() || "main",
      canal: $("#ac-canal", body).value,
      intervaloMin: (CFG.actualizaciones && CFG.actualizaciones.intervaloMin) || 30
    },
    bascula: {
      activa: $("#ba-activa", body).checked,
      modoDirecto: $("#ba-modo", body).value === "directo",
      ip: $("#ba-ip", body).value.trim() || "192.168.100.28",
      ip2: ($("#ba-ip2", body) ? $("#ba-ip2", body).value.trim() : ""),
      puertoDirecto: Math.max(1, Math.min(65535, parseInt($("#ba-puerto", body).value, 10) || 50036)),
      ruta: $("#ba-ruta", body).value.trim() || "C:\\Torrey\\Scale Link\\BaseDeDatos.mdb",
      intervaloSeg: Math.max(1, Math.min(60, parseInt($("#ba-intervalo", body).value, 10) || 3)),
      avisoSonoro: $("#ba-sonido", body).checked,
      autoTicket: $("#ba-auto", body).checked,
      modoEscaneo: $("#ba-escaneo", body).checked,
      codigoBarras: {
        simbologia: $("#bc-simbologia", body).value,
        prefijos: $("#bc-prefijos", body).value.trim(),
        folioInicio: Math.max(0, parseInt($("#bc-folioini", body).value, 10) || 0),
        folioLargo: Math.max(1, parseInt($("#bc-foliolen", body).value, 10) || 6),
        basculaInicio: Math.max(0, parseInt($("#bc-basini", body).value, 10) || 0),
        basculaLargo: Math.max(0, parseInt($("#bc-baslen", body).value, 10) || 0),
        importeInicio: Math.max(0, parseInt($("#bc-impini", body).value, 10) || 0),
        importeLargo: Math.max(0, parseInt($("#bc-implen", body).value, 10) || 0),
        pesoInicio: Math.max(0, parseInt($("#bc-pesoini", body).value, 10) || 0),
        pesoLargo: Math.max(0, parseInt($("#bc-pesolen", body).value, 10) || 0),
        codInicio: Math.max(0, parseInt($("#bc-codini", body).value, 10) || 0),
        codLargo: Math.max(0, parseInt($("#bc-codlen", body).value, 10) || 0)
      }
    },
    permisos: { inventarioSoloAdmin: $("#pm-invadmin", body).checked },
    factura: {
      activa: $("#fa-activa", body).checked,
      modo: $("#fa-modo", body).value,
      serie: $("#fa-serie", body).value.trim() || "A",
      folio: Math.max(1, parseInt($("#fa-folio", body).value, 10) || 1),
      ligaBase: $("#fa-ligabase", body).value.trim(),
      ws: {
        tipo: "rest",
        url: $("#fa-wsurl", body).value.trim(),
        usuario: $("#fa-wsuser", body).value.trim(),
        password: $("#fa-wspass", body).value
      },
      correo: {
        activo: $("#fco-activo", body).checked,
        host: $("#fco-host", body).value.trim(),
        puerto: parseInt($("#fco-puerto", body).value, 10) || 587,
        seguro: $("#fco-seguro", body).checked,
        usuario: $("#fco-user", body).value.trim(),
        password: $("#fco-pass", body).value,
        remitente: $("#fco-remitente", body).value.trim()
      },
      whatsapp: {
        activo: true,
        plantilla: $("#fwa-plantilla", body).value.trim()
      }
    }
  });

  const guardar = async () => { CFG = await window.api.db.setConfig(recolectar()); };

  const pintarBackup = (est) => {
    const el = $("#bk-estado", body);
    if (!el || !est) return;
    const partes = [];
    partes.push(est.activo ? '<span class="tk-ok">● Activo</span>' : '<span class="tk-info">○ Inactivo</span>');
    if (est.ultimoOk) partes.push(`Último respaldo OK: ${new Date(est.ultimoOk).toLocaleString("es-MX")}`);
    if (est.pendiente) partes.push('<span class="tk-warn">Cambios pendientes por subir…</span>');
    if (est.ultimoError) partes.push(`<span class="tk-warn">Error: ${escapeHtml(est.ultimoError)}</span>`);
    el.innerHTML = partes.join("<br/>");
  };
  const pintarSupabase = (est) => {
    const el = $("#sb-estado", body);
    if (!el || !est) return;
    const partes = [];
    partes.push(est.activo ? '<span class="tk-ok">● Activo</span>' : '<span class="tk-info">○ Inactivo</span>');
    partes.push(est.configurado ? "Credenciales capturadas" : '<span class="tk-warn">Falta URL o service_role key</span>');
    partes.push("⚡ Tiempo real, ida y vuelta");
    if (est.ultimoKeepAlive) partes.push(`Keep-alive: ${new Date(est.ultimoKeepAlive).toLocaleString("es-MX")}`);
    if (est.enviando) {
      const p = est.progreso;
      const txt = p && typeof p === "object"
        ? [p.etapa, p.tabla, p.enviados != null ? (p.enviados + "/" + (p.de || "?")) : null].filter(Boolean).join(" · ")
        : String(p || "");
      partes.push('<span class="tk-info">Subiendo… ' + escapeHtml(txt) + "</span>");
    }
    if (est.ultimoOk) partes.push(`Última sync OK: ${new Date(est.ultimoOk).toLocaleString("es-MX")}`);
    if (est.ultimoError) partes.push(`<span class="tk-warn">Error: ${escapeHtml(est.ultimoError)}</span>`);
    el.innerHTML = partes.join("<br/>");
  };
  if (window.api.backup) { try { pintarBackup(await window.api.backup.estado()); } catch (e) {} }
  if (window.api.supabase) { try { pintarSupabase(await window.api.supabase.estado()); } catch (e) {} }

  $("#cf-guardar", body).addEventListener("click", async () => {
    await guardar();
    $("#cf-estado", body).innerHTML = '<span class="tk-ok">✅ Configuración guardada.</span>';
    if (window.api.backup) { try { pintarBackup(await window.api.backup.estado()); } catch (e) {} }
    if (window.api.supabase) { try { pintarSupabase(await window.api.supabase.estado()); } catch (e) {} }
  });
  $("#cf-exportar", body).addEventListener("click", async () => {
    const el = $("#cf-local-estado", body);
    el.innerHTML = "Preparando respaldo…";
    const r = await window.api.db.exportar();
    if (r && r.ok) el.innerHTML = `<span class="tk-ok">✅ Respaldo guardado en:<br/>${escapeHtml(r.ruta)}</span>`;
    else if (r && r.cancelado) el.innerHTML = '<span class="tk-info">Exportación cancelada.</span>';
    else el.innerHTML = `<span class="tk-warn">⚠️ ${r && r.error ? escapeHtml(r.error) : "No se pudo exportar."}</span>`;
  });
  $("#cf-importar", body).addEventListener("click", async () => {
    const el = $("#cf-local-estado", body);
    if (!confirm("Importar un respaldo REEMPLAZA toda la información actual de esta terminal. ¿Continuar?")) return;
    el.innerHTML = "Leyendo archivo…";
    const r = await window.api.db.importar();
    if (r && r.ok) {
      el.innerHTML = '<span class="tk-ok">✅ Respaldo importado. Recargando…</span>';
      setTimeout(() => location.reload(), 900);
    } else if (r && r.cancelado) el.innerHTML = '<span class="tk-info">Importación cancelada.</span>';
    else el.innerHTML = `<span class="tk-warn">⚠️ ${r && r.error ? escapeHtml(r.error) : "No se pudo importar."}</span>`;
  });
  $("#cf-eleventa", body).addEventListener("click", () => {
    pedirImportarEleventa(() => showModule("config"));
  });
  // Mostrar/ocultar campos según el modo de conexión.
  const baModo = $("#ba-modo", body);
  const aplicarModo = () => {
    const directo = baModo && baModo.value === "directo";
    const boxD = $("#ba-directo-box", body); const boxR = $("#ba-ruta-box", body);
    if (boxD) boxD.style.display = directo ? "" : "none";
    if (boxR) boxR.style.display = directo ? "none" : "";
  };
  if (baModo) { baModo.addEventListener("change", aplicarModo); aplicarModo(); }

  const baProbar = $("#ba-probar", body);
  if (baProbar) baProbar.addEventListener("click", async () => {
    basculaAlertSilenciada = false;   // reconectar manual: vuelve a habilitar el aviso
    await guardar();
    const directo = baModo && baModo.value === "directo";
    const est = $("#ba-estado", body);
    est.innerHTML = directo ? "Conectando con la báscula…" : "Conectando con Scale Link…";
    let r; try { r = await window.api.bascula.probar(); } catch (e) { r = { error: e.message }; }
    if (r && r.directo && Array.isArray(r.basculasProbar)) {
      const filas = r.basculasProbar.map((b) =>
        b.ok
          ? `<span class="tk-ok">✅ Báscula #${b.id} conectada</span> · ${escapeHtml(b.ip)}:${escapeHtml(String(b.puerto || ""))}`
          : `<span class="tk-warn">⚠️ Báscula #${b.id} (${escapeHtml(b.ip)}): ${escapeHtml(b.error || "sin respuesta")}</span>`
      ).join("<br/>");
      est.innerHTML = filas || '<span class="tk-warn">⚠️ No hay básculas configuradas.</span>';
    } else if (r && r.ok) {
      if (directo) {
        est.innerHTML = `<span class="tk-ok">✅ Conectada la báscula (directo TCP).</span><br/>` +
          `${escapeHtml(r.ip || "")}:${escapeHtml(String(r.puerto || ""))}`;
      } else {
        const bl = (r.basculas || []).map((b) =>
          `#${b.id} ${escapeHtml(b.nombre || "")}${b.serie ? (" · serie " + escapeHtml(b.serie)) : ""}${b.ip ? (" · " + escapeHtml(b.ip)) : ""}`
        ).join("<br/>");
        est.innerHTML = `<span class="tk-ok">✅ Conectado a Scale Link.</span><br/>` +
          `Ventas: ${r.ventas} · Detalle: ${r.detalle} · Productos: ${r.productos}` +
          (bl ? ("<br/><b>Básculas dadas de alta:</b><br/>" + bl)
              : "<br/><span class='tk-info'>Aún no hay básculas dadas de alta en Scale Link.</span>");
      }
    } else {
      est.innerHTML = `<span class="tk-warn">⚠️ ${escapeHtml(r && r.error ? r.error : "No se pudo conectar.")}</span>`;
    }
  });
  const baBuscar = $("#ba-buscar", body);
  if (baBuscar) baBuscar.addEventListener("click", async () => {
    basculaAlertSilenciada = false;   // buscar básculas: vuelve a habilitar el aviso
    const msgEl = $("#ba-buscar-msg", body);
    baBuscar.disabled = true; const txt = baBuscar.textContent; baBuscar.textContent = "Buscando…";
    if (msgEl) msgEl.textContent = "Escaneando la red local…";
    let r; try { r = await window.api.bascula.descubrir(); } catch (e) { r = { error: e.message }; }
    baBuscar.disabled = false; baBuscar.textContent = txt;
    if (r && r.ok && r.ips && r.ips.length) {
      const ip1 = $("#ba-ip", body), ip2 = $("#ba-ip2", body);
      if (ip1) ip1.value = r.ips[0] || "";
      if (ip2) ip2.value = r.ips[1] || "";
      if (msgEl) msgEl.innerHTML = `<span class="tk-ok">Encontradas: ${r.ips.join(", ")}. Pulsa "Guardar configuración".</span>`;
    } else if (r && r.ok) {
      if (msgEl) msgEl.innerHTML = `<span class="tk-warn">No se encontraron básculas (¿encendidas y en la misma red WiFi?).</span>`;
    } else {
      if (msgEl) msgEl.innerHTML = `<span class="tk-warn">${escapeHtml(r && r.error ? r.error : "No se pudo buscar.")}</span>`;
    }
  });
  const baReiniciar = $("#ba-reiniciar", body);
  if (baReiniciar) baReiniciar.addEventListener("click", async () => {
    if (!confirm("Esto hará que el POS vuelva a tomar como 'nuevas' las ventas de la báscula disponibles. ¿Continuar?")) return;
    try { await window.api.bascula.reiniciarVistas(); } catch (e) {}
    $("#ba-estado", body).innerHTML = '<span class="tk-info">Histórico reiniciado. Las próximas lecturas traerán las ventas disponibles.</span>';
  });

  $("#cf-probar", body).addEventListener("click", async () => {
    await guardar();
    const est = $("#cf-estado", body);
    est.textContent = "Enviando prueba…";
    const r = await window.api.printer.probar();
    est.innerHTML = r && r.ok
      ? '<span class="tk-ok">✅ Prueba enviada a la impresora.</span>'
      : `<span class="tk-warn">⚠️ ${r && r.error ? r.error : "No se pudo imprimir."}</span>`;
  });
  $("#cf-abrir-cajon", body).addEventListener("click", async () => {
    await guardar();
    const est = $("#cf-estado", body);
    const r = await window.api.printer.abrirCajon();
    est.innerHTML = r && r.ok
      ? '<span class="tk-ok">✅ Pulso de apertura enviado.</span>'
      : `<span class="tk-warn">⚠️ ${r && r.error ? r.error : "No se pudo abrir el cajón."}</span>`;
  });
  $("#cf-ticket-preview", body).addEventListener("click", async () => {
    await guardar();
    mostrarEjemploTicket();
  });
  $("#bk-vincular", body).addEventListener("click", async () => {
    const el = $("#bk-estado", body);
    const endpoint = $("#bk-endpoint", body).value.trim();
    const token = $("#bk-token", body).value.trim();
    if (!endpoint || !token) {
      el.innerHTML = '<span class="tk-warn">⚠️ Captura la dirección (endpoint) y el token antes de vincular.</span>';
      return;
    }
    $("#bk-activo", body).checked = true;   // vincular = activar
    await guardar();
    el.innerHTML = "Vinculando y probando conexión…";
    const r = await window.api.backup.probar();
    if (r && r.ok) {
      const est = await window.api.backup.sincronizar();   // primer respaldo inmediato
      el.innerHTML = '<span class="tk-ok">✅ Vinculado. Primer respaldo enviado.</span>';
      setTimeout(() => pintarBackup(est), 400);
    } else {
      $("#bk-activo", body).checked = false;
      await guardar();
      el.innerHTML = `<span class="tk-warn">⚠️ No se pudo vincular: ${r && r.error ? escapeHtml(r.error) : "sin conexión"}.</span>`;
    }
  });
  $("#bk-desvincular", body).addEventListener("click", async () => {
    if (!confirm("¿Desvincular el respaldo en la nube? Se dejará de enviar copias (los datos locales no se tocan).")) return;
    $("#bk-activo", body).checked = false;
    await guardar();
    const el = $("#bk-estado", body);
    el.innerHTML = '<span class="tk-info">○ Desvinculado. El respaldo automático está apagado.</span>';
    if (window.api.backup) { try { pintarBackup(await window.api.backup.estado()); } catch (e) {} }
  });
  $("#bk-probar", body).addEventListener("click", async () => {
    await guardar();
    const el = $("#bk-estado", body);
    el.innerHTML = "Probando conexión…";
    const r = await window.api.backup.probar();
    if (r && r.ok) { el.innerHTML = '<span class="tk-ok">✅ Conexión correcta con el servicio de respaldo.</span>'; }
    else { el.innerHTML = `<span class="tk-warn">⚠️ ${r && r.error ? escapeHtml(r.error) : "No se pudo conectar."}</span>`; }
  });
  $("#bk-sync", body).addEventListener("click", async () => {
    await guardar();
    const el = $("#bk-estado", body);
    el.innerHTML = "Respaldando…";
    const est = await window.api.backup.sincronizar();
    pintarBackup(est);
  });

  const sbSchema = $("#sb-schema", body);
  if (sbSchema) sbSchema.addEventListener("click", async () => {
    const el = $("#sb-estado", body);
    el.innerHTML = "Copiando schema…";
    let r; try { r = await window.api.supabase.abrirSchema(); } catch (e) { r = { error: e.message }; }
    if (r && r.ok) el.innerHTML = `<span class="tk-ok">✅ Schema en Escritorio:<br/>${escapeHtml(r.ruta)}</span>`;
    else el.innerHTML = `<span class="tk-warn">⚠️ ${escapeHtml(r && r.error ? r.error : "No se pudo copiar.")}</span>`;
  });
  const sbProbar = $("#sb-probar", body);
  if (sbProbar) sbProbar.addEventListener("click", async () => {
    await guardar();
    const el = $("#sb-estado", body);
    el.innerHTML = "Probando conexión con Supabase…";
    let r; try { r = await window.api.supabase.probar(); } catch (e) { r = { error: e.message }; }
    if (r && r.ok) el.innerHTML = '<span class="tk-ok">✅ Conexión OK. Las tablas existen.</span>';
    else el.innerHTML = `<span class="tk-warn">⚠️ ${escapeHtml(r && r.error ? r.error : "No se pudo conectar.")}</span>`;
  });
  const sbBajar = $("#sb-bajar", body);
  if (sbBajar) sbBajar.addEventListener("click", async () => {
    await guardar();
    const el = $("#sb-estado", body);
    el.innerHTML = "Trayendo cambios de la otra PC…";
    sbBajar.disabled = true;
    let r; try { r = await window.api.supabase.bajarAhora(); } catch (e) { r = { ok: false, error: e.message }; }
    sbBajar.disabled = false;
    if (r && r.ok) el.innerHTML = '<span class="tk-ok">✅ ' + (r.cambio ? "Cambios traídos." : "Ya estabas al día.") + "</span>";
    else el.innerHTML = '<span class="tk-warn">⚠️ ' + escapeHtml(r && r.error ? r.error : "No se pudo traer (revisa conexión).") + "</span>";
  });
  const sbSync = $("#sb-sync", body);
  if (sbSync) sbSync.addEventListener("click", async () => {
    await guardar();
    const el = $("#sb-estado", body);
    el.innerHTML = "Reenviando TODO a la nube (puede tardar con muchas ventas)…";
    sbSync.disabled = true;
    // El botón manual fuerza un reenvío COMPLETO (útil tras correr el SQL). El
    // automático en tiempo real solo manda los cambios.
    let est; try { est = await window.api.supabase.sincronizar(true); } catch (e) { est = { ultimoError: e.message }; }
    sbSync.disabled = false;
    pintarSupabase(est || await window.api.supabase.estado());
    if (est && !est.ultimoError && est.ultimoOk) {
      el.innerHTML = (el.innerHTML || "") + '<br/><span class="tk-ok">✅ Sincronización completa.</span>';
    }
  });

  // ---- Actualizaciones del sistema ----
  const acEstado = $("#ac-estado", body);
  const acInstalar = $("#ac-instalar", body);
  const acVerLocal = $("#ac-version-local", body);
  let acUltima = null; // última info con actualización disponible
  const acPintar = (info) => {
    if (acVerLocal && info && info.versionActual) acVerLocal.textContent = "v" + info.versionActual;
    if (!acEstado || !info) return;
    if (!info.ok) {
      const m = info.motivo === "sin-config" ? "Configura usuario, repositorio y canal, y guarda."
        : info.motivo === "inactivo" ? "La revisión automática está desactivada."
        : info.motivo === "red" ? "Sin conexión al canal de actualizaciones."
        : info.motivo === "manifiesto-invalido" ? "El canal existe pero el archivo de versión no es válido."
        : (info.error || "No se pudo revisar.");
      acEstado.innerHTML = '<span class="tk-info">' + escapeHtml(m) + "</span>";
      if (acInstalar) acInstalar.disabled = true;
      return;
    }
    if (info.hay) {
      acUltima = info;
      if (acInstalar) acInstalar.disabled = false;
      acEstado.innerHTML =
        '<span class="tk-ok">✅ Hay una actualización disponible: <b>v' + escapeHtml(info.version) + "</b></span>" +
        (info.notas ? '<br/><span class="sub">' + escapeHtml(info.notas) + "</span>" : "") +
        '<br/><span class="sub">Da clic en “Actualizar sistema” para instalarla.</span>';
    } else {
      acUltima = null;
      if (acInstalar) acInstalar.disabled = true;
      acEstado.innerHTML = '<span class="tk-ok">● Estás al día (v' + escapeHtml(info.versionActual || "") + ").</span>";
    }
  };
  const acBuscar = $("#ac-buscar", body);
  if (acBuscar) acBuscar.addEventListener("click", async () => {
    await guardar();
    if (acEstado) acEstado.innerHTML = "Buscando actualización…";
    let info; try { info = await window.api.actualizador.revisar(); } catch (e) { info = { ok: false, error: e.message }; }
    acPintar(info);
  });
  if (acInstalar) acInstalar.addEventListener("click", async () => {
    const info = acUltima;
    if (!info || !info.hay) return;
    const ok = window.confirm(
      "¿Instalar la actualización v" + info.version + " ahora?\n\n" +
      "El programa se respaldará, instalará la actualización y se reiniciará automáticamente.\n\n" +
      "Asegúrate de NO tener una venta en curso."
    );
    if (!ok) return;
    acInstalar.disabled = true;
    if (acEstado) acEstado.innerHTML = '<span class="tk-info">Descargando e instalando… no cierres el programa. Se reiniciará solo.</span>';
    let r; try { r = await window.api.actualizador.instalar(); } catch (e) { r = { ok: false, error: e.message }; }
    if (r && r.ok) {
      if (acEstado) acEstado.innerHTML = '<span class="tk-ok">✅ Actualización lista. Reiniciando…</span>';
    } else {
      acInstalar.disabled = false;
      if (acEstado) acEstado.innerHTML = '<span class="tk-warn">⚠️ ' + escapeHtml(r && r.error ? r.error : "No se pudo instalar.") + "</span>";
    }
  });
  if (window.api.actualizador) {
    (async () => {
      let info = null;
      try { info = await window.api.actualizador.estado(); } catch (e) {}
      if (info) acPintar(info);
    })();
  }
}

// Muestra un ticket de ejemplo con la estructura configurada actualmente.
async function mostrarEjemploTicket() {
  const demo = {
    folio: 1234,
    fecha: new Date().toLocaleString("es-MX"),
    cajero: usuarioActual ? usuarioActual.nombre : "Cajero",
    cliente: CLIENTE_DEFAULT,
    items: [
      { nombre: "Arrachera marinada", cant: 1.5, unidad: "kg", tipo: "producto", precioCents: 19900, importeCents: 29850 }
    ],
    totalCents: 29850, pago: "efectivo", pagoLabel: "Efectivo", recibidoCents: 30000, cambioCents: 150
  };
  let texto = "";
  try { texto = await window.api.printer.vistaPrevia(demo); } catch (e) { texto = ""; }
  if (!texto && typeof vistaPreviaLocal === "function") texto = vistaPreviaLocal(demo);
  const back = document.createElement("div");
  back.className = "modal-back";
  back.innerHTML = `
    <div class="modal modal--ticket">
      <h3>Ejemplo de ticket</h3>
      <pre class="ticket-preview">${escapeHtml(texto)}</pre>
      <div class="modal__foot"><button class="btn btn--primary" data-cerrar="1">Cerrar</button></div>
    </div>`;
  document.body.appendChild(back);
  back.addEventListener("click", (e) => { if (e.target === back || e.target.dataset.cerrar) back.remove(); });
}

function attr(s) { return String(s == null ? "" : s).replace(/"/g, "&quot;"); }

/* ---------------- Reloj ---------------- */
function tickClock() { $("#clock").textContent = new Date().toLocaleTimeString("es-MX"); }

/* ---------------- Eventos ---------------- */
function bindEvents() {
  $$("#pinpad .pinpad__keys button").forEach((b) => b.addEventListener("click", () => pinKey(b.dataset.k)));
  // Permite teclear el PIN con el teclado físico (sin necesidad de clic) mientras el pinpad está visible.
  document.addEventListener("keydown", (e) => {
    // Solo debe actuar en la pantalla de inicio, con el pinpad visible y
    // cuando el foco NO está en un campo de texto (evita bloquear la escritura).
    const login = $("#view-login");
    if (!login || login.classList.contains("hidden")) return;
    const pp = $("#pinpad");
    if (!pp || pp.classList.contains("hidden")) return;
    const t = e.target;
    if (esCampoEditable(t)) return;
    if (e.key >= "0" && e.key <= "9") { e.preventDefault(); pinKey(e.key); }
    else if (e.key === "Backspace") { e.preventDefault(); pinKey("back"); }
    else if (e.key === "Escape") { e.preventDefault(); pinKey("cancel"); }
    else if (e.key === "Enter") { e.preventDefault(); if (pinBuffer.length === 4) tryLogin(); }
  });
  const btnCrear = $("#btn-crear-usuario");
  if (btnCrear) btnCrear.addEventListener("click", crearUsuarioFlujo);
  $("#btn-logout").addEventListener("click", logout);

  $('.navbtn[data-view="venta"]').addEventListener("click", () => showVenta());
  $$(".navbtn[data-module]").forEach((b) =>
    b.addEventListener("click", () => showModule(b.dataset.module)));
  $("#mv-back").addEventListener("click", showVenta);


  const bReimp = $("#btn-reimprimir"); if (bReimp) bReimp.addEventListener("click", () => abrirHistorialTickets());
  $("#btn-limpiar").addEventListener("click", () => { const t = ticketActual(); if (t) t.descuentoCents = 0; cart.length = 0; renderCart(); });
  const bDesc = $("#btn-descuento"); if (bDesc) bDesc.addEventListener("click", descuentoFlujo);
  $("#btn-cobro").addEventListener("click", () => abrirCobro());
  $$('[data-accion]').forEach((b) => b.addEventListener("click", () => {
    const a = b.dataset.accion;
    if (a === "apartar") apartarFlujo();
    else if (a === "devoluciones") abrirHistorialTickets();
    else if (a === "creditos") showModule("creditos");
  }));
  $("#btn-cliente").addEventListener("click", () => abrirSelectorCliente());

  const search = $("#entry-search");
  search.addEventListener("input", (e) => renderProducts(e.target.value));
  search.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    const txt = e.target.value.trim().toLowerCase();
    if (!txt) return;
    const parts = txt.split(/\s+/);
    const maybeCant = parseFloat(parts[parts.length - 1]);
    const nombre = (isNaN(maybeCant) ? txt : parts.slice(0, -1).join(" ")).trim();
    const q = nombre || txt;
    const prod = DATA.productos.find((p) => productoConInventario(p) && p.nombre.toLowerCase().includes(q));
    if (prod) {
      addProducto(prod, isNaN(maybeCant) ? 1 : maybeCant);
      e.target.value = ""; renderProducts();
    }
  });
  $("#btn-manual").addEventListener("click", addProductoManual);

  document.addEventListener("keydown", (e) => {
    if ($("#view-app").classList.contains("hidden")) return;
    // Ctrl+P (o Cmd+P): abre rápido el "Producto común" manual, incluso con el
    // foco en un campo (por eso va ANTES del filtro de campos editables).
    if ((e.ctrlKey || e.metaKey) && (e.key === "p" || e.key === "P")) { e.preventDefault(); addProductoManual(); return; }
    // Teclas de función = atajos (no escriben texto): deben funcionar SIEMPRE,
    // aunque el cursor esté en un campo (antes F12/F1–F4 fallaban si el buscador
    // tenía el foco). No se disparan si hay un modal abierto, para no encimar.
    if (!document.querySelector(".modal-back")) {
      if (e.key === "F1") { e.preventDefault(); $("#entry-search").focus(); return; }
      if (e.key === "F2") { e.preventDefault(); $("#btn-cliente").click(); return; }
      if (e.key === "F3") { e.preventDefault(); addProductoManual(); return; }
      if (e.key === "F4") { e.preventDefault(); nuevoTicket(); return; }
      if (e.key === "F12") { e.preventDefault(); abrirCobro(); return; }
    }
    if (esCampoEditable(e.target)) return;
  });
}

/* ---------------- Recuadro de última venta (esquina inferior izquierda) ---------------- */
function wireUltimaVenta() {
  const panel = document.getElementById("lastsale");
  if (!panel) return;
  const min = document.getElementById("lastsale-min");
  const tog = document.getElementById("lastsale-toggle");
  if (min) min.addEventListener("click", () => panel.classList.add("is-min"));
  if (tog) tog.addEventListener("click", () => panel.classList.remove("is-min"));
}

// Reajusta la cuadrícula cuando cambia el tamaño del área o se vuelve a Ventas.
function wireAjusteGrid() {
  const scroll = document.querySelector("#view-venta .products-scroll");
  if (scroll && typeof ResizeObserver !== "undefined") {
    const ro = new ResizeObserver(() => programarAjusteGrid());
    ro.observe(scroll);
  }
  window.addEventListener("resize", programarAjusteGrid);
}

// Evita el "teclado bloqueado" al volver a la ventana: cuando el sistema recupera
// el foco, si ningún campo editable está activo y estamos en Ventas, deja el
// cursor listo en el buscador. Así SIEMPRE se puede escribir sin cerrar/abrir.
/* ---------------- Anti-bloqueo de teclado / capas ----------------
   A veces una ventana (.modal-back) queda invisible o vacía encima de todo
   porque un error cortó el código antes de cerrarla. Esa capa se traga los
   clics y el teclado: hay que cerrar y volver a abrir. Estas defensas lo
   evitan en cualquier módulo, sin cambiar el uso normal. */

function ordenarCapas() {
  const capas = [...document.querySelectorAll(".modal-back")];
  capas.forEach((c, i) => {
    c.style.zIndex = String(60 + i * 10);
    const activa = i === capas.length - 1;
    c.style.pointerEvents = activa ? "" : "none";
    c.setAttribute("aria-hidden", activa ? "false" : "true");
  });
  return capas;
}

const GRACIA_CAPA_MS = 6000;
function limpiarCapasHuerfanas() {
  let quitadas = 0;
  const ahora = Date.now();
  for (const c of [...document.querySelectorAll(".modal-back")]) {
    const caja = c.querySelector(".modal");
    const visible = caja && (caja.offsetParent !== null || caja.getClientRects().length > 0);
    if (visible) { delete c.dataset.vacioDesde; continue; }
    if (!c.dataset.vacioDesde) { c.dataset.vacioDesde = String(ahora); continue; }
    if (ahora - Number(c.dataset.vacioDesde) >= GRACIA_CAPA_MS) { c.remove(); quitadas++; }
  }
  if (quitadas) ordenarCapas();
  return quitadas;
}

let cerrandoCapa = false;
function cerrarCapa(back) {
  if (!back || !back.isConnected || cerrandoCapa) return;
  cerrandoCapa = true;
  try {
    const btn = back.querySelector("[data-cerrar]");
    if (btn) btn.click();
    if (back.isConnected) {
      back.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    }
  } catch (err) { /* pudo cerrarse a medio camino */ }
  cerrandoCapa = false;
  if (back.isConnected) back.remove();
  ordenarCapas();
}

function devolverFoco() {
  if (document.querySelector(".modal-back")) return;
  const buscador = document.getElementById("entry-search");
  if (buscador && buscador.offsetParent !== null) { buscador.focus(); return; }
  const campo = document.querySelector(
    "#module-view.is-active input:not([type=hidden]):not([disabled]), #module-view.is-active textarea:not([disabled]), #module-view.is-active select:not([disabled])"
  );
  if (campo && campo.offsetParent !== null) { try { campo.focus(); } catch (e) {} return; }
  if (document.activeElement && document.activeElement !== document.body) {
    try { document.activeElement.blur(); } catch (e) {}
  }
}

function vigilarBloqueos() {
  const observador = new MutationObserver(() => ordenarCapas());
  observador.observe(document.body, { childList: true });

  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape" || cerrandoCapa) return;
    const alerta = document.getElementById("bascula-desconectada");
    if (alerta && alerta.classList.contains("is-show")) {
      alerta.classList.remove("is-show");
      if (typeof basculaAlertSilenciada !== "undefined") basculaAlertSilenciada = true;
      return;
    }
    if (e.target && e.target.closest && e.target.closest(".modal-back")) return;
    const capas = ordenarCapas();
    if (!capas.length) return;
    cerrarCapa(capas[capas.length - 1]);
    if (!document.querySelector(".modal-back")) devolverFoco();
  }, true);

  let escs = [];
  document.addEventListener("keydown", (e) => {
    if (cerrandoCapa) return;
    const forzar = (e.ctrlKey && e.shiftKey && e.key === "Escape");
    if (!forzar) {
      if (e.key !== "Escape") { escs = []; return; }
      escs.push(Date.now());
      escs = escs.filter((t) => Date.now() - t < 1500);
      if (escs.length < 3) return;
    }
    escs = [];
    [...document.querySelectorAll(".modal-back")].reverse().forEach(cerrarCapa);
    const alerta = document.getElementById("bascula-desconectada");
    if (alerta) alerta.classList.remove("is-show");
    devolverFoco();
    basculaToast("🔓 Pantalla liberada. Ya puedes escribir.");
  }, true);

  // Clic en una zona vacía: si el foco se perdió y no hay modal, recupera el cursor.
  document.addEventListener("mousedown", (e) => {
    if (!usuarioActual) return;
    if (document.querySelector(".modal-back")) return;
    if (e.target && typeof e.target.closest === "function") {
      if (e.target.closest("input, textarea, select, button, a, [contenteditable='true'], .modal-back")) return;
    }
    setTimeout(() => {
      const a = document.activeElement;
      if (a && a !== document.body && esCampoEditable(a)) return;
      devolverFoco();
    }, 0);
  });

  setInterval(limpiarCapasHuerfanas, 4000);
}

function wireReenfoque() {
  const asegurarCursor = () => {
    setTimeout(() => {
      try {
        if (!usuarioActual) return;
        const login = $("#view-login");
        if (login && !login.classList.contains("hidden")) return;
        limpiarCapasHuerfanas();
        if (document.querySelector(".modal-back")) return;
        const a = document.activeElement;
        if (a && a !== document.body && esCampoEditable(a)) return;
        devolverFoco();
      } catch (e) {}
    }, 40);
  };
  window.addEventListener("focus", asegurarCursor);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) asegurarCursor(); });
}

function actualizarUltimaVenta() {
  const cont = document.getElementById("lastsale-content");
  if (!cont) return;
  const t = ultimoTicket;
  if (!t) { cont.innerHTML = '<p class="lastsale__empty">Aún no hay ventas en este turno.</p>'; return; }
  const filas = (t.items || []).map((it) =>
    `<div class="lastsale__row"><span>${escapeHtml(it.nombre)}</span><b>${fmt(it.importeCents)}</b></div>`
  ).join("");
  cont.innerHTML =
    `<div class="lastsale__meta">Folio ${escapeHtml(String(t.folio))}${t.basculaFolio != null ? ` · ⚖️${escapeHtml(String(t.basculaFolio))}` : ""} · ${escapeHtml(t.fecha || "")}</div>` +
    `<div class="lastsale__rows">${filas}</div>` +
    `<div class="lastsale__total"><span>Total</span><b>${fmt(t.totalCents)}</b></div>` +
    `<div class="lastsale__pay">${escapeHtml(t.pagoLabel || "")}${t.cambioCents ? (" · Cambio " + fmt(t.cambioCents)) : ""}</div>` +
    `<button class="btn btn--sec btn--block" id="lastsale-reprint">🖨️ Reimprimir</button>`;
  const rp = document.getElementById("lastsale-reprint");
  if (rp) rp.addEventListener("click", () => mostrarTicket(t, { impreso: false, modo: (CFG && CFG.impresora ? CFG.impresora.modo : "off") }));
}

async function refrescarEnVivo() {
  const punto = document.getElementById("nube-vivo");
  if (punto) {
    punto.classList.add("recibio");
    punto.textContent = "En vivo · actualizado";
    setTimeout(() => { punto.classList.remove("recibio"); punto.textContent = "En vivo"; }, 2500);
  }
  if (document.querySelector(".modal-back")) return;
  const ae = document.activeElement;
  if (ae && esCampoEditable(ae)) return;
  if (document.querySelector(".gan-body") && !document.querySelector(".gan-body.is-locked")) return;
  try { await loadData(); } catch (e) { return; }
  const activo = document.querySelector(".navbtn.is-active");
  if (activo && activo.dataset.module) {
    try { await showModule(activo.dataset.module); } catch (e) {}
    return;
  }
  const buscador = document.getElementById("entry-search");
  if (buscador && typeof renderProducts === "function") {
    try { renderProducts(buscador.value || ""); } catch (e) {}
  }
}

async function init() {
  await loadData();
  // Detecta si ESTA PC es la copia en vivo (oficina administrativa). Lo usamos
  // para mostrar opciones que SOLO aplican en oficina (efectivo casa, etc.).
  try {
    if (window.api && window.api.getAppInfo) {
      const _inf = await window.api.getAppInfo();
      copiaEnVivo = !!(_inf && _inf.copiaEnVivo);
    }
  } catch (_) {}
  renderUsers();
  bindEvents();
  wireUltimaVenta();
  wireAjusteGrid();
  wireReenfoque();
  vigilarBloqueos();
  tickClock();
  setInterval(tickClock, 1000);
  mostrarVersion();
  // Escucha las ventas que llegan automáticamente desde la báscula (Scale Link).
  if (window.api && window.api.bascula) {
    window.api.bascula.onLote((lote) => recibirVentasBascula(lote));
    window.api.bascula.onError((msg) => basculaToast("⚖️ " + msg));
    if (window.api.bascula.onConexion) window.api.bascula.onConexion((info) => onBasculaConexion(info));
  }
  if (window.api && window.api.supabase && window.api.supabase.onEnVivo) {
    window.api.supabase.onEnVivo(() => { refrescarEnVivo(); });
  }
  if (window.api && window.api.actualizador && window.api.actualizador.onEstado) {
    let acAvisado = "";
    window.api.actualizador.onEstado((info) => {
      if (info && info.ok && info.hay && info.version !== acAvisado) {
        acAvisado = info.version;
        basculaToast("🔄 Hay una actualización disponible (v" + info.version + "). Ve a Ajustes → Actualizaciones del sistema para instalarla.");
      }
    });
  }
  iniciarLectorBascula();
}

// Captura de lector de código de barras USB (funciona como teclado). Un lector
// "teclea" los dígitos muy rápido y termina con Enter. Detectamos esa ráfaga y,
// si el código corresponde al formato de la báscula, abrimos el ticket completo
// (que Scale Link ya descargó). No interfiere con la escritura normal porque
// solo actúa ante ráfagas rápidas de dígitos terminadas en Enter.
function iniciarLectorBascula() {
  let buffer = "";
  let ultimo = 0;
  const IDLE_MS = 1500;    // idle largo => descarta una ráfaga vieja a medias

  const largoEsperado = () =>
    ((CFG && CFG.bascula && CFG.bascula.codigoBarras && CFG.bascula.codigoBarras.simbologia) === "UPC12") ? 12 : 13;

  // Borra los dígitos que el lector pudo dejar escritos en el buscador de ventas.
  const limpiarBuscador = () => {
    const s = document.getElementById("entry-search");
    if (s) {
      s.value = "";
      try { renderProducts(""); } catch (e) {}
    }
  };

  // Trata `code` como etiqueta de báscula. Devuelve true si lo tomó (y ya generó
  // la línea/ticket). Si `e` viene, bloquea el Enter para que el buscador no
  // haga además una búsqueda por nombre con los dígitos.
  const procesarCodigo = (code, e) => {
    if (!(code && /^\d+$/.test(code))) return false;
    // El ESCÁNER de etiquetas funciona SIEMPRE que el formato del código esté
    // configurado, AUNQUE las básculas por WiFi estén desactivadas/desconectadas
    // desde Configuración. Son cosas independientes: el lector USB por un lado y
    // el sondeo de básculas por red por el otro. Por eso NO se checa `activa`.
    if (!decodificarCodigoBascula(code)) return false;   // no coincide con el formato de báscula
    if (e) { e.preventDefault(); e.stopImmediatePropagation(); }
    limpiarBuscador();
    // Busca la venta descargada por WiFi y, si no está (o no hay red), arma la
    // línea con el IMPORTE embebido en el código. Así SIEMPRE genera el ticket.
    abrirVentaBasculaPorCodigo(code);
    return true;
  };

  document.addEventListener("keydown", (e) => {
    // No interferir con la pantalla de inicio (pinpad) ni con la sesión cerrada.
    if (!usuarioActual) return;
    const login = $("#view-login");
    if (login && !login.classList.contains("hidden")) return;

    // Protege SIEMPRE la escritura manual en modales y en cualquier campo que NO
    // sea el buscador de ventas. El buscador SÍ participa: justo ahí el lector
    // "escribía" el código y no se generaba el ticket.
    const t = e.target;
    const enBuscador = !!(t && t.id === "entry-search");
    if (esCampoEditable(t) && !enBuscador) { buffer = ""; return; }

    const ahora = Date.now();
    if (ahora - ultimo > IDLE_MS) buffer = "";   // ráfaga vieja: reinicia
    ultimo = ahora;

    // Enter/Tab: fin de ráfaga del lector. Procesa lo acumulado.
    if (e.key === "Enter" || e.key === "Tab") {
      const code = buffer;
      buffer = "";
      procesarCodigo(code, e);
      return;
    }

    if (e.key && e.key.length === 1 && e.key >= "0" && e.key <= "9") {
      buffer += e.key;
      if (buffer.length > 24) buffer = buffer.slice(-24);
      // DISPARO POR LONGITUD: no dependemos del tiempo entre teclas ni de que el
      // lector mande Enter. En cuanto los últimos N dígitos formen un código de
      // báscula VÁLIDO (prefijo + longitud correctos), se genera la línea.
      const esp = largoEsperado();
      if (buffer.length >= esp) {
        const cand = buffer.slice(-esp);
        if (procesarCodigo(cand, e)) { buffer = ""; return; }
      }
    } else if (e.key && e.key.length === 1) {
      // Cualquier carácter no numérico rompe la ráfaga (no es código de báscula).
      buffer = "";
    }
  }, true);
}

async function mostrarVersion() {
  const el = $("#app-version");
  if (!el) return;
  let v = "1.0";
  try { if (window.api && window.api.getAppInfo) { const info = await window.api.getAppInfo(); if (info && info.version) v = info.version; } } catch (e) {}
  el.textContent = "Versión " + v;
}

document.addEventListener("DOMContentLoaded", init);
