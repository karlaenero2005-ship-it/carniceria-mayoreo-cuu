@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

REM ======================================================================
REM   PUBLICAR ACTUALIZACION - Mayoreo de Carnes de Res
REM   Se corre SOLO en la PC de sistemas. Doble clic y sigue las preguntas.
REM   Usa el ejecutable del propio sistema como motor (no requiere instalar
REM   Node por separado).
REM ======================================================================

set "SCRIPT=%~dp0publicar-actualizacion.js"
set "EXE=%~dp0..\..\..\Mayoreo de Carne de Res.exe"

echo ===============================================================
echo    PUBLICAR ACTUALIZACION - Mayoreo de Carnes de Res
echo ===============================================================
echo.
echo  A que PC quieres ENVIAR la actualizacion?
echo.
echo     1) Solo OFICINA
echo     2) Solo CARNICERIA
echo     3) AMBAS
echo.
set /p "OP=Escribe 1, 2 o 3 y pulsa Enter: "

set "CANAL="
if "%OP%"=="1" set "CANAL=oficina"
if "%OP%"=="2" set "CANAL=carniceria"
if "%OP%"=="3" set "CANAL=ambos"

if "%CANAL%"=="" (
  echo.
  echo  Opcion invalida. Vuelve a abrir el archivo e intenta de nuevo.
  echo.
  pause
  exit /b 1
)

echo.
set /p "NOTAS=Escribe en pocas palabras QUE arreglaste: "
if "%NOTAS%"=="" set "NOTAS=Actualizacion"

echo.
echo  Publicando al canal: %CANAL%
echo  Nota: %NOTAS%
echo.

if exist "%EXE%" goto :conEXE

echo  (No encontre el ejecutable; intento con Node instalado...)
node "%SCRIPT%" --canal %CANAL% --notas "%NOTAS%"
goto :fin

:conEXE
set ELECTRON_RUN_AS_NODE=1
"%EXE%" "%SCRIPT%" --canal %CANAL% --notas "%NOTAS%"
set ELECTRON_RUN_AS_NODE=

:fin
echo.
echo ===============================================================
echo  Si viste lineas con "publicado (v...)" quedo subida la
echo  actualizacion. Las PCs de ese canal la veran en unos minutos
echo  (o al abrir el programa) y podran dar "Actualizar sistema".
echo ===============================================================
echo.
pause
