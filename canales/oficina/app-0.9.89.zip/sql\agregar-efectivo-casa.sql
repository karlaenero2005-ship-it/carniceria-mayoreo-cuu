-- Mayoreo de Carnes de Res — tabla NUEVA para abonos "Efectivo casa".
-- Pegar en el editor SQL del proyecto de Superbasa de Mayoreo.
-- NO modifica tablas existentes (clientes, credito_movimientos, caja_movimientos, etc.).
-- Se puede volver a ejecutar sin riesgo.

create table if not exists public.efectivo_casa (
  terminal text not null,
  id text not null,
  cliente_id bigint,
  cliente_nombre text,
  fecha timestamptz,
  monto_cents bigint default 0,
  saldo_cents bigint default 0,
  comentario text,
  nota text,
  aplicaciones jsonb,
  usuario text,
  caja_id bigint,
  activo boolean default true,
  synced_at timestamptz,
  primary key (terminal, id)
);

grant select, insert, update, delete on public.efectivo_casa to service_role;
notify pgrst, 'reload schema';
