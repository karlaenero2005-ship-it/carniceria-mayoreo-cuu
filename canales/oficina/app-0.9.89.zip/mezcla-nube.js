"use strict";

// Junta lo que bajó de Supabase con la base local.
// Las filas que esta PC acaba de cambiar (proteger) no se pisan.
// Si completo es falso, lo que no vino en esta descarga se conserva
// (el historial viejo no se vuelve a bajar en cada ciclo).

function mezclaLista(localArr, remotoArr, idDe, dirty, completo, bajas, cuidarListas) {
  const loc = new Map();
  (localArr || []).forEach((x) => loc.set(String(idDe(x)), x));
  const rem = new Map();
  (remotoArr || []).forEach((x) => {
    const id = String(idDe(x));
    if (bajas && bajas[id]) return;
    rem.set(id, x);
  });
  const out = [];
  const vistos = new Set();
  rem.forEach((r, id) => {
    vistos.add(id);
    const l = loc.get(id);
    if (dirty && dirty[id] && l) out.push(l);
    else if (l) {
      const merged = Object.assign({}, l, r);
      (cuidarListas || []).forEach((campo) => {
        const lv = l[campo];
        const rv = r[campo];
        if (Array.isArray(lv) && lv.length && (!Array.isArray(rv) || !rv.length)) merged[campo] = lv;
      });
      out.push(merged);
    } else out.push(r);
  });
  loc.forEach((l, id) => {
    if (vistos.has(id)) return;
    if (!completo || (dirty && dirty[id])) out.push(l);
  });
  return out;
}

function mezclaCajas(localArr, remotoArr, dirtyCajas, dirtyMovs, completo, bajasMov) {
  const loc = new Map((localArr || []).map((c) => [String(c.id), c]));
  const rem = new Map((remotoArr || []).map((c) => [String(c.id), c]));
  const ids = new Set([...loc.keys(), ...rem.keys()]);
  const out = [];
  ids.forEach((id) => {
    const l = loc.get(id);
    const r = rem.get(id);
    if (!r) {
      if (l && (!completo || (dirtyCajas && dirtyCajas[id]))) out.push(l);
      return;
    }
    if (!l) {
      if (bajasMov && Array.isArray(r.movimientos)) {
        r.movimientos = r.movimientos.filter((m) => !bajasMov.has(id + "|" + m.id));
      }
      out.push(r);
      return;
    }
    if (bajasMov && Array.isArray(r.movimientos)) {
      r.movimientos = r.movimientos.filter((m) => !bajasMov.has(id + "|" + m.id));
    }
    const caja = Object.assign({}, l, r);
    const dirtyDeEsta = {};
    if (dirtyMovs) {
      Object.keys(dirtyMovs).forEach((k) => {
        const partes = k.split("|");
        if (partes[0] === id) dirtyDeEsta[partes[1]] = true;
      });
    }
    // No se borra un movimiento local que la nube todavía no tiene.
    caja.movimientos = mezclaLista(l.movimientos || [], r.movimientos || [], (m) => m.id, dirtyDeEsta, false, null);
    if (!r.ticketImpresion && l.ticketImpresion) caja.ticketImpresion = l.ticketImpresion;
    if (dirtyCajas && dirtyCajas[id]) {
      caja.abierta = l.abierta;
      caja.cierreFecha = l.cierreFecha;
      caja.conteoCents = l.conteoCents;
      caja.corte = l.corte;
      caja.basculaTotalManualCents = l.basculaTotalManualCents;
      caja.paquetesTotalManualCents = l.paquetesTotalManualCents;
      caja.ticketImpresion = l.ticketImpresion || caja.ticketImpresion;
    }
    out.push(caja);
  });
  return out.sort((a, b) => Number(a.id) - Number(b.id));
}

function aplicar(db, parte, opts) {
  opts = opts || {};
  const prot = opts.proteger || {};
  const completo = !!opts.completo;
  const bajas = {};
  const sb = db.syncBajas || {};
  ["clientes", "productos", "pendientes"].forEach((tipo) => {
    bajas[tipo] = {};
    (sb[tipo] || []).forEach((id) => { bajas[tipo][String(id)] = true; });
  });
  const bajasProv = new Set((sb.proveedores || []).map((x) => String(x).toLowerCase()));

  if (Array.isArray(parte.categorias)) {
    db.categorias = mezclaLista(db.categorias, parte.categorias, (x) => x.id, prot.categorias, true, null);
  }
  if (Array.isArray(parte.productos)) {
    db.productos = mezclaLista(db.productos, parte.productos, (x) => x.id, prot.productos, true, bajas.productos);
  }
  if (Array.isArray(parte.paquetes)) {
    db.paquetes = mezclaLista(db.paquetes, parte.paquetes, (x) => x.id, prot.paquetes, true, null);
  }
  if (Array.isArray(parte.usuarios) && parte.usuarios.length) {
    db.usuarios = mezclaLista(db.usuarios, parte.usuarios, (x) => x.id, prot.usuarios, true, null);
  }
  if (Array.isArray(parte.clientes)) {
    // Conserva "clientes casa" locales: no se suben a la nube y no deben
    // borrarse al mezclar con lo que bajó de la otra PC.
    const casaLocal = {};
    (db.clientes || []).forEach((c) => {
      if (c && c.clienteCasa) casaLocal[String(c.id)] = Object.assign({}, c);
    });
    db.clientes = mezclaLista(db.clientes, parte.clientes, (x) => x.id, prot.clientes, true, bajas.clientes, ["movimientos"]);
    Object.keys(casaLocal).forEach((id) => {
      if (bajas.clientes && bajas.clientes[id]) return;
      const prev = casaLocal[id];
      const cur = (db.clientes || []).find((c) => String(c.id) === id);
      if (cur) {
        cur.clienteCasa = true;
        cur.movimientos = prev.movimientos || cur.movimientos || [];
        cur.saldoCents = prev.saldoCents || 0;
      } else {
        db.clientes.push(prev);
      }
    });
    (db.clientes || []).forEach((c) => {
      if (!c) return;
      c.clienteCasa = !!casaLocal[String(c.id)];
    });
  }
  if (Array.isArray(parte.proveedores) && !(prot.proveedores && Object.keys(prot.proveedores).length)) {
    const nombres = parte.proveedores.filter((n) => !bajasProv.has(String(n).toLowerCase()));
    db.proveedores = nombres;
  }
  if (Array.isArray(parte.proveedoresOcultos)) {
    db.proveedoresOcultos = parte.proveedoresOcultos.slice();
  }
  if (Array.isArray(parte.cajas)) {
    const bajasMov = new Set((sb.cajaMovs || []).map(String));
    db.cajas = mezclaCajas(db.cajas, parte.cajas, prot.cajas, prot.movs, true, bajasMov);
  }
  if (Array.isArray(parte.movimientosPendientes)) {
    db.movimientosPendientes = mezclaLista(
      db.movimientosPendientes, parte.movimientosPendientes,
      (x) => x.id, prot.pendientes, true, bajas.pendientes
    );
  }
  if (Array.isArray(parte.ventas)) {
    db.ventas = mezclaLista(db.ventas, parte.ventas, (x) => x.folio, prot.ventas, completo, null, ["items", "pagos"]);
    db.ventas.sort((a, b) => Number(a.folio) - Number(b.folio));
  }
  if (Array.isArray(parte.devoluciones)) {
    db.devoluciones = mezclaLista(db.devoluciones, parte.devoluciones, (x) => x.folio, prot.devoluciones, true, null);
  }
  // La bitácora y el inventario no guardan el id de la nube en el archivo local.
  // En cada ciclo se reemplaza solo la ventana de fechas que se volvió a bajar.
  const huellaMov = (m) => [m && m.fecha, m && m.tipo, m && (m.detalle || ""), m && (m.usuario || ""), m && (m.productoId || ""), m && (m.cant || ""), m && (m.nota || ""), m && (m.folio || "")].join("|");
  const sumarSinPerder = (arr, nuevos) => {
    const base = (arr || []).slice();
    const ya = new Set(base.map(huellaMov));
    (nuevos || []).forEach((m) => {
      const h = huellaMov(m);
      if (!ya.has(h)) { base.push(m); ya.add(h); }
    });
    return base;
  };
  if (Array.isArray(parte.movimientos)) db.movimientos = sumarSinPerder(db.movimientos, parte.movimientos);
  if (Array.isArray(parte.movimientosInv)) db.movimientosInv = sumarSinPerder(db.movimientosInv, parte.movimientosInv);
  if (Array.isArray(parte.apartados)) {
    db.apartados = mezclaLista(db.apartados, parte.apartados, (x) => x.id, prot.apartados, true, null);
  }
  if (Array.isArray(parte.ordenesEspera)) {
    db.ordenesEspera = mezclaLista(db.ordenesEspera, parte.ordenesEspera, (x) => x.id, null, true, null);
  }
  if (Array.isArray(parte.facturas)) {
    db.facturas = mezclaLista(db.facturas, parte.facturas, (x) => x.id, null, true, null);
  }
  // Espejo de abonos "efectivo casa". completo=false: no borra filas locales
  // que aún no están en la nube (evita perder abonos si la descarga viene vacía).
  if (Array.isArray(parte.efectivoCasa)) {
    db.efectivoCasa = mezclaLista(db.efectivoCasa || [], parte.efectivoCasa, (x) => x.id, null, false, null);
  }
  if (Array.isArray(parte.cortesEleventa) && (completo || !(db.cortesEleventa || []).length)) {
    db.cortesEleventa = parte.cortesEleventa;
  }
  if (parte.negocio && !(prot.pos_terminal && Object.keys(prot.pos_terminal).length)) {
    const n = Object.assign({}, parte.negocio);
    delete n._ocultos;
    db.config.negocio = Object.assign({}, db.config.negocio || {}, n);
  }

  const maxFolio = (db.ventas || []).reduce((m, v) => Math.max(m, Number(v.folio) || 0), 0);
  if (maxFolio + 1 > (Number(db.config.folioVenta) || 1)) db.config.folioVenta = maxFolio + 1;
  const maxDev = (db.devoluciones || []).reduce((m, v) => Math.max(m, Number(v.folio) || 0), 0);
  if (maxDev + 1 > (Number(db.config.folioDevolucion) || 1)) db.config.folioDevolucion = maxDev + 1;

  const actual = (db.cajas || []).find((c) => c.id === db.config.cajaActualId);
  if (actual && actual.abierta === false && actual.cierreFecha) db.config.cajaActualId = null;
  if (!db.config.cajaActualId) {
    const abiertas = (db.cajas || []).filter((c) => c.abierta);
    if (abiertas.length) db.config.cajaActualId = abiertas[abiertas.length - 1].id;
  }
  if (opts.habilitarEnvio) db.config.sincronizarNube = true;
  if (completo) db.config.nubeCompleta = true;
}

module.exports = { aplicar };
