"use strict";

/* ============================================================
   Respaldo en la nube (best-effort) hacia un Cloudflare Worker + D1.
   - No bloquea nunca la venta: todo es asíncrono y tolerante a fallos.
   - Si no hay internet, se marca "pendiente" y se reintenta solo.
   - Los datos SIEMPRE viven primero en disco (db.json durable); la nube
     es un espejo que se pone al día cuando hay conexión.
   ============================================================ */

const https = require("https");
const http = require("http");
const zlib = require("zlib");
const { URL } = require("url");

let opts = null;              // { getRespaldo, getSnapshot }
let pendiente = false;        // hay cambios sin respaldar
let debounceTimer = null;
let intervalTimer = null;
const estado = {
  ultimoOk: null,
  ultimoError: null,
  ultimoIntento: null,
  enviando: false
};

function init(o) {
  opts = o;
  reconfigurar();
  // Al arrancar, empuja el estado actual (por si quedó algo sin subir).
  marcarCambio();
}

// Llamado tras cada persist() de la base de datos.
function marcarCambio() {
  pendiente = true;
  if (debounceTimer) clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => { flush(false); }, 2500);
}

// (Re)inicia el temporizador periódico según el intervalo configurado.
function reconfigurar() {
  if (intervalTimer) clearInterval(intervalTimer);
  const cfg = opts ? opts.getRespaldo() : null;
  const seg = Math.max(15, (cfg && cfg.intervaloSeg) || 60);
  intervalTimer = setInterval(() => { flush(false); }, seg * 1000);
  if (intervalTimer.unref) intervalTimer.unref();
}

function httpPost(endpoint, ruta, token, jsonObj, timeoutMs = 15000) {
  return new Promise((resolve) => {
    let url;
    try {
      const base = endpoint.endsWith("/") ? endpoint : endpoint + "/";
      url = new URL(ruta, base);
    } catch (e) {
      return resolve({ ok: false, error: "URL de respaldo inválida" });
    }
    const lib = url.protocol === "http:" ? http : https;
    const body = Buffer.from(JSON.stringify(jsonObj), "utf8");
    const req = lib.request(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": body.length,
        "Authorization": token ? "Bearer " + token : ""
      },
      timeout: timeoutMs
    }, (res) => {
      let data = "";
      res.setEncoding("utf8");
      res.on("data", (c) => (data += c));
      res.on("end", () => {
        const ok = res.statusCode >= 200 && res.statusCode < 300;
        resolve({ ok, status: res.statusCode, body: data });
      });
    });
    req.on("timeout", () => req.destroy(new Error("Tiempo de espera agotado")));
    req.on("error", (e) => resolve({ ok: false, error: e.message }));
    req.write(body);
    req.end();
  });
}

async function flush(force) {
  if (!opts) return { skipped: true };
  const cfg = opts.getRespaldo();
  if (!cfg.activo || !cfg.endpoint) { pendiente = false; return { skipped: true }; }
  if (estado.enviando) return { busy: true };
  if (!force && !pendiente) return { nada: true };

  estado.enviando = true;
  estado.ultimoIntento = new Date().toISOString();
  try {
    const snap = opts.getSnapshot();
    const jsonStr = JSON.stringify(snap.db);
    let encoding = "none";
    let payload = jsonStr;
    if (cfg.comprimir) {
      payload = zlib.gzipSync(Buffer.from(jsonStr, "utf8")).toString("base64");
      encoding = "gzip+base64";
    }
    const r = await httpPost(cfg.endpoint, "backup", cfg.token, {
      tipo: "snapshot",
      terminal: snap.terminal,
      ts: snap.ts,
      encoding,
      bytes: Buffer.byteLength(jsonStr, "utf8"),
      payload
    });
    if (r.ok) {
      estado.ultimoOk = new Date().toISOString();
      estado.ultimoError = null;
      pendiente = false;
    } else {
      estado.ultimoError = r.error || ("HTTP " + r.status + " " + (r.body || "")).trim();
    }
    return r;
  } catch (e) {
    estado.ultimoError = String(e && e.message ? e.message : e);
    return { ok: false, error: estado.ultimoError };
  } finally {
    estado.enviando = false;
  }
}

async function probar() {
  if (!opts) return { ok: false, error: "Respaldo no inicializado." };
  const cfg = opts.getRespaldo();
  if (!cfg.endpoint) return { ok: false, error: "Falta la dirección (endpoint) del respaldo." };
  const r = await httpPost(cfg.endpoint, "ping", cfg.token, {
    tipo: "ping", terminal: opts.getSnapshot().terminal, ts: new Date().toISOString()
  });
  if (r.ok) { estado.ultimoOk = new Date().toISOString(); estado.ultimoError = null; return { ok: true }; }
  estado.ultimoError = r.error || ("HTTP " + r.status + " " + (r.body || "")).trim();
  return { ok: false, error: estado.ultimoError };
}

async function sincronizarAhora() {
  const r = await flush(true);
  return Object.assign({}, estadoActual(), { resultado: r });
}

function estadoActual() {
  const cfg = opts ? opts.getRespaldo() : {};
  return {
    activo: !!cfg.activo,
    configurado: !!cfg.endpoint,
    intervaloSeg: cfg.intervaloSeg || 60,
    ultimoOk: estado.ultimoOk,
    ultimoError: estado.ultimoError,
    ultimoIntento: estado.ultimoIntento,
    enviando: estado.enviando,
    pendiente
  };
}

module.exports = { init, marcarCambio, reconfigurar, flush, probar, sincronizarAhora, estadoActual };
