"use strict";
/*
  Importador de datos desde ELEVENTA (antiguo sistema de punto de venta).

  ELEVENTA guarda su información en una base de datos Firebird llamada
  PDVDATA.FDB, normalmente en:
    - eleventa MonoCaja:  C:\\Program Files (x86)\\AbarrotesPDV\\db\\PDVDATA.FDB
    - eleventa MultiCaja: C:\\Program Files (x86)\\AbarrotesMultiCaja\\db\\PDVDATA.FDB

  Conexión típica: host localhost, puerto 3050, usuario SYSDBA, clave masterkey.
  (MonoCaja usa Firebird embebido: para leerlo desde fuera hay que tener un
   servidor Firebird 2.5 corriendo; MultiCaja ya incluye el servidor.)

  Tabla principal PRODUCTOS: CODIGO, DESCRIPCION, PVENTA, PFINAL, PCOSTO,
  DEPT, MEDIDA_ID, ELIMINADO_EN (NULL = activo).

  Este módulo es "introspectivo": primero lee el esquema real de la base
  (RDB$RELATIONS / RDB$RELATION_FIELDS) y solo usa las columnas que existen,
  para tolerar diferencias entre versiones y evitar fallas.
*/

let Firebird = null;
try { Firebird = require("node-firebird"); } catch (_) { Firebird = null; }

function opciones(cfg) {
  cfg = cfg || {};
  return {
    host: cfg.host || "localhost",
    port: cfg.port || 3050,
    database: cfg.database || cfg.archivo,
    user: cfg.user || "SYSDBA",
    password: cfg.password || "masterkey",
    lowercase_keys: false,
    role: null,
    pageSize: 4096,
    encoding: "ISO8859_1"
  };
}

function attach(opts) {
  return new Promise((res, rej) => {
    if (!Firebird) return rej(new Error("El componente de lectura Firebird no está disponible."));
    Firebird.attach(opts, (err, db) => (err ? rej(err) : res(db)));
  });
}
function query(db, sql, params) {
  return new Promise((res, rej) => db.query(sql, params || [], (err, r) => (err ? rej(err) : res(r))));
}
function s(v) { return v == null ? "" : String(v).trim(); }
function num(v) { const n = parseFloat(v); return isNaN(n) ? 0 : n; }

async function conColumnas(db, tabla) {
  const rows = await query(db,
    "SELECT TRIM(rf.RDB$FIELD_NAME) AS F FROM RDB$RELATION_FIELDS rf WHERE rf.RDB$RELATION_NAME = ? ORDER BY rf.RDB$FIELD_POSITION",
    [tabla]);
  return rows.map((r) => s(r.F));
}
async function tablas(db) {
  const rows = await query(db,
    "SELECT TRIM(RDB$RELATION_NAME) AS T FROM RDB$RELATIONS WHERE RDB$SYSTEM_FLAG = 0 AND RDB$VIEW_BLR IS NULL");
  return rows.map((r) => s(r.T));
}
// Devuelve la primera columna existente de una lista de candidatos.
function primera(cols, candidatos) {
  const set = new Set(cols.map((c) => c.toUpperCase()));
  for (const c of candidatos) if (set.has(c.toUpperCase())) return c.toUpperCase();
  return null;
}
// Primera columna cuyo nombre contiene alguno de los patrones (y ninguno excluido).
function porPatron(cols, incluye, excluye) {
  excluye = excluye || [];
  for (const c of cols) {
    const u = c.toUpperCase();
    if (incluye.some((p) => u.includes(p)) && !excluye.some((p) => u.includes(p))) return u;
  }
  return null;
}

/* ---------- Prueba de conexión ---------- */
async function probar(cfg) {
  if (!Firebird) return { error: "No se pudo cargar el lector de Firebird (node-firebird)." };
  let db;
  try {
    db = await attach(opciones(cfg));
    await query(db, "SELECT 1 FROM RDB$DATABASE");
    return { ok: true };
  } catch (e) {
    return { error: traducirError(e) };
  } finally {
    if (db) try { db.detach(); } catch (_) {}
  }
}

/* ---------- Vista previa (qué se encontró) ---------- */
async function analizar(cfg) {
  if (!Firebird) return { error: "No se pudo cargar el lector de Firebird (node-firebird)." };
  let db;
  try {
    db = await attach(opciones(cfg));
    const ts = await tablas(db);
    const set = new Set(ts.map((t) => t.toUpperCase()));
    const cuenta = async (t) => {
      if (!set.has(t)) return null;
      try { const r = await query(db, `SELECT COUNT(*) AS N FROM ${t}`); return num(r[0].N); }
      catch (_) { return null; }
    };
    return {
      ok: true,
      productos: await cuenta("PRODUCTOS"),
      departamentos: await cuenta("DEPARTAMENTOS"),
      clientes: await cuenta("CLIENTES"),
      ventas: await cuenta("VENTAS"),
      tablas: ts
    };
  } catch (e) {
    return { error: traducirError(e) };
  } finally {
    if (db) try { db.detach(); } catch (_) {}
  }
}

/* ---------- Lectura de catálogos ---------- */
async function leerDepartamentos(db, set) {
  const mapa = {};
  if (!set.has("DEPARTAMENTOS")) return mapa;
  const cols = await conColumnas(db, "DEPARTAMENTOS");
  const idc = primera(cols, ["ID", "DEPT", "DEPARTAMENTO_ID"]);
  const nomc = primera(cols, ["NOMBRE", "DESCRIPCION", "DEPARTAMENTO"]);
  if (!idc || !nomc) return mapa;
  const rows = await query(db, `SELECT ${idc} AS ID, ${nomc} AS NOMBRE FROM DEPARTAMENTOS`);
  for (const r of rows) mapa[s(r.ID)] = s(r.NOMBRE) || "General";
  return mapa;
}

async function leerProductos(db, set, deptMapa) {
  if (!set.has("PRODUCTOS")) return [];
  const cols = await conColumnas(db, "PRODUCTOS");
  const c = {
    id: primera(cols, ["ID"]),
    codigo: primera(cols, ["CODIGO"]),
    desc: primera(cols, ["DESCRIPCION", "NOMBRE"]),
    pventa: primera(cols, ["PVENTA", "PFINAL", "PRECIO", "PRECIO_VENTA"]),
    pfinal: primera(cols, ["PFINAL", "PVENTA"]),
    pcosto: primera(cols, ["PCOSTO", "COSTO", "PRECIO_COSTO"]),
    dept: primera(cols, ["DEPT", "DEPARTAMENTO_ID", "DEPARTAMENTO"]),
    exist: porPatron(cols, ["INVENTARIO", "EXISTENCIA", "STOCK"], ["MINIMO", "MAXIMO", "MIN", "MAX", "USA", "UTILIZA", "MANEJA", "CONTROL", "ACTIVO"]),
    min: porPatron(cols, ["MINIMO", "INVENTARIO_MIN", "STOCK_MIN"], ["MAXIMO"]),
    usaInv: primera(cols, ["USA_INVENTARIO", "UTILIZA_INVENTARIO", "CONTROL_INVENTARIO", "MANEJA_INVENTARIO", "INVENTARIO_ACTIVO", "CONTROLA_INVENTARIO"]),
    granel: porPatron(cols, ["GRANEL", "SE_VENDE", "PESADO", "FRACCION"], []),
    borrado: primera(cols, ["ELIMINADO_EN", "ELIMINADO", "BORRADO", "ACTIVO"])
  };
  if (!c.desc) return [];
  const sel = ["p." + (c.id || "CODIGO") + " AS PID", "p." + c.desc + " AS DESCRIPCION"];
  if (c.codigo) sel.push("p." + c.codigo + " AS CODIGO");
  if (c.pventa) sel.push("p." + c.pventa + " AS PVENTA");
  if (c.pfinal && c.pfinal !== c.pventa) sel.push("p." + c.pfinal + " AS PFINAL");
  if (c.pcosto) sel.push("p." + c.pcosto + " AS PCOSTO");
  if (c.dept) sel.push("p." + c.dept + " AS DEPT");
  if (c.exist) sel.push("p." + c.exist + " AS EXIST");
  if (c.min) sel.push("p." + c.min + " AS EXISTMIN");
  if (c.usaInv) sel.push("p." + c.usaInv + " AS USAINV");
  if (c.granel) sel.push("p." + c.granel + " AS GRANEL");
  if (c.borrado) sel.push("p." + c.borrado + " AS BORRADO");

  let sql = `SELECT ${sel.join(", ")} FROM PRODUCTOS p`;
  // Solo activos si hay bandera de eliminado (ELIMINADO_EN IS NULL).
  if (c.borrado === "ELIMINADO_EN" || c.borrado === "ELIMINADO" || c.borrado === "BORRADO") {
    sql += ` WHERE p.${c.borrado} IS NULL`;
  }

  const rows = await query(db, sql);
  return rows.map((r) => {
    const precio = num(r.PVENTA != null ? r.PVENTA : r.PFINAL);
    const granel = esGranel(r.GRANEL);
    // Controla inventario: usa la bandera de ELEVENTA si existe; si no, se
    // asume que sí controla cuando trae una columna de existencias.
    let controla;
    if (c.usaInv) controla = esBandera(r.USAINV);
    else controla = c.exist != null;
    return {
      codigo: s(r.CODIGO) || s(r.PID),
      nombre: s(r.DESCRIPCION) || "Producto",
      precio: precio,
      costo: num(r.PCOSTO),
      cat: (c.dept && deptMapa[s(r.DEPT)]) ? deptMapa[s(r.DEPT)] : "General",
      unidad: granel ? "kg" : "pza",
      controlaInventario: controla,
      existencia: r.EXIST != null ? num(r.EXIST) : 0,
      stockMin: r.EXISTMIN != null ? num(r.EXISTMIN) : 0
    };
  });
}
function esGranel(v) {
  if (v == null) return false;
  const t = String(v).trim().toUpperCase();
  return t === "1" || t === "T" || t === "TRUE" || t === "GRANEL" || t === "KG" || t === "PESADO" || t === "Y";
}
function esBandera(v) {
  if (v == null) return false;
  const t = String(v).trim().toUpperCase();
  return t === "1" || t === "T" || t === "TRUE" || t === "S" || t === "SI" || t === "Y";
}

async function leerClientes(db, set) {
  if (!set.has("CLIENTES")) return [];
  const cols = await conColumnas(db, "CLIENTES");
  const c = {
    id: primera(cols, ["ID"]),
    nombre: primera(cols, ["NOMBRE", "DESCRIPCION", "RAZON_SOCIAL"]),
    tel: primera(cols, ["TELEFONO", "TEL", "CELULAR"]),
    rfc: primera(cols, ["RFC"]),
    dir: primera(cols, ["DIRECCION", "DOMICILIO"]),
    saldo: primera(cols, ["SALDO", "SALDO_ACTUAL", "DEUDA"]),
    limite: primera(cols, ["LIMITE_CREDITO", "LIMITE", "CREDITO_LIMITE"]),
    borrado: primera(cols, ["ELIMINADO_EN", "ELIMINADO", "BORRADO"])
  };
  if (!c.nombre) return [];
  const sel = [];
  if (c.nombre) sel.push(c.nombre + " AS NOMBRE");
  if (c.tel) sel.push(c.tel + " AS TELEFONO");
  if (c.rfc) sel.push(c.rfc + " AS RFC");
  if (c.dir) sel.push(c.dir + " AS DIRECCION");
  if (c.saldo) sel.push(c.saldo + " AS SALDO");
  if (c.limite) sel.push(c.limite + " AS LIMITE");
  let sql = `SELECT ${sel.join(", ")} FROM CLIENTES`;
  if (c.borrado === "ELIMINADO_EN") sql += ` WHERE ${c.borrado} IS NULL`;
  const rows = await query(db, sql);
  return rows
    .map((r) => ({
      nombre: s(r.NOMBRE),
      telefono: s(r.TELEFONO),
      rfc: s(r.RFC),
      direccion: s(r.DIRECCION),
      saldoCents: Math.round(num(r.SALDO) * 100),
      limiteCents: Math.round(num(r.LIMITE) * 100)
    }))
    .filter((x) => x.nombre && x.nombre.toUpperCase() !== "PUBLICO EN GENERAL" && x.nombre.toUpperCase() !== "PÚBLICO EN GENERAL");
}

/* ---------- Importación completa (catálogo) ---------- */
async function importar(cfg) {
  if (!Firebird) return { error: "No se pudo cargar el lector de Firebird (node-firebird)." };
  let db;
  try {
    db = await attach(opciones(cfg));
    const ts = await tablas(db);
    const set = new Set(ts.map((t) => t.toUpperCase()));
    const deptMapa = await leerDepartamentos(db, set);
    const productos = await leerProductos(db, set, deptMapa);
    let clientes = [];
    try { clientes = await leerClientes(db, set); } catch (_) { clientes = []; }
    const categorias = [...new Set(productos.map((p) => p.cat))].filter(Boolean);
    return {
      ok: true,
      datos: { productos, clientes, categorias },
      resumen: { productos: productos.length, clientes: clientes.length, categorias: categorias.length }
    };
  } catch (e) {
    return { error: traducirError(e) };
  } finally {
    if (db) try { db.detach(); } catch (_) {}
  }
}

/* ---------- Importación OPERATIVA (ventas, clientes, créditos, cortes, devoluciones) ----------
   NO toca inventario/productos. Trae clientes con su crédito/saldo y facturación,
   las ventas recientes (ventana de días), devoluciones recientes y los cortes
   (resumen por día/caja). Pensado para migrar la operación desde ELEVENTA. */
function isoFecha(v) {
  if (v == null) return null;
  if (v instanceof Date) return v.toISOString();
  return String(v);
}
function mapFormaPago(cod) {
  const c = String(cod == null ? "" : cod).trim().toLowerCase();
  const m = { e: "efectivo", t: "tarjeta", c: "credito", d: "dolares", v: "vales", s: "transferencia", m: "combinado", q: "otro" };
  return m[c] || "otro";
}
function nombreCompleto(nombres, apellidos) {
  return [s(nombres), s(apellidos)].filter(Boolean).join(" ").trim();
}

async function importarOperativo(cfg, opciones2) {
  if (!Firebird) return { error: "No se pudo cargar el lector de Firebird (node-firebird)." };
  opciones2 = opciones2 || {};
  const dias = Math.max(0, parseInt(opciones2.dias, 10) || 30);
  // Ventana en UTC (los timestamps vienen etiquetados en UTC).
  const cutoff = new Date(Date.now() - dias * 86400000).toISOString().slice(0, 19).replace("T", " ");
  let db;
  try {
    db = await attach(opciones(cfg));
    const ts = await tablas(db);
    const set = new Set(ts.map((t) => t.toUpperCase()));

    // ----- Clientes (con crédito y facturación) -----
    let clientes = [];
    if (set.has("CLIENTESV2")) {
      const rows = await query(db,
        "SELECT c.ID, c.NOMBRES, c.APELLIDOS, c.TELEFONO, c.EMAIL, c.DOMICILIO1, c.CODIGO_POSTAL, c.DE_SISTEMA, " +
        "cr.TIENE_CREDITO, cr.LIMITE_CREDITO, cr.SALDO_ACTUAL, " +
        "f.RFC, f.REGIMEN_FISCAL, f.CODIGOPOSTAL, f.EMAIL AS FEMAIL " +
        "FROM CLIENTESV2 c " +
        "LEFT JOIN CLIENTESV2_CREDITO cr ON cr.CLIENTESV2_ID = c.ID " +
        "LEFT JOIN CLIENTESV2_FACTURACION f ON f.CLIENTESV2_ID = c.ID " +
        "WHERE c.ID > 2 AND (c.DE_SISTEMA IS NULL OR c.DE_SISTEMA = 0)");
      clientes = rows.map((r) => ({
        oldId: num(r.ID),
        nombre: nombreCompleto(r.NOMBRES, r.APELLIDOS) || "Cliente",
        telefono: s(r.TELEFONO),
        email: s(r.EMAIL) || s(r.FEMAIL),
        direccion: s(r.DOMICILIO1),
        rfc: s(r.RFC),
        regimenFiscal: s(r.REGIMEN_FISCAL),
        codigoPostal: s(r.CODIGO_POSTAL) || s(r.CODIGOPOSTAL),
        creditoActivo: esBandera(r.TIENE_CREDITO),
        limiteCents: Math.round(num(r.LIMITE_CREDITO) * 100),
        saldoCents: Math.round(num(r.SALDO_ACTUAL) * 100)
      })).filter((c) => c.nombre && c.nombre.toUpperCase() !== "PUBLICO EN GENERAL");
    }

    // ----- Ventas recientes -----
    const ventas = [];
    if (set.has("VENTATICKETS")) {
      const cabs = await query(db,
        "SELECT ID, FOLIO, VENDIDO_EN, SUBTOTAL, TOTAL, FORMA_PAGO, ESTA_CANCELADO, CLIENTESV2_ID, PAGO_CON, NUMERO_ARTICULOS " +
        "FROM VENTATICKETS WHERE (ESTA_ABIERTO = 'f' OR ESTA_ABIERTO IS NULL) AND VENDIDO_EN >= '" + cutoff + "' ORDER BY VENDIDO_EN");
      // Artículos y pagos mixtos de la ventana, agrupados por ticket.
      const artRows = await query(db,
        "SELECT a.TICKET_ID, a.PRODUCTO_NOMBRE, a.CANTIDAD, a.PRECIO_FINAL, a.TOTAL_ARTICULO, a.FUE_DEVUELTO " +
        "FROM VENTATICKETS_ARTICULOS a JOIN VENTATICKETS t ON t.ID = a.TICKET_ID WHERE t.VENDIDO_EN >= '" + cutoff + "'");
      const artPorTicket = new Map();
      for (const a of artRows) {
        const arr = artPorTicket.get(num(a.TICKET_ID)) || [];
        arr.push({
          tipo: "producto",
          nombre: s(a.PRODUCTO_NOMBRE) || "Producto",
          cant: num(a.CANTIDAD) || 1,
          unidad: (num(a.CANTIDAD) % 1 !== 0) ? "kg" : "pza",
          precioCents: Math.round(num(a.PRECIO_FINAL) * 100),
          importeCents: Math.round(num(a.TOTAL_ARTICULO) * 100)
        });
        artPorTicket.set(num(a.TICKET_ID), arr);
      }
      let mixtos = new Map();
      if (set.has("PAGOS_MIXTOS")) {
        const pmRows = await query(db,
          "SELECT pm.TICKET_ID, pm.FORMA_DE_PAGO, pm.MONTO FROM PAGOS_MIXTOS pm JOIN VENTATICKETS t ON t.ID = pm.TICKET_ID WHERE t.VENDIDO_EN >= '" + cutoff + "'");
        for (const p of pmRows) {
          if (p.TICKET_ID == null) continue;
          const arr = mixtos.get(num(p.TICKET_ID)) || [];
          arr.push({ metodo: mapFormaPago(p.FORMA_DE_PAGO), montoCents: Math.round(num(p.MONTO) * 100) });
          mixtos.set(num(p.TICKET_ID), arr);
        }
      }
      for (const c of cabs) {
        const id = num(c.ID);
        const pago = mapFormaPago(c.FORMA_PAGO);
        const pagos = pago === "combinado" ? (mixtos.get(id) || []) : null;
        ventas.push({
          folio: num(c.FOLIO) || id,
          fecha: isoFecha(c.VENDIDO_EN),
          subtotalCents: Math.round(num(c.SUBTOTAL) * 100),
          totalCents: Math.round(num(c.TOTAL) * 100),
          pago,
          pagos: pagos && pagos.length ? pagos : undefined,
          cancelada: esBandera(c.ESTA_CANCELADO) || String(s(c.ESTA_CANCELADO)).toLowerCase() === "t",
          clienteOldId: c.CLIENTESV2_ID != null ? num(c.CLIENTESV2_ID) : null,
          recibidoCents: Math.round(num(c.PAGO_CON) * 100),
          items: artPorTicket.get(id) || []
        });
      }
    }

    // ----- Devoluciones recientes -----
    const devoluciones = [];
    if (set.has("DEVOLUCIONES")) {
      const rows = await query(db,
        "SELECT ID, TICKET_ID, DEVUELTO_EN, TOTAL_DEVUELTO, CAJERO FROM DEVOLUCIONES WHERE DEVUELTO_EN >= '" + cutoff + "'");
      for (const d of rows) {
        devoluciones.push({
          folio: num(d.ID),
          ticketOldId: d.TICKET_ID != null ? num(d.TICKET_ID) : null,
          fecha: isoFecha(d.DEVUELTO_EN),
          totalCents: Math.round(num(d.TOTAL_DEVUELTO) * 100),
          pago: "efectivo",
          motivo: "Devolución importada de ELEVENTA",
          usuario: s(d.CAJERO)
        });
      }
    }

    // ----- Cortes (resumen por día/caja) -----
    const cortes = [];
    if (set.has("CORTE_OPERACIONES")) {
      const rows = await query(db,
        "SELECT DIA, ID_CAJA, ACUMULADO_VENTAS, ACUMULADO_ENTRADAS, ACUMULADO_SALIDAS, VENTAS_EFECTIVO, VENTAS_TARJETA, VENTAS_CREDITO, VENTAS_TRANSFERENCIA, ABONOS_EFECTIVO, NUMERO_VENTAS FROM CORTE_OPERACIONES ORDER BY DIA DESC");
      for (const r of rows) {
        cortes.push({
          dia: isoFecha(r.DIA),
          caja: num(r.ID_CAJA),
          totalVentasCents: Math.round(num(r.ACUMULADO_VENTAS) * 100),
          entradasCents: Math.round(num(r.ACUMULADO_ENTRADAS) * 100),
          salidasCents: Math.round(num(r.ACUMULADO_SALIDAS) * 100),
          efectivoCents: Math.round(num(r.VENTAS_EFECTIVO) * 100),
          tarjetaCents: Math.round(num(r.VENTAS_TARJETA) * 100),
          creditoCents: Math.round(num(r.VENTAS_CREDITO) * 100),
          transferenciaCents: Math.round(num(r.VENTAS_TRANSFERENCIA) * 100),
          abonosEfectivoCents: Math.round(num(r.ABONOS_EFECTIVO) * 100),
          numVentas: num(r.NUMERO_VENTAS)
        });
      }
    }

    return {
      ok: true,
      datos: { clientes, ventas, devoluciones, cortes, dias },
      resumen: { clientes: clientes.length, ventas: ventas.length, devoluciones: devoluciones.length, cortes: cortes.length, dias }
    };
  } catch (e) {
    return { error: traducirError(e) };
  } finally {
    if (db) try { db.detach(); } catch (_) {}
  }
}

function traducirError(e) {
  const m = (e && e.message) ? e.message : String(e);
  if (/ECONNREFUSED|connect/i.test(m)) return "No se pudo conectar al servidor Firebird. Verifica que ELEVENTA/Firebird esté instalado y el servicio activo (puerto 3050).";
  if (/no such file|I\/O error|not exist|cannot find/i.test(m)) return "No se encontró el archivo PDVDATA.FDB en la ruta indicada.";
  if (/password|login|user name/i.test(m)) return "Usuario o contraseña de Firebird incorrectos (por defecto SYSDBA / masterkey).";
  return "Error al leer ELEVENTA: " + m;
}

module.exports = { probar, analizar, importar, importarOperativo };
