-- ============================================================================
-- Preparación para sincronización INCREMENTAL (bajar solo lo que cambió) y para
-- identificar el crédito de clientes por uid estable (evitar choques entre PCs).
--
-- Es SEGURO y REPETIBLE: usa "if not exists" y no borra datos. No cambia el
-- comportamiento de la app por sí solo; el código nuevo (cuando se active y se
-- pruebe) es el que empezará a aprovechar estas columnas.
--
-- Cómo correrlo: en Supabase -> SQL Editor -> pegar todo -> Run.
-- Requisito: el proyecto debe estar DESBLOQUEADO (sin el 402 de cuota).
-- ============================================================================

-- 1) Función común que sella la fecha de última modificación en cada UPDATE.
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- 2) Agrega updated_at + disparador a TODAS las tablas que se sincronizan.
--    (default now() cubre los INSERT; el trigger cubre los UPDATE/upsert.)
do $$
declare
  t text;
  tablas text[] := array[
    'pos_terminal','categorias','productos','paquetes','usuarios','clientes',
    'credito_movimientos','cajas','caja_movimientos','ventas','venta_items',
    'venta_pagos','devoluciones','devolucion_items','movimientos_inv',
    'movimientos','apartados','facturas','proveedores','proveedores_ocultos',
    'ordenes_espera','movimientos_pendientes','corte_tickets','cortes_eleventa',
    'efectivo_casa'
  ];
begin
  foreach t in array tablas loop
    -- Solo si la tabla existe (por si alguna aún no se creó en este proyecto).
    if to_regclass('public.' || t) is not null then
      execute format(
        'alter table public.%I add column if not exists updated_at timestamptz not null default now()', t);
      execute format('drop trigger if exists trg_%s_updated on public.%I', t, t);
      execute format(
        'create trigger trg_%s_updated before update on public.%I
           for each row execute function public.set_updated_at()', t, t);
    end if;
  end loop;
end $$;

-- 3) Índice por updated_at en las tablas que más crecen (acelera el "dame lo
--    que cambió después de X"). if not exists => repetible.
do $$
declare
  t text;
  grandes text[] := array[
    'ventas','venta_items','venta_pagos','caja_movimientos','credito_movimientos',
    'movimientos','movimientos_inv','movimientos_pendientes','clientes','devoluciones'
  ];
begin
  foreach t in array grandes loop
    if to_regclass('public.' || t) is not null then
      execute format(
        'create index if not exists ix_%s_terminal_updated on public.%I (terminal, updated_at)', t, t);
    end if;
  end loop;
end $$;

-- 4) Crédito de clientes por uid estable (prepara el arreglo anti-choques).
--    Se agrega la columna y se rellena para las filas viejas. El cambio de
--    "llave de conflicto" a uid se hará en el código, ya probado; aquí solo se
--    deja lista la columna. No rompe nada porque el código actual ignora uid.
do $$
begin
  if to_regclass('public.credito_movimientos') is not null then
    alter table public.credito_movimientos add column if not exists uid text;
    -- Relleno determinista para filas existentes sin uid (único por cliente).
    update public.credito_movimientos
       set uid = terminal || '-' || cliente_id || '-' || idx
     where uid is null;
  end if;
end $$;

-- Listo. Después de correr esto una vez, la nube ya guarda "updated_at" en cada
-- fila y el crédito de clientes tiene uid. El siguiente paso es del lado del
-- código (activar la descarga incremental) y se prueba en UNA PC antes de las dos.
