-- ============================================================
-- Mayoreo de Carne de Res — esquema Supabase (PostgreSQL)
-- Pegar TODO este script en: Supabase → SQL Editor → Run
-- ============================================================

-- Terminal / meta
create table if not exists pos_terminal (
  terminal text primary key,
  negocio jsonb,
  synced_at timestamptz default now()
);

-- Catálogo
create table if not exists categorias (
  terminal text not null,
  id text not null,
  nombre text,
  emoji text,
  orden int default 0,
  primary key (terminal, id)
);

create table if not exists productos (
  terminal text not null,
  id bigint not null,
  cat text,
  nombre text,
  precio_cents bigint,
  unidad text,
  controla_inventario boolean default false,
  existencia numeric,
  stock_min numeric,
  activo boolean default true,
  en_panel boolean,
  clave_prod_serv text,
  clave_unidad text,
  iva_tasa numeric,
  primary key (terminal, id)
);

create table if not exists paquetes (
  terminal text not null,
  id text not null,
  nombre text,
  emoji text,
  precio_cents bigint,
  componentes jsonb,
  primary key (terminal, id)
);

-- Usuarios (PIN se sube cifrado en base64 simple; usa service_role y no expongas la key)
create table if not exists usuarios (
  terminal text not null,
  id bigint not null,
  nombre text,
  rol text,
  pin text,
  primary key (terminal, id)
);

-- Clientes y crédito
create table if not exists clientes (
  terminal text not null,
  id bigint not null,
  nombre text,
  telefono text,
  rfc text,
  direccion text,
  notas text,
  email text,
  regimen_fiscal text,
  uso_cfdi text,
  codigo_postal text,
  credito_activo boolean default false,
  limite_cents bigint default 0,
  saldo_cents bigint default 0,
  primary key (terminal, id)
);

create table if not exists credito_movimientos (
  terminal text not null,
  cliente_id bigint not null,
  idx int not null,
  fecha timestamptz,
  tipo text,
  monto_cents bigint,
  saldo_cents bigint,
  nota text,
  comentario text,
  forma_pago text,
  venta_folio bigint,
  usuario text,
  aplicaciones jsonb,
  primary key (terminal, cliente_id, idx)
);

-- Ventas desglosadas
create table if not exists ventas (
  terminal text not null,
  folio bigint not null,
  fecha timestamptz,
  caja_id bigint,
  cliente text,
  usuario text,
  subtotal_cents bigint,
  descuento_cents bigint,
  total_cents bigint,
  pago text,
  recibido_cents bigint,
  cambio_cents bigint,
  cancelada boolean default false,
  cancelada_motivo text,
  credito_cliente_id bigint,
  origen_eleventa boolean,
  bascula_folio text,
  es_apartado_pago boolean,
  origen_bascula jsonb,
  primary key (terminal, folio)
);
alter table ventas add column if not exists origen_bascula jsonb;
alter table ventas add column if not exists cancelada_fecha timestamptz;
alter table ventas add column if not exists saldo_cliente_cents bigint;
alter table ventas add column if not exists tipo_cambio numeric;
alter table ventas add column if not exists dolares_recibidos numeric;
alter table ventas add column if not exists nota_apartado text;

create table if not exists venta_items (
  terminal text not null,
  venta_folio bigint not null,
  idx int not null,
  tipo text,
  nombre text,
  cant numeric,
  unidad text,
  precio_cents bigint,
  importe_cents bigint,
  ref_id bigint,
  producto_id bigint,
  bascula boolean,
  manual boolean,
  primary key (terminal, venta_folio, idx)
);
alter table venta_items add column if not exists producto_id bigint;
alter table venta_items add column if not exists bascula boolean;
alter table venta_items add column if not exists manual boolean;
alter table venta_items add column if not exists componentes jsonb;
alter table venta_items add column if not exists extras jsonb;

create table if not exists venta_pagos (
  terminal text not null,
  venta_folio bigint not null,
  idx int not null,
  metodo text,
  monto_cents bigint,
  primary key (terminal, venta_folio, idx)
);

-- Devoluciones
create table if not exists devoluciones (
  terminal text not null,
  folio bigint not null,
  fecha timestamptz,
  caja_id bigint,
  venta_folio bigint,
  total_cents bigint,
  pago text,
  motivo text,
  usuario text,
  primary key (terminal, folio)
);

create table if not exists devolucion_items (
  terminal text not null,
  devolucion_folio bigint not null,
  idx int not null,
  nombre text,
  cant numeric,
  unidad text,
  importe_cents bigint,
  primary key (terminal, devolucion_folio, idx)
);

-- Caja / cortes
create table if not exists cajas (
  terminal text not null,
  id bigint not null,
  usuario text,
  fondo_cents bigint,
  tipo_cambio numeric,
  apertura_fecha timestamptz,
  cierre_fecha timestamptz,
  abierta boolean,
  conteo_cents bigint,
  corte jsonb,
  bascula_total_manual_cents bigint,
  paquetes_total_manual_cents bigint,
  dinero_en_caja_cierre_cents bigint,
  entregado_cents bigint,
  primary key (terminal, id)
);
alter table cajas add column if not exists bascula_total_manual_cents bigint;
alter table cajas add column if not exists paquetes_total_manual_cents bigint;
alter table cajas add column if not exists dinero_en_caja_cierre_cents bigint;
alter table cajas add column if not exists entregado_cents bigint;

create table if not exists caja_movimientos (
  terminal text not null,
  caja_id bigint not null,
  id bigint not null,
  fecha timestamptz,
  tipo text,
  monto_cents bigint,
  motivo text,
  proveedor text,
  categoria text,
  forma_pago text,
  cliente text,
  usuario text,
  cantidad numeric,
  pendiente_id bigint,
  primary key (terminal, caja_id, id)
);
alter table caja_movimientos add column if not exists cantidad numeric;
alter table caja_movimientos add column if not exists pendiente_id bigint;

-- Inventario y bitácora
create table if not exists movimientos_inv (
  terminal text not null,
  id bigserial,
  fecha timestamptz,
  producto_id bigint,
  tipo text,
  cant numeric,
  existencia numeric,
  folio bigint,
  nota text,
  usuario text,
  primary key (terminal, id)
);

create table if not exists movimientos (
  terminal text not null,
  id bigserial,
  fecha timestamptz,
  tipo text,
  usuario text,
  detalle text,
  primary key (terminal, id)
);

-- Apartados / facturas (por si hay)
create table if not exists apartados (
  terminal text not null,
  id bigint not null,
  data jsonb,
  primary key (terminal, id)
);

create table if not exists facturas (
  terminal text not null,
  id text not null,
  data jsonb,
  primary key (terminal, id)
);

-- Cortes históricos importados de ELEVENTA (resumen por día/caja)
create table if not exists cortes_eleventa (
  terminal text not null,
  dia date not null,
  caja int not null default 1,
  total_ventas_cents bigint,
  entradas_cents bigint,
  salidas_cents bigint,
  efectivo_cents bigint,
  tarjeta_cents bigint,
  credito_cents bigint,
  transferencia_cents bigint,
  abonos_efectivo_cents bigint,
  num_ventas int,
  primary key (terminal, dia, caja)
);

create table if not exists proveedores (
  terminal text not null,
  idx int not null,
  nombre text,
  clave text,
  primary key (terminal, idx)
);
alter table proveedores add column if not exists clave text;

create table if not exists proveedores_ocultos (
  terminal text not null,
  clave text not null,
  primary key (terminal, clave)
);

create table if not exists ordenes_espera (
  terminal text not null,
  id bigint not null,
  data jsonb,
  primary key (terminal, id)
);

-- Créditos / compras pendientes a proveedor (no caducan si siguen abiertos)
create table if not exists movimientos_pendientes (
  terminal text not null,
  id bigint not null,
  fecha timestamptz,
  tipo text,
  categoria text,
  monto_cents bigint,
  motivo text,
  proveedor text,
  forma_pago text,
  cantidad numeric,
  estado text,
  usuario text,
  pago_fecha timestamptz,
  pago_forma text,
  pago_caja_id bigint,
  pago_mov_id bigint,
  abono_de bigint,
  primary key (terminal, id)
);

-- Ticket de corte listo para reimprimir en otra PC (mismo formato printer.lineasCorte)
create table if not exists corte_tickets (
  terminal text not null,
  caja_id bigint not null,
  dia date,
  abierta boolean,
  cajero text,
  formato text,
  ticket jsonb not null,
  updated_at timestamptz,
  primary key (terminal, caja_id)
);
create index if not exists idx_corte_tickets_dia on corte_tickets (terminal, dia);

-- Log de sincronización
create table if not exists sync_log (
  id bigserial primary key,
  terminal text,
  started_at timestamptz,
  finished_at timestamptz,
  ok boolean,
  detalle jsonb
);

-- Índices útiles
create index if not exists idx_ventas_fecha on ventas (terminal, fecha);
create index if not exists idx_ventas_pago on ventas (terminal, pago);
create index if not exists idx_credito_cliente on credito_movimientos (terminal, cliente_id);
create index if not exists idx_caja_mov_fecha on caja_movimientos (terminal, fecha);

-- RLS: desactivado para service_role; si usas anon key, habilita políticas propias.
alter table pos_terminal enable row level security;
alter table categorias enable row level security;
alter table productos enable row level security;
alter table paquetes enable row level security;
alter table usuarios enable row level security;
alter table clientes enable row level security;
alter table credito_movimientos enable row level security;
alter table ventas enable row level security;
alter table venta_items enable row level security;
alter table venta_pagos enable row level security;
alter table devoluciones enable row level security;
alter table devolucion_items enable row level security;
alter table cajas enable row level security;
alter table caja_movimientos enable row level security;
alter table movimientos_inv enable row level security;
alter table movimientos enable row level security;
alter table apartados enable row level security;
alter table facturas enable row level security;
alter table cortes_eleventa enable row level security;
alter table movimientos_pendientes enable row level security;
alter table corte_tickets enable row level security;
alter table proveedores enable row level security;
alter table proveedores_ocultos enable row level security;
alter table ordenes_espera enable row level security;
alter table sync_log enable row level security;

-- Políticas abiertas SOLO si usas la "service_role" key desde el POS (recomendado).
-- Con service_role, RLS no aplica. Si usas anon key, crea políticas restrictivas.-- ============================================================
-- Ventana móvil: en la nube solo los ÚLTIMOS 2 AÑOS de historial
-- Pegar en Supabase → SQL Editor → Run (una sola vez)
-- ============================================================
-- SE BORRA (al pasar de 2 años, conforme avanzan los meses):
--   ventas, ítems, pagos, devoluciones, cajas cerradas viejas,
--   cortes ELEVENTA, bitácoras, sync_log antiguos
--
-- NUNCA SE TOCA (permanece siempre):
--   clientes, credito_movimientos, productos, categorías,
--   paquetes, usuarios, pos_terminal
-- ============================================================

create or replace function limpiar_historial_pos(p_anos integer default 2)
returns jsonb
language plpgsql
security definer
as $$
declare
  limite_ts timestamptz := now() - make_interval(years => greatest(1, coalesce(p_anos, 2)));
  corte_date date := (limite_ts at time zone 'UTC')::date;
  n_vi bigint := 0;
  n_vp bigint := 0;
  n_v bigint := 0;
  n_di bigint := 0;
  n_d bigint := 0;
  n_cm bigint := 0;
  n_c bigint := 0;
  n_mi bigint := 0;
  n_m bigint := 0;
  n_ce bigint := 0;
  n_sl bigint := 0;
  n_fa bigint := 0;
  n_ap bigint := 0;
  n_ct bigint := 0;
  n_mp bigint := 0;
begin
  -- Hijos de ventas primero
  delete from venta_items vi
    using ventas v
    where vi.terminal = v.terminal and vi.venta_folio = v.folio
      and v.fecha is not null and v.fecha < limite_ts;
  get diagnostics n_vi = row_count;

  delete from venta_pagos vp
    using ventas v
    where vp.terminal = v.terminal and vp.venta_folio = v.folio
      and v.fecha is not null and v.fecha < limite_ts;
  get diagnostics n_vp = row_count;

  delete from ventas where fecha is not null and fecha < limite_ts;
  get diagnostics n_v = row_count;

  delete from devolucion_items di
    using devoluciones d
    where di.terminal = d.terminal and di.devolucion_folio = d.folio
      and d.fecha is not null and d.fecha < limite_ts;
  get diagnostics n_di = row_count;

  delete from devoluciones where fecha is not null and fecha < limite_ts;
  get diagnostics n_d = row_count;

  delete from corte_tickets
    where abierta = false
      and dia is not null
      and dia < corte_date;
  get diagnostics n_ct = row_count;

  delete from caja_movimientos cm
    using cajas c
    where cm.terminal = c.terminal and cm.caja_id = c.id
      and c.abierta = false
      and (
        (c.cierre_fecha is not null and c.cierre_fecha < limite_ts)
        or (c.cierre_fecha is null and c.apertura_fecha is not null and c.apertura_fecha < limite_ts)
      );
  get diagnostics n_cm = row_count;

  delete from cajas
    where abierta = false
      and (
        (cierre_fecha is not null and cierre_fecha < limite_ts)
        or (cierre_fecha is null and apertura_fecha is not null and apertura_fecha < limite_ts)
      );
  get diagnostics n_c = row_count;

  delete from movimientos_inv where fecha is not null and fecha < limite_ts;
  get diagnostics n_mi = row_count;

  delete from movimientos where fecha is not null and fecha < limite_ts;
  get diagnostics n_m = row_count;

  delete from cortes_eleventa where dia < corte_date;
  get diagnostics n_ce = row_count;

  delete from sync_log where coalesce(finished_at, started_at) < limite_ts;
  get diagnostics n_sl = row_count;

  delete from facturas
    where (data->>'fecha') is not null
      and (data->>'fecha')::timestamptz < limite_ts;
  get diagnostics n_fa = row_count;

  delete from apartados
    where (data->>'fecha') is not null
      and (data->>'fecha')::timestamptz < limite_ts;
  get diagnostics n_ap = row_count;

  delete from movimientos_pendientes
    where estado = 'pagado'
      and coalesce(pago_fecha, fecha) is not null
      and coalesce(pago_fecha, fecha) < limite_ts;
  get diagnostics n_mp = row_count;

  -- NO se toca: clientes, credito_movimientos, productos, categorias, paquetes, usuarios

  return jsonb_build_object(
    'ok', true,
    'corte', limite_ts,
    'anos', p_anos,
    'nota', 'clientes y creditos permanecen siempre',
    'borrados', jsonb_build_object(
      'venta_items', n_vi,
      'venta_pagos', n_vp,
      'ventas', n_v,
      'devolucion_items', n_di,
      'devoluciones', n_d,
      'caja_movimientos', n_cm,
      'cajas', n_c,
      'movimientos_inv', n_mi,
      'movimientos', n_m,
      'cortes_eleventa', n_ce,
      'sync_log', n_sl,
      'facturas', n_fa,
      'apartados', n_ap,
      'corte_tickets', n_ct,
      'movimientos_pendientes_pagados', n_mp
    )
  );
end;
$$;

grant execute on function limpiar_historial_pos(integer) to service_role;
grant execute on function limpiar_historial_pos(integer) to anon;
grant execute on function limpiar_historial_pos(integer) to authenticated;

-- Prueba (opcional):
-- select limpiar_historial_pos(2);

