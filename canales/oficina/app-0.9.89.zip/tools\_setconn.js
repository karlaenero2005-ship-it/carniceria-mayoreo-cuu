// Escribe la config de Supabase en db.json de forma SEGURA (respaldo + verificacion).
// Lee los valores de variables de entorno para no dejarlos en el archivo.
const fs = require("fs");
const path = require("path");
const DB = path.join(process.env.DBDIR, "db.json");

const raw = fs.readFileSync(DB, "utf8");
const j = JSON.parse(raw);                    // si el JSON estuviera roto, aqui falla y no toca nada
j.config = j.config || {};
j.config.supabase = Object.assign({}, j.config.supabase, {
  url: process.env.SBURL,
  key: process.env.SBKEY,
  activo: true
});

const out = JSON.stringify(j);
JSON.parse(out);                              // verifica que lo que vamos a escribir es JSON valido
fs.writeFileSync(DB + ".new", out);
JSON.parse(fs.readFileSync(DB + ".new", "utf8")); // re-verifica el archivo escrito
fs.copyFileSync(DB, DB + ".bak-antes-supabase");  // respaldo del original
fs.renameSync(DB + ".new", DB);               // reemplazo atomico

const s = j.config.supabase;
console.log("OK  url=" + s.url + "  activo=" + s.activo + "  bajarCadaMin=" + (s.bajarCadaMin || "(default 120)") + "  keyLen=" + (s.key || "").length);
