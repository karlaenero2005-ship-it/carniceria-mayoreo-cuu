"use strict";
/*
  Puente de integración con básculas TORREY W-LABEL a través de Scale Link.

  Scale Link (software oficial de la báscula) ya hace el trabajo pesado:
    - Programa productos/precios/PLU en la báscula.
    - Recupera automáticamente las ventas/pesadas de la báscula y las guarda
      en su propia base de datos Microsoft Access (BaseDeDatos.mdb), en las
      tablas `Ventas` (encabezado) y `Ventas_Detalle` (cada pesada).

  Este módulo lee esa base en modo SOLO LECTURA y devuelve las ventas nuevas
  para que el POS arme un ticket automáticamente. No modifica nada de Scale
  Link ni habla directamente con la báscula (no requiere el protocolo de red).

  Lectura: se usa el proveedor "Microsoft.ACE.OLEDB.12.0" (el mismo que
  instala y usa Scale Link) invocando PowerShell + ADODB. Así evitamos
  dependencias nativas de Node y usamos exactamente el driver ya presente.

  Uso previsto (Opción A):
    1. En Scale Link: dar de alta la(s) báscula(s) y activar "Activar
       Frecuencia" con un intervalo corto, para que baje las ventas solas.
    2. El POS consulta este puente cada pocos segundos y crea un ticket por
       cada venta nueva de la báscula.
*/

const { execFile } = require("child_process");
const path = require("path");

const RUTA_DEFECTO = "C:\\Torrey\\Scale Link\\BaseDeDatos.mdb";

function rutaMdb(cfg) {
  cfg = cfg || {};
  return String(cfg.ruta || RUTA_DEFECTO);
}

// Ejecuta un script de PowerShell y devuelve su stdout. Se pasa el script
// codificado en Base64 (UTF-16LE) para evitar problemas de comillas/escapes.
function runPowerShell(script) {
  return new Promise((resolve, reject) => {
    const b64 = Buffer.from(script, "utf16le").toString("base64");
    execFile(
      "powershell.exe",
      ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", b64],
      { windowsHide: true, maxBuffer: 64 * 1024 * 1024 },
      (err, stdout, stderr) => {
        if (err) return reject(new Error((stderr && stderr.trim()) || err.message));
        resolve(String(stdout || ""));
      }
    );
  });
}

// Cadena de conexión ACE OLEDB en solo lectura.
function connString(ruta) {
  return "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ruta +
    ";Persist Security Info=True;User ID=Admin;Mode=Read";
}

// Analiza la salida JSON de PowerShell tolerando texto vacío y objetos sueltos.
function parseJson(stdout) {
  const txt = String(stdout || "").trim();
  if (!txt) return null;
  return JSON.parse(txt);
}

/* ---------------- Prueba de conexión / diagnóstico ---------------- */
// Devuelve conteos de tablas y la lista de básculas configuradas en Scale Link.
async function probar(cfg) {
  const ruta = rutaMdb(cfg);
  const cs = connString(ruta);
  const script = `
$ErrorActionPreference='Stop'
try {
  if (-not (Test-Path -LiteralPath '${ruta.replace(/'/g, "''")}')) { '{"error":"NO_FILE"}'; exit }
  $cn = New-Object -ComObject ADODB.Connection
  $cn.Open('${cs.replace(/'/g, "''")}')
  function Cnt($t){ try { $rs=$cn.Execute("SELECT COUNT(*) AS n FROM [$t]"); [int]$rs.Fields.Item('n').Value } catch { -1 } }
  $bas = New-Object System.Collections.ArrayList
  try {
    $rs = $cn.Execute("SELECT id_bascula, nombre, no_serie, dir_ip, puerto, tipo_conec FROM Bascula")
    while (-not $rs.EOF) {
      [void]$bas.Add(@{ id=$rs.Fields.Item('id_bascula').Value; nombre=[string]$rs.Fields.Item('nombre').Value; serie=[string]$rs.Fields.Item('no_serie').Value; ip=[string]$rs.Fields.Item('dir_ip').Value; puerto=$rs.Fields.Item('puerto').Value; conexion=$rs.Fields.Item('tipo_conec').Value })
      $rs.MoveNext()
    }
  } catch {}
  $out = @{ ok=$true; ventas=(Cnt 'Ventas'); detalle=(Cnt 'Ventas_Detalle'); productos=(Cnt 'Productos'); basculas=$bas }
  $cn.Close()
  $out | ConvertTo-Json -Depth 5 -Compress
} catch {
  @{ error=$_.Exception.Message } | ConvertTo-Json -Compress
}
`;
  try {
    const j = parseJson(await runPowerShell(script));
    if (!j) return { error: "No se recibió respuesta del lector de la báscula." };
    if (j.error) return { error: traducirError(j.error, ruta) };
    return {
      ok: true,
      ruta,
      ventas: j.ventas, detalle: j.detalle, productos: j.productos,
      basculas: normalizarBasculas(j.basculas)
    };
  } catch (e) {
    return { error: traducirError(e.message, ruta) };
  }
}

function normalizarBasculas(b) {
  if (!b) return [];
  const arr = Array.isArray(b) ? b : [b];
  return arr.map((x) => ({
    id: x.id, nombre: x.nombre || "", serie: x.serie || "",
    ip: x.ip || "", puerto: x.puerto, conexion: x.conexion
  }));
}

/* ---------------- Lectura de ventas ---------------- */
// Lee las ventas recientes de la báscula (encabezado + líneas) y las agrupa
// por venta. Cada venta trae sus líneas (pesadas) ya normalizadas.
async function leerVentas(cfg) {
  cfg = cfg || {};
  const ruta = rutaMdb(cfg);
  const cs = connString(ruta);
  const tope = Math.max(1, Math.min(2000, parseInt(cfg.tope, 10) || 800));
  const script = `
$ErrorActionPreference='Stop'
try {
  if (-not (Test-Path -LiteralPath '${ruta.replace(/'/g, "''")}')) { '{"error":"NO_FILE"}'; exit }
  $cn = New-Object -ComObject ADODB.Connection
  $cn.Open('${cs.replace(/'/g, "''")}')
  $sqlBase = "SELECT TOP ${tope} v.id_bascula, v.id_Corte, v.id_Venta, v.Folio, v.Fecha, v.Hora, v.Nserie, v.registro, d.Linea, d.Codigo, d.NoPlu, d.Nombre, d.Peso, d.Precio, d.Total, d.Devolucion, d.TipoPLU FROM Ventas v INNER JOIN Ventas_Detalle d ON v.id_bascula=d.id_bascula AND v.id_Corte=d.id_corte AND v.id_Venta=d.id_Venta"
  try { $rs = $cn.Execute($sqlBase + " ORDER BY v.registro DESC") } catch { $rs = $cn.Execute($sqlBase) }
  $rows = New-Object System.Collections.ArrayList
  $n = 0
  while (-not $rs.EOF -and $n -lt ${tope} * 40) {
    [void]$rows.Add(@{
      id_bascula=$rs.Fields.Item('id_bascula').Value
      id_Corte=$rs.Fields.Item('id_Corte').Value
      id_Venta=$rs.Fields.Item('id_Venta').Value
      Folio=$rs.Fields.Item('Folio').Value
      Fecha=[string]$rs.Fields.Item('Fecha').Value
      Hora=[string]$rs.Fields.Item('Hora').Value
      Nserie=[string]$rs.Fields.Item('Nserie').Value
      Linea=$rs.Fields.Item('Linea').Value
      Codigo=[string]$rs.Fields.Item('Codigo').Value
      NoPlu=[string]$rs.Fields.Item('NoPlu').Value
      Nombre=[string]$rs.Fields.Item('Nombre').Value
      Peso=$rs.Fields.Item('Peso').Value
      Precio=$rs.Fields.Item('Precio').Value
      Total=$rs.Fields.Item('Total').Value
      Devolucion=$rs.Fields.Item('Devolucion').Value
      TipoPLU=$rs.Fields.Item('TipoPLU').Value
    })
    $rs.MoveNext(); $n++
  }
  $cn.Close()
  @($rows) | ConvertTo-Json -Depth 4 -Compress
} catch {
  @{ error=$_.Exception.Message } | ConvertTo-Json -Compress
}
`;
  try {
    const j = parseJson(await runPowerShell(script));
    if (j && j.error) return { error: traducirError(j.error, ruta) };
    const rows = !j ? [] : (Array.isArray(j) ? j : [j]);
    return { ok: true, ventas: agrupar(rows) };
  } catch (e) {
    return { error: traducirError(e.message, ruta) };
  }
}

function num(v) { const n = parseFloat(v); return isNaN(n) ? 0 : n; }
function cents(v) { return Math.round(num(v) * 100); }

// Agrupa filas encabezado+línea en ventas con sus líneas.
function agrupar(rows) {
  const mapa = new Map();
  for (const r of rows) {
    const key = [r.id_bascula, r.id_Corte, r.id_Venta].join("|");
    let venta = mapa.get(key);
    if (!venta) {
      venta = {
        key,
        idBascula: r.id_bascula, idCorte: r.id_Corte, idVenta: r.id_Venta,
        folio: r.Folio, fecha: r.Fecha, hora: r.Hora, nserie: r.Nserie,
        lineas: [], totalCents: 0
      };
      mapa.set(key, venta);
    }
    const peso = num(r.Peso);
    const esPeso = peso > 0;
    const dev = num(r.Devolucion) !== 0 || r.Devolucion === true;
    const linea = {
      codigo: (r.Codigo || "").trim(),
      noPlu: (r.NoPlu || "").trim(),
      nombre: (r.Nombre || "").trim() || "Producto",
      cant: esPeso ? peso : 1,
      unidad: esPeso ? "kg" : "pza",
      precioCents: cents(r.Precio),
      importeCents: cents(r.Total),
      devolucion: dev
    };
    venta.lineas.push(linea);
    venta.totalCents += dev ? -linea.importeCents : linea.importeCents;
  }
  return Array.from(mapa.values());
}

function traducirError(m, ruta) {
  m = String(m || "");
  if (m === "NO_FILE") return "No se encontró la base de Scale Link en: " + (ruta || "") + ". Verifica la ruta en Configuración › Báscula.";
  if (/ACE\.OLEDB|proveedor|provider|not registered|no está registrado/i.test(m))
    return "Falta el proveedor Microsoft ACE OLEDB (normalmente lo instala Scale Link). Instala Scale Link o el 'Access Database Engine' de 64 bits.";
  if (/no se puede abrir|cannot open|in use|locked|uso/i.test(m))
    return "No se pudo abrir la base de Scale Link (¿en uso exclusivo?). Se reintentará automáticamente.";
  return "Error al leer la báscula: " + m;
}

module.exports = { probar, leerVentas, RUTA_DEFECTO };
