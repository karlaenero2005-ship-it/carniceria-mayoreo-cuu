const { contextBridge, ipcRenderer } = require("electron");

// Puente seguro entre el proceso principal y la interfaz.
// Expone únicamente operaciones controladas (base de datos local, etc.).
contextBridge.exposeInMainWorld("api", {
  getAppInfo: () => ipcRenderer.invoke("app:info"),
  db: {
    bootstrap: () => ipcRenderer.invoke("db:bootstrap"),
    registrarVenta: (venta) => ipcRenderer.invoke("db:registrarVenta", venta),
    registrarMovimiento: (mov) => ipcRenderer.invoke("db:registrarMovimiento", mov),
    registrarDevolucion: (dev) => ipcRenderer.invoke("db:registrarDevolucion", dev),
    detalleDia: (fecha) => ipcRenderer.invoke("db:detalleDia", fecha),
    resumenIngresosMeses: () => ipcRenderer.invoke("db:resumenIngresosMeses"),
    renombrarUsuario: (id, nombre, pinActual) => ipcRenderer.invoke("db:renombrarUsuario", id, nombre, pinActual),
    crearUsuario: (nombre, pin, rol) => ipcRenderer.invoke("db:crearUsuario", nombre, pin, rol),
    eliminarUsuario: (id) => ipcRenderer.invoke("db:eliminarUsuario", id),
    cambiarPin: (id, pin, pinActual) => ipcRenderer.invoke("db:cambiarPin", id, pin, pinActual),
    guardarProducto: (prod) => ipcRenderer.invoke("db:guardarProducto", prod),
    eliminarProducto: (id) => ipcRenderer.invoke("db:eliminarProducto", id),
    guardarCategoria: (cat) => ipcRenderer.invoke("db:guardarCategoria", cat),
    eliminarCategoria: (id) => ipcRenderer.invoke("db:eliminarCategoria", id),
    getClientes: () => ipcRenderer.invoke("db:getClientes"),
    guardarCliente: (cli) => ipcRenderer.invoke("db:guardarCliente", cli),
    eliminarCliente: (id) => ipcRenderer.invoke("db:eliminarCliente", id),
    limpiarHistorialPantallaCliente: (id) => ipcRenderer.invoke("db:limpiarHistorialPantallaCliente", id),
    getHistorialPantallaDesde: (id) => ipcRenderer.invoke("db:getHistorialPantallaDesde", id),
    getOcultarPagadasCliente: (id) => ipcRenderer.invoke("db:getOcultarPagadasCliente", id),
    setOcultarPagadasCliente: (id, v) => ipcRenderer.invoke("db:setOcultarPagadasCliente", id, v),
    movimientoCredito: (id, tipo, monto, nota, usuario, formaPago) => ipcRenderer.invoke("db:movimientoCredito", id, tipo, monto, nota, usuario, formaPago),
    estadoCuentaCliente: (id) => ipcRenderer.invoke("db:estadoCuentaCliente", id),
    abonarCredito: (id, monto, opciones) => ipcRenderer.invoke("db:abonarCredito", id, monto, opciones),
    cancelarMovimientoCredito: (clienteId, movId) => ipcRenderer.invoke("db:cancelarMovimientoCredito", clienteId, movId),
    resumenCreditos: () => ipcRenderer.invoke("db:resumenCreditos"),
    resumenAuditoria: (periodo, ancla) => ipcRenderer.invoke("db:resumenAuditoria", periodo, ancla),
    corteDia: (fecha) => ipcRenderer.invoke("db:corteDia", fecha),
    // Caja / corte
    reimpresionDia: (fecha) => ipcRenderer.invoke("db:reimpresionDia", fecha),
    movimientosEfectivoDia: (fecha) => ipcRenderer.invoke("db:movimientosEfectivoDia", fecha),
    estadoCaja: () => ipcRenderer.invoke("db:estadoCaja"),
    abrirCaja: (fondoCents, usuario, tipoCambio) => ipcRenderer.invoke("db:abrirCaja", fondoCents, usuario, tipoCambio),
    setFondoInicialCaja: (fondoCents, tipoCambio, usuario) => ipcRenderer.invoke("db:setFondoInicialCaja", fondoCents, tipoCambio, usuario),
    setTipoCambioCaja: (tipoCambio) => ipcRenderer.invoke("db:setTipoCambioCaja", tipoCambio),
    movimientoEfectivo: (tipo, montoCents, motivo, usuario, proveedor, categoria, formaPago, cantidad) => ipcRenderer.invoke("db:movimientoEfectivo", tipo, montoCents, motivo, usuario, proveedor, categoria, formaPago, cantidad),
    getMovimientosPendientes: () => ipcRenderer.invoke("db:getMovimientosPendientes"),
    liberarMovimientoPendiente: (id, formaPago, usuario) => ipcRenderer.invoke("db:liberarMovimientoPendiente", id, formaPago, usuario),
    abonarCreditoProveedor: (proveedor, montoCents, formaPago, usuario, opts) => ipcRenderer.invoke("db:abonarCreditoProveedor", proveedor, montoCents, formaPago, usuario, opts),
    estadoCuentaProveedor: (nombre) => ipcRenderer.invoke("db:estadoCuentaProveedor", nombre),
    cancelarMovimientoPendiente: (id, usuario) => ipcRenderer.invoke("db:cancelarMovimientoPendiente", id, usuario),
    cancelarCuentaProveedor: (nombre, usuario, motivo) => ipcRenderer.invoke("db:cancelarCuentaProveedor", nombre, usuario, motivo),
    getProveedores: () => ipcRenderer.invoke("db:getProveedores"),
    guardarProveedor: (nombre) => ipcRenderer.invoke("db:guardarProveedor", nombre),
    eliminarProveedor: (nombre, usuario) => ipcRenderer.invoke("db:eliminarProveedor", nombre, usuario),
    cancelarMovimientoEfectivo: (movId, usuario) => ipcRenderer.invoke("db:cancelarMovimientoEfectivo", movId, usuario),
    cerrarCaja: (conteoCents, usuario, extras) => ipcRenderer.invoke("db:cerrarCaja", conteoCents, usuario, extras),
    // Inventario
    getInventario: () => ipcRenderer.invoke("db:getInventario"),
    getVentaPorFolio: (folio) => ipcRenderer.invoke("db:getVentaPorFolio", folio),
    cancelarVenta: (folio, usuario, motivo) => ipcRenderer.invoke("db:cancelarVenta", folio, usuario, motivo),
    ventasDelDia: (fecha) => ipcRenderer.invoke("db:ventasDelDia", fecha),
    resumenBasculaCorte: () => ipcRenderer.invoke("db:resumenBasculaCorte"),
    detalleCorteBasculaDia: (fecha) => ipcRenderer.invoke("db:detalleCorteBasculaDia", fecha),
    getImagenesProducto: () => ipcRenderer.invoke("db:getImagenesProducto"),
    setImagenProducto: (id, dataURL) => ipcRenderer.invoke("db:setImagenProducto", id, dataURL),
    getMovimientos: (filtro) => ipcRenderer.invoke("db:getMovimientos", filtro),
    getMovimientosInv: (filtro) => ipcRenderer.invoke("db:getMovimientosInv", filtro),
    exportar: () => ipcRenderer.invoke("db:exportar"),
    importar: () => ipcRenderer.invoke("db:importar"),
    getEsperas: () => ipcRenderer.invoke("db:getEsperas"),
    guardarEspera: (orden) => ipcRenderer.invoke("db:guardarEspera", orden),
    eliminarEspera: (id) => ipcRenderer.invoke("db:eliminarEspera", id),
    getApartados: () => ipcRenderer.invoke("db:getApartados"),
    crearApartado: (data) => ipcRenderer.invoke("db:crearApartado", data),
    abonarApartado: (id, montoCents, metodo, usuario) => ipcRenderer.invoke("db:abonarApartado", id, montoCents, metodo, usuario),
    liquidarApartado: (id, metodo, usuario) => ipcRenderer.invoke("db:liquidarApartado", id, metodo, usuario),
    entregarApartado: (id, entregado) => ipcRenderer.invoke("db:entregarApartado", id, entregado),
    eliminarApartado: (id) => ipcRenderer.invoke("db:eliminarApartado", id),
    marcarEntregado: (folio, entregado) => ipcRenderer.invoke("db:marcarEntregado", folio, entregado),
    actualizarNotaApartado: (folio, nota) => ipcRenderer.invoke("db:actualizarNotaApartado", folio, nota),
    guardarPaquete: (pq) => ipcRenderer.invoke("db:guardarPaquete", pq),
    eliminarPaquete: (id) => ipcRenderer.invoke("db:eliminarPaquete", id),
    movimientoInventario: (productoId, tipo, cant, nota, usuario) => ipcRenderer.invoke("db:movimientoInventario", productoId, tipo, cant, nota, usuario),
    // Configuración
    getConfig: () => ipcRenderer.invoke("db:getConfig"),
    setConfig: (parcial) => ipcRenderer.invoke("db:setConfig", parcial),
    marcarConfigurado: () => ipcRenderer.invoke("db:marcarConfigurado"),
    cortesEleventa: () => ipcRenderer.invoke("db:cortesEleventa")
  },
  eleventa: {
    elegirArchivo: () => ipcRenderer.invoke("eleventa:elegirArchivo"),
    probar: (cfg) => ipcRenderer.invoke("eleventa:probar", cfg),
    analizar: (cfg) => ipcRenderer.invoke("eleventa:analizar", cfg),
    importar: (cfg) => ipcRenderer.invoke("eleventa:importar", cfg),
    importarOperativo: (cfg, opciones) => ipcRenderer.invoke("eleventa:importarOperativo", cfg, opciones)
  },
  bascula: {
    probar: () => ipcRenderer.invoke("bascula:probar"),
    leerAhora: () => ipcRenderer.invoke("bascula:leerAhora"),
    leerVentasTodas: () => ipcRenderer.invoke("bascula:leerVentasTodas"),
    enviarPrecios: (payload) => ipcRenderer.invoke("bascula:enviarPrecios", payload),
    leerProductos: () => ipcRenderer.invoke("bascula:leerProductos"),
    descubrir: () => ipcRenderer.invoke("bascula:descubrir"),
    reintentar: () => ipcRenderer.invoke("bascula:reintentar"),
    reiniciarVistas: () => ipcRenderer.invoke("bascula:reiniciarVistas"),
    marcarVistas: (keys) => ipcRenderer.invoke("bascula:marcarVistas", keys),
    // Eventos empujados desde el proceso principal (poller).
    onLote: (cb) => { const h = (_e, lote) => cb(lote); ipcRenderer.on("bascula:lote", h); return () => ipcRenderer.removeListener("bascula:lote", h); },
    onError: (cb) => { const h = (_e, msg) => cb(msg); ipcRenderer.on("bascula:error", h); return () => ipcRenderer.removeListener("bascula:error", h); },
    onConexion: (cb) => { const h = (_e, info) => cb(info); ipcRenderer.on("bascula:conexion", h); return () => ipcRenderer.removeListener("bascula:conexion", h); }
  },
  printer: {
    imprimir: (ticket) => ipcRenderer.invoke("printer:imprimir", ticket),
    abrirCajon: () => ipcRenderer.invoke("printer:abrirCajon"),
    probar: () => ipcRenderer.invoke("printer:probar"),
    vistaPrevia: (ticket) => ipcRenderer.invoke("printer:vistaPrevia", ticket),
    imprimirCorte: (corte) => ipcRenderer.invoke("printer:imprimirCorte", corte),
    vistaPreviaCorte: (corte) => ipcRenderer.invoke("printer:vistaPreviaCorte", corte),
    imprimirTexto: (titulo, lineas) => ipcRenderer.invoke("printer:imprimirTexto", titulo, lineas),
    vistaPreviaTexto: (titulo, lineas) => ipcRenderer.invoke("printer:vistaPreviaTexto", titulo, lineas),
    imprimirHtml: (html) => ipcRenderer.invoke("printer:imprimirHtml", html),
    esDocumentoHoja: () => ipcRenderer.invoke("printer:esDocumentoHoja"),
    listarImpresoras: () => ipcRenderer.invoke("printer:listarImpresoras")
  },
  backup: {
    estado: () => ipcRenderer.invoke("backup:estado"),
    probar: () => ipcRenderer.invoke("backup:probar"),
    sincronizar: () => ipcRenderer.invoke("backup:sincronizar")
  },
  supabase: {
    estado: () => ipcRenderer.invoke("supabase:estado"),
    probar: () => ipcRenderer.invoke("supabase:probar"),
    sincronizar: (full) => ipcRenderer.invoke("supabase:sincronizar", full),
    bajarAhora: () => ipcRenderer.invoke("supabase:bajarAhora"),
    abrirSchema: () => ipcRenderer.invoke("supabase:abrirSchema"),
    listarTicketsCorte: (filtro) => ipcRenderer.invoke("supabase:listarTicketsCorte", filtro),
    onEnVivo: (cb) => {
      const h = (_e, info) => cb(info);
      ipcRenderer.on("supabase:enVivo", h);
      return () => ipcRenderer.removeListener("supabase:enVivo", h);
    }
  },
  actualizador: {
    estado: () => ipcRenderer.invoke("actualizador:estado"),
    revisar: () => ipcRenderer.invoke("actualizador:revisar"),
    instalar: () => ipcRenderer.invoke("actualizador:instalar"),
    onEstado: (cb) => {
      const h = (_e, info) => cb(info);
      ipcRenderer.on("actualizacion:estado", h);
      return () => ipcRenderer.removeListener("actualizacion:estado", h);
    }
  },
  fx: {
    usdMxn: (force) => ipcRenderer.invoke("fx:usdMxn", force)
  },
  factura: {
    previewVenta: (folio) => ipcRenderer.invoke("factura:previewVenta", folio),
    crear: (data) => ipcRenderer.invoke("factura:crear", data),
    listar: () => ipcRenderer.invoke("factura:listar"),
    timbrar: (id) => ipcRenderer.invoke("factura:timbrar", id),
    enviarCorreo: (id) => ipcRenderer.invoke("factura:enviarCorreo", id),
    enviarWhatsApp: (id) => ipcRenderer.invoke("factura:enviarWhatsApp", id),
    verPdf: (id) => ipcRenderer.invoke("factura:verPdf", id)
  }
});
