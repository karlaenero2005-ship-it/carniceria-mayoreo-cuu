"use strict";

/* ============================================================
   Facturación electrónica CFDI 4.0.

   Aísla la generación del comprobante y el timbrado con el PAC
   (Copynorte). El resto del sistema solo llama a `timbrar(factura, cfg)`.

   - modo "simulacion": genera UUID, XML y PDF de prueba SIN contactar al PAC,
     para poder probar todo el flujo (UI, correo, WhatsApp) de punta a punta.
   - modo "produccion": envía al web service de Copynorte. El formato exacto de
     la petición/respuesta se completa con el kit de integración de Copynorte
     (ver `timbrarCopynorte`). Es el ÚNICO punto que depende del PAC.
   ============================================================ */

const https = require("https");
const http = require("http");
const { URL } = require("url");

const money = (cents) => (Math.round(cents || 0) / 100).toFixed(2);
const nowLocalISO = () => {
  const d = new Date();
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 19); // sin zona, hora local
};

function xmlEscape(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

// Descripción de la tasa/impuesto de un concepto para el XML.
function conceptoImpuestosXML(c) {
  const base = money(c.importeCents);
  if (!c.ivaTasa || c.ivaTasa <= 0) {
    // Tasa 0% (alimentos): Traslado con TasaOCuota 0.000000
    return `<cfdi:Impuestos><cfdi:Traslados>` +
      `<cfdi:Traslado Base="${base}" Impuesto="002" TipoFactor="Tasa" TasaOCuota="0.000000" Importe="0.00"/>` +
      `</cfdi:Traslados></cfdi:Impuestos>`;
  }
  const tasa = Number(c.ivaTasa).toFixed(6);
  return `<cfdi:Impuestos><cfdi:Traslados>` +
    `<cfdi:Traslado Base="${base}" Impuesto="002" TipoFactor="Tasa" TasaOCuota="${tasa}" Importe="${money(c.ivaImporteCents)}"/>` +
    `</cfdi:Traslados></cfdi:Impuestos>`;
}

// Construye un XML CFDI 4.0 representativo (sin sellar). En producción el PAC
// genera/sella el XML definitivo; este sirve para vista previa y simulación.
function construirXML(f, opts) {
  opts = opts || {};
  const conceptos = (f.conceptos || []).map((c) =>
    `<cfdi:Concepto ClaveProdServ="${c.claveProdServ}" Cantidad="${c.cantidad}" ClaveUnidad="${c.claveUnidad}" ` +
    `Unidad="${xmlEscape(c.unidad)}" Descripcion="${xmlEscape(c.descripcion)}" ` +
    `ValorUnitario="${money(c.valorUnitarioCents)}" Importe="${money(c.importeCents)}" ObjetoImp="02">` +
    conceptoImpuestosXML(c) +
    `</cfdi:Concepto>`
  ).join("");

  const traslados = `<cfdi:Traslado Base="${money(f.subtotalCents)}" Impuesto="002" TipoFactor="Tasa" ` +
    `TasaOCuota="0.160000" Importe="${money(f.ivaCents)}"/>`;
  const impuestos = (f.ivaCents || 0) > 0
    ? `<cfdi:Impuestos TotalImpuestosTrasladados="${money(f.ivaCents)}"><cfdi:Traslados>${traslados}</cfdi:Traslados></cfdi:Impuestos>`
    : "";

  const timbre = opts.uuid
    ? `<cfdi:Complemento><tfd:TimbreFiscalDigital xmlns:tfd="http://www.sat.gob.mx/TimbreFiscalDigital" ` +
      `Version="1.1" UUID="${opts.uuid}" FechaTimbrado="${opts.fechaTimbrado || nowLocalISO()}" ` +
      `RfcProvCertif="${opts.rfcPac || "SIMULACION"}"/></cfdi:Complemento>`
    : "";

  return `<?xml version="1.0" encoding="UTF-8"?>` +
    `<cfdi:Comprobante xmlns:cfdi="http://www.sat.gob.mx/cfd/4" Version="4.0" ` +
    `Serie="${xmlEscape(f.serie)}" Folio="${f.folioFactura}" Fecha="${nowLocalISO()}" ` +
    `SubTotal="${money(f.subtotalCents)}" Total="${money(f.totalCents)}" Moneda="MXN" ` +
    `TipoDeComprobante="I" Exportacion="01" MetodoPago="${f.metodoPago}" FormaPago="${f.formaPago}" ` +
    `LugarExpedicion="${xmlEscape(f.emisor.codigoPostal)}">` +
    `<cfdi:Emisor Rfc="${xmlEscape(f.emisor.rfc)}" Nombre="${xmlEscape(f.emisor.razonSocial)}" ` +
    `RegimenFiscal="${xmlEscape(f.emisor.regimenFiscal)}"/>` +
    `<cfdi:Receptor Rfc="${xmlEscape(f.receptor.rfc)}" Nombre="${xmlEscape(f.receptor.nombre)}" ` +
    `DomicilioFiscalReceptor="${xmlEscape(f.receptor.codigoPostal)}" ` +
    `RegimenFiscalReceptor="${xmlEscape(f.receptor.regimenFiscal)}" UsoCFDI="${xmlEscape(f.receptor.usoCfdi)}"/>` +
    `<cfdi:Conceptos>${conceptos}</cfdi:Conceptos>` +
    impuestos +
    timbre +
    `</cfdi:Comprobante>`;
}

/* ---------- PDF simple (representación impresa) ----------
   Genera un PDF mínimo válido de una página con las líneas de texto dadas,
   sin dependencias externas. Sirve para simulación; en producción se usa el
   PDF que devuelve Copynorte. */
function pdfSimple(lineas) {
  const esc = (s) => String(s == null ? "" : s).replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
  let contenido = "BT /F1 10 Tf 50 780 Td 13 TL\n";
  for (const ln of lineas) contenido += `(${esc(ln)}) Tj T*\n`;
  contenido += "ET";
  const objs = [];
  objs.push("<< /Type /Catalog /Pages 2 0 R >>");
  objs.push("<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
  objs.push("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>");
  objs.push("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
  objs.push(`<< /Length ${Buffer.byteLength(contenido, "latin1")} >>\nstream\n${contenido}\nendstream`);

  let pdf = "%PDF-1.4\n";
  const offsets = [];
  objs.forEach((o, i) => {
    offsets.push(Buffer.byteLength(pdf, "latin1"));
    pdf += `${i + 1} 0 obj\n${o}\nendobj\n`;
  });
  const xrefPos = Buffer.byteLength(pdf, "latin1");
  pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  offsets.forEach((off) => { pdf += String(off).padStart(10, "0") + " 00000 n \n"; });
  pdf += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF`;
  return Buffer.from(pdf, "latin1");
}

// PDF legible de la factura (para simulación / respaldo local).
function pdfDeFactura(f, uuid) {
  const L = [];
  L.push(`FACTURA ${f.serie}${f.folioFactura}` + (uuid ? "   (SIMULACION)" : ""));
  L.push("");
  L.push(`Emisor: ${f.emisor.razonSocial}  RFC ${f.emisor.rfc}`);
  L.push(`Regimen ${f.emisor.regimenFiscal}   CP ${f.emisor.codigoPostal}`);
  L.push("");
  L.push(`Receptor: ${f.receptor.nombre}  RFC ${f.receptor.rfc}`);
  L.push(`Uso CFDI ${f.receptor.usoCfdi}   Regimen ${f.receptor.regimenFiscal}   CP ${f.receptor.codigoPostal}`);
  L.push("");
  L.push("Cant  Descripcion                         Importe");
  L.push("------------------------------------------------");
  for (const c of (f.conceptos || [])) {
    const cant = String(c.cantidad).padEnd(5).slice(0, 5);
    const desc = String(c.descripcion).padEnd(34).slice(0, 34);
    L.push(`${cant} ${desc} ${money(c.totalLineaCents).padStart(9)}`);
  }
  L.push("------------------------------------------------");
  L.push(`Subtotal: ${money(f.subtotalCents)}`);
  L.push(`IVA:      ${money(f.ivaCents)}`);
  L.push(`TOTAL:    ${money(f.totalCents)} MXN`);
  L.push("");
  if (uuid) L.push(`Folio fiscal (UUID): ${uuid}`);
  L.push(`Fecha: ${new Date(f.fecha).toLocaleString("es-MX")}`);
  return pdfSimple(L);
}

// UUID v4 (para simulación). En producción lo asigna el SAT/PAC.
function uuidV4() {
  const h = () => Math.floor((1 + Math.random()) * 0x10000).toString(16).slice(1);
  return `${h()}${h()}-${h()}-4${h().slice(1)}-${((8 + Math.floor(Math.random() * 4)).toString(16))}${h().slice(1)}-${h()}${h()}${h()}`.toUpperCase();
}

// Petición HTTP(S) simple con cuerpo JSON. Devuelve { status, body }.
function httpRequest(urlStr, { method = "POST", headers = {}, body = null, timeoutMs = 20000 } = {}) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(urlStr); } catch (e) { return reject(new Error("URL del web service inválida.")); }
    const mod = u.protocol === "http:" ? http : https;
    const req = mod.request(u, { method, headers, timeout: timeoutMs }, (res) => {
      let data = "";
      res.on("data", (ch) => { data += ch; });
      res.on("end", () => resolve({ status: res.statusCode, body: data }));
    });
    req.on("error", reject);
    req.on("timeout", () => { req.destroy(new Error("Tiempo de espera agotado al contactar al PAC.")); });
    if (body) req.write(body);
    req.end();
  });
}

/* ---------- Timbrado real con Copynorte ----------
   PENDIENTE DE KIT: completar el formato exacto de la petición/respuesta con la
   documentación de Copynorte (endpoint, credenciales, campos). La estructura de
   `factura` ya trae todo lo necesario (emisor, receptor, conceptos, totales).
   Se deja una implementación REST/JSON genérica lista para ajustar. */
async function timbrarCopynorte(f, cfg) {
  const ws = (cfg && cfg.ws) || {};
  if (!ws.url) return { error: "Falta configurar el web service de Copynorte (URL) en Configuración → Facturación." };
  if (!ws.usuario || !ws.password) return { error: "Faltan usuario/contraseña del web service de Copynorte." };

  // NOTA: el cuerpo y los headers exactos dependen del kit de Copynorte.
  // Se envía la factura estructurada; ajustar nombres de campos al recibir el kit.
  const payload = JSON.stringify({
    usuario: ws.usuario,
    password: ws.password,
    comprobante: f
  });
  let resp;
  try {
    resp = await httpRequest(ws.url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(payload) },
      body: payload
    });
  } catch (e) {
    return { error: "No se pudo contactar a Copynorte: " + e.message };
  }
  if (resp.status < 200 || resp.status >= 300) {
    return { error: `Copynorte respondió ${resp.status}: ${String(resp.body).slice(0, 300)}` };
  }
  let data;
  try { data = JSON.parse(resp.body); } catch (e) { return { error: "Respuesta del PAC no es JSON válido." }; }
  // Ajustar estos nombres de campos al kit real de Copynorte:
  const uuid = data.uuid || data.UUID || (data.timbre && data.timbre.uuid);
  const xml = data.xml || data.XML || "";
  const pdfB64 = data.pdf || data.PDF || "";
  const liga = data.liga || data.url || data.ligaPublica || "";
  if (!uuid) return { error: "El PAC no devolvió UUID (revisar formato de respuesta / kit de Copynorte)." };
  return {
    ok: true, uuid,
    xml: xml || construirXML(f, { uuid, rfcPac: data.rfcPac }),
    pdfBuffer: pdfB64 ? Buffer.from(pdfB64, "base64") : pdfDeFactura(f, uuid),
    ligaPublica: liga
  };
}

// Timbra una factura. Devuelve { ok, uuid, xml, pdfBuffer, ligaPublica } o { error }.
async function timbrar(f, cfg) {
  cfg = cfg || {};
  if (cfg.modo === "produccion") return timbrarCopynorte(f, cfg);
  // Simulación: no contacta al PAC.
  const uuid = uuidV4();
  const fechaTimbrado = nowLocalISO();
  return {
    ok: true,
    simulado: true,
    uuid,
    fechaTimbrado,
    xml: construirXML(f, { uuid, fechaTimbrado, rfcPac: "SIMULACION" }),
    pdfBuffer: pdfDeFactura(f, uuid),
    ligaPublica: ""
  };
}

module.exports = { construirXML, pdfDeFactura, timbrar };
